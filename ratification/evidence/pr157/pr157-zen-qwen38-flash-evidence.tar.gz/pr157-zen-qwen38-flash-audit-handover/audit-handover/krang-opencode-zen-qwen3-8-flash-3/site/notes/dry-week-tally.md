---
title: "What survived the dry week"
description: "A midsummer tally from three Fernway beds: verbena and chives rode out the dry week, while the salad leaves quit — and why that is worth writing down."
date: "2026-07-15T08:00:00Z"
author: "Tomas Ren"
schema: Article
og:type: article
twitter:card: summary_large_image
---

# What survived the dry week

The week of the 7th was the driest anyone at the library could remember. I walked the borrowed
beds on Saturday with a pencil and counted, and here is the honest tally for anyone planning
next summer's shelf.

What made it: verbena, chives, the borlotto beans that sent roots sideways, and every plant
started under the grange's old vines. What quit: all three salad-leaf packets, two of the four
cucumber hills, and anything in a pot smaller than a bucket.

The lesson the volunteers keep repeating at the counter: shade is a seed you can't lend, but
you can borrow a bed with it. If you have one shady square, take the lettuce packet in May
instead of July and it will beat mine by a month.

One oddity worth saving for next year — the dry-week beans set pods on stems we'd sworn were
done. I dried those seeds separately and labeled the envelope "dry week 2026". If that line
of beans is drought-hardy, it belongs on the shelf, not in my pantry.
