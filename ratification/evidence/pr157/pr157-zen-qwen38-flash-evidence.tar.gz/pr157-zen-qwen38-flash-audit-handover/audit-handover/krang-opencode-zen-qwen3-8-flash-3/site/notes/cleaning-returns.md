---
title: "Cleaning and labeling returns"
description: "Everything arrives in a shoebox eventually: how to dry, thresh and label returned seed so the autumn shelf opens with packets growers can trust."
date: "2026-10-05T14:00:00Z"
author: "Bea Oduya"
schema: Article
og:type: article
twitter:card: summary_large_image
---

# Cleaning and labeling returns

The returns are the best and messiest week of the year. Everything arrives eventually — in
envelopes, jam jars, an occasional shoebox — and the shelf reopens in February only if we
clean it all properly first. This is the method one of us will demonstrate at the autumn swap.

Dry the seed on the plant as long as you can, then once more on a plate for a week before it
goes into an envelope. Chaff keeps packets honest-looking and empty. If you can't tell the
seed from the chaff, you haven't finished; rub it between your palms and blow sideways, not
downward.

Label like the grower you wish had labeled for you:

- crop and variety — "mammoth sunflower," not "big yellow one";
- where it grew and the year, in numbers: Fernway Lane, 2026;
- how many seeds were lent, and how many came back. That last line is how the library knows
  which varieties thrive here.

Count the return against the loan before you seal the envelope. If you borrowed four packets
and saved from two, write that too — a partial return, honestly marked, beats a mystery jar
on the shelf. See you at the swap.
