---
title: "Broad beans before the beans think of it"
description: "Sow beans the week the soil warms, not the week the calendar says: what the 2026 spring sowing day taught us at the grange hall."
date: "2026-04-08T09:30:00Z"
lastmod: "2026-04-10T16:00:00Z"
author: "Rosa Ilves"
schema: Article
og:type: article
twitter:card: summary_large_image
---

# Broad beans before the beans think of it

We spent sowing morning filling envelopes of Scarlet Runner for the Wednesday shelf, and half
the room insisted on waiting until the "safe" date at the end of April. The soil under the
grange hall was already moving — the worms had been editing it all winter — and the beds that
went in the first week were three full inches ahead of the rest by the middle of May.

Three things I would tell anyone borrowing a bean packet now:

- Press the seed two knuckles deep, not one. Shallow beans dry out; the deep ones find water
  on their own.
- Soak overnight only what you sow tomorrow. Soaked seed that misses its day sulks.
- Write the sowing date *on* the envelope in pencil, not on your phone. The envelope is where
  the note lives when someone else inherits the bed.

The beans do not read the calendar. They read the soil. Borrow early, and forgive yourself
a cold week.
