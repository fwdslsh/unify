# Fernway Seed Library — handover report

Built with `./unify` (v0.11.18). Source: `site/` plus generator `scripts/gen.mjs`,
configured by `unify.yaml`. Published output: `dist/`, correct for
`https://fernway.example/library/` with no `.html` in any visitor address.

## 1. Publish command

```
./unify build --clean
```

The address-dependent options live in `unify.yaml`, which makes the bare build
correct *for that address* and gates publishing on the strict audit
(`audit: true`, `strict: true`):

```yaml
# saved flags for unify build/audit/dev/watch; a command-line flag wins over this file
base-url: https://fernway.example/library/
pretty-urls: true
generate: scripts/gen.mjs
audit: true
strict: true
```

`clean` is deliberately **not** in the config: a saved `clean: true` makes
`unify audit` refuse to run ("unify audit does not take --clean: audit never
writes"), so it belongs on the publish command line only.

## 2. Final output of every check

All four ran against the finished site; every one exits 0 and reports nothing.

`./unify build --dry-run --strict` — the whole build, every check, writes nothing:

```
gen.mjs: wrote notes/index.html from 3 post(s)
audit: nothing to report
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 6 pages would gain a JSON-LD block
copy dist/assets/seed-card.svg (/library/assets/seed-card.svg) ← assets/seed-card.svg
copy dist/assets/style.css (/library/assets/style.css) ← assets/style.css
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/2026-03-02-ordering-the-spring-seed-boxes/index.html (/library/notes/2026-03-02-ordering-the-spring-seed-boxes/) ← notes/2026-03-02-ordering-the-spring-seed-boxes.md + _layout.html
write dist/notes/2026-06-28-ten-tomatoes-one-very-dry-july/index.html (/library/notes/2026-06-28-ten-tomatoes-one-very-dry-july/) ← notes/2026-06-28-ten-tomatoes-one-very-dry-july.md + _layout.html
write dist/notes/2026-10-11-returning-seed-at-the-autumn-table/index.html (/library/notes/2026-10-11-returning-seed-at-the-autumn-table/) ← notes/2026-10-11-returning-seed-at-the-autumn-table.md + _layout.html
write dist/notes/index.html (/library/notes/) ← generated + _layout.html
copy dist/robots.txt (/library/robots.txt) ← robots.txt
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 11 files to dist/
```

`./unify audit --strict` — the findings alone, advisories and `incomplete`
findings counted as problems:

```
gen.mjs: wrote notes/index.html from 3 post(s)
audit: nothing to report
```

`./unify audit --strict --external` — the non-blocking off-origin URL check:

```
gen.mjs: wrote notes/index.html from 3 post(s)
audit: nothing to report
```

(The site emits no off-origin `http(s)` URLs — every link is same-origin or
`mailto:` — so nothing was fetched and nothing failed.)

`./unify build --clean` — the publish itself (its `audit: true`/`strict: true`
gate ran the audit before writing):

```
gen.mjs: wrote notes/index.html from 3 post(s)
audit: nothing to report
```

Exit code 0; `dist/` is the complete site.

## 3. What rules.md did not answer

**The generator's calling contract.** rules.md says only "unify runs it before
every build and it writes into the directory unify hands it." The sentence I
wanted and could not find: *"unify hands the script, in argv, the source root,
the overlay directory, and a context file naming `source-pages.json` — files
written into the overlay join the build as ordinary pages."* I found that
contract only in a comment inside `scripts/gen.mjs` of the `unify init blog`
scaffold, which cites a "conformance-spec §33.2" rules.md never mentions.

**The audit command itself.** rules.md never names `unify audit`, its finding
classes (`broken`, `incomplete`, advisories), `--strict`, or `--external`. The
sentence I wanted — *"these are every checks the tool offers and how to run
them"* — is simply absent; `--help` and the scaffold's README/DEPLOY had it.

**That the generator runs for `audit` too.** rules.md says "before every
build." The scaffold comment says "before every build, dev rebuild and audit."
I learned it the hard way: a debug file my probe script wrote, that I deleted,
came back after a plain `audit`.

**Which saved config keys each command accepts.** Nothing says that a config
carrying `clean: true` breaks `unify audit` with exit 2. I discovered it by
being rejected.

**Nested overlay pages.** Whether a generated `notes/index.html` (a directory
index made by the script, not `--pretty-urls`) satisfies a hand-written `/notes/`
directory link — implied by "a page like any other once it is in the overlay"
(a scaffold comment, not rules.md), confirmed by probe.

## What I had to re-read

**The "Files" bullet** of rules.md. It packs link rules, `--pretty-urls`
behavior, and the directory-link condition into one ~90-word run-on: "This
stays true under `--pretty-urls`: you still write `/about.html` … A directory
link you write yourself (`/guides/`) builds only when the output has a
`guides/index.html` — one you wrote, or one `--pretty-urls` made from
`guides.html`." It did not land first time because my nav links `/notes/` by
hand while the index page exists only as generator output — whether that counts
as "one you wrote" is exactly the case the sentence does not separate. It sent
me back to "derived files (a post index)" two paragraphs above.

**The og-defaults sentence** in the Head section: "og:title/og:description/
og:url default to final title/description/canonical; page-head declarations
win over derived values, which win over layout fallbacks. No missing value or
Twitter tag is invented." It did not land first time because the scaffold's
example post frontmatter *does* spell out `og:title:` and `og:description:`,
and the sentence never says so — my first instinct was to copy that into every
post. Re-reading the "default to final title/description/canonical" clause
made it redundant: values derived from the same title/description I already
declare, leaving only `og:type: article` worth writing (which the posts do).
It mattered because the whole share-card requirement rides on derivation I
had not yet seen proven.

**The date rules.** "a `date:` with no time is reported and left out rather
than guessed at" (feed, first paragraph) versus the schema paragraph's
accepted `2026-01-02` form. One read mixes these up: a date-only post is fine
for JSON-LD but *reported* for the feed — and the coordinator rejects any
report. Hence every post date carries a full `…T09:30:00Z`-style timestamp.

## Guessed or inferred, not read

- That "every check the tool offers" = the build's composition checks + `unify
  audit` (all severities, with `--strict`) + `unify audit --external`, and that
  `--format json|sarif` are renderings of the same audit rather than separate
  checks. `unify dev`'s `/_unify/` page is a browser view of the same findings
  and unreachable here (no browser), so the three CLI runs above stand in for it.
- That `mailto:` links and the `https://schema.org` `@context` inside
  unify-generated JSON-LD are not "off-origin URLs the site emits" for
  `--external`; the clean run is evidence, not a sentence I read.
- That hand-writing `<meta name="twitter:card" content="summary_large_image">`
  in the layout is the sanctioned move — rules.md only says unify itself never
  invents a Twitter tag.
- That `--canonical auto` is the default when `--base-url` is set: rules.md
  offers "`--canonical auto`" as an option; "(the default with --base-url)"
  is help text only. I relied on it — every page's canonical in `dist/` is
  absolute and correct.
- That `og:image:width/height` must match the real image and that no check
  will catch the mismatch (a scaffold warning, not a rules.md one): the
  declared 1200×630 is exactly the shipped SVG's size.
- All site facts (address, hours, volunteers, notes content) are invented —
  the brief asks for a plausible site; rules.md forbids unify guessing
  metadata, so every machine-readable field is traceable to what a page
  declares. The one image is a placeholder SVG, as instructed.
