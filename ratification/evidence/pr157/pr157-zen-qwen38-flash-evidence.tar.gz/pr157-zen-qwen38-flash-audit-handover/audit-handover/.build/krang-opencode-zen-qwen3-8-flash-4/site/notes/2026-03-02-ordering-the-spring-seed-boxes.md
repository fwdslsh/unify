---
title: Ordering the spring seed boxes
description: How the volunteers put this year's seed boxes together, what went on each shelf, and what to look for when you borrow early.
date: 2026-03-02T08:30:00Z
author: Marta Bell
schema: BlogPosting
og:type: article
---

# Ordering the spring seed boxes

The boxes arrived on Tuesday and filled the whole potting bench: forty-one kinds of
vegetable and eleven of flower, most of them seed we returned last autumn.

We shelved them the way the old catalogue had it, with the early sowings to the left —
broad beans, onions, leeks, the three cabbages — and the tender things to the right,
waiting until the ground warms. If you borrow early, look for the blue labels. Those are
the packets that need a cool start and a cool head: sow them now, and you will be
glad in May.

Runner beans came back strongest, which says the plots along the ditch were kind to
them. We are short on spinach this year and do not have beetroot at all; if you saved
either last season, the returning table will want to hear from you.
