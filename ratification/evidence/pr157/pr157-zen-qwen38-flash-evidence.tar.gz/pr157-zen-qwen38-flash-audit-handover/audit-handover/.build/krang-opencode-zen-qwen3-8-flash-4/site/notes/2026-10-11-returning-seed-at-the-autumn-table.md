---
title: Returning seed at the autumn table
description: A short guide to what the returning table takes, how to dry and label seed before you bring it, and what happens on the shelves in October.
date: 2026-10-11T10:00:00Z
author: Priya Raman
schema: BlogPosting
og:type: article
---

# Returning seed at the autumn table

The returning table is open Saturdays in October and the first Sunday of November, in
the glass shed. Bring seed dry — a week on a kitchen windowsill beats a rushed
afternoon on a radiator — and loose is fine: an envelope, a jam jar, anything clean.

Label with three things, and write them large: the kind, the year, and the plot
it came from. "Courgette, 2026, allotment 12" tells the whole story. If you can,
tuck your growing note in the same envelope, even one line: *late, but heavy*.
The next borrower gets the note with the seed, and that trade of notes is the
best part of this place.

We sort everything on the table that afternoon, count it into the ledger, and
the seed is shelved the following Saturday. This year we opened with nineteen
envelopes of beans before a single courgette came in. Thank you, everyone who
saved twice what you borrowed.
