---
title: "Ten tomatoes, one very dry July: what the beds remembered"
description: The summer trial compared ten tomato kinds through a dry July, and the climbing beans came up and shaded out two whole rows.
date: 2026-06-28T16:45:00Z
author: Owen Hartley
schema: BlogPosting
og:type: article
---

# Ten tomatoes, one very dry July: what the beds remembered

We put ten tomato kinds down the long bed in May and let July do its worst.
Watering is a two-bucket chore here, so the point of the trial was honesty: which
kinds keep fruiting when the bed goes dry between waterings.

The small red cherry kinds won, as they always seem to. Gardener's Delight and
Tiny Tim both set fruit through the worst week; the two big beefsteaks dropped
almost every truss. Write it down plainly: if you want tomatoes in a dry July,
borrow the cherries.

Two other notes from the same bed. The climbing beans we sowed too close to the
fence came up and shaded out rows three and four by the end of the month — sow them
on their own canes this far from the fence. And the marigolds along the path, from
seed returned twice now, have gotten taller and later than the ones we bought,
flowering well into September.
