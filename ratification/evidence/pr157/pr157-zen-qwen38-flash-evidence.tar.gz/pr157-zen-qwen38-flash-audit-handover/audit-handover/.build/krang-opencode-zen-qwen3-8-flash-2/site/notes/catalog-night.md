---
title: "Catalog night: sorting this year's packets"
description: "Thirty kinds of donated seed, one long table, and the labels that make a shelf usable. Notes from the winter sort."
date: 2026-02-14T10:15:00Z
author: Rosa Almqvist
schema: Article
class: notes
og:type: article
og:title: "Catalog night: sorting this year's packets"
---

# Catalog night: sorting this year's packets

We spent the first Saturday of February at the long table in the shed, going through
everything the growers donated last autumn and everything the seed swap brought in.
Thirty-one kinds of vegetable, nine flowers, and one jar of unidentified beans that
will get a trial patch this spring.

## What we did

- Counted every envelope and wrote the number of usable seed on the catalogue card.
  Anything under twenty went to the growing-out bin instead of the shelf.
- Split the big donations. The Charenton melon came in as a coffee tin from two
  different plots; it is now two labelled packets, because seed from different
  parents is not the same variety, however it arrived.
- Retired the old index cards and started the new one, alphabet by crop, then by
  the month you should sow it.

## What I learned

Labels do the work. A packet that says "beans, purple" is a guess; a packet that
says "bean, Royal Purple Climber, saved 2025, plot 14" is a record. From this
season we staple the return slip to the packet and keep the slip when the seed
comes back, so the shelf carries its own history.

The shed was open until six and half of us stayed for soup. If you want to join
the next sort, [come along on an open afternoon](/visit.html) and ask at the desk.
