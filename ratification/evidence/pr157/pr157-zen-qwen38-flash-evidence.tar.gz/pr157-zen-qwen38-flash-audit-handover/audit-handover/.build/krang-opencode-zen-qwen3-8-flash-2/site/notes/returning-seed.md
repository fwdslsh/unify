---
title: "Returning seed: dry, clean, label"
description: "Returns are coming through the hatch. What good returned seed looks like, and the three things to do before you drop yours in."
date: 2026-09-19T16:20:00Z
author: Ida Okafor
schema: Article
class: notes
og:type: article
og:title: "Returning seed: dry, clean, label"
---

# Returning seed: dry, clean, label

The hatch behind the shed door is rattling full already. This is the note I wish
growers had in their pocket when they pick up a spring packet, so from now on we
print it on the back of the return slip.

## Three things before you return

1. **Dry.** Seed you can bend is seed that will rot in an envelope. A week on a
   plate indoors, or two dry days outdoors under a screen, beats any trick.
2. **Clean.** No pods, no chaff, no soil. You do not need a sieve — a cup and a
   breath over the rim will lift most of what a seed wants rid of.
3. **Label.** Crop, variety if you know it, your plot or street, and the year.
   That is a record. Anything else is a rumor.

## On the weight

We ask for the packet's weight back, not a harvest. Ten tomato seeds from a good
vine are a fine return for a ten-seed packet; two hundred from the same vine are
a gift to the whole shelf, and they go into next spring's growing-out bin to
multiply again.

If the plant did badly, say so on the slip anyway — a bad year for a good variety
is worth knowing about, and someone will want to try it again in a better bed.
The [hours on the Visit page](/visit.html) cover the desk; the hatch takes returns
whenever the yard gate is open.
