# Handover report — Fernway Seed Library

## 1. Publishing the site

Run from this directory (the project root, where `site/`, `scripts/` and `unify.yaml` live):

```
./unify build --clean
```

`unify.yaml` carries `base-url: https://fernway.example/library/`, `pretty-urls: true`
and `generate: scripts/gen.mjs`, so this one command publishes the complete site to
`dist/` for that address. The equivalent fully explicit form is
`./unify build --clean --base-url https://fernway.example/library/ --pretty-urls`.
Exit 0 means `dist/` is the complete site; non-zero means nothing was published.
(The only published `.html` file is `404.html`, which hosts map as the error page;
every visitor-facing address ends in `/`.)

## 2. Every check, final output

These are the checks the tool offers — the build's own checks via `--dry-run`, the
audit (the checks that do not block a plain build) in its three strict variants, and
the publish-gated build. All four were run after the last source change; outputs are
verbatim, exit codes noted.

### `./unify build --dry-run --strict` — exit 0

```
gen.mjs: wrote notes.html from 3 post(s)
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 6 pages would gain a JSON-LD block
write dist/404.html (/library/404.html) ← 404.html (no layout)
copy dist/assets/seed.svg (/library/assets/seed.svg) ← assets/seed.svg
copy dist/assets/share-card.svg (/library/assets/share-card.svg) ← assets/share-card.svg
copy dist/assets/style.css (/library/assets/style.css) ← assets/style.css
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/catalog-night/index.html (/library/notes/catalog-night/) ← notes/catalog-night.md + _layout.html
write dist/notes/index.html (/library/notes/) ← generated + _layout.html
write dist/notes/may-beds/index.html (/library/notes/may-beds/) ← notes/may-beds.md + _layout.html
write dist/notes/returning-seed/index.html (/library/notes/returning-seed/) ← notes/returning-seed.md + _layout.html
copy dist/robots.txt (/library/robots.txt) ← robots.txt
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 13 files to dist/
```

### `./unify audit --strict` — exit 0

```
gen.mjs: wrote notes.html from 3 post(s)
audit: nothing to report
```

### `./unify audit --strict --external` — exit 0

```
gen.mjs: wrote notes.html from 3 post(s)
audit: nothing to report
```

### `./unify build --audit --strict` — exit 0

```
gen.mjs: wrote notes.html from 3 post(s)
audit: nothing to report
```

## 3. What `rules.md` did not answer

- **`unify audit` is never mentioned in rules.md.** The sentence I wanted: "the
  non-blocking checks live in `unify audit`; run `unify audit --strict` (and
  `--external`) — advisories and `incomplete` findings only count under `--strict`."
  rules.md documents only `build --dry-run --strict`. I found the audit command in
  `./unify --help`, and the handover framing (dry-run / audit / build --audit, all
  `--strict`) in the README and DEPLOY notes that `./unify init` scaffolds.
- **How a generate script is handed things.** rules.md says the script "writes into
  the directory unify hands it" — the sentence I wanted is the one I never found
  there: "unify runs it as `node <script> <source-root> <overlay-dir>
  <generator-context.json>`, and that context names `source-pages.json`." The script's whole
  interface (argv positions, the context file, the inventory's fields —
  `source`, `href`, `title`, `description`, `date`, `meta[]`, `links[]`) is not in
  rules.md; I read it out of the `blog` template's `scripts/gen.mjs` (which names
  conformance-spec sections §33.2/§33.7 that rules.md doesn't reproduce), and I
  dumped the actual `generator-context.json` and `source-pages.json` with a throwaway
  script to confirm the shapes before writing mine.
- **`clean: true` in `unify.yaml` breaks `unify audit`** — audit exits 2 telling me
  "audit does not take --clean". Nothing in rules.md or the scaffold docs warns that
  a saved build option is rejected by another command; I moved `--clean` onto the
  publish command line.
- Minor gaps I had to fill from `--help`: `--save-config`, `--feed-full`,
  `--catalog`, `--search-corpus`, `--format sarif`.

## 4. What I had to re-read, and why it did not land the first time

- **The Files paragraph's link rules.** The sentence "Always link the real filename —
  `/about.html`, not `/about/`. This stays true under `--pretty-urls`" made me think
  directory links and page links were the same rule; re-reading it I saw they are
  two different promises: links I *write* get rewritten to pretty form, while a
  directory link *I* write (`/notes/`) only builds if an `index.html` genuinely
  exists at that output path. The dense prose (one paragraph, four mechanisms, and
  the `--base-url` sentence attached to all of them) is why it didn't land; I then
  verified the real behavior with a probe build rather than trusting the reread.
- **The merging rules around `<footer>`.** "A bare `<header>`/`<footer>` does not
  replace the layout's — only `slot=` fills, and it fills the *contents*" read at
  first like `slot=` swaps whole elements; the second pass, while writing the layout,
  was where "write `<p slot=\"footer\">`, or you ship a footer inside a footer"
  actually registered. The two rules (named slot replaces the slot tag; a footer fill
  replaces contents, not the wrapper) sit three sentences apart and contradict each
  other until you notice which kind of slot each is about.
- **The two date sentences.** Line 6 says a feed "reports and leaves out" a `date:`
  with no time; line 54 says JSON-LD accepts `2026-01-02` as a date. Re-read side by
  side, they are about different consumers, not contradictory. To keep *every* check
  silent I used full `2026-02-14T10:15:00Z` timestamps in all posts.

## 5. What I guessed at, or inferred rather than read

- That `unify init` had a `blog` template. rules.md never lists built-ins; the help
  said "a built-in name", and `unify init blog` happened to ship exactly the
  generator + post example the rules referred to. I copied its *interface* (argv,
  inventory, escaping, newest-first sort with a tie-break by href) rather than
  inventing one.
- That `href="assets/style.css"` relative inside `_layout.html` is rewritten per
  page depth — rules.md only says unify rewrites `href`/`src`; the claim that a
  layout's *relative* path resolves correctly for a page two folders deep comes from
  a template comment. Confirmed in `dist/notes/may-beds/index.html` afterwards.
- That an `.md` post's inventory `href` is `/notes/<name>.html` (the `.md` is not
  its address). Inferred from the probe's generated listing; it built and audited
  clean, which then *checks* the generated links too.
- That `audit --external` counts XML namespaces in `feed.xml`/`sitemap.xml`
  (schema.org, Atom, sitemaps.org) as vocabulary, not off-origin fetches — inferred
  from it exiting 0 in a sandbox with no network use; every other URL the site
  emits is `https://fernway.example/...` or a `mailto:`.
- That `404.html` should ship standalone (`data-layout="none"`, `noindex`) — rules.md
  says nothing about error pages; the template's scaffold does it this way and the
  probe's sitemap confirmed `noindex` keeps a page out of the sitemap.
- The library's *facts*: street, hours, names, prose. The brief supplies none, so
  they are invented but self-consistent, kept on the reserved `fernway.example`
  domain so nothing points at a real third party, and the share image and seed mark
  are placeholder SVGs written for this site, as the brief required.
- That a share card should also carry `twitter:card`. rules.md says unify invents no
  Twitter tags; I wrote the meta into the layout myself — an inference about crawlers,
  not a read rule.
