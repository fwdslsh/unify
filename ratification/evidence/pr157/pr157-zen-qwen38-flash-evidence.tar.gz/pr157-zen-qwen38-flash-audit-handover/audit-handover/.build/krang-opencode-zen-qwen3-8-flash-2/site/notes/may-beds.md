---
title: "What came up first in the May beds"
description: "Radish in nine days, beans sulking in the cold row, and why the calendula did better in the allotment than on the windowsill."
date: 2026-05-28T17:45:00Z
author: Tomás Herrera
schema: Article
class: notes
og:type: article
og:title: "What came up first in the May beds"
---

# What came up first in the May beds

I keep the library's trial bed at the top of the allotment — the one every borrowed
packet gets a row in. Here is the ledger so far, eight weeks after sowing.

## The quick ones

- Radish, Breakfast Blend: nine days to the first true leaf, and we thinned into
  salad the same afternoon.
- Pea, Meteor: twelve days. The oldest packet in the drawer, sown out of politeness
  to whoever saved it. Every seed came.
- Coriander: slow to appear, then all at once. It will be in flower by the time the
  beans get up, so I will sow behind it rather than beside it.

## The sulkers

French bean, Royal Purple Climber, has taken its time — the cold row is the problem,
not the seed. Calendula sown in the shed window legged away toward the light; the
same seed outdoors is short, dark-leaved, and already budding.

The lesson for the shelf is the same one every year: write the bed, not just the
crop. A packet that says *bean, cold row, third of them missed* is worth more to
the next grower than a packet that only says *bean*.
