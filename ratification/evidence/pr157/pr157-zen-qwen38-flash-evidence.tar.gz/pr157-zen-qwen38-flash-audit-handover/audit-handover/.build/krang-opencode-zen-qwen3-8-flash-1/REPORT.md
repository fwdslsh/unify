# Fernway Seed Library — handover report

## 1. The publish command

Run from this directory; `base-url: https://fernway.example/library/`,
`pretty-urls: true` and `generate: scripts/gen.mjs` come from `unify.yaml`,
so the whole publish is one line:

```
./unify build --audit --strict
```

(`./unify build` alone publishes too; the extra flags make the build refuse to
write `dist/` unless `unify audit --strict` is clean. Exit 0 means `dist/` is
the complete site; non-zero means nothing was published.)

## 2. Final output of every check run

Every check the tool offers was run, including the ones that do not block a
build (advisories and `incomplete` findings, via `--strict`, and the
off-origin fetch pass, via `--external`). All four exit 0; nothing is reported.

### `./unify build --dry-run --strict`

```
$ ./unify build --dry-run --strict
gen.mjs: wrote notes.html from 3 note(s)
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 6 pages would gain a JSON-LD block
copy dist/assets/seed-card.svg (/library/assets/seed-card.svg) ← assets/seed-card.svg
copy dist/assets/style.css (/library/assets/style.css) ← assets/style.css
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/broad-beans-checkpoint/index.html (/library/notes/broad-beans-checkpoint/) ← notes/broad-beans-checkpoint.md + _layout.html
write dist/notes/index.html (/library/notes/) ← generated + _layout.html
write dist/notes/saving-tomato-seed/index.html (/library/notes/saving-tomato-seed/) ← notes/saving-tomato-seed.md + _layout.html
write dist/notes/sweet-peas-under-glass/index.html (/library/notes/sweet-peas-under-glass/) ← notes/sweet-peas-under-glass.md + _layout.html
copy dist/robots.txt (/library/robots.txt) ← robots.txt
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 11 files to dist/
exit: 0
```

### `./unify audit --strict`

```
$ ./unify audit --strict
gen.mjs: wrote notes.html from 3 note(s)
audit: nothing to report
exit: 0
```

### `./unify audit --strict --external`

```
$ ./unify audit --strict --external
gen.mjs: wrote notes.html from 3 note(s)
audit: nothing to report
exit: 0
```

### `./unify build --audit --strict` (the publish itself)

```
$ ./unify build --audit --strict
gen.mjs: wrote notes.html from 3 note(s)
audit: nothing to report
exit: 0
```

## 3. Honest answers

**What `rules.md` did not answer — the sentence I wanted and could not find.**
The generate script. Line 6 says only "it writes into the directory unify
hands it" — the sentence that never appears is *what exactly unify hands it*:
the script's `argv` contract (`argv[2]` source root, `argv[3]` fresh overlay
directory whose files join the build as ordinary pages, `argv[4]`
`generator-context.json`, which names `source-pages.json`) exists only in the
comments of `scripts/gen.mjs` inside the `blog` template, reachable via
`unify init blog`, not in `rules.md`. The shape of `source-pages.json` itself
(fields `source`, `href`, `title`, `description`, `date`, `meta`, and that
`href` stays the authored `/notes/x.html` form so the build rewrites it) I had
to learn by running a probe build and dumping the file. Related sentences that
also don't appear: that `unify audit` exists as its own command with
`--strict`/`--external`, and that an advisory is what a day-only `date:` earns
a page ("this page is not in feed.xml").

**What I had to re-read, and why it didn't land the first time.** The two
date rules. Line 6 says a `date:` with no time "is reported and left out" and
line 54 says a date unify can read as `2026-01-02` is accepted — which looks
like a contradiction. On re-reading, they are different sentences about
different machines: the first is about `feed.xml` entries, the second about
JSON-LD, and a bare day is fine for one and a reported omission for the other.
I read them as one rule about "dates" and could not reconcile them until I
watched the advisory fire on a probe page. The merging bullet ("A bare
`<header>`/`<footer>` does not replace the layout's — only `slot=` fills, and
it fills the *contents*: … write `<p slot="footer">`") also needed a second
pass: it states both "the element replaces the slot" and "it fills the
contents" in one breath, and which happens depends on whether the layout wraps
its slot in its own element.

**What I guessed at or inferred rather than read.**

- That the overlay `notes.html` and the source directory `site/notes/` would
  coexist — the listing becoming `/library/notes/` and posts
  `/library/notes/<slug>/` — with no rule about name collisions between an
  overlay page and a source folder. Verified by inspecting `dist/`, not by
  reading.
- That `--base-url` in `unify.yaml` also applies to `audit`/`--dry-run`, from
  one comment line in the scaffolded `unify.yaml` ("saved flags for build,
  audit, dev and watch") — `rules.md` never says the config covers checks.
- That relative links inside the generated page (`p.href`) get the base prefix
  and pretty rewrite like any other link, because the template says an overlay
  file "is a page like any other" — inferred, not stated for generated links.
- That `--external` ignores `mailto:` (it "reports the ones that don't
  resolve" among off-origin URLs; a `mailto:` was reported neither way).
- Every fact on the site — the mews address, the Tuesday-to-Saturday hours,
  the three volunteers and their dates — is invented content the brief asked
  for, not read from anywhere.
- That an SVG is an acceptable `og:image` despite real crawlers preferring
  raster: the brief says write a placeholder SVG wherever an image is needed,
  so I matched the declared `og:image:width/height` (1200×630) to the file's
  own `width`/`height` attributes and moved on.

## 4. What is where

- `site/_layout.html` — shared head (title suffix, `og:` seed-card image,
  `schema: WebPage`, feed alternate), header with inline seed-mark SVG, nav
  via `<include>`, footer with shared byline.
- `site/index.html` (Home), `site/visit.html` (Visit — where, hours, how
  borrowing works), `site/notes/*.md` (three dated volunteer notes, frontmatter
  only, `schema: Article` → unify writes each page's JSON-LD: headline,
  description, date, author).
- `scripts/gen.mjs` + `unify.yaml` — `notes.html`, the index of every note,
  newest first, derived on every build from unify's own source-page inventory.
- `site/assets/style.css` (hand-written, no external fonts, no `url()`),
  `site/assets/seed-card.svg` (the share-card image), `site/robots.txt`.
- `dist/` — the published site: served at `https://fernway.example/library/`,
  no address ends in `.html`, every share card (image/title/description) and
  canonical is absolute at that address; nothing in `dist/` loads from another
  website.
