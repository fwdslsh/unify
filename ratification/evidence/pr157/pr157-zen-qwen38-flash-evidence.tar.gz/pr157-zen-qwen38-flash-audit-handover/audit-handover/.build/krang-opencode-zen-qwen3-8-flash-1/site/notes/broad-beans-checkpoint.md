---
title: "Broad beans hit the checkpoint"
description: "Mid-June at the Mews beds: the wet March did less damage than we feared, and the long pods are counting themselves out."
date: "2026-06-14T08:00:00Z"
author: "Otty Fenn"
schema: Article
class: notes
og:type: article
og:title: "Broad beans hit the checkpoint"
og:description: "Mid-June at the Mews beds: the wet March did less damage than we feared, and the long pods are counting themselves out."
---

# Broad beans hit the checkpoint

*By Otty Fenn — 14 June 2026*

Everyone wrote the March off — three inches of rain in the week the beans went in, and the
bed looked like a pond for a fortnight. The beans disagreed. Nearly every sown row came up,
and by the second week of June the first flowers at the base of the stems are telling us the
plant has stopped making leaf and started making dinner. That is the checkpoint: from here on
the top shoots are for the pan, not for the seed card.

Two notes for anyone who borrowed the Longwich Green packets:

1. Pinch the tops once those bottom flowers open. It stops the blackfly the lane gardens all
   seem to grow by July.
2. Water once, deeply, if the dry stretches past ten days. Beans drawn up short will pod
   thin and you will think it was the March. It was not the March.

We are saving seed from the earliest six plants only, and those six get a peg and a date on
the card so next spring's shelf can say where the stockline came from.
