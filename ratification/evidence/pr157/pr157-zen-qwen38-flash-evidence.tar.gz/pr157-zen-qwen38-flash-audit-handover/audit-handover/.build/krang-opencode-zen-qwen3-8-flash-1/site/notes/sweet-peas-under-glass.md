---
title: "Sweet peas under glass before the freeze"
description: "What the last week of January is for at the shelf: sweet peas sown in the greenhouse bench, and why we start them cold."
date: "2026-01-10T09:15:00Z"
author: "Ben Alder"
schema: Article
class: notes
og:type: article
og:title: "Sweet peas under glass before the freeze"
og:description: "What the last week of January is for at the shelf: sweet peas sown in the greenhouse bench, and why we start them cold."
---

# Sweet peas under glass before the freeze

*By Ben Alder — 10 January 2026*

The January packet on our shelf is always the same: Spencer sweet peas, sown now rather
than in spring. Ben fills the modules on the cold bench in the greenhouse — no heat, just
the glass and the frost going through the soil once or twice, which they seem to want.

Two things worth writing down for whoever borrows them:

- Soak the seed overnight before it goes in. The January ones took nine days to break;
  the soaked ones were up in five.
- Do not let them get pot-bound thinking they are tomatoes. They sulk harder than anything
  else on the bench, and a rooted module of four is worth more in April than a crowded
  tray of forty.

We have eleven packets left of the grey-seeded mix from the Henderson garden, the one that
smelled strongest in the evening. If you take two, write which one flowered first on the
card.
