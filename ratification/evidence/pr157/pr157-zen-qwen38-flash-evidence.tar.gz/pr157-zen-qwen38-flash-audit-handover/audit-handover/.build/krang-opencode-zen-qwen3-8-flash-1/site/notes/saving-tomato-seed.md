---
title: "Saving tomato seed before the heat breaks"
description: "Ferment, rinse, dry — the shelf's method for the late August returns, written up by the volunteer who runs the seed table."
date: "2026-08-02T18:30:00Z"
author: "Marguerite Clay"
schema: Article
class: notes
og:type: article
og:title: "Saving tomato seed before the heat breaks"
og:description: "Ferment, rinse, dry — the shelf's method for the late August returns, written up by the volunteer who runs the seed table."
---

# Saving tomato seed before the heat breaks

*By Marguerite Clay — 2 August 2026*

The August returns are the ones that teach people. A tomato is not a packet you empty; it
is three days of work on the seed table, and the weather decides whether you get there.
This is the method we want on every returned jar, so that whoever opens it next spring can
trust it.

Scoop the seed and its jelly into a jar with an inch of water and leave it on the shelf in
the shade — not the sun, or you will cook what you meant to save. Two days, sometimes three:
you are looking for a skin on the water and the seed sinking. Then pour through a sieve,
rinse until the water runs clean, and dry on a plate, never on paper towel, spreading the
seed so it dries single-grain. One week of dry air and it keeps.

The Marmalade Ripener came back from four households this year, which is the best news in
the ledger. Keep the jar lid on tight and write the year inside the label, not on it — the
outdoor writing fades by the time the shelf needs it.
