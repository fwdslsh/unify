# Fernway Seed Library — build report

## Publish command

```
./unify build --clean
```

The saved options in `unify.yaml` carry the address-sensitive flags, so the bare
command is the whole publish:

```yaml
generate: scripts/gen.mjs
pretty-urls: true
base-url: https://fernway.example/library/
```

(Equivalent one-liner: `./unify build --clean --generate scripts/gen.mjs --pretty-urls --base-url https://fernway.example/library/`.)
It exits 0 and publishes 11 files to `dist/`, served at
`https://fernway.example/library/` with no `.html` in visitor addresses.

## Checks run (final state)

`unify audit` — the non-blocking check set, on its own:

```
$ ./unify audit
audit: nothing to report
exit=0
```

`unify audit --strict` — advisories and `incomplete` findings count too:

```
$ ./unify audit --strict
audit: nothing to report
exit=0
```

`unify audit --external --strict` — every off-origin URL the site emits is
fetched; the site emits none (only `schema.org` inside JSON-LD and the SVG
namespace, neither fetched), and nothing failed:

```
$ ./unify audit --external --strict
audit: nothing to report
exit=0
```

The whole build plus every check in one pass, writing nothing:

```
$ ./unify build --dry-run --strict
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 3 pages would gain a JSON-LD block
copy dist/assets/seed-card.svg (/library/assets/seed-card.svg) ← assets/seed-card.svg
copy dist/assets/seed-mark.svg (/library/assets/seed-mark.svg) ← assets/seed-mark.svg
copy dist/assets/style.css (/library/assets/style.css) ← assets/style.css
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/2026-04-05-spring-inventory/index.html (/library/notes/2026-04-05-spring-inventory/) ← notes/2026-04-05-spring-inventory.md + _layout.html
write dist/notes/2026-07-14-midsummer-sowing/index.html (/library/notes/2026-07-14-midsummer-sowing/) ← notes/2026-07-14-midsummer-sowing.md + _layout.html
write dist/notes/2026-09-26-seed-swap/index.html (/library/notes/2026-09-26-seed-swap/) ← notes/2026-09-26-seed-swap.md + _layout.html
write dist/notes/index.html (/library/notes/) ← generated + _layout.html
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 11 files to dist/
exit=0
```

Everything the brief demands was confirmed in `dist/`: absolute `og:image`
(+width/height), `og:title`/`og:description`/`og:url` and `canonical` on every
post; a generated `BlogPosting` JSON-LD block (headline, description, url,
image, author, datePublished) with no hand-written JSON; an Atom `feed.xml`;
the generated `/notes/` index lists all three posts newest-first.

## What `rules.md` did not answer

The sentence I wanted and could not find, in so many words: **"the generate
script is run with argv = [source root, the generated overlay directory, the
path of a context JSON file whose `inputs.sourcePages` points at the page
inventory]."** `rules.md` says only that the script "writes into the directory
unify hands it, never into `site/`" — it never names that directory, never says
how the script learns it, and never explains the overlay's relationship to the
source root. I found it by making a probe script print `process.argv` and the
context file. Two more gaps: it never says the generated overlay files are
*composed* like source pages (layout applied, links rewritten, broken links
checked) — only that they "write into" a directory; the fact is visible solely
in the `← generated + _layout.html` dry-run line. And it does not enumerate the
audit's checks — I learned that `og:image` without `og:image:width`/`og:image:height`
is an `image-missing-dimensions` advisory only when `unify audit` reported it.

## What I re-read, and why it did not land

- **`--base-url`** ("the site's whole address, never a bare path — prefixes
  every link and makes `og:`/`canonical` absolute for share crawlers"). It did
  not land because on first reading I registered "absolute URLs" as a nicety,
  not the mechanism; I had begun planning a hand-written `sitemap.xml` and a
  feed script before re-reading and seeing that `--base-url` alone generates
  `sitemap.xml`, and — with `schema:` declared — `feed.xml`. That feed sentence
  sits at the very end of the dense opening paragraph; I read past it twice.
- **The filename-vs-directory-link pair of rules**: "Always link the real
  filename — `/about.html`, not `/about/`. This stays true under
  `--pretty-urls`" next to "A directory link you write yourself (`/guides/`)
  builds only when the output has a `guides/index.html`." They look
  contradictory at a glance; I re-read to work out that `/notes/` in the nav is
  legal only because the generator emits `notes/index.html`, while post links
  must be written `/notes/x.html` and the build rewrites them.
- **"A canonical still has no frontmatter key … (that stamps every page with
  the same URL), so write that page in HTML, use `--canonical auto`, or leave it
  off."** The parenthetical warning reads like it forbids auto-canonical for a
  section; it does not — it forbids putting a canonical in a *layout*. I had to
  read it again to see `--canonical auto` (default with `--base-url`) was
  exactly the intended answer for generated pages.

## What I guessed at or inferred rather than read

- That "at least three dated posts in Markdown, written by volunteers who do
  not write HTML" means plain body markdown with only meaningful frontmatter;
  I chose to omit `title:` and let the first `# Heading` supply it ("No
  `title:` → first `# Heading` is documented; using it so the same string flows
  into og/JSON-LD/feed is my inference).
- Dates with times (`2026-09-26T16:00:00Z`): the date format rules are
  documented, but I *inferred* that feeding a time into the feed's `<updated>`
  and JSON-LD `datePublished` is what "a `date:` with no time is reported and
  left out" is steering me toward; exact output key names I read from `dist/`,
  not from `rules.md`.
- That every `_*` exclusion default plus "the source root is `site/`" means
  `scripts/` (beside `site/`) is never published — reasonable, but rules.md only
  guarantees it for underscore-prefixed things; `--extends`/init output showed
  the `generate: scripts/gen.mjs` example "relative to this file" (unify.yaml),
  which I trusted.
- The argv/context protocol itself, the shape of `source-pages.json`
  (`pages[].source/href/title/description/date/meta[]`) — read off a probe
  build's output, not documented in rules.md.
- That `--external` with zero off-origin URLs reports nothing rather than
  complaining it checked none — confirmed by running it, inferred before.
- "Every check the tool offers" — rules.md never enumerates the checks; I
  inferred the set from `--help`: `audit` (broken + incomplete), `--strict`
  (advisories), `--external`, and `build --dry-run --strict` as the
  everything-in-one-pass form.
- I also guessed `twitter:card` belongs as a plain `<meta name=…>` in the
  layout (rules.md promises Twitter tags are "not invented", so adding it
  myself seemed wanted, not required); nothing in the docs or audit checks it.

One misstep worth recording: `unify init nope` (probing for built-in templates)
silently fetched an npm package called `nope` from the network; irrelevant to
the site, and deleted.
