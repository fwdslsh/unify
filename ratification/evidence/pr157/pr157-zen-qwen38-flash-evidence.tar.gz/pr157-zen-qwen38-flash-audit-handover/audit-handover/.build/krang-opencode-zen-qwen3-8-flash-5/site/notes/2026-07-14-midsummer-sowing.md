---
date: 2026-07-14T09:30:00Z
author: Theo Vance
description: A second sowing list for July, plus why your tomatoes want less attention, not more, in the heat.
schema: BlogPosting
class: notes
og:image: /assets/seed-card.svg
og:image:width: 1200
og:image:height: 630
---

# Midsummer: What to Sow Now and What to Leave Alone

July is not a dead month at all, if you plan it right. You can still sow:

- Buckwheat, to feed the soil before autumn
- Salad rocket, in the shade of the taller rows
- Winter radish, the big French variety on the middle shelf

And a word on tomatoes: stop feeding them. In this heat, more water and more
food give you leaves instead of fruit. Water deeply once a week and let the
plants hunt.

If you took bean packets in May, now is the time to start drying the pods for
the swap. Seeds want a week of shade-drying, never sun.
