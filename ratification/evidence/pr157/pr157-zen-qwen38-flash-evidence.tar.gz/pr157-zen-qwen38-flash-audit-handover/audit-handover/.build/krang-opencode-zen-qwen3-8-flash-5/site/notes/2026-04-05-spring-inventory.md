---
date: 2026-04-05T08:00:00Z
author: Priya Raman
description: Forty-one new varieties joined the shelf this spring, and the lentil drawer needs a label. A season-opening report from the sorting table.
schema: BlogPosting
class: notes
og:image: /assets/seed-card.svg
og:image:width: 1200
og:image:height: 630
---

# Spring Shelf Inventory Is Done

Six of us spent the rainy Saturday at the sorting table, and the shelf is the
best it has ever looked. Forty-one new varieties came in from last season's
returns, including the climbing sunflower everyone asked about at the swap.

One small favor: the lentil drawer has lost its label. If you borrowed lentils
this winter, tell us which kind they were so we can write it back.

Remember the rule we print on every card: borrow five packets, return a
spoonful of your own seed in autumn. New to the library? The
[home page](/index.html) explains how it works, and the
[Visit page](/visit.html) has the hours.
