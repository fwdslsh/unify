import { mkdirSync, readFileSync, writeFileSync } from "node:fs";

const [, , , overlayDir, contextPath] = process.argv;
const context = JSON.parse(readFileSync(contextPath, "utf8"));
const { pages } = JSON.parse(readFileSync(context.inputs.sourcePages, "utf8"));

const posts = pages
  .filter((p) => p.source.startsWith("notes/") && p.source.endsWith(".md"))
  .sort((a, b) => (b.date || "").localeCompare(a.date || ""));

const esc = (s) =>
  String(s ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");

const monthNames = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

const prettyDate = (iso) => {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || "");
  if (!m) return "";
  return `${Number(m[3])} ${monthNames[Number(m[2]) - 1]} ${m[1]}`;
};

const metaOf = (page, name) =>
  (page.meta || []).find((entry) => entry.name === name)?.content;

const items = posts
  .map((p) => {
    const author = metaOf(p, "author");
    return [
      "      <li>",
      `        <a href="${esc(p.href)}">${esc(p.title)}</a>`,
      `        <span class="post-date">${esc(prettyDate(p.date))}${author ? ` · ${esc(author)}` : ""}</span>`,
      `        <p>${esc(p.description)}</p>`,
      "      </li>",
    ].join("\n");
  })
  .join("\n");

const page = [
  "<!doctype html>",
  '<html lang="en">',
  "  <head>",
  '    <meta charset="utf-8" />',
  "    <title>Notes</title>",
  '    <meta name="description" content="Field notes from the volunteers of the Fernway Seed Library." />',
  "  </head>",
  '  <body class="notes">',
  "    <main>",
  "      <h1>Notes from the shelf</h1>",
  "      <p>Field notes written by the volunteers who sort, lend, and return our seed — newest first.</p>",
  '      <ul class="post-list">',
  items,
  "      </ul>",
  "    </main>",
  "  </body>",
  "</html>",
  "",
].join("\n");

mkdirSync(`${overlayDir}/notes`, { recursive: true });
writeFileSync(`${overlayDir}/notes/index.html`, page);
