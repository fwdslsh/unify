# Ratification round pr157-zen-qwen38-flash-audit-handover

- **unify** 0.11.18 at `98dfd174e09b` (working tree)
- **rules** `fb07d931bd36` · **prompt** `456131468750` · **agent** opencode 1.18.25 · **models** krang/opencode-zen/qwen3.8-flash · **isolation** mount namespace, probe clean
- 2026-11-08T22:58:25.802Z to 2026-11-08T23:07:41.756Z; scored 2026-11-08T23:07:41.757Z

## Score

**4 of 5 samples completed their brief: every scored check passed (80%).**

The protocol's bar, at least 4 of 5 samples of a model on each brief: **met**.

| Brief | Model | Passed | Checks that failed |
|---|---|---|---|
| audit-handover | krang/opencode-zen/qwen3.8-flash | 4/5 | publish-command (1), strict-build (1), fresh-build (1), addresses (1), audit-strict (1), article-data (1), share-cards (1) |

## audit-handover — Hand over only when every check the tool offers reports nothing

*round 28; checks follow its pre-registered V1-V4, plus the brief's extensionless addresses.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | audit-strict | article-data | share-cards | ran-audit | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 6m54s | 51 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | 6m47s | 53 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-3 | 5m28s | 39 | $0.00 | ✓ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✓ (i) | fail |
| krang-opencode-zen-qwen3-8-flash-4 | 8m16s | 52 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-5 | 5m18s | 57 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |

- krang-opencode-zen-qwen3-8-flash-1 · **ran-audit** (not scored): 6 runs matching /unify audit/
- krang-opencode-zen-qwen3-8-flash-2 · **ran-audit** (not scored): 7 runs matching /unify audit/
- krang-opencode-zen-qwen3-8-flash-3 · **publish-command**: no fenced `unify build` or resolvable npm run command found
- krang-opencode-zen-qwen3-8-flash-3 · **strict-build**: no fenced `unify build` or resolvable npm run command found
- krang-opencode-zen-qwen3-8-flash-3 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-3 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **audit-strict**: no publish command
- krang-opencode-zen-qwen3-8-flash-3 · **article-data**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **share-cards**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **ran-audit** (not scored): 3 runs matching /unify audit/
- krang-opencode-zen-qwen3-8-flash-4 · **ran-audit** (not scored): 7 runs matching /unify audit/
- krang-opencode-zen-qwen3-8-flash-5 · **ran-audit** (not scored): 7 runs matching /unify audit/

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> **What `rules.md` did not answer — the sentence I wanted and could not find.**
> The generate script. Line 6 says only "it writes into the directory unify
> hands it" — the sentence that never appears is *what exactly unify hands it*:
> the script's `argv` contract (`argv[2]` source root, `argv[3]` fresh overlay
> directory whose files join the build as ordinary pages, `argv[4]`
> `generator-context.json`, which names `source-pages.json`) exists only in the
> comments of `scripts/gen.mjs` inside the `blog` template, reachable via
> `unify init blog`, not in `rules.md`. The shape of `source-pages.json` itself
> (fields `source`, `href`, `title`, `description`, `date`, `meta`, and that
> `href` stays the authored `/notes/x.html` form so the build rewrites it) I had
> to learn by running a probe build and dumping the file. Related sentences that
> also don't appear: that `unify audit` exists as its own command with

**krang-opencode-zen-qwen3-8-flash-2**

> ## 3. What `rules.md` did not answer
> 
> - **`unify audit` is never mentioned in rules.md.** The sentence I wanted: "the
>   non-blocking checks live in `unify audit`; run `unify audit --strict` (and
>   `--external`) — advisories and `incomplete` findings only count under `--strict`."
>   rules.md documents only `build --dry-run --strict`. I found the audit command in
>   `./unify --help`, and the handover framing (dry-run / audit / build --audit, all
>   `--strict`) in the README and DEPLOY notes that `./unify init` scaffolds.
> - **How a generate script is handed things.** rules.md says the script "writes into
>   the directory unify hands it" — the sentence I wanted is the one I never found
>   there: "unify runs it as `node <script> <source-root> <overlay-dir>
>   <generator-context.json>`, and that context names `source-pages.json`." The script's whole

**krang-opencode-zen-qwen3-8-flash-3**

> **What `rules.md` did not answer — the sentence I wanted.** The one sentence
> I looked for and could not find: how the generate script is *handed* that
> directory and the page list. The rules say the script "writes into the
> directory unify hands it" and that `--source-inventory` "give[s] that file
> source-pages.json", but never *how* — no argv, env, or cwd contract anywhere.
> I got the real contract (`argv[2]` source root, `argv[3]` a throwaway overlay
> directory, `argv[4]` a `generator-context.json` naming the inventory) only by
> scaffolding `unify init blog` in a scratch folder and reading the template's
> `scripts/gen.mjs`, then by writing a dump script and printing the JSON.
> Sentences I also wanted and did not find: "overlay pages join the build as
> ordinary pages" (do generated pages get the layout and link rewriting? — not
> stated in rules.md); and any list of what `unify audit` checks — I learned its

**krang-opencode-zen-qwen3-8-flash-4**

> ## 3. What rules.md did not answer
> 
> **The generator's calling contract.** rules.md says only "unify runs it before
> every build and it writes into the directory unify hands it." The sentence I
> wanted and could not find: *"unify hands the script, in argv, the source root,
> the overlay directory, and a context file naming `source-pages.json` — files
> written into the overlay join the build as ordinary pages."* I found that
> contract only in a comment inside `scripts/gen.mjs` of the `unify init blog`
> scaffold, which cites a "conformance-spec §33.2" rules.md never mentions.
> 
> **The audit command itself.** rules.md never names `unify audit`, its finding
> classes (`broken`, `incomplete`, advisories), `--strict`, or `--external`. The

**krang-opencode-zen-qwen3-8-flash-5**

> ## What `rules.md` did not answer
> 
> The sentence I wanted and could not find, in so many words: **"the generate
> script is run with argv = [source root, the generated overlay directory, the
> path of a context JSON file whose `inputs.sourcePages` points at the page
> inventory]."** `rules.md` says only that the script "writes into the directory
> unify hands it, never into `site/`" — it never names that directory, never says
> how the script learns it, and never explains the overlay's relationship to the
> source root. I found it by making a probe script print `process.argv` and the
> context file. Two more gaps: it never says the generated overlay files are
> *composed* like source pages (layout applied, links rewritten, broken links
> checked) — only that they "write into" a directory; the fact is visible solely


---

`✓` passed, `✗` failed, `(i)` reported but not scored. Each sample's directory is `<brief>/<sample>/`, its OpenCode event stream and session data are in `<brief>/.harness/<sample>/`, and the build the checks read is `<brief>/.build/<sample>/`. Triage every failure with ratification/ratification-protocol.md before changing anything.
