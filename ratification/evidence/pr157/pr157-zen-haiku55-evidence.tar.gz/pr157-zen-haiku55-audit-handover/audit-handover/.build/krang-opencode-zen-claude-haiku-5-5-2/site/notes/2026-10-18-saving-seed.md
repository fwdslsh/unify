---
title: "Saving seed at season's end"
description: "Which plants to leave for seed, how to dry them, and how to label each packet."
date: 2026-10-18T09:00:00Z
author: "Mei Lin"
lang: en
schema: BlogPosting
og:image: /assets/card.svg
---

# Saving seed at season's end

Seed saving starts with choosing the healthiest plants, not the first to ripen. Leave a few of the best ones to go fully to seed.

## Drying

Dry seed heads on a tray indoors, out of direct sun, until the seed rattles.

## Labelling

Write the variety, the year, and the growing site on every packet before you return it.
