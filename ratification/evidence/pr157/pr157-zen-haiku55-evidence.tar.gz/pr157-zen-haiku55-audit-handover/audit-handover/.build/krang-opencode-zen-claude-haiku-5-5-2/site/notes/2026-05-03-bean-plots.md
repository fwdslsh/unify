---
title: "Bean plots in the community garden"
description: "How the shared bean plots were sown, staked, and watered in May."
date: 2026-05-03T09:00:00Z
author: "Tom Okafor"
lang: en
schema: BlogPosting
og:image: /assets/card.svg
---

# Bean plots in the community garden

The shared plots went in on the first warm weekend of May. We sowed borlotti and runner beans in two rows.

## Staking

Runner beans climb. Set canes before sowing so the roots are not disturbed later.

## Watering

Water at the base in the morning. Wet leaves in the evening invite mildew.
