---
title: "Starting tomatoes indoors"
description: "Sowing dates, pots, and light for the first tomato seedlings of the year."
date: 2026-02-14T09:00:00Z
author: "Ana Reyes"
lang: en
schema: BlogPosting
og:image: /assets/card.svg
---

# Starting tomatoes indoors

Our first sowing day is the middle of February. We use small pots, a propagator lid, and a bright windowsill that gets sun from the south.

## Pots and soil

Use clean pots and a seed compost that is fine and free of lumps. Sow shallow, then cover lightly.

## Light

Seedlings stretch quickly on a dim sill. Move them under a lamp as soon as the first true leaves appear.
