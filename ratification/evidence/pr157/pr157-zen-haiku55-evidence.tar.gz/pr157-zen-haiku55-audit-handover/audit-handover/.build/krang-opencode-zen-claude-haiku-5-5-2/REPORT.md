# REPORT — Fernway Seed Library site

## 1. Publish command

```bash
./unify build --clean --audit --strict --pretty-urls --base-url https://fernway.example/library/ --canonical auto
```

Output of that command (exit 0, `dist/` published):

```
notes index: 3 posts
audit: nothing to report
```

## 2. Checks

Every check the tool offers was run against the same flags as the publish command.

### 2a. Strict dry run (whole build plus every check, writes nothing)

Command:

```bash
./unify build --dry-run --strict --pretty-urls --base-url https://fernway.example/library/ --canonical auto --clean
```

Output:

```
notes index: 3 posts
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 3 pages would gain a JSON-LD block
copy dist/assets/card.svg (/library/assets/card.svg) ← assets/card.svg
copy dist/assets/seed.svg (/library/assets/seed.svg) ← assets/seed.svg
copy dist/assets/site.css (/library/assets/site.css) ← assets/site.css
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/2026-02-14-starting-tomatoes/index.html (/library/notes/2026-02-14-starting-tomatoes/) ← notes/2026-02-14-starting-tomatoes.md + _layout.html
write dist/notes/2026-05-03-bean-plots/index.html (/library/notes/2026-05-03-bean-plots/) ← notes/2026-05-03-bean-plots.md + _layout.html
write dist/notes/2026-10-18-saving-seed/index.html (/library/notes/2026-10-18-saving-seed/) ← notes/2026-10-18-saving-seed.md + _layout.html
write dist/notes/index.html (/library/notes/) ← generated + _layout.html
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 11 files to dist/
```

Exit code: 0. No advisories.

### 2b. Audit, strict (default human format)

Command:

```bash
./unify audit --strict --pretty-urls --base-url https://fernway.example/library/
```

Output:

```
notes index: 3 posts
audit: nothing to report
```

Exit code: 0.

### 2c. Audit, strict, with external link check

Command:

```bash
./unify audit --strict --external --pretty-urls --base-url https://fernway.example/library/
```

Output:

```
notes index: 3 posts
audit: nothing to report
```

Exit code: 0. (I did not confirm whether the sandbox had network access for the external fetches; the output is what the tool reported.)

### 2d. Audit, strict, JSON format

Command:

```bash
./unify audit --strict --format json --pretty-urls --base-url https://fernway.example/library/
```

Output (the `pages` array, roughly 400 lines describing each page's head and body, is elided here; the summary and findings are shown in full):

```
notes index: 3 posts
{
  "schemaVersion": 1,
  "baseUrl": "https://fernway.example/library/",
  "summary": {
    "broken": 0,
    "incomplete": 0,
    "problems": 0,
    "advisories": 0
  },
  "pages": [ ...elided... ],
  "findings": []
}
```

Exit code: 0.

### 2e. Audit, strict, SARIF format

Command:

```bash
./unify audit --strict --format sarif --pretty-urls --base-url https://fernway.example/library/
```

Output:

```
notes index: 3 posts
{
  "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json",
  "version": "2.1.0",
  "runs": [
    {
      "tool": {
        "driver": {
          "name": "unify",
          "informationUri": "https://github.com/fwdslsh/unify#readme",
          "version": "0.11.18",
          "rules": []
        }
      },
      "results": []
    }
  ]
}
```

Exit code: 0.

### 2f. Publish with audit gate (the real build)

Command: the publish command in section 1. Output and exit code are shown there (exit 0).

## 3. Answers

**What did `rules.md` not answer?**
- The sentence I wanted: "unify runs the generate script with these arguments: the source root, the overlay directory it must write into, and the path of a `generator-context.json`." `rules.md` says the script "writes into the directory unify hands it", but never says how that directory is handed over. I found it by writing a probe script that dumped `process.argv`.
- The sentence I wanted: "`--strict` makes advisories and `incomplete` audit findings fail the exit code; `broken` findings always do." `rules.md` mentions `--strict` only in the dry-run line. The meaning comes from `--help`.
- The sentence I wanted: a list of audit rule IDs and what each requires (for example `h1-missing` and `image-missing-dimensions`). `rules.md` does not name the checks. I learned them by running `audit`.
- The sentence I wanted: "a Markdown post needs a `# Heading` in its body, not only a `title:` key, to pass audit." The rules say a missing `title:` falls back to the first `# Heading`, but not that the audit requires one.
- The sentence I wanted: "a share image should declare `og:image:width` and `og:image:height`." Only the audit reports this.

**What did I have to re-read, and why did it not land the first time?**
- The generate-script paragraph. I read it once and assumed the overlay directory would be passed in a predictable way. It was not specified, so I probed for it. My first attempt to find it inside the binary with `grep` returned noise.
- I wrote the Markdown post dates as plain `2026-02-14` (as the rules show in examples) and got three advisories. The dry run then said a date with no time is left out of `feed.xml`. I should have read the date rule before writing it.
- I initially put the generator under `site/_scripts/` instead of the top-level `scripts/`. The rules name `scripts/` beside the site, and I corrected it.
- I had to re-run the audit after each fix. I did not read the full list of checks beforehand, so the fixes came one audit at a time.

**What did I guess at or infer rather than read?**
- The argument order of the generate script (source, overlay, context), inferred from the probe output.
- That the `generator-context.json` schema is stable. I did not use it; I read only the paths.
- That `og:image` in the layout plus per-post `og:image` is harmless. The output is correct, but I inferred the duplication is fine.
- That SVG is acceptable for a share card. The brief required an SVG placeholder, and the rules do not say whether crawlers accept it. Some social platforms reject SVG for `og:image` and will show no preview. This is a real risk I did not verify (no browser or crawler is available).
- That the JSON-LD output is correct for search engines. I read the generated block but did not validate it against a schema.
- That the external-link check made real network requests. The tool reported nothing, and I did not confirm the network path.
- That the feed's `<updated>` value (the newest post) is the desired site-wide update time.
