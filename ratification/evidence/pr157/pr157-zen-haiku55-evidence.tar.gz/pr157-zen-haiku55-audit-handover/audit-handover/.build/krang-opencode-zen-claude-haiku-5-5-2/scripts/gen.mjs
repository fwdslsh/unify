// Writes notes/index.html (newest first) into the overlay directory unify hands us.
import fs from 'fs';
import path from 'path';

const [, , sourceRoot, overlayRoot] = process.argv;
const notesDir = path.join(sourceRoot, 'notes');

function frontmatter(text) {
  const m = text.match(/^---\n([\s\S]*?)\n---\n/);
  const out = {};
  if (!m) return out;
  for (const line of m[1].split('\n')) {
    const kv = line.match(/^([A-Za-z:_-]+):\s*(.*)$/);
    if (kv) out[kv[1]] = kv[2].replace(/^"(.*)"$/, '$1');
  }
  return out;
}

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const posts = fs.readdirSync(notesDir)
  .filter((f) => f.endsWith('.md') && f !== 'index.md')
  .map((f) => {
    const fm = frontmatter(fs.readFileSync(path.join(notesDir, f), 'utf8'));
    return { file: f.replace(/\.md$/, '.html'), title: fm.title, description: fm.description, date: fm.date, author: fm.author };
  })
  .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));

const items = posts.map((p) => `    <li>
      <h2><a href="/notes/${esc(p.file)}">${esc(p.title)}</a></h2>
      <p><time datetime="${esc(p.date)}">${esc(p.date.slice(0, 10))}</time> by ${esc(p.author)}</p>
      <p>${esc(p.description)}</p>
    </li>`).join('\n');

const html = `<!doctype html>
<html lang="en" data-layout="/_layout.html">
<head>
<title>Notes</title>
<meta name="description" content="Dated notes from Fernway volunteers on sowing, growing, and saving seed.">
</head>
<body class="notes">
<main>
  <h1>Notes</h1>
  <ul class="post-list">
${items}
  </ul>
</main>
</body>
</html>
`;

const outDir = path.join(overlayRoot, 'notes');
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, 'index.html'), html);
console.log(`notes index: ${posts.length} posts`);
