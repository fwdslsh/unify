// Writes the notes index into the overlay directory unify hands us.
// Arguments: <sourceRoot> <overlayDir> <contextJson>
import fs from 'node:fs';
import path from 'node:path';

const [, overlay, contextPath] = process.argv.slice(2);
const context = JSON.parse(fs.readFileSync(contextPath, 'utf8'));
const inventory = JSON.parse(fs.readFileSync(context.inputs.sourcePages, 'utf8'));

const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const posts = inventory.pages
  .filter((p) => p.source.startsWith('notes/') && p.source !== 'notes/index.html' && p.date)
  .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));

const items = posts.map((p) => `<li>
<p class="post-meta"><time datetime="${esc(p.date)}">${esc(p.date)}</time></p>
<h2><a href="${esc(p.href)}">${esc(p.title)}</a></h2>
<p>${esc(p.description)}</p>
</li>`).join('\n');

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Notes</title>
<meta name="description" content="Dated notes from volunteers at the Fernway Seed Library, newest first.">
</head>
<body>
<main>
<h1>Notes</h1>
<ul class="post-list">
${items}
</ul>
</main>
</body>
</html>
`;

const outDir = path.join(overlay, 'notes');
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, 'index.html'), html);
console.log(`notes index: ${posts.length} posts`);
