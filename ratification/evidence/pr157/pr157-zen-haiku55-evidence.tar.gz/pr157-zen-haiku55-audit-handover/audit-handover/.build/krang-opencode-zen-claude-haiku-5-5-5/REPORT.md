# Fernway Seed Library: build report

## Publish command

```
./unify build --clean --generate _scripts/gen.mjs --base-url https://fernway.example/library/ --pretty-urls --audit
```

Output: `dist/` (11 files). Exit 0, `audit: nothing to report`.

## Checks

Every check the tool offers was run. All exit 0 with nothing to report.

### 1. Dry-run with every check (`--strict`)

Command:

```
./unify build --dry-run --strict --base-url https://fernway.example/library/ --pretty-urls --generate _scripts/gen.mjs --exclude '_*'
```

```
notes index: 3 posts
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 3 pages would gain a JSON-LD block
copy dist/assets/card.svg (/library/assets/card.svg) ← assets/card.svg
copy dist/assets/mark.svg (/library/assets/mark.svg) ← assets/mark.svg
copy dist/assets/site.css (/library/assets/site.css) ← assets/site.css
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/2026-03-14-first-sowing/index.html (/library/notes/2026-03-14-first-sowing/) ← notes/2026-03-14-first-sowing.md + _layout.html
write dist/notes/2026-06-02-midsummer-check/index.html (/library/notes/2026-06-02-midsummer-check/) ← notes/2026-06-02-midsummer-check.md + _layout.html
write dist/notes/2026-10-01-seed-return/index.html (/library/notes/2026-10-01-seed-return/) ← notes/2026-10-01-seed-return.md + _layout.html
write dist/notes/index.html (/library/notes/) ← generated + _layout.html
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 11 files to dist/
```

### 2. Audit, default human output (`--strict`)

Command:

```
./unify audit --base-url https://fernway.example/library/ --pretty-urls --generate _scripts/gen.mjs --strict
```

```
notes index: 3 posts
audit: nothing to report
```

### 3. Audit, JSON format

Command:

```
./unify audit --base-url https://fernway.example/library/ --pretty-urls --generate _scripts/gen.mjs --strict --format json
```

Summary and findings (full document also contains the per-page head/body breakdown):

```
{"summary":{"broken":0,"incomplete":0,"problems":0,"advisories":0},"findings":[]}
```

### 4. Audit, SARIF format

Command:

```
./unify audit --base-url https://fernway.example/library/ --pretty-urls --generate _scripts/gen.mjs --strict --format sarif
```

```
notes index: 3 posts
{
  "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json",
  "version": "2.1.0",
  "runs": [
    {
      "tool": {
        "driver": {
          "name": "unify",
          "informationUri": "https://github.com/fwdslsh/unify#readme",
          "version": "0.11.18",
          "rules": []
        }
      },
      "results": []
    }
  ]
}
```

### 5. Audit with external link check

Command:

```
./unify audit --base-url https://fernway.example/library/ --pretty-urls --generate _scripts/gen.mjs --strict --external
```

```
notes index: 3 posts
audit: nothing to report
```

### Earlier findings, fixed

- `date` without a time (`2026-03-14`) was an advisory and left the posts out of `feed.xml`. Fixed by writing `2026-03-14T09:00:00Z` etc.
- `image-missing-dimensions` (incomplete) on all three posts. Fixed by adding `og:image:width: 1200` and `og:image:height: 630`.

## Verification of the published address

- Canonical, `og:url`, `og:image`, sitemap, and feed entries are all absolute under `https://fernway.example/library/`.
- Every internal `href`/`src` carries `/library/`. No link ends in `.html`.
- Each post has a `BlogPosting` JSON-LD block with headline, description, url, image, author, datePublished, and inLanguage.

## Honest answers

**What did `rules.md` not answer? Name the sentence you wanted.**
The sentence I wanted: "A generator is run as `<script> <sourceRoot> <overlayDir> <contextJson>`, and its `--generate` path is resolved from the source root." `rules.md` says only "unify runs it before every build and it writes into the directory unify hands it" and puts scripts in `scripts/` "beside the site". The first `--generate scripts/gen.mjs` failed because it resolved from the source root, not the project root. The argument order and the context file (which holds `inputs.sourcePages`) appear only in the generator's own behavior and `--help`, not in `rules.md`. The docs also never list the checks by name, so I took them from `--help` (`audit`, `--strict`, `--format`, `--external`, `--dry-run`).

**What went wrong during the work?**
- A probe script was first written to `/tmp/probe`, outside the working directory; a permission rule blocked it, so I moved the probe into the working directory and removed it afterward. Nothing was left behind.
- A `sed` edit to the three post front matter joined lines together (`cardog:image:width...`). I fixed them with exact edits and re-ran the audit.
- A `cd` in a shell call was also blocked; I used `workdir` for later commands.

**What did I have to re-read, and why did it not land the first time?**
The `Files` section and the `--generate` option. I first read "scripts/ beside the site", placed the script in the project root, and the build failed. I re-read `--help` and then probed the generator's arguments. The "source root" and "beside the site" wording point to different places, and I did not connect them the first time.

**What did I guess at or infer rather than read?**
- The times `09:00:00Z` on the post dates. `rules.md` requires a time and says not to invent one from the clock, so I chose a fixed time. This is a guess about publication time.
- The notes index is generated by my script, which I inferred from the `source-pages.json` shape, not from any documented schema beyond what the probe printed.
- The `og:image` is an SVG card. Some share crawlers do not render SVG images; a PNG would be safer, but the brief asked for SVG placeholders.
- The JSON-LD `headline` includes the site-name suffix (`... — Fernway Seed Library`), because unify takes the full page title. I did not find a documented way to set a bare headline without writing my own JSON-LD block, which Markdown pages cannot contain. I left it as generated.
- The visit address, opening hours, and seed-borrowing steps are placeholder content I wrote. The brief did not supply real details.
