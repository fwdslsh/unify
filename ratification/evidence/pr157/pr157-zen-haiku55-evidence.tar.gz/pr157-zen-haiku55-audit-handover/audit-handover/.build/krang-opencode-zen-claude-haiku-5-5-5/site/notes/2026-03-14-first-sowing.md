---
title: "First sowing: what we lent in March"
description: "The first seed packets went out this month. Here is what growers borrowed and what to watch for."
date: 2026-03-14T09:00:00Z
author: Maria Ortega
schema: BlogPosting
og:image: /assets/card.svg
og:image:alt: Fernway Seed Library card
og:image:width: 1200
og:image:height: 630
twitter:card: summary_large_image
---

# First sowing: what we lent in March

The first packets went out on the opening Saturday. Tomatoes, beans, and marigolds were the most popular.

## What to watch for

Keep trays warm and out of direct sun until the first true leaves appear. Label every row, even if you think you will remember.
