---
title: "Midsummer check-in"
description: "Growers are reporting strong bean yields and some powdery mildew on squash. Notes on both."
date: 2026-06-02T09:00:00Z
author: Tom Eriksen
schema: BlogPosting
og:image: /assets/card.svg
og:image:alt: Fernway Seed Library card
og:image:width: 1200
og:image:height: 630
twitter:card: summary_large_image
---

# Midsummer check-in

Bean yields are strong this year. Squash is showing powdery mildew in the damper beds.

## Advice

Water at the base of the plant, in the morning, and leave space between squash plants for airflow.
