---
title: "Seed return begins"
description: "Returns open this week. Here is how to dry, label, and bring back the seed you grew."
date: 2026-10-01T09:00:00Z
author: Priya Natarajan
schema: BlogPosting
og:image: /assets/card.svg
og:image:alt: Fernway Seed Library card
og:image:width: 1200
og:image:height: 630
twitter:card: summary_large_image
---

# Seed return begins

Seed returns open on the first Saturday of October. Dry seed fully before you bring it in.

## How to dry seed

Spread seed on a paper plate in a warm, dry room for about two weeks, then store it in a labelled envelope.
