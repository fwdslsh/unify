# REPORT — Fernway Seed Library site

## 1. Publish command

```
./unify build --clean --audit --base-url https://fernway.example/library/ --pretty-urls
```

`unify.yaml` also records `pretty-urls`, `base-url` and `audit`, so a bare `./unify build`
produces the same output. `clean` is deliberately not saved there (see section 3).

## 2. Check outputs

Final run, after all source edits. All exit codes are 0.

Command:
```
./unify build --clean --audit --base-url https://fernway.example/library/ --pretty-urls
```
Output:
```
audit: nothing to report
publish exit=0
```

Command:
```
./unify build --dry-run --strict --base-url https://fernway.example/library/ --pretty-urls
```
Output:
```
audit: nothing to report
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 3 pages would gain a JSON-LD block
copy dist/assets/card.svg (/library/assets/card.svg) ← assets/card.svg
copy dist/assets/seed.svg (/library/assets/seed.svg) ← assets/seed.svg
copy dist/assets/site.css (/library/assets/site.css) ← assets/site.css
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/2026-03-14-starting-tomatoes-indoors/index.html (/library/notes/2026-03-14-starting-tomatoes-indoors/) ← notes/2026-03-14-starting-tomatoes-indoors.md + _layout.html
write dist/notes/2026-05-02-saving-bean-seed/index.html (/library/notes/2026-05-02-saving-bean-seed/) ← notes/2026-05-02-saving-bean-seed.md + _layout.html
write dist/notes/2026-08-21-end-of-season-returns/index.html (/library/notes/2026-08-21-end-of-season-returns/) ← notes/2026-08-21-end-of-season-returns.md + _layout.html
write dist/notes/index.html (/library/notes/) ← notes/index.md + _layout.html
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 11 files to dist/
dry-run exit=0
```

Command:
```
./unify audit --strict --external --base-url https://fernway.example/library/ --pretty-urls
```
Output:
```
audit: nothing to report
audit exit=0
```

Command (JSON format, excerpt; the full output is about 400 lines and was not pasted):
```
./unify audit --strict --format json --base-url https://fernway.example/library/ --pretty-urls
```
Output (excerpt):
```
{
  "schemaVersion": 1,
  "baseUrl": "https://fernway.example/library/",
  "summary": {
    "broken": 0,
    "incomplete": 0,
    "problems": 0,
    "advisories": 0
  },
  ...
  "findings": []
}
json exit=0
```

Findings I fixed on the way (all now gone):
- `feed.xml` / dry-run `--strict` advisories: three dates were bare `YYYY-MM-DD`; given `T09:00:00Z`.
- `audit --strict` `h1-missing` on the three posts: each post now has an `# H1`.
- `audit --strict` `image-missing-dimensions` on all pages: `og:image:width`/`og:image:height` (1200 x 630) added to the layout.
- `audit --strict` reported 9 `incomplete` findings in total before these fixes; the rerun reported none.

Also checked: no `.html` address appears in any emitted page (`grep` for `.html"` in `dist/` returns nothing).

## 3. Answers

**What did rules.md not answer? Name the sentence you wanted.**
- I wanted a sentence listing every check the tool offers. rules.md says `unify build --dry-run --strict` "is the whole build and every check", which is false in practice. `unify audit --strict --external` is a separate check that rules.md never mentions. I only found it in `unify --help`.
- I wanted a sentence saying which audit findings are required (`h1-missing`, `image-missing-dimensions`) and which are advisory. Neither appears in rules.md. I learned of them only from audit output.
- I wanted a sentence saying `--save-config` must not save `clean`. Saving `clean` made `unify audit` exit 2 ("audit never writes"). rules.md does not warn about this.
- I wanted a sentence on what a post's time should be when the author gives only a date. rules.md says a date with no time "is reported and left out", but not what to write instead.

**What did I have to re-read, and why did it not land the first time?**
- I did not re-read rules.md. I read it once, in full, at the start. What I went back to was `unify --help`, because rules.md did not name the audit command or its flags. That is the gap in section 1 above.
- I re-ran the dry-run and audit after each fix rather than re-reading the docs, because the messages named the exact fix.

**What did I guess at or infer rather than read?**
- The post times `09:00:00Z` are invented by me, not authored by the volunteers. The brief gave no times. They are placeholders the coordinator should confirm.
- The post authors, titles, and body text are invented placeholders, as are the library's address, hours, and bean/tomato advice on the Visit page and in the notes. The coordinator must replace them with real content.
- I wrote the Notes index by hand rather than through a `generate:` script. rules.md suggests derived files come from a script, but a hand-written list was simpler for three posts. It will drift if a fourth post is added without updating it.
- I assumed `og:image` as SVG is acceptable for share cards. The brief asked for an image and said to use SVG placeholders, but some social platforms do not render SVG previews. This is a risk I did not verify; I have no browser or image tool to test it. A PNG card at 1200 x 630 would be safer.
- `--external` returned clean, but the site emits no off-origin URLs, so that check passed trivially.
- I inferred the layout's `<main>` wrapping from the rules' "bare `<slot>` inside `<main>`" wording. The build output (`<main>` with page content, no nested `<main>`) confirms it, so this one I checked rather than guessed.
