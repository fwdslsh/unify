---
title: "Saving bean seed without losing the variety"
description: "Beans cross-pollinate less than most crops, but isolation still matters for a pure line."
date: 2026-05-02T09:00:00Z
author: "Dev Raman"
schema: BlogPosting
og:image: /assets/card.svg
---

# Saving bean seed without losing the variety

Most beans are self-pollinating, so you can save seed from a single plant and keep the
variety true. Leave the best pods on the vine until they are dry and rattle.

## Choosing plants to save from

Pick healthy plants that bore early and kept bearing. Mark them with a ribbon so nobody
picks their pods for dinner.

## Drying and storing

Dry the pods indoors for two weeks, shell them, and store the seed in a sealed jar away
from light. Label it with the variety and the year.
