---
title: "Notes"
description: "Notes from Fernway Seed Library volunteers, newest first."
---

# Notes

Notes from our volunteers, newest first.

- 2026-08-21 — [End-of-season returns: what we need and what we can't use](/notes/2026-08-21-end-of-season-returns.html)
- 2026-05-02 — [Saving bean seed without losing the variety](/notes/2026-05-02-saving-bean-seed.html)
- 2026-03-14 — [Starting tomatoes indoors: a volunteer's first season](/notes/2026-03-14-starting-tomatoes-indoors.html)
