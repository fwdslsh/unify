---
title: "End-of-season returns: what we need and what we can't use"
description: "A short guide to returning seed so the next grower can borrow it."
date: 2026-08-21T09:00:00Z
author: "Priya Lindqvist"
schema: BlogPosting
og:image: /assets/card.svg
---

# End-of-season returns: what we need and what we can't use

We want seed from plants that grew well in your garden. Please return seed in a labelled
paper envelope, with the variety name and the year.

## What we can use

Dry, fully ripe seed from open-pollinated varieties. Squash, beans, lettuce and calendula
are all popular.

## What we can't use

Seed from hybrid (F1) plants, seed that is damp or mouldy, and seed in unlabelled bags.
If you are unsure, bring it anyway and a volunteer will look at it with you.
