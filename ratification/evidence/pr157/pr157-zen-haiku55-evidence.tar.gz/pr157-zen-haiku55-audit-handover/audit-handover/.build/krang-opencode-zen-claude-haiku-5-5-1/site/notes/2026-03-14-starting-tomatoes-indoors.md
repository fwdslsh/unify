---
title: "Starting tomatoes indoors: a volunteer's first season"
description: "Timing, light and the one mistake that cost me a tray of seedlings."
date: 2026-03-14T09:00:00Z
author: "Maya Okafor"
schema: BlogPosting
og:image: /assets/card.svg
---

# Starting tomatoes indoors: a volunteer's first season

Sow tomato seed indoors about six weeks before your last frost date. Shallow trays with
a fine seed compost are enough.

## Light matters more than heat

Once the seedlings emerge, they need strong light for most of the day. A south window
gave me leggy plants; a cheap grow light hung a few centimetres above the leaves fixed it.

## Borrow, then return

Packets from the library are labelled with the year they were saved. Sow a few seeds from
each, keep notes on which plants did best, and bring back the best fruit's seed in autumn.
