---
title: "Welcome to the library"
description: "What the Fernway Seed Library is for, and how a volunteer can help keep it running."
date: 2026-02-14T09:00:00Z
author: Jo Park
schema: BlogPosting
---

# Welcome to the library

The library exists so that every grower in Fernway can try a new variety without buying a full packet. You borrow a little seed, and you give back a little more.

Volunteers keep the cabinet tidy, label envelopes, and check returned seed for germination. No experience is needed to help.
