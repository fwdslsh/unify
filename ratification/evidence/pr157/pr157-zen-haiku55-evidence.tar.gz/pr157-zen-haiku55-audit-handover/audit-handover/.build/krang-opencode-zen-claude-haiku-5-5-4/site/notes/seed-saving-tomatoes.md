---
title: "Saving seed from tomatoes"
description: "A volunteer's step-by-step guide to fermenting and drying tomato seed for the library."
date: 2026-09-20T09:00:00Z
author: Priya Nair
schema: BlogPosting
---

# Saving seed from tomatoes

Choose the ripest, healthiest fruit from the strongest plant. Scoop out the seed and gel into a jar.

Let it ferment for two to three days until a mould layer forms on top. Rinse well, then dry the seed on a plate away from direct sun.
