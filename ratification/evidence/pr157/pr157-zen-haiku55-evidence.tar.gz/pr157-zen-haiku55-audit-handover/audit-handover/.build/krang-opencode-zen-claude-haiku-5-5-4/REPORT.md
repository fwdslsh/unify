# REPORT — Fernway Seed Library

## Publish command

```
./unify build -s site --pretty-urls --base-url https://fernway.example/library/ --audit --strict --clean
```

Output:

```
audit: nothing to report
exit=0
```

Published files in `dist/`: `index.html`, `visit/index.html`, `notes/index.html`,
`notes/{welcome-to-the-library,first-sowing-of-the-year,seed-saving-tomatoes}/index.html`,
`feed.xml`, `sitemap.xml`, `assets/{seed.svg,card.svg,site.css}`.

## Checks

Each check was run after the final edits, from the sandbox directory.

### 1. Dry run, strict (whole build plus every check, writes nothing)

Command:

```
./unify build --dry-run --strict --pretty-urls -s site --base-url https://fernway.example/library/
```

Output:

```
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 3 pages would gain a JSON-LD block
copy dist/assets/card.svg (/library/assets/card.svg) ← assets/card.svg
copy dist/assets/seed.svg (/library/assets/seed.svg) ← assets/seed.svg
copy dist/assets/site.css (/library/assets/site.css) ← assets/site.css
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/first-sowing-of-the-year/index.html (/library/notes/first-sowing-of-the-year/) ← notes/first-sowing-of-the-year.md + _layout.html
write dist/notes/index.html (/library/notes/) ← notes/index.html + _layout.html
write dist/notes/seed-saving-tomatoes/index.html (/library/notes/seed-saving-tomatoes/) ← notes/seed-saving-tomatoes.md + _layout.html
write dist/notes/welcome-to-the-library/index.html (/library/notes/welcome-to-the-library/) ← notes/welcome-to-the-library.md + _layout.html
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 11 files to dist/
exit=0
```

### 2. Audit (advisories shown, exit code ignores them)

Command:

```
./unify audit -s site --pretty-urls --base-url https://fernway.example/library/
```

Output:

```
audit: nothing to report
exit=0
```

### 3. Audit, strict (advisories count for the exit code)

Command:

```
./unify audit --strict -s site --pretty-urls --base-url https://fernway.example/library/
```

Output:

```
audit: nothing to report
exit=0
```

### 4. Audit, external (fetches every off-origin URL the site emits)

Command:

```
./unify audit --external -s site --pretty-urls --base-url https://fernway.example/library/
```

Output:

```
audit: nothing to report
exit=0
```

Earlier runs reported advisories that I fixed:
- Three posts had dates without a time (`2026-02-14`, etc.); the dry run warned they would be left out of `feed.xml`. I changed them to `…T09:00:00Z`.
- Six pages reported `image-missing-dimensions`. I added `og:image:width` 1200 and `og:image:height` 630 to the layout and removed the per-post `og:image` lines, which duplicated the layout's.

## Answers

**What did `rules.md` not answer? Name the sentence you wanted.**
- I wanted a sentence saying that the default build keeps `.html` in addresses and that `--pretty-urls` is the option that removes it, stated in the publish section. The text mentions `--pretty-urls` only as a rewrite of links under the "Files" heading, and never says it is the way to meet the "no `.html` in visible addresses" requirement.
- I also wanted the rule for a post date with no time: whether to add a time, and which one. The doc says a date with no time is "reported and left out rather than guessed at", but does not say what to write instead. I chose `T09:00:00Z` myself, which is a guess.
- Nothing in the doc explains the `image-missing-dimensions` advisory or how to satisfy it. I found the fix only from the advisory text.

**What did I have to re-read, and why did it not land the first time?**
- I read `rules.md` once and did not re-read it. The missing pieces came from running the tool, not from a second reading. I should have checked the `--pretty-urls` and fragment-naming rules before writing the files, not after.
- My first batch of file writes was blocked by a permission rule when I used `cd ..` in a chained command. I thought the files had been written, but they had not, so my first dry run used a partial site. I caught it by listing the directory. Using `workdir` instead of `cd` avoided the block.

**What did I guess at or infer rather than read?**
- The `T09:00:00Z` time on the three post dates: an invented value, not from the brief or the doc.
- That the `.fragment.html` suffix is needed for includes. I renamed the header and footer before testing, based on the doc, and the build then accepted them.
- The Twitter card: the brief asks for a preview card, and the layout declares `twitter:card` `summary_large_image`. The doc says no Twitter tag is invented, so I did not add `twitter:image`. Crawlers that fall back to `og:image` will get the image, but I did not confirm that on a real crawler and no browser was available.
- The venue, hours, and borrowing rules on the Visit page are placeholder content I wrote. The brief gave no real details, and they should be checked by the coordinator.
