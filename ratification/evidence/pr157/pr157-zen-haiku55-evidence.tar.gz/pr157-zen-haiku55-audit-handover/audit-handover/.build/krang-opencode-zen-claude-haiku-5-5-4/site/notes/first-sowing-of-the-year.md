---
title: "The first sowing of the year"
description: "Which seeds we started indoors in early spring, and what we learned from the first trays."
date: 2026-04-05T09:00:00Z
author: Sam Okafor
schema: BlogPosting
---

# The first sowing of the year

We started leeks, onions and early lettuce indoors in the first week of April. Trays went on the sunny windowsill and were turned daily.

The lettuce came up fastest. The leeks were slow, as they always are, so keep them warm and be patient.
