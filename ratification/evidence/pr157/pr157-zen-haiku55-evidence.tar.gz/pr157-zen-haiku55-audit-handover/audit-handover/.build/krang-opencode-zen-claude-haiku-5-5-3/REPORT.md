# REPORT — Fernway Seed Library

## 1. Publish command

```
./unify build --audit --clean --pretty-urls --base-url https://fernway.example/library/
```

Exit code 0. Output: `audit: nothing to report`. It publishes to `dist/`.

## 2. Checks and their final output

Every check was run after the last site change.

### `./unify build --dry-run --strict --pretty-urls --base-url https://fernway.example/library/`

```
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 3 pages would gain a JSON-LD block
copy dist/assets/cards/autumn-returns.svg (/library/assets/cards/autumn-returns.svg) ← assets/cards/autumn-returns.svg
copy dist/assets/cards/first-sowing.svg (/library/assets/cards/first-sowing.svg) ← assets/cards/first-sowing.svg
copy dist/assets/cards/seed-saving-basics.svg (/library/assets/cards/seed-saving-basics.svg) ← assets/cards/seed-saving-basics.svg
copy dist/assets/seed.svg (/library/assets/seed.svg) ← assets/seed.svg
copy dist/assets/style.css (/library/assets/style.css) ← assets/style.css
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/autumn-returns/index.html (/library/notes/autumn-returns/) ← notes/autumn-returns.md + _layout.html
write dist/notes/first-sowing/index.html (/library/notes/first-sowing/) ← notes/first-sowing.md + _layout.html
write dist/notes/index.html (/library/notes/) ← notes/index.html + _layout.html
write dist/notes/seed-saving-basics/index.html (/library/notes/seed-saving-basics/) ← notes/seed-saving-basics.md + _layout.html
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 13 files to dist/
```
exit 0

### `./unify audit --strict --pretty-urls --base-url https://fernway.example/library/`

```
audit: nothing to report
```
exit 0

### `./unify audit --external --pretty-urls --base-url https://fernway.example/library/`

```
audit: nothing to report
```
exit 0

### `./unify build --audit --pretty-urls --base-url https://fernway.example/library/ --clean`

```
audit: nothing to report
```
exit 0

### `./unify audit --format json --strict --pretty-urls --base-url https://fernway.example/library/`

The JSON report ends with `"findings": []`. Exit 0.

### `./unify audit --format sarif --strict --pretty-urls --base-url https://fernway.example/library/`

Zero `ruleId` entries. Exit 0.

## 3. Honest answers

**What did `rules.md` not answer? Name the sentence you wanted.**
- I wanted the sentence saying how a `generate:` script learns the output directory it must write into. Line 6 says it "writes into the directory unify hands it" but never says how it is handed over. I did not use a generator. I hand-wrote the post index so I would not guess at this contract.
- I wanted the sentence listing the checks that `audit` runs. `rules.md` line 60 says `--dry-run --strict` is "the whole build and every check", but two audit findings (`h1-missing`, `image-missing-dimensions`) appeared only under `audit`, never under the dry run. The dry run passed while the audit still had six findings. The brief says to run every check, so I had to discover `audit` and `--external` from `--help`.
- I also wanted the publish command to name `--pretty-urls`. `rules.md` requires addresses without `.html`, but it only mentions `--pretty-urls` in passing. The option is described only in `--help`.

**What did I have to re-read, and why did it not land the first time?**
- `rules.md` line 60 (the dry-run sentence). I read it as covering all checks, which was wrong, because `audit` runs additional checks.
- The `--help` output, which I read twice. The first read did not show that `audit` is a separate command with its own checks. It was not obvious from the option list alone.
- The Markdown section in `rules.md` (line 54 about `og:image`, and line 50 about frontmatter titles). I did not re-read it, but it took a second pass through the audit output to connect `h1-missing` to the frontmatter title. The title came from frontmatter, so no `<h1>` was emitted.

**What did I guess at, or infer rather than read?**
- I inferred that `site/` is the source root from line 9 of `rules.md`. That was read, not guessed.
- I guessed the `dist/` layout after `--pretty-urls`. The dry run confirmed it.
- I guessed that a date with a time and `Z` would fix the feed advisory. The advisory itself stated the fix, so this was confirmed.
- I added `# Title` headings to the posts and `og:image:width`/`height` to the frontmatter to satisfy the audit. The audit stated these fixes.
- I added `twitter:card` to the layout. `rules.md` does not mention Twitter cards. I added it to satisfy the preview-card requirement and did not verify how a crawler renders it, because no browser is available.
- One tool call (writing to `/tmp/opencode`) was blocked by a permission rule. I worked around it by reading the output directly. This did not change any result.
