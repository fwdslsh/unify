---
title: "Seed saving basics: letting plants finish"
description: "Why a few plants must be left to flower and set seed, and how to tell when seed is dry."
schema: Article
author: "Dev Raman"
date: 2026-06-02T09:00:00Z
og:image: /assets/cards/seed-saving-basics.svg
og:image:width: 1200
og:image:height: 630
---

# Seed saving basics: letting plants finish

Seed is ready when the pod or head turns brown and dry and the seed rattles. Bring it in before a wet spell, and dry it on a paper towel for a week.

## Keep it clean

Label every envelope with the variety and the year. Mixed or unlabeled seed is hard to lend out.
