---
title: "First sowing: starting seed at home"
description: "How to start borrowed seed indoors in early spring, and what to write on the return card."
schema: Article
author: "Maya Ortiz"
date: 2026-03-14T09:00:00Z
og:image: /assets/cards/first-sowing.svg
og:image:width: 1200
og:image:height: 630
---

# First sowing: starting seed at home

Spring is the time to start seed indoors. Pick a shallow tray, fill it with fresh seed-starting mix, and sow each packet at the depth printed on it.

## What to write on the return card

Note the variety, the date you sowed it, and how many plants you grew. Growers who return seed later tell us this helps the next borrower.
