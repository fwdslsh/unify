---
title: "Autumn returns: bringing seed back"
description: "What to return at season end, how much to bring back, and when the library reopens."
schema: Article
author: "Lina Okafor"
date: 2026-10-18T09:00:00Z
og:image: /assets/cards/autumn-returns.svg
og:image:width: 1200
og:image:height: 630
---

# Autumn returns: bringing seed back

Return fresh seed from the plants you borrowed from, at the autumn returns day. Bring more than you borrowed when you can, so the library keeps a stock for next spring.

## Before you come

Check that each envelope is labeled and dry. Drop off at the desk during open hours listed on the [Visit page](/visit.html).
