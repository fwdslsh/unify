# Ratification round pr157-zen-haiku55-audit-handover

- **unify** 0.11.18 at `83bc115168cb` (working tree)
- **rules** `fb07d931bd36` · **prompt** `456131468750` · **agent** opencode 1.18.25 · **models** krang/opencode-zen/claude-haiku-5-5 · **isolation** mount namespace, probe clean
- 2026-11-09T00:07:23.404Z to 2026-11-09T00:12:49.907Z; scored 2026-11-09T00:12:49.907Z

## Score

**5 of 5 samples completed their brief: every scored check passed (100%).**

The protocol's bar, at least 4 of 5 samples of a model on each brief: **met**.

| Brief | Model | Passed | Checks that failed |
|---|---|---|---|
| audit-handover | krang/opencode-zen/claude-haiku-5-5 | 5/5 | — |

## audit-handover — Hand over only when every check the tool offers reports nothing

*round 28; checks follow its pre-registered V1-V4, plus the brief's extensionless addresses.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | audit-strict | article-data | share-cards | ran-audit | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-claude-haiku-5-5-1 | 2m53s | 20 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-opencode-zen-claude-haiku-5-5-2 | 3m29s | 27 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-opencode-zen-claude-haiku-5-5-3 | 2m16s | 20 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-opencode-zen-claude-haiku-5-5-4 | 2m25s | 24 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-opencode-zen-claude-haiku-5-5-5 | 4m06s | 32 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |

- krang-opencode-zen-claude-haiku-5-5-1 · **ran-audit** (not scored): 6 runs matching /unify audit/
- krang-opencode-zen-claude-haiku-5-5-2 · **ran-audit** (not scored): 7 runs matching /unify audit/
- krang-opencode-zen-claude-haiku-5-5-3 · **ran-audit** (not scored): 6 runs matching /unify audit/
- krang-opencode-zen-claude-haiku-5-5-4 · **ran-audit** (not scored): 4 runs matching /unify audit/
- krang-opencode-zen-claude-haiku-5-5-5 · **ran-audit** (not scored): 3 runs matching /unify audit/

What the agents said the rules did not answer:

**krang-opencode-zen-claude-haiku-5-5-1**

> **What did rules.md not answer? Name the sentence you wanted.**
> - I wanted a sentence listing every check the tool offers. rules.md says `unify build --dry-run --strict` "is the whole build and every check", which is false in practice. `unify audit --strict --external` is a separate check that rules.md never mentions. I only found it in `unify --help`.
> - I wanted a sentence saying which audit findings are required (`h1-missing`, `image-missing-dimensions`) and which are advisory. Neither appears in rules.md. I learned of them only from audit output.
> - I wanted a sentence saying `--save-config` must not save `clean`. Saving `clean` made `unify audit` exit 2 ("audit never writes"). rules.md does not warn about this.
> - I wanted a sentence on what a post's time should be when the author gives only a date. rules.md says a date with no time "is reported and left out", but not what to write instead.
> 
> **What did I have to re-read, and why did it not land the first time?**
> - I did not re-read rules.md. I read it once, in full, at the start. What I went back to was `unify --help`, because rules.md did not name the audit command or its flags. That is the gap in section 1 above.
> - I re-ran the dry-run and audit after each fix rather than re-reading the docs, because the messages named the exact fix.
> 
> **What did I guess at or infer rather than read?**
> - The post times `09:00:00Z` are invented by me, not authored by the volunteers. The brief gave no times. They are placeholders the coordinator should confirm.

**krang-opencode-zen-claude-haiku-5-5-2**

> **What did `rules.md` not answer?**
> - The sentence I wanted: "unify runs the generate script with these arguments: the source root, the overlay directory it must write into, and the path of a `generator-context.json`." `rules.md` says the script "writes into the directory unify hands it", but never says how that directory is handed over. I found it by writing a probe script that dumped `process.argv`.
> - The sentence I wanted: "`--strict` makes advisories and `incomplete` audit findings fail the exit code; `broken` findings always do." `rules.md` mentions `--strict` only in the dry-run line. The meaning comes from `--help`.
> - The sentence I wanted: a list of audit rule IDs and what each requires (for example `h1-missing` and `image-missing-dimensions`). `rules.md` does not name the checks. I learned them by running `audit`.
> - The sentence I wanted: "a Markdown post needs a `# Heading` in its body, not only a `title:` key, to pass audit." The rules say a missing `title:` falls back to the first `# Heading`, but not that the audit requires one.
> - The sentence I wanted: "a share image should declare `og:image:width` and `og:image:height`." Only the audit reports this.
> 
> **What did I have to re-read, and why did it not land the first time?**
> - The generate-script paragraph. I read it once and assumed the overlay directory would be passed in a predictable way. It was not specified, so I probed for it. My first attempt to find it inside the binary with `grep` returned noise.
> - I wrote the Markdown post dates as plain `2026-02-14` (as the rules show in examples) and got three advisories. The dry run then said a date with no time is left out of `feed.xml`. I should have read the date rule before writing it.
> - I initially put the generator under `site/_scripts/` instead of the top-level `scripts/`. The rules name `scripts/` beside the site, and I corrected it.
> - I had to re-run the audit after each fix. I did not read the full list of checks beforehand, so the fixes came one audit at a time.

**krang-opencode-zen-claude-haiku-5-5-3**

> **What did `rules.md` not answer? Name the sentence you wanted.**
> - I wanted the sentence saying how a `generate:` script learns the output directory it must write into. Line 6 says it "writes into the directory unify hands it" but never says how it is handed over. I did not use a generator. I hand-wrote the post index so I would not guess at this contract.
> - I wanted the sentence listing the checks that `audit` runs. `rules.md` line 60 says `--dry-run --strict` is "the whole build and every check", but two audit findings (`h1-missing`, `image-missing-dimensions`) appeared only under `audit`, never under the dry run. The dry run passed while the audit still had six findings. The brief says to run every check, so I had to discover `audit` and `--external` from `--help`.
> - I also wanted the publish command to name `--pretty-urls`. `rules.md` requires addresses without `.html`, but it only mentions `--pretty-urls` in passing. The option is described only in `--help`.
> 
> **What did I have to re-read, and why did it not land the first time?**
> - `rules.md` line 60 (the dry-run sentence). I read it as covering all checks, which was wrong, because `audit` runs additional checks.
> - The `--help` output, which I read twice. The first read did not show that `audit` is a separate command with its own checks. It was not obvious from the option list alone.
> - The Markdown section in `rules.md` (line 54 about `og:image`, and line 50 about frontmatter titles). I did not re-read it, but it took a second pass through the audit output to connect `h1-missing` to the frontmatter title. The title came from frontmatter, so no `<h1>` was emitted.
> 
> **What did I guess at, or infer rather than read?**
> - I inferred that `site/` is the source root from line 9 of `rules.md`. That was read, not guessed.

**krang-opencode-zen-claude-haiku-5-5-4**

> **What did `rules.md` not answer? Name the sentence you wanted.**
> - I wanted a sentence saying that the default build keeps `.html` in addresses and that `--pretty-urls` is the option that removes it, stated in the publish section. The text mentions `--pretty-urls` only as a rewrite of links under the "Files" heading, and never says it is the way to meet the "no `.html` in visible addresses" requirement.
> - I also wanted the rule for a post date with no time: whether to add a time, and which one. The doc says a date with no time is "reported and left out rather than guessed at", but does not say what to write instead. I chose `T09:00:00Z` myself, which is a guess.
> - Nothing in the doc explains the `image-missing-dimensions` advisory or how to satisfy it. I found the fix only from the advisory text.
> 
> **What did I have to re-read, and why did it not land the first time?**
> - I read `rules.md` once and did not re-read it. The missing pieces came from running the tool, not from a second reading. I should have checked the `--pretty-urls` and fragment-naming rules before writing the files, not after.
> - My first batch of file writes was blocked by a permission rule when I used `cd ..` in a chained command. I thought the files had been written, but they had not, so my first dry run used a partial site. I caught it by listing the directory. Using `workdir` instead of `cd` avoided the block.
> 
> **What did I guess at or infer rather than read?**
> - The `T09:00:00Z` time on the three post dates: an invented value, not from the brief or the doc.
> - That the `.fragment.html` suffix is needed for includes. I renamed the header and footer before testing, based on the doc, and the build then accepted them.

**krang-opencode-zen-claude-haiku-5-5-5**

> **What did `rules.md` not answer? Name the sentence you wanted.**
> The sentence I wanted: "A generator is run as `<script> <sourceRoot> <overlayDir> <contextJson>`, and its `--generate` path is resolved from the source root." `rules.md` says only "unify runs it before every build and it writes into the directory unify hands it" and puts scripts in `scripts/` "beside the site". The first `--generate scripts/gen.mjs` failed because it resolved from the source root, not the project root. The argument order and the context file (which holds `inputs.sourcePages`) appear only in the generator's own behavior and `--help`, not in `rules.md`. The docs also never list the checks by name, so I took them from `--help` (`audit`, `--strict`, `--format`, `--external`, `--dry-run`).
> 
> **What went wrong during the work?**
> - A probe script was first written to `/tmp/probe`, outside the working directory; a permission rule blocked it, so I moved the probe into the working directory and removed it afterward. Nothing was left behind.
> - A `sed` edit to the three post front matter joined lines together (`cardog:image:width...`). I fixed them with exact edits and re-ran the audit.
> - A `cd` in a shell call was also blocked; I used `workdir` for later commands.
> 
> **What did I have to re-read, and why did it not land the first time?**
> The `Files` section and the `--generate` option. I first read "scripts/ beside the site", placed the script in the project root, and the build failed. I re-read `--help` and then probed the generator's arguments. The "source root" and "beside the site" wording point to different places, and I did not connect them the first time.
> 
> **What did I guess at or infer rather than read?**


---

`✓` passed, `✗` failed, `(i)` reported but not scored. Each sample's directory is `<brief>/<sample>/`, its OpenCode event stream and session data are in `<brief>/.harness/<sample>/`, and the build the checks read is `<brief>/.build/<sample>/`. Triage every failure with ratification/ratification-protocol.md before changing anything.
