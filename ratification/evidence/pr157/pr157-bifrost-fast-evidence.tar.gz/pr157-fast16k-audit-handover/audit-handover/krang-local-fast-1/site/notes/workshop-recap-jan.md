---
title: Seed Saving Workshop Recap
date: '2025-06-14'
category: workshop
type: post
description: Our winter seed-saving workshop covered techniques for tomatoes, beans, and peppers.
---

## January Workshop Wrap-Up

On the 8th of January we held our indoor **seed-saving workshop** at the Fernway Community Centre. We covered three main families this time around: tomato, bean, and pepper seeds.

### What We Covered

1. **Fermentation method for tomato and pepper seeds** — soak in water for 3 days, rinse, dry on ceramic plates.
2. **Dry shelling for beans** — harvest when pods are brown and crispy; winnow gently to remove chaff.
3. **Labeling best practices** — always record the year and growing location for future reference.

We had about twenty participants and managed to save roughly fifteen kilograms of seeds that will go into our spring lending basket.

### Next Workshop

Our next gathering is planned for late July and will focus on **herb and flower seed saving**. If you'd like to be notified, just send us a note during your visit!
