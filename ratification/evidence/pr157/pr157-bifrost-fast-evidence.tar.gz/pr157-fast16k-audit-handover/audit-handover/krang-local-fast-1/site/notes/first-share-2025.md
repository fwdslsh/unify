---
title: First Seed Share of 2025
date: '2025-04-18'
category: community
type: post
description: A recap of our first spring seed lending event and the varieties we're most excited about.
---

## Spring Is Here!

This past Saturday was our first seed lending day of 2025, and we had **over forty** neighbours stop by to pick up seeds. It has been wonderful to see so many new faces — some growing on balconies, others in full backyard plots.

The most popular variety this year is definitely the **'Cherokee Purple' tomato**. We ran out of those within two hours! If you missed it, we have a few packets left at the shed and will be ordering more next Saturday.

### What's New This Season

- **Purple Hopi Corn** — deep colour and smoky flavour. Great for roasting in the husk.
- **French Bean 'Verte de Camargue'** — salt-free, excellent when slow-sautéed with garlic.
- **'Lacinato' Kale** (also called dinosaur kale) — hardy through mild frosts, very reliable.

If you have extra seed packets from last year or want to donate, we're happy to take them at the shed during visit hours!
