---
title: Heirloom Varieties We're Excited About
date: '2025-03-05'
category: varieties
type: post
description: An overview of the heirloom varieties we have in stock and why they deserve a place in your garden.
---

## Heirlooms Worth Growing

We love sharing heirloom seeds because each variety carries generations of careful selection — not just for flavour, but for resilience in local growing conditions.

### Tomatoes

- **'Mortgage Lifter'** — bred in the 1930s by a Virginia electrician who sold tomatoes to pay off his debts. Big, juicy fruit with a smooth, meaty texture.
- **'Sungold'** — a cherry tomato that has been our most-requested variety for three seasons running. Sweet, tangy, and incredibly productive.

### Beans & Peas

- **'Scarlet Runners'** — beautiful red flowers that attract hummingbirds, plus edible pods when young. We grow these as an ornamental edge crop along fences.
- **'Avalanche' Sweet Pea** — fragrant, tall-growing, perfect for cutting and arranging indoors during early spring.

### Heirloom Note

We prefer seeds from plants pollinated naturally by insects or self-pollination so that the varieties stay true to type. If you're new to seed saving, ask us for a **starter guide packet** — it includes instructions on paper envelopes.
