---
title: Saving Tomato Seeds the Easy Way
description: A simple fermentation method for extracting viable tomato seeds without mess or guesswork.
date: 2025-10-18T11:00:00Z
category: tomato
---

<article>
  <h1>Saving Tomato Seeds the Easy Way</h1>

  <p>Tomato seeds are surrounded by a gelatinous coating that contains compounds which suppress germination. To make them viable for storage, that coating must be removed through fermentation.</p>

  <h2>The Fermentation Method</h2>
  <ol>
    <li><strong>Scoop:</strong>&nbsp; squeeze seeds and pulp into a jar or cup.</li>
    <li><strong>Ferment:</strong>&nbsp; leave uncovered at room temperature for 3–5 days. A layer of mold on top is normal — that's the process working.</li>
    <li><strong>Rinse:</strong>&nbsp; fill with water, stir vigorously, and let viable seeds sink while chaff floats. Repeat until water runs clear.</li>
    <li><strong>Dry:</strong>&nbsp; spread on a non-stick surface (coffee filter or ceramic plate) for 1–2 weeks.</li>
  </ol>

  <h2>Why Ferment?</h2>
  <p>Fermentation kills bacterial and fungal pathogens that can be present in the fruit pulp. It also mimics natural decomposition, triggering the seed's germination response when conditions are right.</p>

  <table>
    <thead>
      <tr><th>Step</th><th>Time Required</th></tr>
    </thead>
    <tbody>
      <tr><td>Scooping</td><td>5 minutes</td></tr>
      <tr><td>Fermenting</td><td>3–5 days (hands-off)</td></tr>
      <tr><td>Rinsing &amp; Drying</td><td>20 minutes active, 14 days passive</td></tr>
    </tbody>
  </table>

  <blockquote cite="">
    <p>Ferment once, rinse twice — if you follow those two rules you'll always have clean, viable seeds.</p>
  </blockquote>

</article>
