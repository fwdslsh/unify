---
title: Storing Seeds for Winter
description: Best practices for drying, cleaning, and storing seeds through the cold months.
date: 2025-06-02T14:30:00Z
category: storage
---

<article>
  <h1>Storing Seeds for Winter</h1>

  <p>The secret to long-term seed viability is moisture control. Before any seeds see a jar or envelope, they must be dried thoroughly — typically 1–2 weeks in a cool, dry place with good air circulation.</p>

  <h2>Drying Process</h2>
  <ol>
    <li><strong>Clean:</strong>&nbsp; remove all chaff and husks. For tomato seeds, wash away the gel coating to prevent germination during storage.</li>
    <li><strong>Dry:</strong>&nbsp; spread seeds on a screen or paper plate for 7–14 days.</li>
    <li><strong>Test dryness:</strong>&nbsp; seeds should rattle when shaken and snap, not bend, when dropped from knee height.</li>
  </ol>

  <h2>Packaging Options</h2>
  <ul>
    <li><strong>Paper envelopes:</strong>&nbsp; breathable, good for short-term storage (under one year).</li>
    <li><strong>Airtight glass jars:</strong>&nbsp; ideal for long-term. Add silica gel packs to control humidity.</li>
    <li><strong>Frost-free freezer:</strong>&nbsp; store at −18&nbsp;°C for maximum longevity (5–10 years).</li>
  </ul>

  <h2>Storage Conditions</h2>
  <table>
    <thead>
      <tr>
        <th>Crop</th>
        <th>Relative Humidity</th>
        <th>Temperature</th>
        <th>Viability (years)</th>
      </tr>
    </thead>
    <tbody>
      <tr><td>Tomato</td><td>&lt;40%</td><td>4&nbsp;°C or freezer</td><td>5–10</td></tr>
      <tr><td>Bean</td><td>&lt;50%</td><td>Room temp (cool)</td><td>3–6</td></tr>
      <tr><td>Heirloom lettuce</td><td>&lt;40%</td><td>Freezer</td><td>4–8</td></tr>
    </tbody>
  </table>

  <blockquote cite="">
    <p>Store them cool, dry and dark — that rule works for every seed in the jar.</p>
  </blockquote>

</article>
