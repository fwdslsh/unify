---
title: Bee-Pollinated Beans
description: How bumblebees cross-pollinate our bean varieties and what it means for seed purity.
date: 2025-03-14T09:00:00Z
category: pollination
---

<article>
  <h1>Bee-Pollinated Beans</h1>

  <p>This spring we watched bumblebees — not just honey bees, but the fuzzy ones nesting near our south fence — visit dozens of bean flowers. Bean plants are naturally self-pollinating, but heavy bee activity can still cause cross-pollination between varieties, especially in dry beans and lima beans.</p>

  <h2>What We Observed</h2>
  <ul>
    <li><strong>Number of hives nearby:</strong>&nbsp; three colonies within 50 metres.</li>
    <li><strong>Varieties grown side by side:</strong>&nbsp; 'Scarlet Runner' and 'Cannes de Édimbourg' (both dry beans).</li>
    <li><strong>Results:</strong>&nbsp; approximately 30% of pods showed mixed seed coats, indicating cross-pollination.</li>
  </ul>

  <h2>Steps Taken</h2>
  <ol>
    <li>We hand-pollinated the remaining flowers with a small brush to preserve varietal purity.</li>
    <li><strong>Isolation distance:</strong>&nbsp; future plantings will be separated by at least 10&nbsp;m or bagged before flowering.</li>
    <li><strong>Timing:</strong>&nbsp; we staggered bloom dates so the most bee-attractive variety flowers first, drawing pollinators away from seed crops.</li>
  </ol>

  <h2>Tips for Gardeners</h2>
  <p>If you are saving bean seed, hand-pollination with a brush or by tapping flowers gently is reliable. Bagging inflorescences before buds open prevents unwanted bee visits entirely.</p>

  <blockquote cite="">
    <p>The bees do their work; we just make sure the right seeds are saved for next season.</p>
  </blockquote>

</article>
