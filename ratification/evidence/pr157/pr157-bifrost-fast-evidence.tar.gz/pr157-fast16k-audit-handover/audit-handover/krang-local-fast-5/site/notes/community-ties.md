---
title: Building Community Ties Through Seed Sharing
date: '2025-06-12'
author: Fernway Volunteer Team
description: Explore how neighborhood seed swaps and shared gardens strengthen local relationships. A look at community-based seed preservation in the Pacific Northwest.
---

<!doctype html>
<html lang="en">
<head>
  <meta charset>
  <title>Community Ties Through Seed Sharing — Fernway Seed Library</title>
  <link rel="stylesheet" href="/css/style.css">
  <script type="application/ld+json"></script>
</head>
<body class="post" data-layout="/_layout.html">
  <header slot="header">
    <nav aria-label="Notes breadcrumb"><a href="/notes/">Notes</a></nav>
  </header>
  <main slot="content">
    <article>
      <h1>Building Community Ties Through Seed Sharing</h1>

      <p>Seed libraries do more than preserve varieties — they bring people together. From neighborhood swaps to school gardens, seeds are a thread connecting communities.</p>

      <h2>Why Share Seeds?</h2>
      <ul>
        <li><strong>Biodiversity</strong>: Home gardener varieties aren't available commercially.</li>
        <li><strong>Adaptation</strong>: Locally saved seeds improve with each generation in your region.</li>
        <li><strong>Knowledge exchange</strong>: When you share a seed, you share the story of how it grew.</li>
      </ul>

      <h2>How It Works at Fernway</h2>
      <p>Fernway runs monthly community swaps where gardeners bring excess seeds and trade stories. Everyone is welcome — beginners are paired with experienced growers to learn proper storage techniques.</p>

      <h2>Tips for Starting Your Own Swap</h2>
      <ol>
        <li>Choose a consistent date (e.g., first Saturday each month).</li>
        <li>Provide labeling supplies: envelopes, markers, variety tags.</li>
        <li>Set simple rules: only viable seeds, proper labeling required.</li>
        <li>Host at a library, community center, or garden plot.</li>
      </ol>

      <h2>A Word from Our Neighbors</h2>
      <p>“I learned to save carrots and broad beans here,” says Marla K. “Now I swap with three families across my street.” Community swaps turn casual gardening into shared stewardship.</p>
    </article>
  </main>
</body>
</html>
