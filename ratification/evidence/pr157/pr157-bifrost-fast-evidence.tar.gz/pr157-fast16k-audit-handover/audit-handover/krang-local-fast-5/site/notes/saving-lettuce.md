---
title: Saving Lettuce Seeds — A First-Timer's Guide
date: '2025-04-15'
author: Fernway Volunteer Team
description: Learn how to dry, thresh, and store lettuce seeds for next season. A beginner-friendly walkthrough from flower to packet.
---

<!doctype html>
<html lang="en">
<head>
  <meta charset>
  <title>Saving Lettuce Seeds — Fernway Seed Library</title>
  <link rel="stylesheet" href="/css/style.css">
  <script type="application/ld+json"></script>
</head>
<body class="post" data-layout="/_layout.html">
  <header slot="header">
    <nav aria-label="Notes breadcrumb"><a href="/notes/">Notes</a></nav>
  </header>
  <main slot="content">
    <article>
      <h1>Saving Lettuce Seeds: A First-Timer's Guide</h1>

      <p>Lettuce is one of the easiest garden plants to save seed from — and it only takes about five minutes once you know what to look for.</p>

      <h2>When to Harvest</h2>
      <p>Wait until the stems turn brown and the seeds begin falling on their own. The seed heads should feel dry and brittle, not green or succulent.</p>

      <h2>Step-by-Step</h2>
      <ol>
        <li><strong>Cut</strong>: Snip the stem about 4 inches below the flower head.</li>
        <li><strong>Dry</strong>: Hang bundles upside down in a paper bag for one week.</li>
        <li><strong>Thresh</strong>: Gently rub the heads together to release seeds into the bag.</li>
        <li><strong>Clean</strong>: Winnow by tossing seeds in a breeze or over a shallow bowl.</li>
        <li><strong>Store</strong>: Label with variety and date; store in a cool, dry place.</li>
      </ol>

      <h2>Why Save Lettuce Seeds?</h2>
      <p>Home-saved lettuce varieties often taste stronger than commercial packets — many gardeners swear they notice the difference the first time.</p>
    </article>
  </main>
</body>
</html>
