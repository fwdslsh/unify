# Ratification round pr157-fast16k-audit-handover

- **unify** 0.11.18 at `98dfd174e09b` (working tree)
- **rules** `fb07d931bd36` · **prompt** `456131468750` · **agent** opencode 1.18.25 · **models** krang/local/fast · **isolation** mount namespace, probe clean
- 2026-11-08T21:41:32.417Z to 2026-11-08T22:09:54.894Z; scored 2026-11-08T22:09:54.895Z

## Score

**0 of 5 samples completed their brief: every scored check passed (0%).**

The protocol's bar, at least 4 of 5 samples of a model on each brief: **not met**.

| Brief | Model | Passed | Checks that failed |
|---|---|---|---|
| audit-handover | krang/local/fast | 0/5 | agent-finished (5), publish-command (5), strict-build (5), fresh-build (5), addresses (5), audit-strict (5), article-data (5), share-cards (5) |

## audit-handover — Hand over only when every check the tool offers reports nothing

*round 28; checks follow its pre-registered V1-V4, plus the brief's extensionless addresses.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | audit-strict | article-data | share-cards | ran-audit | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-local-fast-1 | 28m22s | 125 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-local-fast-2 | 3m58s | 18 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-local-fast-3 | 22m31s | 88 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-local-fast-4 | 14m21s | 46 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-local-fast-5 | 26m53s | 97 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |

- krang-local-fast-1 · **agent-finished**: exit 0, no REPORT.md
- krang-local-fast-1 · **publish-command**: no REPORT.md
- krang-local-fast-1 · **strict-build**: not judged: no REPORT.md
- krang-local-fast-1 · **fresh-build**: publish command could not be rebuilt
- krang-local-fast-1 · **addresses**: no build output
- krang-local-fast-1 · **audit-strict**: no publish command
- krang-local-fast-1 · **article-data**: no build output
- krang-local-fast-1 · **share-cards**: no build output
- krang-local-fast-1 · **ran-audit** (not scored): 0 runs matching /unify audit/
- krang-local-fast-2 · **agent-finished**: exit 0, no REPORT.md
- krang-local-fast-2 · **publish-command**: no REPORT.md
- krang-local-fast-2 · **strict-build**: not judged: no REPORT.md
- krang-local-fast-2 · **fresh-build**: publish command could not be rebuilt
- krang-local-fast-2 · **addresses**: no build output
- krang-local-fast-2 · **audit-strict**: no publish command
- krang-local-fast-2 · **article-data**: no build output
- krang-local-fast-2 · **share-cards**: no build output
- krang-local-fast-2 · **ran-audit** (not scored): 0 runs matching /unify audit/
- krang-local-fast-3 · **agent-finished**: exit 0, no REPORT.md
- krang-local-fast-3 · **publish-command**: no REPORT.md
- krang-local-fast-3 · **strict-build**: not judged: no REPORT.md
- krang-local-fast-3 · **fresh-build**: publish command could not be rebuilt
- krang-local-fast-3 · **addresses**: no build output
- krang-local-fast-3 · **audit-strict**: no publish command
- krang-local-fast-3 · **article-data**: no build output
- krang-local-fast-3 · **share-cards**: no build output
- krang-local-fast-3 · **ran-audit** (not scored): 0 runs matching /unify audit/
- krang-local-fast-4 · **agent-finished**: exit 0, no REPORT.md
- krang-local-fast-4 · **publish-command**: no REPORT.md
- krang-local-fast-4 · **strict-build**: not judged: no REPORT.md
- krang-local-fast-4 · **fresh-build**: publish command could not be rebuilt
- krang-local-fast-4 · **addresses**: no build output
- krang-local-fast-4 · **audit-strict**: no publish command
- krang-local-fast-4 · **article-data**: no build output
- krang-local-fast-4 · **share-cards**: no build output
- krang-local-fast-4 · **ran-audit** (not scored): 0 runs matching /unify audit/
- krang-local-fast-5 · **agent-finished**: exit 0, no REPORT.md
- krang-local-fast-5 · **publish-command**: no REPORT.md
- krang-local-fast-5 · **strict-build**: not judged: no REPORT.md
- krang-local-fast-5 · **fresh-build**: publish command could not be rebuilt
- krang-local-fast-5 · **addresses**: no build output
- krang-local-fast-5 · **audit-strict**: no publish command
- krang-local-fast-5 · **article-data**: no build output
- krang-local-fast-5 · **share-cards**: no build output
- krang-local-fast-5 · **ran-audit** (not scored): 0 runs matching /unify audit/

---

`✓` passed, `✗` failed, `(i)` reported but not scored. Each sample's directory is `<brief>/<sample>/`, its OpenCode event stream and session data are in `<brief>/.harness/<sample>/`, and the build the checks read is `<brief>/.build/<sample>/`. Triage every failure with ratification/ratification-protocol.md before changing anything.
