---
title: Kettle update – a new heating element arrives
date: '2025-07-18T09:00:00Z'
description: We've secured a batch of generic heating elements that fit most standard kettles. Bring your broken kettle and we'll swap it out on the spot.
schema: BlogPosting
---

<meta name="og:title" content="Kettle update – a new heating element arrives">
<meta name="og:type" content="article">
<meta name="og:description" content="We've secured a batch of generic heating elements that fit most standard kettles. Bring your broken kettle and we'll swap it out on the spot.">

## A proper kettle fix, finally

Last week our volunteer team managed to source a decent stock of universal 2200 W heating elements. For years these have been the single most common cause of kettle deaths across our repair bench — dead, corroded, or just plain tired out after a couple thousand boils.

The good news is they're cheap and fit more brands than we expected. If your kettle is making loud clicks then tripping its thermal fuse mid-boil, bring it along this Saturday and we'll swap the element in about ten minutes. No appointment needed; drop-in repair clinic runs from 10 am to 4 pm on Oak Lane.
