---
title: Spares donation – a box full of chargers and cables
date: '2025-10-03T09:00:00Z'
description: A local household cleared out their old charging accessories. We've sorted through them and found dozens that are perfectly fine — all tagged with a quick multimeter test. Bring your broken charger or cable, we may have the matching plug to save the day.
schema: BlogPosting
---

<meta name="og:title" content="Spares donation – a box full of chargers and cables">
<meta name="og:type" content="article">
<meta name="og:description" content="A local household cleared out their old charging accessories. We've sorted through them and found dozens that are perfectly fine — all tagged with a quick multimeter test. Bring your broken charger or cable, we may have the matching plug to save the day.">

## The great charger sweep

When our resident hoarder (volunteered title) emptied their garage last weekend, they handed over an entire crate of old phone chargers, USB cables, and wall bricks.

Our volunteers put every single one through a multimeter test and found that roughly 68 % still output correct voltage on at least one port. That's nearly forty devices sitting in drawers waiting to be thrown away — and now they're ours again.

If your phone charger or laptop brick is acting up, bring the device along on Saturday. We'll match it with a tested donor unit and re-cable the connector if needed. Free of charge; donation to the collective appreciated at heart.
