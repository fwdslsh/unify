---
title: Saturday clinic – toaster teardowns and tea breaks
date: '2025-06-02T09:00:00Z'
description: Join us every Saturday for a group repair session. This month we're focusing on toasters, from classic two-slice models to the fancy multi-slot ones with crumb trays that never clean properly.
schema: BlogPosting
---

<meta name="og:title" content="Saturday clinic – toaster teardowns and tea breaks">
<meta name="og:type" content="article">
<meta name="og:description" content="Join us every Saturday for a group repair session. This month we're focusing on toasters, from classic two-slice models to the fancy multi-slot ones with crumb trays that never clean properly.">

## Tear them apart together

This month's repair clinic theme is **toasters**. We've had a steady stream of bread-heating machines coming through the door — some that refuse to pop the toast back up, others whose heating elements are dimming to an embarrassed glow.

If yours has one of these problems:
- Toast stuck inside (crumbs or burnt slice)
- Only one slot heating up
- Switch won't stay depressed

…then bring it along and we'll open it up together. We've got insulated screwdrivers, multimeters, and a spare parts bin full of switches, levers, and bimetal strips. Tea's always on too.
