---
title: Thank you to our newest volunteer, Priya
date: '2025-04-15T09:00:00Z'
description: Priya has joined the collective full-time. Her background in electronics engineering means we're now better equipped than ever to tackle smartphones, tablets, and small appliances that most people write off as unrepairable.
schema: BlogPosting
---

<meta name="og:title" content="Thank you to our newest volunteer, Priya">
<meta name="og:type" content="article">
<meta name="og:description" content="Priya has joined the collective full-time. Her background in electronics engineering means we're now better equipped than ever to tackle smartphones, tablets, and small appliances that most people write off as unrepairable.">

## A warm welcome to Priya

We're pleased to announce that **Priya** — a former electronics design engineer with fourteen years of industry experience — has joined the Bellwick Repair Collective on a full-time basis. She'll be heading up our small-appliance repair bench and will run monthly soldering workshops for beginners starting in May.

> "I've spent my career designing gadgets that break too easily," Priya told us at her first orientation. "It feels good to spend time fixing them instead."

Come say hello on your next visit — she'll be sitting at the corner bench with a magnifying glass and a cup of Earl Grey.
