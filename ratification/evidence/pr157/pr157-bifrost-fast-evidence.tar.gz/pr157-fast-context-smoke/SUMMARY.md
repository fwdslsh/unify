# Ratification round pr157-fast-context-smoke

- **unify** 0.11.18 at `98dfd174e09b` (working tree)
- **rules** `fb07d931bd36` · **prompt** `456131468750` · **agent** opencode 1.18.25 · **models** krang/local/fast · **isolation** mount namespace, probe clean
- 2026-11-08T21:36:32.106Z to 2026-11-08T21:40:19.372Z; scored 2026-11-08T21:40:19.372Z

## Score

**0 of 1 samples completed their brief: every scored check passed (0%).**

The protocol's bar, at least 4 of 5 samples of a model on each brief: not measured: the bar needs at least 5 samples per brief and model, so this score is indicative.

| Brief | Model | Passed | Checks that failed |
|---|---|---|---|
| publishing | krang/local/fast | 0/1 | agent-finished (1), publish-command (1), strict-build (1), fresh-build (1), addresses (1), feed (1), article-data (1), share-cards (1) |

## publishing — Publishing surface: schema:, og: share cards, dated posts, a feed, a subpath

*round 27, re-run unchanged in round 29; checks follow round 27's pre-registered V1-V5.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | feed | article-data | share-cards | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-local-fast-1 | 3m47s | 55 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |

- krang-local-fast-1 · **agent-finished**: exit 0, no REPORT.md
- krang-local-fast-1 · **publish-command**: no REPORT.md
- krang-local-fast-1 · **strict-build**: not judged: no REPORT.md
- krang-local-fast-1 · **fresh-build**: publish command could not be rebuilt
- krang-local-fast-1 · **addresses**: no build output
- krang-local-fast-1 · **feed**: no build output
- krang-local-fast-1 · **article-data**: no build output
- krang-local-fast-1 · **share-cards**: no build output

---

`✓` passed, `✗` failed, `(i)` reported but not scored. Each sample's directory is `<brief>/<sample>/`, its OpenCode event stream and session data are in `<brief>/.harness/<sample>/`, and the build the checks read is `<brief>/.build/<sample>/`. Triage every failure with ratification/ratification-protocol.md before changing anything.
