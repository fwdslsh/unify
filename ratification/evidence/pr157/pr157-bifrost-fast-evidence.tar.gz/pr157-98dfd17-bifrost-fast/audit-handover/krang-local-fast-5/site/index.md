---
title: Welcome to Fernway Seed Library
schema: WebPage
description: Borrow fresh vegetable and flower seeds from our community library, grow your own garden, and return seed from your harvest at season's end.
og:image: /img/placeholder.svg
---

<div class="hero">
  <h1>🌱 Fernway Seed Library</h1>
  <p>Borrow vegetable &amp; flower seeds for free from our community library, grow your own garden, and return seed from your harvest at season's end.</p>
</div>

<div class="content">
  <h2>How It Works</h2>
  <p>We collect and condition seeds from volunteer growers across the neighbourhood. Each growing season you may borrow a selection of seeds — enough for your plot or balcony garden — at no cost. At harvest's end you return fresh, saved seed to replenish the library for next year.</p>

  <div class="info-box">
    <h3>Who Can Borrow</h3>
    <p>Every local gardener and grower is welcome. No membership fee, no fine — just a commitment to share your harvest back with the community.</p>
  </div>

  <h2>What We Grow</h2>
  <p>We specialise in heritage varieties suited to our growing region: heirloom tomatoes, hardy brassicas, sweet peas, sunflowers, and pollinator-friendly wildflowers. Each batch is conditioned from saved stock over the past year.</p>

  <h2>Get Involved</h2>
  <ul>
    <li><strong>Borrow</strong>&thinsp;— visit us each spring and choose your seeds.</li>
    <li><strong>Grow</strong>&thinsp;— nurture them through the season with our growing notes.</li>
    <li><strong>Return seed</strong>&thinsp;— save and bring back a portion of your harvest to share with neighbours.</li>
  </ul>

  <p>New to this? Visit our <a href="/library/visit.html">Visit page</a> for hours, location, and how borrowing works. Read the latest volunteer stories in <a href="/library/notes/index.html">Notes</a>.</p>
</div>
