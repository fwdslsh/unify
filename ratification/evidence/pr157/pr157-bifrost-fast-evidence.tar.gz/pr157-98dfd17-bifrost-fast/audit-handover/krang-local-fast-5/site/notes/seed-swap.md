---
title: Seed Swap Day Was a Success
date: 2025-11-03
author: Mabel Chen
description: Last Saturday's autumn seed swap brought together twelve families who shared heritage tomato and pea seeds. Over three kilograms of labelled seed changed hands.
og:image: /img/placeholder.svg
---

## A Beautiful Day for Sharing Seed

Last Saturday's autumn seed swap was a lovely surprise — we had not anticipated so many new faces, but twelve families turned up with bags of carefully sorted seed. The highlight was the heritage tomato corner where volunteers from the 1970s swapped notes on flavour profiles.

## What Changed Hands

The numbers tell a good story: over three kilograms of labelled envelopes passed between growers. Marmande tomatoes, Purple Pod beans, and the ever-popular Avon peas were the most popular. Several first-time visitors signed up to borrow in spring.

We are already planning next year's swap date — mark your calendars for an early autumn Saturday again.
