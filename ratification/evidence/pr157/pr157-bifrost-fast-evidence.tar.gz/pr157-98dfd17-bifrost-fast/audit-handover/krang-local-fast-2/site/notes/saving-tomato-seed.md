---
title: Saving tomato seed in our cool climate
author: Maya Lin
date: 2025-10-18
description: Tips and tricks for harvesting viable seed from heritage tomatoes when the growing season is short.
schema: BlogPosting
og:image: /img/post-tomato.svg
---

# Saving tomato seed in our cool climate

This autumn has been unusually mild, which means we had time to ripen some excellent heritage varieties at Fernway. Here's what I learned after thirty years of saving seed back home in the valley.

## Timing is everything

The biggest challenge in a short season is waiting until seeds are fully mature. Tomatoes need a long hang-time on the vine, and sometimes that means leaving fruit behind as frost threatens. Pick slightly green tomatoes late in the season and let them ripen indoors — you still get viable seed that way.

## The fermentation process

Tomato seed comes embedded in a gelatinous coating that must be fermented to remove germination inhibitors. Scoop seeds into a small jar with some pulp, cover loosely, and leave it for three to five days. A layer of mold on top is normal — it means the fermentation is working. After that, rinse the clean seed through a sieve and let them dry completely.

## Storage

Fully dried tomato seed stores well in paper envelopes in the fridge for up to ten years. Label everything with variety and date, and you will have reliable stock year after year.
