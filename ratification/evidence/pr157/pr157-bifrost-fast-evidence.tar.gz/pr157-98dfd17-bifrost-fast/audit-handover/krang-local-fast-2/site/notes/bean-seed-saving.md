---
title: Bean seed saving for beginners
author: Tomáš Kovács
date: 2025-10-05
description: A straightforward guide to harvesting and cleaning dry bean seed, with advice on isolation distances to keep varieties true.
schema: BlogPosting
og:image: /img/post-beans.svg
---

# Bean seed saving for beginners

Dry beans are one of the easiest crops to save seed from, even in a small garden plot. Here is everything you need to know to get started.

## Know your types

There are two kinds of beans when it comes to seed saving: **dry beans** (like runner beans, French beans, and broad beans) which produce seeds inside dry pods, and **green pod beans** (like sweet peas) where the whole seed with the cotyledons is harvested. Both are straightforward, but they need different handling.

## Harvest timing

Wait until the pods on the ground have turned brown and crispy. Shake a pod — if you can hear the seeds rattling inside, it is ready. Pick pods through dry weather; wet harvests risk mould in storage.

## Threshing and cleaning

Simply bash dried bean pods into a bucket, then winnow by pouring the contents slowly between two bowls in a breeze. The light chaff blows away while the heavier seed falls straight down. For broad beans, hand-threshing is quicker on small quantities.

## Storage tips

Dry beans keep for many years when stored cool and dry. Once fully dried to a rattling point, store them in sealed containers with a desiccant packet. A label with variety and year will remind you of the age — test germination before planting older stock.
