---
title: Seed Saving Tips for Heirloom Tomatoes
layout: /_layout.html
date: 2025-11-02
author: Maya Patel
description: Our volunteer seed saver shares practical methods for drying, storing, and labeling heirloom tomato seeds so they stay viable through the winter.
og:image: /seed-placeholder.svg
schema: BlogPosting
---

# Seed Saving Tips for Heirloom Tomatoes

It has been a long growing season here at Fernway, and now is the time we all look forward to — seed saving. There is something almost magical about pulling a tomato pod apart in January, knowing that next spring its descendants will go back into garden beds across our neighbourhood.

Heirloom tomatoes are our most popular lending variety. Members borrow them because every packet carries genetics that have thrived locally for decades, adapted through seasons of trial and honest sharing. But heirloom seeds only persist if someone saves them, cleans them properly, and stores them well.

## Choosing the right fruit

Start with healthy, ripe tomatoes from plants free of disease. Pick fruits that are fully coloured — deep red, golden yellow, or purple-black depending on the variety. The most reliable seeds come from firm, fully ripened fruits taken near the middle of the plant, not from early-season or late-season stragglers.

## Fermentation is your friend

Tomato seeds are wrapped in a gel-like coating that carries germination inhibitors. You need to remove it. Scoop seeds and pulp into a small jar, add an equal volume of water, cover with a cloth, and leave it on the counter for three to five days. A sour smell means fermentation is working. When you see a layer of mould on top — grey, not green — the viable seeds have sunk to the bottom and the rest will float away.

## Drying and storing

Rinse the settled seeds through a sieve, spread them on a plate or ceramic tile, and let them dry for at least one week in a well-ventilated room. Once they rattle when you shake the container, pack them into a small paper envelope with the variety name, date saved, and your initials. Store in a cool, dark place until spring planting time.

Every seed returned to our library is sorted, re-packed, and labelled so the next grower knows exactly what they are planting. Thank you to everyone who has already brought back their first round of tomato seed this year.
