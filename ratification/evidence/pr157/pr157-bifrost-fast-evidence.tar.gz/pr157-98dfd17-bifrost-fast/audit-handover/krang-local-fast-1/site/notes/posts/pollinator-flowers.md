---
title: Pollinator Flowers — Planting for the Long Run
layout: /_layout.html
date: 2025-08-05
author: Lena Okonkwo
description: How to grow, save, and share flower seeds from our pollinator collection so beneficial insects return every summer.
og:image: /seed-placeholder.svg
schema: BlogPosting
---

# Pollinator Flowers — Planting for the Long Run

The Fernway Seed Library has quietly expanded its flower seed section over the past few years. Where once we offered a single packet of sunflowers and some borage, our shelves now hold borage, cosmos, sweet pea, cornflower, amaranth, and several native goldenrod species. This growth was not planned around aesthetics alone — it followed a clear pattern from members who asked for pollinator-friendly seeds after exhausting the vegetable packets.

## Why flowers matter to vegetable growers

If you grow vegetables without planting flowers nearby, you are missing half of your pollination strategy. Bees hover between crops, yes, but they need continuous bloom from early spring through late autumn to stay in the area. Native goldenrod, for instance, blooms late and is one of the last reliable nectar sources bees rely on before winter.

## Growing tips by variety

**Cornflower** — self-seeds readily if you let a few flower heads dry on the plant. Shake them into a bag at first sign of browning, then store in a paper envelope. The seeds stay viable for four to five years when kept cool and dry.

**Cosmos** — annuals that bloom non-stop until frost. They do not need saving; every packet you sow this spring will produce seed for next year if you leave the spent blooms on the stem rather than deadheading.

**Sweet pea** — an overwintering challenge in our zone, but worth it. The pods must be left on the vine until they turn brown and papery. Harvest early in dry weather to avoid mould. Save a portion for yourself and return the rest to the library so others can try this fragrant staple.

## Returning what you save

Every flower seed returned should come with at least one sentence about how it performed that season — planting date, whether it came up through winter mulch, when first bloom appeared. That context helps future growers choose wisely. We compile these notes into a small booklet each autumn and distribute them at our January sorting event.
