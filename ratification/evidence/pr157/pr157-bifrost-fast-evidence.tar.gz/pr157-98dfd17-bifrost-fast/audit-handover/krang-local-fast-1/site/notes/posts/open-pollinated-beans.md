---
title: Why We Focus on Open-Pollinated Beans
layout: /_layout.html
date: 2025-09-18
author: Tom Eshelman
description: An overview of open-pollinated bean varieties in our library, why they matter for seed sovereignty, and how to select pods for next year's saving.
og:image: /seed-placeholder.svg
schema: BlogPosting
---

# Why We Focus on Open-Pollinated Beans

If you have browsed our seed shelves this spring, you may have noticed that we carry almost exclusively open-pollinated beans — no hybrids, no GMO lines. That is deliberate. It goes to the heart of what a seed library does and why it exists at all.

## What open-pollinated means

Open-pollinated seeds come from plants that fertilise themselves or pollinate through wind, insects, or birds. Their offspring reliably reproduce the parent's traits. That stability is exactly what makes saving possible: you plant one variety, save seed from its pods, and next year you grow the same thing again. Hybrid varieties simply cannot do this — their seeds segregate in unpredictable ways.

## Varieties we lend

Our current collection includes:

- **Scarlet Runner** — a vigorous climber with stunning red-orange flowers that attract hummingbirds. The beans are large and flavourful when cooked young.
- **Jacob's Cattle** — a New England heirloom with striking striped seeds, known for cold tolerance in northern Ontario.
- **Rosa de Mayo** — a pink-seeded pole bean from Mexico, popular for its sweet, tender pods used in traditional May Day dishes.
- **Hoppertone** — a low-moisture storage bean that keeps through winter without drying hard.

Each of these has been tested in our region over multiple seasons and proved reliable. We grow them in the library's shared plot each year to refresh stock, then lend what we do not need for planting.

## Selecting pods for saving

When you harvest beans for seed saving, wait until the pods are fully dry on the vine — brown, rattling pods are ideal. Shuck them indoors, winnow gently to remove chaff, and let the seeds rest at room temperature in a humid environment for two weeks. This conditioning improves germination rates noticeably.

Store your saved beans in paper bags with variety name, year, and your signature on the outside. Bring them back during our autumn return days, or drop them off any Tuesday during open hours.
