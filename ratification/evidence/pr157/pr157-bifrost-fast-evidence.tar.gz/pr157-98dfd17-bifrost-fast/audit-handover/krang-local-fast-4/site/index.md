---
title: Home
layout: /_layout.html
description: Fernway Seed Library — borrow vegetable and flower seeds for your garden, return fresh seed at season's end.
schema: WebPage
---

<section class="hero">
  <div class="hero-inner">
    <svg width="80" height="80" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <circle cx="16" cy="16" r="15" fill="#4a7c59"/>
      <ellipse cx="16" cy="18" rx="4" ry="6" fill="#e8dcc8"/>
      <path d="M16 12 Q13 8, 10 9" stroke="#7cb87a" stroke-width="1.5" fill="none"/>
    </svg>
    <h1>Fernway Seed Library</h1>
    <p class="tagline">Borrow seeds. Grow your garden. Return fresh seed at season's end.</p>
  </div>
</section>

<section class="content">
  <h2>Welcome to the library</h2>
  <p>Every growing season, Fernway Seed Library opens its shelves of vegetable and flower seeds to local growers. Borrow what you need for your plot, receive expert guidance from our volunteers, and at season's end return whatever seed you've saved — replenishing the collection for next year.</p>

  <h2>How it works</h2>
  <ol>
    <li><strong>Borrow</strong> — browse our shelves and pick seeds for your garden.</li>
    <li><strong>Grow</strong> — tend, harvest, and save seed from your crops.</li>
    <li><strong>Return</strong> — bring your saved seed back at season's end to refill the library for others.</li>
  </ol>

  <p>We grow on trust. Every return strengthens our shared collection of heirloom and locally-adapted varieties.</p>
</section>

<section class="cta">
  <a href="/library/visit/">Plan your visit &rarr;</a>
</section>
