---
title: Home
layout: /_layout.html
---

<h2>Welcome to Fernway Seed Library</h2>

<p>Fernway Seed Library is a community resource that lets local growers borrow
high-quality vegetable and flower seeds each season, then return fresh seed from their own harvest at the end.</p>

<p>We believe every gardener should start with strong genetics. By lending you the
best of what our region grows, we keep seeds adapted to local soil, climate,
and disease pressure — and strengthen neighbour-to-neighbour ties along the way.</p>

<h3>How it works</h3>

<ol>
  <li><strong>Visit us</strong> during open hours at the Fernway Community Centre.</li>
  <li><strong>Borrow seeds</strong> — pick whatever you need for your plot, balcony or windowsill.</li>
  <li><strong>Grow all season</strong>.</li>
  <li><strong>Return seed</strong> from your harvest — clean, labelled, and ready to lend again.</li>
</ol>

<p>No membership fee. Just a willingness to share what you grow with someone
who needs it next spring.</p>

<p>We host free seed-saving workshops each autumn and welcome volunteer
seed-keepers year-round. Drop in anytime and ask — we love talking about seeds.</p>
