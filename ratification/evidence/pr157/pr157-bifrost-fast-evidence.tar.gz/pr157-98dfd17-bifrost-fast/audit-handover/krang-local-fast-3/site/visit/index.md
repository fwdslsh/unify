---
title: Visit
layout: /_layout.html
---

<h2>Visit Us</h2>

<p>The Fernway Seed Library is open to everyone — gardeners, hobbyists, and first-time growers alike.</p>

<h3>Where we are</h3>

<p>Fernway Community Centre&#160;—<br>
472 Evergreen Drive<br>
Maple Ridge, BC &#8236; V2X 5K9</p>

<h3>Open hours</h3>

<table>
  <tr><td>Tuesday&nbsp;&nbsp;&nbsp;</td><td>10:00 – 17:00</td></tr>
  <tr><td>Thursday</td><td>10:00 – 17:00</td></tr>
  <tr><td>Saturday</td><td>9:00 – 13:00</td></tr>
</table>

<p>We close for lunch midday Tuesday and Thursday. Seed distribution runs each
March through May and September through October.</p>

<h3>Borrowing rules</h3>

<ol>
  <li><strong>Bring a neighbour</strong> — any local grower may borrow seeds at your next visit.</li>
  <li><strong>Return with seed</strong> — clean and labelled, the same variety you borrowed (or close to it).</li>
  <li><strong>No penalties</strong> — if you lose a batch just return what you can. We learn from each season together.</li>
</ol>

<h3>Getting in touch</h3>

<p>Email: <a href="mailto:seeds@fernway.example">seeds&#64;fernway.example</a><br>
Phone: 604-555-2187</p>
