---
title: Seed-Saving Basics — What to Label First
date: 2026-09-15
author: Mara Lin
description: A quick guide to labelling and storing seed correctly so every variety keeps true through the next planting season.
layout: /_layout.html
og:image: /library/notes/images/seeds.jpg
---

## Seed-Saving Basics

After the first frost lifts, it's time to collect, clean, and label your seed.
Here's what we wish every grower knew on day one.

### 1. Harvest at maturity

Wait until pods are brown and dry on the vine — not green. Green seed looks ripe
but won't germinate reliably. Give beans, lettuce, and tomatoes a few extra days
on the plant before pulling them in to finish drying indoors.

### 2. Keep notes while fresh

Label immediately after cleaning. Write the **variety**, **date collected**, and
**growing location**. A tiny note inside each envelope prevents confusion come
spring. We've lost "Red Kettle" beans more times than we can count because a label
fell off and another grower's seeds ended up in that envelope instead.

### 3. Store cool, dry, dark

Paper envelopes in the fridge work better than plastic bags. If you must use
plastic, add a silica-gel packet and never seal it warm — condensation kills
vitality fast.

We keep a spare set of seed boxes at Fernway so every volunteer has backup copies
to lend if their home stash fails. It's saved our lending library twice now.
