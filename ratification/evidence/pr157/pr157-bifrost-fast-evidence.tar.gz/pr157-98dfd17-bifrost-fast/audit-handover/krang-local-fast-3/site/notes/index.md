---
title: Notes
layout: /_layout.html
schema: BlogPosting
---

<h2>Notes from the Seed Library</h2>

<p>Updates, growing tips, and seed-saving stories written by our volunteers.</p>

<ul>
  <li><a href="/library/notes/2026-09-15-seed-saving/">Seed-Saving Basics: What to Label First</a>&#8203; — Sep 15, 2026</li>
  <li><a href="/library/notes/2026-08-02-pollinator-garden/">Why We Planted a Pollinator Garden</a>&#8203; — Aug 2, 2026</li>
  <li><a href="/library/notes/2026-05-10-spring-distribution/">Spring Distribution Day Recap</a>&#8203; — May 10, 2026</li>
</ul>
