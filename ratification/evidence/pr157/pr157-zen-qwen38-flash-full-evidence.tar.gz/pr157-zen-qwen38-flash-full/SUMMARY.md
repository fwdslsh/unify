# Ratification round pr157-zen-qwen38-flash-full

- **unify** 0.11.18 at `83bc115168cb` (working tree)
- **rules** `fb07d931bd36` · **prompt** `456131468750` · **agent** opencode 1.18.25 · **models** krang/opencode-zen/qwen3.8-flash · **isolation** mount namespace, probe clean
- 2026-11-09T00:23:54.424Z to 2026-11-09T00:37:44.903Z; scored 2026-11-09T00:37:44.934Z

## Score

**14 of 35 samples completed their brief: every scored check passed (40%).**

The protocol's bar, at least 4 of 5 samples of a model on each brief: **not met**.

| Brief | Model | Passed | Checks that failed |
|---|---|---|---|
| audit-handover | krang/opencode-zen/qwen3.8-flash | 4/5 | agent-finished (1) |
| callouts | krang/opencode-zen/qwen3.8-flash | 5/5 | — |
| council-panel | krang/opencode-zen/qwen3.8-flash | 2/5 | agent-finished (3), publish-command (2), strict-build (2), fresh-build (2), addresses (2), drafts-unpublished (2), bare-fragment (2) |
| photo-banners | krang/opencode-zen/qwen3.8-flash | 3/5 | agent-finished (2), publish-command (2), strict-build (2), fresh-build (2), addresses (2), css-urls (2) |
| publishing | krang/opencode-zen/qwen3.8-flash | 0/5 | agent-finished (5), publish-command (5), strict-build (5), fresh-build (5), addresses (5), feed (5), article-data (5), share-cards (5) |
| seed-catalogue | krang/opencode-zen/qwen3.8-flash | 0/5 | agent-finished (5), publish-command (5), strict-build (5), fresh-build (5), addresses (5), drafts-and-export-unpublished (5), private-data (5), variety-pages (5) |
| svelte-estimator | krang/opencode-zen/qwen3.8-flash | 0/5 | agent-finished (5), publish-command (5), strict-build (5), fresh-build (5), addresses (5), drafts-unpublished (5) |

## audit-handover — Hand over only when every check the tool offers reports nothing

*round 28; checks follow its pre-registered V1-V4, plus the brief's extensionless addresses.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | audit-strict | article-data | share-cards | ran-audit | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 10m11s | 49 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | 12m06s | 109 | $0.00 | ✗ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | fail |
| krang-opencode-zen-qwen3-8-flash-3 | 6m35s | 55 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-4 | 6m23s | 42 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-5 | 5m22s | 45 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |

- krang-opencode-zen-qwen3-8-flash-1 · **ran-audit** (not scored): 9 runs matching /unify audit/
- krang-opencode-zen-qwen3-8-flash-2 · **agent-finished**: exit 1, agent error: Insufficient account funds, wrote REPORT.md
- krang-opencode-zen-qwen3-8-flash-2 · **ran-audit** (not scored): 19 runs matching /unify audit/
- krang-opencode-zen-qwen3-8-flash-3 · **ran-audit** (not scored): 9 runs matching /unify audit/
- krang-opencode-zen-qwen3-8-flash-4 · **ran-audit** (not scored): 7 runs matching /unify audit/
- krang-opencode-zen-qwen3-8-flash-5 · **ran-audit** (not scored): 7 runs matching /unify audit/

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> **What `rules.md` did not answer — the sentence I wanted.** It never documents
> `unify audit` at all: no sentence like "the checks beyond the build are `unify audit`, whose
> non-blocking findings — advisories and `incomplete` — only fail the exit code under
> `--strict`, and whose `--external` check fetches off-origin URLs." The brief demands
> every check including the non-blocking ones, and rules.md's only mention of checks is the
> one line about `build --dry-run --strict`. I found audit from `./unify --help`, and the
> convention (`build --audit --strict` before publishing) from the `unify init` scaffold's
> own README.md and DEPLOY.md. Second gap: how a `generate:` script is run. The sentence I
> wanted was "unify hands it argv[2] the source root, argv[3] an overlay directory whose
> files join the build as ordinary pages, and argv[4] generator-context.json, which names
> source-pages.json." rules.md says only "it writes into the directory unify hands it" —
> what that directory is, and the whole shape of source-pages.json, are absent; I took them

**krang-opencode-zen-qwen3-8-flash-2**

> ## 4. What `rules.md` did not answer
> 
> The single biggest hole: **how the generator is invoked.** The sentence I wanted and could not find
> is something like *"unify runs the generator with three arguments: the source root, the directory it
> hands you to write into, and a JSON context file naming the source inventory."* What the doc says is
> only "unify runs it before every build and it writes into the directory unify hands it, never into
> `site/`". I found `argv = [unify, script, sourceRoot, generatedRoot, generator-context.json]`, the
> `paths`/`site`/`inputs` shape of the context file, and `inputs.sourcePages` by printing them from a
> throwaway script. Nothing in the doc mentions `generator-context.json` at all.
> 
> Second: **the inventory reports only authored values.** `rules.md` says a Markdown page with no
> `title:` takes its title from the first `# Heading` — true of the page — and `--help` calls the file it

**krang-opencode-zen-qwen3-8-flash-3**

> **What `rules.md` did not answer — the sentence I wanted and could not find.**
> Nothing in the file tells you how a generator is actually invoked. The sentence I kept
> looking for was some form of *"unify runs it as `node gen.mjs <sourceRoot> <generatedRoot> <context.json>`"*:
> "it writes into the directory unify hands it" never names the handoff — the generated
> root arrives as `argv[3]` and the pointer to `source-pages.json` sits in a context JSON
> (`argv[4]` → `inputs.sourcePages`). I instrumented a probe script and read the printed
> argv to find this. Two more missing sentences: whether `generate:` in `unify.yaml`
> resolves relative to the yaml (it does) or the source root like the `--generate` flag
> (it doesn't — that looked for `site/scripts/` and failed); and whether the inventory's
> "authored title" includes a Markdown page's heading-derived title — it doesn't
> (`title: null`), so the posts keep both a `title:` key *and* an `<h1>` heading, which
> the prose neither requires nor forbids.

**krang-opencode-zen-qwen3-8-flash-4**

> **What `rules.md` did not answer — the sentence I wanted and could not find.**
> There is no sentence describing the generator script's calling contract. `rules.md` says only that the script "writes into the directory unify hands it" — it never says *how* it is handed that directory. I had to write a probe script and print `process.argv` to discover it is invoked as `node gen.mjs <sourceRoot> <generatedOverlayDir> <contextJsonPath>`, and find `ctx.inputs.sourcePages` inside that JSON to read the page inventory. Related gaps:
> - Nothing lists what the checks look for. "Every check the tool offers" was clear (`audit`, `--strict`, `--external`, `build --dry-run --strict`, from `./unify --help`), but rules.md never mentions `h1-missing`, `image-missing-dimensions`, or the `incomplete`/`broken` categories at all — I learned them only by running `audit --strict` and being told.
> - Nothing says whether files written into the generated overlay are still wrapped by the site's `_layout.html` (they are — confirmed in output), and whether a generated `.md` may use frontmatter (it may).
> - Nothing states which options `--save-config` treats as saveable; I inferred baseUrl/pretty-urls/generate from the one-line it echoed.
> 
> **What I had to re-read, and why it did not land the first time.**
> The Files section bullet — one unbroken paragraph mixing source-root resolution, `.fragment.html`, byte-for-byte copying, link spelling under `--pretty-urls` ("write `/about.html`, the build rewrites to `/about/`"), directory links, and `--base-url`. It didn't land because the key rule (always author the `.html` filename, even under pretty-urls) is the *middle* sentence of a seven-sentence paragraph; I had to re-read to be sure the post links in the generated index use `/notes/xxx.html` while the served URLs are pretty. Same for the schema/Markdown paragraph: the rule "a `date` unify cannot read as `2026-01-02` or `2026-01-02T09:30:00Z` is left out and reported" sits at its end — I first wrote quoted dates without checking the exact accepted formats, and the earlier feed sentence ("a `date:` with no time is … reported and left out") only made sense on a second pass. The Head bullet's override order (page `<meta>` replaces layout's same-name; `og:` defaults to final title/description/canonical) also took a second read to see that I only needed `og:image*` per post and no hand-written `og:title`.
> 
> **What I guessed or inferred rather than read.**
> - The generator's argv/context contract — inferred by probing (see above); rules.md documents none of it.
> - That the generator's output md should declare `layout: /_layout.html` rather than rely on nearest-layout discovery across the overlay — a guess; the dry-run shows it resolved.

**krang-opencode-zen-qwen3-8-flash-5**

> ## What `rules.md` did not answer
> 
> **The sentence I wanted most and could not find:** something like *"unify runs the
> generate script with three arguments — the source root, the generated overlay
> directory it may write into, and a JSON context file naming `inputs.sourcePages`"* .
> `rules.md` only says the script "writes into the directory unify hands it" without
> ever saying **how the directory is handed over** (argv? env? cwd?), nor that the
> hand-written script receives the pages' titles/dates via the source inventory. I
> found the contract by making `scripts/gen.mjs` print `process.argv`, `process.cwd()`
> and a directory listing during a dry-run build. Even the inventory itself
> (`--source-inventory`, "on by default with `--generate`") exists only in `--help`,
> not in `rules.md` at all.


## callouts — One equipment callout in ten places with different words, its border changed in one file

*round 26, the slotted-include ship condition (conformance spec §32.7).*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-unpublished | no-slot-shipped | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 6m43s | 53 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | 8m57s | 94 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-3 | 8m43s | 41 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-4 | 8m56s | 49 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-5 | 5m57s | 38 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> ## 1. What `rules.md` did not answer
> 
> The sentence I wanted and could not find: *what the `generate` script is passed.*
> Line 6 says the script "writes into the directory unify hands it" and nothing names
> the hand. I had to run the script printing `process.argv` to learn it is handed
> `(sourceRoot, generatedOverlay, contextJsonPath)`, and find the context JSON's
> `inputs.sourcePages` path (the inventory file) there — `--help` names the inventory
> but not these. Related: nothing states that **generated overlay files get the same
> layout merging, link rewriting and `--pretty-urls` treatment as source pages**; I
> observed `← generated + _layout.html` in the dry-run listing and trusted it after
> that.

**krang-opencode-zen-qwen3-8-flash-2**

> **1. What rules.md did not answer.** The sentence I wanted and could not find: what
> arguments and what environment a generator script is actually run with. rules.md says
> "unify runs it before every build and it writes into the directory unify hands it" — it
> never says how that directory is handed to the script (argv? env var?). I had to
> print `process.argv` and `generator-context.json` from a throwaway script to learn the
> contract: `argv[2..4] = sourceRoot, overlay, contextPath`, plus `--source-inventory`'s
> JSON path. rules.md also never says generated overlay files are treated as source pages
> (i.e. that a `<include>` or `data-layout` inside them is processed); I inferred it from a
> probe and confirmed it by grepping the built output. And it never says the source-pages
> inventory reports `title: null` for a Markdown page whose title comes from its first `#`
> heading — the "no `title:` → first `# Heading`" rule applies to the rendered page, not to
> the inventory I feed `gen.mjs`, which I discovered only when the built log index listed

**krang-opencode-zen-qwen3-8-flash-3**

> ## 1. What `rules.md` did not answer
> 
> The interface of the `generate` script. "unify runs it before every build and it writes into the
> directory unify hands it" — the sentence I wanted and could not find is: *"your script is invoked
> with the source root, the generated-overlay directory, and a JSON context file as argv 2–4"* (and
> what is inside that context). The CLI help adds that the script gets `source-pages.json`, but
> neither says the overlay is a first-class source. I probed with a throwaway site and found argv =
> `[unify, script, sourceRoot, overlay, generator-context.json]`, the context carrying `baseUrl`,
> `prettyUrls`, `outputRoot`, `inputs.sourcePages` — and, crucially, that files written into the
> overlay behave like real pages (they get the nearest `_layout.html`, title joining, and the
> `--base-url`/`--pretty-urls` link rewrites).

**krang-opencode-zen-qwen3-8-flash-4**

> ## What `rules.md` did not answer — the sentence I wanted and could not find
> 
> The generator contract. The one relevant sentence is "unify runs it before every build and it
> writes into the directory unify hands it, never into `site/`" — but nowhere does it say *how*
> the directory is handed. I wanted: "your script is called as
> `gen.mjs <sourceRoot> <generatedRoot> <context.json>`" — that is what the probe of argv
> showed, plus the context naming `inputs.sourcePages`. Also never stated: the shape of
> `source-pages.json` (I dumped one and read it), whether a page written into the generated
> overlay is wrapped by the site's `_layout.html` like an authored page (it is), and whether
> `--generate` (help: "a relative path is from the source root") and the yaml key `generate:`
> resolve from the same base — they do not: the yaml path resolves from the working directory,
> which is the only reading that makes "kept in `scripts/` beside the site" true. Nothing says

**krang-opencode-zen-qwen3-8-flash-5**

> ## 1. What `rules.md` did not answer
> 
> The generate-script contract. The sentence I wanted and could not find: **"unify invokes
> your script with `argv = [node, script, sourceRoot, generatedRoot, contextJsonPath]`"**
> (or anything like it). rules.md says only that the script "writes into the directory unify
> hands it" — it never says *how* the directory is handed: argv, an env var, the cwd? I had
> to write a probe script that dumped `process.argv` and a `generator-context.json` to learn
> the three positional arguments and the `inputs.sourcePages` inventory path. Nothing in the
> docs says the generated files are then treated as source pages, nor that they get wrapped
> by the site's `_layout.html` — I inferred both from the build report (`log/index.html
> ← generated + _layout.html`).


## council-panel — A bare opening-hours panel another site fetches, kept in one place, and month lists fetched on demand

*round 23, the first exposure of *.fragment.html.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-unpublished | bare-fragment | fetch-targets | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 7m52s | 52 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | 7m11s | 36 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-3 | 8m20s | 34 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-opencode-zen-qwen3-8-flash-4 | 7m59s | 31 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-opencode-zen-qwen3-8-flash-5 | 7m52s | 42 | $0.00 | ✗ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | fail |

- krang-opencode-zen-qwen3-8-flash-1 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-opencode-zen-qwen3-8-flash-2 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-opencode-zen-qwen3-8-flash-3 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-3 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-3 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-3 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-3 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **drafts-unpublished**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **bare-fragment**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **fetch-targets** (not scored): 0 of 0 resolved, 0 built at runtime
- krang-opencode-zen-qwen3-8-flash-4 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-4 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-4 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-4 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-4 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-4 · **drafts-unpublished**: no build output
- krang-opencode-zen-qwen3-8-flash-4 · **bare-fragment**: no build output
- krang-opencode-zen-qwen3-8-flash-4 · **fetch-targets** (not scored): 0 of 0 resolved, 0 built at runtime
- krang-opencode-zen-qwen3-8-flash-5 · **agent-finished**: exit 1, agent error: Insufficient account funds, wrote REPORT.md
- krang-opencode-zen-qwen3-8-flash-5 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> ## 3. What `rules.md` did not answer
> 
> - **How the generator is invoked.** The docs say it "writes into the directory unify hands it"
>   — that is all. The sentence I wanted, and could not find, is the calling convention: *what
>   arguments, and where does it write so unify picks the files up*. I discovered by experiment
>   that the script gets `argv[2]=source root, argv[3]=generated overlay, argv[4]=context JSON`,
>   that the context names `site.baseUrl`, `site.prettyUrls`, and `inputs.sourcePages` (the page
>   inventory), and that HTML written into the overlay is composed like a real page (layout,
>   rewriting, canonical all applied) while a `.fragment.html` written there ships raw. None of
>   that is written down anywhere.
> - **Whether `--pretty-urls` touches fragments.** The docs define pretty-urls as
>   `about.html → about/index.html` and define fragments as shipped "as written"; the interaction

**krang-opencode-zen-qwen3-8-flash-2**

> ## What `rules.md` did not answer
> 
> **Whether a generator's output is composed like a page or shipped verbatim.** The sentence I
> wanted and could not find, on line 6 — "it writes into the directory unify hands it" — stops
> exactly there. Nothing distinguishes the two `milling/index.html` outcomes (a composed
> document with chrome) from the fragments (verbatim copies). The dry-run report label
> `← generated + _layout.html` is the only place the behavior appears, and I found it by
> getting it wrong: my first generator hand-spliced the header and footer into the index, and
> the build wrapped them in the layout chrome too — two mastheads, one list, a doubled title.
> `unify audit` had even told me my probe page was "composed with no layout"; I read that as
> "generated files never get a layout", when it really meant "my probe had no `_layout.html`
> to find". Once I knew the rule, the generated index became a plain page-shaped document

**krang-opencode-zen-qwen3-8-flash-5**

> ## What `rules.md` did not answer
> 
> The sentence I wanted and could not find: something like *"URL attributes inside a shipped
> `*.fragment.html` are/are not rewritten."* §Files says fragments ship "as written"; §Styles
> says unify "rewrites only HTML's own URL attributes (`href`, `src`)". Both sentences are
> true and they disagree for this one file, and the whole design (no links in the panel;
> page-relative links baked by the generator into the month fragments) turns on which wins.
> Experiment decided it: shipped bytes win, the included copy is rewritten separately.
> 
> Also unanswerable from the rules, and learned by probing: that a generated (overlay) page
> participates in nearest-`_layout.html` wrapping, title join, and link rewriting — the rules
> say a derived index "comes from a script", not that the script's output is composed like a


## photo-banners — Photo banners on every section under a subpath, with extensionless addresses

*round 22: does anyone ship a root-relative url() that 404s under the subpath.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | css-urls | Result |
|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 7m49s | 36 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-opencode-zen-qwen3-8-flash-2 | 5m32s | 37 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-3 | 4m56s | 32 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-4 | 4m54s | 32 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-5 | 7m30s | 22 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |

- krang-opencode-zen-qwen3-8-flash-1 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-1 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-1 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-1 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-1 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-1 · **css-urls**: no build output
- krang-opencode-zen-qwen3-8-flash-5 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-5 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-5 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-5 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-5 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-5 · **css-urls**: no build output

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-2**

> ### What `rules.md` did not answer — the sentence I wanted and could not find
> 
> The rules explain `--base-url` and `--pretty-urls` **separately**, each in its own bullet, and
> never show them **together**. There is no sentence anywhere stating that a link I wrote as
> `/visit.html`, under both flags, becomes `https://alderfen.pages.dev/arboretum/visit/` — base
> prefix *and* pretty rewrite composed. I wanted one worked example proving the two flags stack
> cleanly rather than fight (e.g. base-prefix a `.html` that pretty-urls has already removed).
> I had to trust the composition and then verify by reading the literal `href=` values in the
> built `dist/` files.
> 
> A second sentence I looked for and did not find: whether Markdown `title:` frontmatter takes
> part in the separator-join rule (that rule is written entirely for HTML `<title>`:

**krang-opencode-zen-qwen3-8-flash-3**

> ## What `rules.md` did not answer
> 
> The sentence I looked for and could not find: **what counts as the "real filename" when
> linking to a Markdown page.** The rules say "Always link the real filename — `/about.html`,
> not `/about/`", but every example is an `.html` source, and the real filename of the oaks
> guide is `oaks.md`. I wrote `/collections/guides/oaks.html` and got silence from a strict
> audit and the right `/arboretum/collections/guides/oaks/` in the output — proof after the
> fact, not an answer.
> 
> Other things the documentation left open:
> 
> - Whether `--pretty-urls` turns the home page into `index/index.html`. The spec sentence

**krang-opencode-zen-qwen3-8-flash-4**

> ## What `rules.md` did not answer
> 
> - **Links to Markdown pages.** The docs say to link the real filename (`/about.html`, not
>   `/about/`) and that this "stays true under `--pretty-urls`" — but only ever for `.html`. Nowhere
>   is it stated that you write `oaks.md` and the build rewrites it to `/collections/guides/oaks/`.
>   The sentence I wanted and could not find: "a link to a `.md` page names its `.md` file." I wrote
>   `/collections/guides/oaks.md` on the collections page as the obvious extrapolation; the clean
>   strict audit and my link-walk confirmed it.
> - **Front matter `title` and the body `<h1>`.** Nothing says whether `title: "The Oaks"` also
>   renders a heading. I guessed it would and omitted an `# heading`; `audit` reported
>   `h1-missing`, telling me unify deliberately emits no `<h1>` for a titled page — the inverse of
>   what "No `title:` → first `# Heading`" almost implies. Added `# The Oaks` etc.


## publishing — Publishing surface: schema:, og: share cards, dated posts, a feed, a subpath

*round 27, re-run unchanged in round 29; checks follow round 27's pre-registered V1-V5.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | feed | article-data | share-cards | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 5m40s | 44 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-opencode-zen-qwen3-8-flash-2 | 5m20s | 41 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-opencode-zen-qwen3-8-flash-3 | 5m18s | 31 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-opencode-zen-qwen3-8-flash-4 | 4m45s | 38 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-opencode-zen-qwen3-8-flash-5 | 4m21s | 31 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |

- krang-opencode-zen-qwen3-8-flash-1 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-1 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-1 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-1 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-1 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-1 · **feed**: no build output
- krang-opencode-zen-qwen3-8-flash-1 · **article-data**: no build output
- krang-opencode-zen-qwen3-8-flash-1 · **share-cards**: no build output
- krang-opencode-zen-qwen3-8-flash-2 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-2 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-2 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-2 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-2 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-2 · **feed**: no build output
- krang-opencode-zen-qwen3-8-flash-2 · **article-data**: no build output
- krang-opencode-zen-qwen3-8-flash-2 · **share-cards**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-3 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-3 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-3 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-3 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **feed**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **article-data**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **share-cards**: no build output
- krang-opencode-zen-qwen3-8-flash-4 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-4 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-4 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-4 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-4 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-4 · **feed**: no build output
- krang-opencode-zen-qwen3-8-flash-4 · **article-data**: no build output
- krang-opencode-zen-qwen3-8-flash-4 · **share-cards**: no build output
- krang-opencode-zen-qwen3-8-flash-5 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-5 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-5 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-5 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-5 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-5 · **feed**: no build output
- krang-opencode-zen-qwen3-8-flash-5 · **article-data**: no build output
- krang-opencode-zen-qwen3-8-flash-5 · **share-cards**: no build output

## seed-catalogue — A 225-variety catalogue generated from a JSON export, fetched one family at a time

*round 20; the judge's default marker and privacy fields are this brief's.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-and-export-unpublished | private-data | variety-pages | fetch-targets | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 4m24s | 11 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-opencode-zen-qwen3-8-flash-2 | 4m12s | 20 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-opencode-zen-qwen3-8-flash-3 | 3m45s | 10 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-opencode-zen-qwen3-8-flash-4 | 3m29s | 19 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-opencode-zen-qwen3-8-flash-5 | 2m42s | 13 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |

- krang-opencode-zen-qwen3-8-flash-1 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-1 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-1 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-1 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-1 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-1 · **drafts-and-export-unpublished**: no build output
- krang-opencode-zen-qwen3-8-flash-1 · **private-data**: not checked
- krang-opencode-zen-qwen3-8-flash-1 · **variety-pages**: no build output
- krang-opencode-zen-qwen3-8-flash-1 · **fetch-targets** (not scored): 0 of 0 resolved, 0 built at runtime
- krang-opencode-zen-qwen3-8-flash-2 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-2 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-2 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-2 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-2 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-2 · **drafts-and-export-unpublished**: no build output
- krang-opencode-zen-qwen3-8-flash-2 · **private-data**: not checked
- krang-opencode-zen-qwen3-8-flash-2 · **variety-pages**: no build output
- krang-opencode-zen-qwen3-8-flash-2 · **fetch-targets** (not scored): 0 of 0 resolved, 0 built at runtime
- krang-opencode-zen-qwen3-8-flash-3 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-3 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-3 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-3 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-3 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **drafts-and-export-unpublished**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **private-data**: not checked
- krang-opencode-zen-qwen3-8-flash-3 · **variety-pages**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **fetch-targets** (not scored): 0 of 0 resolved, 0 built at runtime
- krang-opencode-zen-qwen3-8-flash-4 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-4 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-4 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-4 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-4 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-4 · **drafts-and-export-unpublished**: no build output
- krang-opencode-zen-qwen3-8-flash-4 · **private-data**: not checked
- krang-opencode-zen-qwen3-8-flash-4 · **variety-pages**: no build output
- krang-opencode-zen-qwen3-8-flash-4 · **fetch-targets** (not scored): 0 of 0 resolved, 0 built at runtime
- krang-opencode-zen-qwen3-8-flash-5 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-5 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-5 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-5 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-5 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-5 · **drafts-and-export-unpublished**: no build output
- krang-opencode-zen-qwen3-8-flash-5 · **private-data**: not checked
- krang-opencode-zen-qwen3-8-flash-5 · **variety-pages**: no build output
- krang-opencode-zen-qwen3-8-flash-5 · **fetch-targets** (not scored): 0 of 0 resolved, 0 built at runtime

## svelte-estimator — A Svelte component compiled to a browser asset by one repeatable command

*round 24 (round 25 re-ran it with docs/integrations.md seeded); needs the npm registry.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-unpublished | Result |
|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 2m49s | 16 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-opencode-zen-qwen3-8-flash-2 | 2m06s | 18 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-opencode-zen-qwen3-8-flash-3 | 1m39s | 15 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-opencode-zen-qwen3-8-flash-4 | 1m19s | 9 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-opencode-zen-qwen3-8-flash-5 | 1m02s | 10 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |

- krang-opencode-zen-qwen3-8-flash-1 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-1 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-1 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-1 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-1 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-1 · **drafts-unpublished**: no build output
- krang-opencode-zen-qwen3-8-flash-2 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-2 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-2 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-2 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-2 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-2 · **drafts-unpublished**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-3 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-3 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-3 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-3 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-3 · **drafts-unpublished**: no build output
- krang-opencode-zen-qwen3-8-flash-4 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-4 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-4 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-4 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-4 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-4 · **drafts-unpublished**: no build output
- krang-opencode-zen-qwen3-8-flash-5 · **agent-finished**: exit 1, agent error: Insufficient account funds, no REPORT.md
- krang-opencode-zen-qwen3-8-flash-5 · **publish-command**: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-5 · **strict-build**: not judged: no REPORT.md
- krang-opencode-zen-qwen3-8-flash-5 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-5 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-5 · **drafts-unpublished**: no build output

---

`✓` passed, `✗` failed, `(i)` reported but not scored. Each sample's directory is `<brief>/<sample>/`, its OpenCode event stream and session data are in `<brief>/.harness/<sample>/`, and the build the checks read is `<brief>/.build/<sample>/`. Triage every failure with ratification/ratification-protocol.md before changing anything.
