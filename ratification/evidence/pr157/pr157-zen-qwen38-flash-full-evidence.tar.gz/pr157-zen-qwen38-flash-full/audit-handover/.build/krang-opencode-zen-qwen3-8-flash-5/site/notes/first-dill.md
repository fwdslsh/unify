---
title: "A First-Time Borrower's Guide to Dill"
description: "Borrowed a dill packet and unsure what you signed up for? Dill volunteers itself: sow it thick, cut it often, and it seeds for next year by August."
author: "Marta Oyelaran"
date: "2026-08-14T17:00:00Z"
schema: Article
og:image: /assets/seed-card.svg
og:image:width: 1200
og:image:height: 630
---

# A First-Time Borrower's Guide to Dill

*Marta Oyelaran · 14 August 2026*

My first season borrowing from Fernway, the dill packet is what I would point
a new grower at.

## Sow it where you will stand

Dill hates being moved. I sowed a short row beside the kitchen door in April
and simply snipped from it all summer. Nothing to transplant, nothing to
stake.

## Cut often, and it waits to seed

Every time I cut the ferny leaves for the table, the plant branched instead
of running to flower. The cutters get leaves into July; the one plant I left
alone got flower heads by August and fat brown seed heads by September.

## One plant seeds the shelf

That uncut plant gave me two packets' worth of seed to return — one for the
library desk, one to trade at the October swap. If you have dill for
pickling, ask the desk for the breadseed poppy next door. It self-sows the
same honest way, and nobody has ever regretted a second bed of it.
