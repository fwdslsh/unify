---
title: "Snip, Dry, Label: Notes from the Marigold Beds"
description: "What three beds of marigold taught me about drying seed heads and labelling them so next spring's selves know what to sow."
author: "Priya Raman"
date: "2026-10-18T09:00:00Z"
schema: Article
og:image: /assets/seed-card.svg
og:image:width: 1200
og:image:height: 630
---

# Snip, Dry, Label: Notes from the Marigold Beds

*Priya Raman · 18 October 2026*

The June sowing came up thick, and by August the beds along the wall were
shoulder-high flowers. Here is what I did with them come September.

## Cut the heads at dusk

Seed detaches easiest when the plant is turgid with the day's cool water. I snip
whole trusses into a paper bag — never plastic, which sweats — and let the bag
stand open in the shed for a week.

## Dry longer than feels right

A head that crumbles between your fingers is dry; one that bends is not. My
first year I bottled the bendy ones and opened them in spring to grey fuzz.
Six weeks on a screen in the loft, and this year every packet kept.

## Label before you forget, not after

Each envelope gets the variety, the bed it grew in, and the date it was
harvested, written on the envelope itself. "Marigold" is a fair guess in
October and a useless one in March.

## Bring it back

The library's shelves take returned seed on any open Saturday through
November. Roughly one dried head gives a packet's worth — enough to lend four
neighbours and keep one bed for myself.
