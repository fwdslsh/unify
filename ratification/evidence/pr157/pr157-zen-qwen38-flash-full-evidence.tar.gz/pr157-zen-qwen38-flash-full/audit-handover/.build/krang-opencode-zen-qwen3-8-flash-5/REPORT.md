# Fernway Seed Library — handover report

## Publish command

The site's whole address (`https://fernway.example/library/`) and the extension-free
URLs live in `unify.yaml`, so the publish step is:

```
./unify build --clean
```

`./unify build` alone publishes the same output (`clean` was deliberately left out of
`unify.yaml` — `unify audit` refuses to run while that key is set; see below).

## Final output of every check

```
$ ./unify build --clean
exit=0
```

```
$ ./unify build --dry-run --strict
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 3 pages would gain a JSON-LD block
copy dist/assets/seed-card.svg (/library/assets/seed-card.svg) ← assets/seed-card.svg
copy dist/assets/seed.svg (/library/assets/seed.svg) ← assets/seed.svg
copy dist/assets/style.css (/library/assets/style.css) ← assets/style.css
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/beans-came-back/index.html (/library/notes/beans-came-back/) ← notes/beans-came-back.md + _layout.html
write dist/notes/first-dill/index.html (/library/notes/first-dill/) ← notes/first-dill.md + _layout.html
write dist/notes/index.html (/library/notes/) ← generated + _layout.html
write dist/notes/marigold-beds/index.html (/library/notes/marigold-beds/) ← notes/marigold-beds.md + _layout.html
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 11 files to dist/
exit=0
```

```
$ ./unify audit
audit: nothing to report
exit=0
```

```
$ ./unify audit --strict
audit: nothing to report
exit=0
```

```
$ ./unify audit --external
audit: nothing to report
exit=0
```

```
$ ./unify audit --external --strict
audit: nothing to report
exit=0
```

## What `rules.md` did not answer

**The sentence I wanted most and could not find:** something like *"unify runs the
generate script with three arguments — the source root, the generated overlay
directory it may write into, and a JSON context file naming `inputs.sourcePages`"* .
`rules.md` only says the script "writes into the directory unify hands it" without
ever saying **how the directory is handed over** (argv? env? cwd?), nor that the
hand-written script receives the pages' titles/dates via the source inventory. I
found the contract by making `scripts/gen.mjs` print `process.argv`, `process.cwd()`
and a directory listing during a dry-run build. Even the inventory itself
(`--source-inventory`, "on by default with `--generate`") exists only in `--help`,
not in `rules.md` at all.

Other things `rules.md` never said:

- **What the checks check.** `rules.md` mentions only "every check" inside the
  `--dry-run --strict` sentence; the whole `audit` command, its finding classes
  (`broken` / `incomplete` / advisories), and `--external` are `--help`-only. I
  would have wanted: *"audit reads the share tags and links of every emitted page
  and reports broken links, incomplete share metadata, and advisories."*
- **`og:image:width`/`og:image:height` are expected** — `audit` reported all three
  posts as `incomplete` without them; nothing in the rules hints at required image
  dimensions, only that the flat keys are legal.
- **A saved `clean:` in `unify.yaml` breaks `unify audit`** ("unify audit does not
  take --clean"). Nothing warns that options saved for `build` can be invalid for
  the other commands.
- **Whether generated overlay files get layouts applied** — the dry-run later
  printed `← generated + _layout.html`, but the rules don't say derived pages are
  composed like source pages.

## What I had to re-read, and why it did not land the first time

- The **Head bullet** ("`og:title`/`og:description`/`og:url` default to final
  title/description/canonical … No missing value or Twitter tag is invented."). I
  first read "the tags are defaulted for you" and moved on; it took a second pass to
  catch that `og:image` is *never* defaulted — "no missing value is invented" is the
  reason every post must declare `og:image:` itself, or the preview card has no
  image.
- The **`--base-url` / directory-link paragraph** in Files. It is one run-on sentence
  mixing three rules (write the real filename; a directory link needs an
  `index.html`; base-url prefixes and absolutizes). The first time I read only
  "prefixes every link"; it landed on re-read that it is also the switch that makes
  `og:`/canonical absolute for crawlers and produces the feed and sitemap — without
  it, none of the "out in the world" requirements work.
- The **frontmatter-keys paragraph** in Markdown, especially "`og:image:width: 1200`
  is one flat key — a colon inside a name is not nesting". I first parsed it as
  nested YAML (`og:image → width`) and nearly wrote a two-level block; re-reading the
  whole sentence ("…is not nesting; an indented block two levels deep is an error")
  fixed it.

## What I guessed or inferred rather than read

- **The generate-script contract** (argv `[sourceRoot, overlay, context.json]`,
  inventory path inside the context file) — probed empirically, not documented.
- **Unquoted vs quoted dates.** The rules say quote values containing a colon and
  show `2026-01-02T09:30:00Z` as readable; I wrote dates quoted *and* with a time,
  inferring that a bare date would be "reported and left out" of the feed and would
  make the strict check noisy. Full UTC timestamps keep every check silent.
- **`title:` + body `# Heading`** — the rule ("no `title:` → first `# Heading`") made
  me unsure whether a body h1 would be swallowed as a title; I inferred it renders
  as an ordinary heading and verified it in `dist/` before adding it to the other
  posts. The visible byline ("*Priya Raman · 18 October 2026*") is my own choice:
  the brief says "dated posts", which a machine-readable date satisfies, but a
  reader arriving on the URL saw no title or date, so I added both.
- **`scripts/gen.mjs` in `unify.yaml` is relative to the working directory**, not the
  source root — the `--generate` help says relative paths resolve *from the source
  root*, which would put the script inside the published tree; the rules say the
  script sits *beside* the site. I went with the rules' wording and the config
  accepted it.
- **Namespace URIs are not off-site loads.** `@context: "https://schema.org"` and the
  Atom/sitemap XML namespaces ship in the output; I *assumed* "loads nothing from
  another website" targets fetched resources, not identifier URIs, and `--external`
  staying silent agreed.
- **The coordinator runs the checks with no extra flags**, so anything `--save-config`
  stored must be valid for all commands — that is why `clean:` lives only on the
  publish command line.
