---
title: "What the Beans Came Back With"
description: "Autumn returns at the library desk: which runner-bean lines gave fresh seed true to type, and which came home as something else entirely."
author: "Tomás Herrera"
date: "2026-09-02T08:30:00Z"
schema: Article
og:image: /assets/seed-card.svg
og:image:width: 1200
og:image:height: 630
---

# What the Beans Came Back With

*Tomás Herrera · 2 September 2026*

Fourteen packets of Scarlet Emperor went out in April. Eleven came back in
August, most of them heavier than what was borrowed. A few lessons from the
returning tin.

## Bees mix, and that is the gift

Two plants flowered within a metre of the old courser's white bean, and the
saved seed shows the mix: pinkish flecks where the line should have been
plain. Nothing wrong with it — the flecked plants grew strong next spring.
Isolation is a seed-saver's problem, not a neighbour's.

## Take seed from the middle pods

The first and last pods on a truss ripen unevenly. The three or four middle
pods, picked when they rattle, gave the cleanest, most even germination of
the whole desk count.

## A return is a letter to next year

Whoever opens these envelopes in March will never meet the grower who filled
them. Write them something worth reading: the bed, the season, one line on
how the crop behaved.
