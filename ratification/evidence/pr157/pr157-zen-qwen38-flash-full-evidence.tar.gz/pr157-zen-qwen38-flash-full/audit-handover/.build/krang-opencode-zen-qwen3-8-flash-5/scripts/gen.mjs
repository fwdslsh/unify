import fs from "node:fs";
import path from "node:path";

const [sourceRoot, overlayRoot, ctxPath] = process.argv.slice(2);
const context = JSON.parse(fs.readFileSync(ctxPath, "utf8"));
const inventory = JSON.parse(fs.readFileSync(context.inputs.sourcePages, "utf8"));

const MONTHS = ["January", "February", "March", "April", "May", "June", "July",
  "August", "September", "October", "November", "December"];

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function prettyDate(iso) {
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  if (!match) return iso;
  return `${Number(match[3])} ${MONTHS[Number(match[2]) - 1]} ${match[1]}`;
}

function metaValue(page, key) {
  const entry = page.meta.find((m) => m.name === key || m.property === key);
  return entry ? entry.content : null;
}

const posts = inventory.pages
  .filter((page) => page.source.startsWith("notes/") && page.date)
  .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : a.source.localeCompare(b.source)));

const items = posts.map((page) => {
  const author = metaValue(page, "author");
  const meta = [
    page.date ? `<time datetime="${escapeHtml(page.date)}">${escapeHtml(prettyDate(page.date))}</time>` : "",
    author ? `by ${escapeHtml(author)}` : "",
  ].filter(Boolean).join(" · ");
  return [
    "      <li>",
    `        <h2><a href="${escapeHtml(page.href)}">${escapeHtml(page.title)}</a></h2>`,
    `        <p class="post-meta">${meta}</p>`,
    page.description ? `        <p>${escapeHtml(page.description)}</p>` : "",
    "      </li>",
  ].filter(Boolean).join("\n");
}).join("\n");

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Notes</title>
<meta name="description" content="Field notes from Fernway Seed Library volunteers: saving, swapping, and returning seed, newest first.">
</head>
<body class="notes-index">
<main>
  <h1>Notes from the beds</h1>
  <p>Field notes by the volunteers who keep the shelves stocked, newest first.</p>
  <ul class="post-list">
${items}
  </ul>
</main>
</body>
</html>
`;

fs.mkdirSync(path.join(overlayRoot, "notes"), { recursive: true });
fs.writeFileSync(path.join(overlayRoot, "notes", "index.html"), html);
