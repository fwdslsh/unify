---
title: "Returning seed: what good looks like"
date: 2026-09-27T09:00:00Z
author: Omar Haddad
description: "How to dry, clean, and label the seed you bring back at season's end, with the faults to avoid."
og:image: /assets/note-card.svg
og:image:width: 1200
og:image:height: 630
schema: BlogPosting
class: notes
---

# Returning seed: what good looks like

Every fall the shelves fill up with envelopes, and some are better than
others. Here is what the sorting team looks for.

**Fully dry, always.** A seed that rattles is a seed that keeps. If you can
squeeze a pod without a snap, it needs more shelf time.

**Cleaned of chaff.** A little stem is fine; a handful of leaf turns a good
packet moldy in a winter.

**One variety, one envelope, one label.** Write the name, the year, and your
plot number in pencil. If you saved seed from that mystery squash, say so on
the label — mystery is part of the collection too.
