---
title: "Zinnias for the cutting table"
date: 2026-08-16T09:00:00Z
author: Priya Raman
description: "Why the library's zinnia blend keeps the flower beds busy from June until the first frost."
og:image: /assets/note-card.svg
og:image:width: 1200
og:image:height: 630
schema: BlogPosting
class: notes
---

# Zinnias for the cutting table

The State Fair mix we have lent since 2021 is the easiest flower in the
shed. Sow it directly after the last frost, pinch the first set of buds,
and it will branch into a bush that hides every bare stem in the bed.

Cut when the stem is stiff and the second ring of petals is just opening,
and a vase on the kitchen table will last ten days. Deadhead weekly and the
plant will keep paying you in blooms until October.

If the bees cluster on the older flowers, leave one or two heads to go to
seed — and bring a thimbleful back in November.
