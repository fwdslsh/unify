import fs from "node:fs";
import path from "node:path";

const [, , sourceRoot, generatedRoot, contextPath] = process.argv;
const context = JSON.parse(fs.readFileSync(contextPath, "utf8"));
const inventory = JSON.parse(fs.readFileSync(context.inputs.sourcePages, "utf8"));

function esc(s) {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

const posts = inventory.pages
  .filter((p) => p.meta.some((m) => m.name === "schema" && /^(Article|BlogPosting)$/.test(m.content || "")))
  .sort((a, b) => String(b.date ?? "").localeCompare(String(a.date ?? "")));

const items = posts
  .map((p) => {
    const author = (p.meta.find((m) => m.name === "author") || {}).content;
    const day = String(p.date ?? "").slice(0, 10);
    return [
      "      <li>",
      `        <h2><a href="${esc(p.href)}">${esc(p.title)}</a></h2>`,
      `        <p class="post-meta"><time datetime="${esc(p.date)}">${esc(day)}</time> · ${esc(author)}</p>`,
        p.description ? `        <p>${esc(p.description)}</p>` : "",
      "      </li>",
    ]
      .filter(Boolean)
      .join("\n");
  })
  .join("\n");

const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Notes</title>
  <meta name="description" content="Field notes from the volunteers of the Fernway Seed Library.">
</head>
<body class="notes">
  <main>
    <h1>Notes from the beds</h1>
    <p class="lede">Short reports from volunteers on what they grew, saved, and learned this season — newest first.</p>
    <ol class="note-list">
${items}
    </ol>
  </main>
</body>
</html>
`;

const out = path.join(generatedRoot, "notes", "index.html");
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, html);
