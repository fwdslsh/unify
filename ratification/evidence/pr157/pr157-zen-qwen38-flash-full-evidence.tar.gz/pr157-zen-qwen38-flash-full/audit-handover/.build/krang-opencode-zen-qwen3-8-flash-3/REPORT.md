# Fernway Seed Library — handover report

## 1. Publish command

```
./unify build --base-url https://fernway.example/library/ --pretty-urls --audit
```

The same options are persisted in `unify.yaml` (`base-url`, `pretty-urls`, `generate`),
so a bare `./unify build` publishes the identical site. Exit 0 published 11 files to
`dist/` at `/library/` paths with clean URLs; nothing ended in `.html`.

## 2. Checks — final output of every check the tool offers

`build --dry-run --strict` is "the whole build and every check"; plain `audit` reports
only `broken` findings, `--strict` adds the non-blocking `incomplete` findings and
advisories, and `--external` adds off-origin URL resolution. All were run against the
final site; `--format json`/`sarif` are shapes of the same audit (json run once, `findings: []`).

### `./unify build --dry-run --strict`

```
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 3 pages would gain a JSON-LD block
copy dist/assets/note-card.svg (/library/assets/note-card.svg) ← assets/note-card.svg
copy dist/assets/seed.svg (/library/assets/seed.svg) ← assets/seed.svg
copy dist/assets/style.css (/library/assets/style.css) ← assets/style.css
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/bean-trial/index.html (/library/notes/bean-trial/) ← notes/bean-trial.md + _layout.html
write dist/notes/index.html (/library/notes/) ← generated + _layout.html
write dist/notes/returning-seed/index.html (/library/notes/returning-seed/) ← notes/returning-seed.md + _layout.html
write dist/notes/zinnias/index.html (/library/notes/zinnias/) ← notes/zinnias.md + _layout.html
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 11 files to dist/
exit=0
```

### `./unify audit`

```
audit: nothing to report
exit=0
```

### `./unify audit --strict`

```
audit: nothing to report
exit=0
```

### `./unify audit --strict --external`

```
audit: nothing to report
exit=0
```

### The publish run itself (audit-gated via `--audit`)

```
$ rm -rf dist && ./unify build --base-url https://fernway.example/library/ --pretty-urls --audit
audit: nothing to report
exit=0
```

Earlier in the build the strict audit reported three `incomplete` findings
(`image-missing-dimensions`) for the posts' `og:image`; fixed by adding the flat keys
`og:image:width: 1200` / `og:image:height: 630` to each post. Nothing has reported since.

## 3. Honest answers

**What `rules.md` did not answer — the sentence I wanted and could not find.**
Nothing in the file tells you how a generator is actually invoked. The sentence I kept
looking for was some form of *"unify runs it as `node gen.mjs <sourceRoot> <generatedRoot> <context.json>`"*:
"it writes into the directory unify hands it" never names the handoff — the generated
root arrives as `argv[3]` and the pointer to `source-pages.json` sits in a context JSON
(`argv[4]` → `inputs.sourcePages`). I instrumented a probe script and read the printed
argv to find this. Two more missing sentences: whether `generate:` in `unify.yaml`
resolves relative to the yaml (it does) or the source root like the `--generate` flag
(it doesn't — that looked for `site/scripts/` and failed); and whether the inventory's
"authored title" includes a Markdown page's heading-derived title — it doesn't
(`title: null`), so the posts keep both a `title:` key *and* an `<h1>` heading, which
the prose neither requires nor forbids.

**What I had to re-read, and why it didn't land the first time.**
The four URL rules crammed into the `## Files` bullets — link the real filename, even
under `--pretty-urls`, and a directory link builds only if the output has an
`index.html` there. It didn't land because the pretty-urls exception sits mid-bullet
between the rule and its counter-example: I paused over whether the Notes nav item
should read `/notes/` or `/notes/index.html` — the "directory link … is a broken link
otherwise" clause seemed to invite the pretty form, and only the next clause ("you
still write `/about.html`") settles it for links *out* — so the authored form is
`/notes/index.html`, which the build rewrites. Second: the "Merging a page into its layout" section — "The first
default-content page main unwraps" plus "bare `<slot>` … otherwise the children of its
`<main>`" — I read it for HTML-to-HTML merging, and only on the second pass realized it
also governs what my generated index page must look like; that generated pages resolve
against the same `_layout.html` was confirmed by the `← generated + _layout.html` line
in the build report, not by the rules.

**What I guessed at or inferred rather than read.**
That the `image-missing-dimensions` check even exists — the rules never enumerate audit
findings, only `broken`/`incomplete`/advisory as categories; I learned the id from the
audit itself. That `--external` is meaningful offline: I inferred the site emits no
off-origin URLs (the schema.org and w3.org strings are vocabulary identifiers, not
fetched resources) and the clean run confirmed it. Which options `--save-config` counts
as "saveable" — tested rather than read. That `date:` values ship "as written" through
YAML — the inventory echoing `2026-10-11T09:00:00Z` verified it. I chose full
`T…Z` timestamps because the opening line says a feed "date: with no time is reported
and left out rather than guessed at", and any reported date would fail the handover
standard — the interaction between feed and schema date tolerance is implied, not
stated. The feed's and sitemap's entry ordering, and Twitter-card tags being unnecessary
("No … Twitter tag is invented") for the preview-card requirement, were inferred. All
editorial content — hours, address, crops, volunteer names and post text — is invented.
