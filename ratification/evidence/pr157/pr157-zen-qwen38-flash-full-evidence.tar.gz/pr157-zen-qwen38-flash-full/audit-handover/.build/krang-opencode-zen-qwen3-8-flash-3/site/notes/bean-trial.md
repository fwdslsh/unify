---
title: "Soaking, scoring, and the great bean trial"
date: 2026-10-11T09:00:00Z
author: Marta Iversen
description: "Three ways to speed bean germination, tried side by side in the raised beds behind the library."
og:image: /assets/note-card.svg
og:image:width: 1200
og:image:height: 630
schema: BlogPosting
class: notes
---

# Soaking, scoring, and the great bean trial

This autumn I ran a small trial with the Fortex and Provider beans members
took home in August: one lot soaked overnight, one lot nicked with a nail
clippers, and one planted straight from the envelope.

Soaked beans came up four days early, but two of them rotted in the damp
bed. Scarified beans matched the control germination rate and needed no
soaking at all. My conclusion for next season: plant dry, plant warm, and
stop fussing.

Thanks to Omar, who watered my plots every Sunday in September.
