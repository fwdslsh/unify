import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";

const [, , sourceRoot, generatedRoot, contextPath] = process.argv;

const context = JSON.parse(readFileSync(contextPath, "utf8"));
if (!context.inputs || !context.inputs.sourcePages) {
  throw new Error("the notes index needs the source inventory: turn source-inventory back on in unify.yaml");
}
const inventory = JSON.parse(readFileSync(context.inputs.sourcePages, "utf8"));

function esc(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function meta(page, name) {
  const found = page.meta.find((m) => m.name === name);
  return found ? found.content : null;
}

// The inventory carries an authored title only, so a post that takes its name
// from its first heading is read here the same way the build reads it.
function authoredTitle(page) {
  if (page.title) return page.title;
  const body = readFileSync(path.join(sourceRoot, page.source), "utf8").split(/^---\n[^\n]*\n---\n?/);
  const heading = (body[body.length - 1].match(/^# (.+)$/m) || [])[1];
  return heading ? heading.trim() : null;
}

const posts = inventory.pages
  .filter((page) => {
    const rel = page.source.split(/[\\/]/).join("/");
    return rel.startsWith("notes/") && rel.endsWith(".md") && !path.basename(rel).startsWith("_");
  })
  .map((page) => ({
    href: page.href,
    title: authoredTitle(page),
    description: page.description,
    date: page.date,
    author: meta(page, "author"),
  }))
  .filter((post) => post.title && post.date)
  .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));

function longDate(iso) {
  const [date] = iso.split("T");
  const [y, m, d] = date.split("-").map(Number);
  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
  ];
  return `${d} ${months[m - 1]} ${y}`;
}

const items = posts
  .map(
    (post) => `      <li>
        <article>
          <h2><a href="${esc(post.href)}">${esc(post.title)}</a></h2>
          <p class="byline"><time datetime="${esc(post.date)}">${esc(longDate(post.date))}</time>${
            post.author ? ` · ${esc(post.author)}` : ""
          }</p>
          <p>${esc(post.description || "")}</p>
        </article>
      </li>`
  )
  .join("\n");

const page = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Notes</title>
<meta name="description" content="Field notes from Fernway Seed Library volunteers, newest first.">
</head>
<body class="notes">
<main>
<h1>Notes</h1>
<p>What our volunteers found in the beds, written during the season and kept newest first.</p>
<ul class="post-list">
${items}
</ul>
</main>
</body>
</html>
`;

const target = path.join(generatedRoot, "notes", "index.html");
mkdirSync(path.dirname(target), { recursive: true });
writeFileSync(target, page);
