---
date: "2026-09-27T09:15:00Z"
author: "Odette Marlowe"
description: "Eleven growers returned seed from the 2026 runner bean shelf. Here is which varieties filled their jars and which quietly did not."
schema: Article
class: notes
og:image: /notes/card-runners.svg
og:image:width: 1200
og:image:height: 630
---

# Runner beans: what came back this year

*Saved by Odette Marlowe at the return table, 27 September 2026*

Eleven of the sixteen borrowers came back to the return table with runner bean seed,
which is the best rate we have had on the shelf since I started writing these notes.

## What filled its jar

**Northerner** went out in eight jars and came back in eight, with more seed than it
left with. It is unbothered by our cool nights and it keeps flowering into September,
so it forgives a bad July.

**Hestia** came back from three growers out of four, and the one that did not was the
windowsill trial on Fernway Row, where the pot was far too small for anything with
roots. That is a note about the pot, not the bean.

## What did not

**Painted Lady** went out twice and returned nothing. Both growers wrote to say the
plants grew well and then dropped their pods in the hot week at the end of July. I
have taken it off the spring shelf for now and kept a jar for the seed-swap in October,
on the chance someone else has an answer for the heat.

## For the label

The seed that came back is weighed, jarred and labelled with the grower's name and the
year. If you are borrowing next spring, the Hestia jar on the shelf was saved on a
windowsill in 2024 and 2025 both, and it behaves.
