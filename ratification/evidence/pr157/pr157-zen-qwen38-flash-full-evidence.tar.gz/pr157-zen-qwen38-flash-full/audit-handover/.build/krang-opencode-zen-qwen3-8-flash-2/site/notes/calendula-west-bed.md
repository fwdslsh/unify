---
date: "2026-06-18T17:40:00Z"
author: "Sam Iles"
description: "A row of calendula sown from shelf seed along the west bed, and the first honest count of aphids on the beans behind it."
schema: Article
class: notes
og:image: /notes/card-calendula.svg
og:image:width: 1200
og:image:height: 630
---

# Calendula along the west bed

*Kept by Sam Iles, 18 June 2026*

The library had more calendula seed than anyone could use in April, so I sowed a
second row along the west bed instead of leaving it in the jar.

## What the row looks like

Two drills, about nine metres, roughly a hand apart, sown straight from the jar on
12 April and thinned never. It flowered by the middle of May and has not stopped.
It is the first thing in the garden that a bee lands on.

## The count

I have been walking the beans behind it every Saturday since 3 May and writing down
what I find on the underside of the top leaf, on a scale of nothing, a few, and a
lot. The bed without a calendula row, at the other end of the site, gets the same
walk on the same day.

- 3 May: both beds clear.
- 17 May: calendula bed a few, open bed a few.
- 31 May: calendula bed a few, open bed a lot.
- 14 June: calendula bed a few, open bed a lot, two plants curled.

That is eleven walks, not a trial, and the seasons are not matched. But I would
sow the row again next April from the same jar, and I am putting the jar back on
the shelf with a note that says so.

## Saving the seed

Calendula seed is the dry black hook at the base of the flower. It comes off in your
hand when it is ripe and none of it needs drying. Two heads gave me a jar; the return
table has it now, labelled, with the year on the lid.
