---
date: "2026-04-02T08:30:00Z"
author: "Wren Hobbs"
description: "Two volunteers sowed the same shelf tomatoes three weeks apart. The early one was not ahead; here is what the difference cost."
schema: Article
class: notes
og:image: /notes/card-tomatoes.svg
og:image:width: 1200
og:image:height: 630
---

# Sowing tomatoes before the last frost

*Written by Wren Hobbs, 2 April 2026*

I sowed our two shelf tomatoes on 8 March, and my neighbour Becca sowed the same jars
three weeks later. I was reliably smug about it for a month.

## The early sowing

The March seeds got up in a warm hall and were leggy by the end of April, when the
plants were still too small to plant out and the weather had no intention of
cooperating. They sat in a cold windowsill for three weeks and lost their first truss.

## The late sowing

Becca's April seeds never stopped in a check. By the second week of June they were
the size of mine, and by July they were ahead, because they were never held back.

## What I will write on the jar

Sowing early only works if you can keep the plants moving. A cold frame, a porch that
does not freeze, or a spare windowsill with a curtain in front of it. If you do not
have somewhere to put a pot for six weeks, sow late and forgive yourself.

Ask at the Tuesday shelf if you want the two jars on the list for this year. They are
both indeterminate, both saved by the same grower in 2025, and both do better sown
when the frost has gone than when the calendar says so.
