# Fernway Seed Library — build report

Built with `unify` 0.11.18 in this directory. Source is `site/`, the derived notes index comes from
`scripts/gen.mjs`, options are saved in `unify.yaml`, and the published output is `dist/` (14 files,
listed at the end).

## 1. The publish command

```
./unify build --clean --base-url https://fernway.example/library/ --pretty-urls --audit --strict
```

`unify.yaml` already carries `generate:`, `base-url:` and `pretty-urls:`, so a bare `./unify build`
publishes byte-identical output — I checked with `diff -r` between a `--clean` build with the flags
and one without them. The flags are spelled out above because "correct for that address" depends on
them, and `--audit --strict` means the build refuses to publish unless every check is quiet.

The output is correct for `https://fernway.example/library/`: every root-relative link, `href` and
`src` is prefixed (`/library/visit/`, `/library/styles.css`), every page carries an absolute
`canonical`, `og:url`, `og:image`, `sitemap.xml` and `feed.xml`, and no visitor-facing address ends
in `.html` (`--clean` matters: `--pretty-urls` moves pages into directories, and stale flat files
would otherwise linger beside them).

## 2. Every check, with its final output

The whole build and every check, writing nothing:

```
$ ./unify build --dry-run --strict
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 3 pages would gain a JSON-LD block
copy dist/card.svg (/library/card.svg) ← card.svg
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/calendula-west-bed/index.html (/library/notes/calendula-west-bed/) ← notes/calendula-west-bed.md + _layout.html
copy dist/notes/card-calendula.svg (/library/notes/card-calendula.svg) ← notes/card-calendula.svg
copy dist/notes/card-runners.svg (/library/notes/card-runners.svg) ← notes/card-runners.svg
copy dist/notes/card-tomatoes.svg (/library/notes/card-tomatoes.svg) ← notes/card-tomatoes.svg
write dist/notes/index.html (/library/notes/) ← generated + _layout.html
write dist/notes/runner-beans-2026/index.html (/library/notes/runner-beans-2026/) ← notes/runner-beans-2026.md + _layout.html
write dist/notes/sowing-tomatoes-early/index.html (/library/notes/sowing-tomatoes-early/) ← notes/sowing-tomatoes-early.md + _layout.html
copy dist/seed-mark.svg (/library/seed-mark.svg) ← seed-mark.svg
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
copy dist/styles.css (/library/styles.css) ← styles.css
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 14 files to dist/
```

The checks that do not block a build — `audit` is a separate command, `--strict` is what makes
incomplete findings and advisories count, `--external` is what resolves off-origin URLs:

```
$ ./unify audit
audit: nothing to report
exit=0
```

```
$ ./unify audit --strict
audit: nothing to report
exit=0
```

```
$ ./unify audit --external
audit: nothing to report
exit=0
```

```
$ ./unify audit --external --strict
audit: nothing to report
exit=0
```

The same audit in machine shape (short enough to include whole, and the only format that proves the
empty finding list without a page dump). `--format json` on this site prints ~600 lines of per-page
document dumps plus `"summary": {"broken":0,"incomplete":0,"problems":0,"advisories":0},
"findings": []` — the same result, so I have not pasted it:

```
$ ./unify audit --format sarif --external --strict
{
  "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json",
  "version": "2.1.0",
  "runs": [
    {
      "tool": {
        "driver": {
          "name": "unify",
          "informationUri": "https://github.com/fwdslsh/unify#readme",
          "version": "0.11.18",
          "rules": []
        }
      },
      "results": []
    }
  ]
}
exit=0
```

And the publish run itself, which refuses to write unless the audit is quiet:

```
$ ./unify build --clean --base-url https://fernway.example/library/ --pretty-urls --audit --strict
audit: nothing to report
exit=0
```

`rules.md` never lists what the checks look for, so I learned the vocabulary by breaking a copy of
the site in a throwaway `_test/` project (deleted) and reading what came back: `problem` for a link
or `og:image` that does not resolve to an emitted file, `incomplete [h1-missing]`,
`incomplete [description-missing]`, `incomplete [description-duplicate]`, `advisory` for a `date:`
that names a day rather than an instant, and a build that cannot publish. An `<img>` with no `alt`,
an empty `<a>`, and a page with no `<title>` are **not** reported — I checked, and had to conclude
there are no accessibility or markup-validity checks here rather than assume it.

## 3. Published output

```
dist/card.svg
dist/feed.xml
dist/index.html
dist/notes/calendula-west-bed/index.html
dist/notes/card-calendula.svg
dist/notes/card-runners.svg
dist/notes/card-tomatoes.svg
dist/notes/index.html
dist/notes/runner-beans-2026/index.html
dist/notes/sowing-tomatoes-early/index.html
dist/seed-mark.svg
dist/sitemap.xml
dist/styles.css
dist/visit/index.html
```

Each post emits `og:image` / `og:title` / `og:description` / `og:url` (all absolute under the base
URL) plus a generated `Article` JSON-LD block with headline, description, `datePublished`, author and
image — no hand-written JSON anywhere in `site/`.

## 4. What `rules.md` did not answer

The single biggest hole: **how the generator is invoked.** The sentence I wanted and could not find
is something like *"unify runs the generator with three arguments: the source root, the directory it
hands you to write into, and a JSON context file naming the source inventory."* What the doc says is
only "unify runs it before every build and it writes into the directory unify hands it, never into
`site/`". I found `argv = [unify, script, sourceRoot, generatedRoot, generator-context.json]`, the
`paths`/`site`/`inputs` shape of the context file, and `inputs.sourcePages` by printing them from a
throwaway script. Nothing in the doc mentions `generator-context.json` at all.

Second: **the inventory reports only authored values.** `rules.md` says a Markdown page with no
`title:` takes its title from the first `# Heading` — true of the page — and `--help` calls the file it
hands the generator "every source page's **authored** title, description, date, meta and links". The
sentence I wanted, in either place, was "a title taken from a heading is `null` in the inventory." My
first published index showed `<h2><a …>null</a></h2>` for all three posts, and **no check caught it**:
the generated HTML was legal, so audit was silent. The generator now re-reads each post's first heading
itself.

Third: **the check commands themselves.** `rules.md` names only `unify build --dry-run --strict`
(line 59). It never says `unify audit` exists, that findings come in three tiers (`problem`,
`incomplete`, `advisory`), that `incomplete` and `advisory` are printed-but-not-counted unless you
pass `--strict`, or that `--external` is the off-origin link check. The handover depends on exactly
that, and I got it from `./unify --help`.

Fourth: **which options are saveable in `unify.yaml`, and how they are spelled.** `rules.md` names
only `source:` and `generate:`; `base-url:` and `pretty-urls:` I discovered with `--save-config`, and
`source-inventory:` only in `--help`. Related, and genuinely contradictory: `rules.md:6` says the
generator is "kept in `scripts/` beside the site", while `--help` says a relative `--generate` path is
"from the source root". My first attempt with the flag failed as
`site/scripts/probe.mjs: Module not found`.

Fifth, smaller gaps: the doc never says `sitemap.xml` is a side effect of `--base-url` (`--help` says
it, `rules.md` does not), never says whether an SVG is an acceptable `og:image`, and — most awkwardly
given what I had to write — never says how a generator is meant to learn which pages exist.
`source-pages.json` and `--source-inventory` appear only in `--help`; `rules.md` is silent, so nothing
in the document I was told to read points at the inventory at all.

## 5. What I re-read, and why it did not land the first time

- **`rules.md:12`, the "Files" bullet** — one ~130-word run-on paragraph that ends with the sentence
  deciding the whole deployment: `--base-url …` *the site's whole address, never a bare path*
  prefixes every link and makes `og:`/`canonical` absolute. The first time I read it as a note about
  directory links, because the sentence before it is about directory links; it only landed when audit
  reported `/feed.xml does not resolve to any emitted file` and I went looking for how a subdirectory
  is meant to work at all. The same paragraph buries "this stays true under `--pretty-urls`: you
  still write `/about.html`" — which is why the generator links real filenames and the build rewrites
  them — and I had re-read it to know that.
- **`rules.md:44` ("Head.")** — four rules stacked in six lines: the title separator is written into
  the layout with *no* leading space; your `<meta>` replaces the layout's same-`name`/`property`;
  page declarations > derived values > layout fallbacks; "No missing value or Twitter tag is
  invented." It did not land because I read it as a merge order rather than as a set of things the
  tool will *not* do for me: I put a shared `description` in the layout (audit:
  `description-duplicate`, twice) and expected `og:image` to be derived from the icon. It took the
  third read, the words "No missing value or Twitter tag is invented", and then the emitted head in
  `dist/`, to see that a `twitter:card` and a per-page `og:image` are mine to write, and that a layout
  `og:image` is a fallback the posts' own `<meta property="og:image">` correctly replaces.
- **`rules.md:54`, the canonical sentence** — "A canonical still has no frontmatter key — it is one
  page's own address, which a layout must never set … so write that page in HTML, use `--canonical
  auto`, or leave it off." I re-read it because I first parsed "write that page in HTML" as an
  instruction about posts rather than one of three ways to get a URL unify will not invent, and because
  the sentence does not say that `--canonical auto` is the *default* whenever `--base-url` is given
  (`--help` does) — so the option that was already on looked like a third choice I had to make.
- **`rules.md:30`, layouts do not chain** — "a section layout is a complete standalone page". The
  first pass read as "a section may have its own layout"; it means a `notes/_layout.html` would
  *replace*, not add to, the root chrome, which would break the shared header/footer requirement.
  Hence exactly one layout, and `class: notes` on each post instead.
- **`rules.md:6`, the feed sentence** — "a `date:` with no time is reported and left out rather than
  guessed at" sits at the tail of a paragraph about something else, so my first pass treated post
  dates as free text. All three dates carry a time and `Z` because of the second read — and because
  the advisory is invisible unless you run `audit --strict`, a plain `audit` on a date-only site
  would have looked clean.

## 6. What I guessed at or inferred rather than read

- **That a 1200×630 SVG is an acceptable `og:image`.** The doc's only example is `/card.png`. Real
  share crawlers mostly reject SVG, so this is the weakest inference in the build; I used SVG because
  the brief forbids loading anything from another site and gives no image files, and I added the flat
  `og:image:width` / `og:image:height` keys (whose "a colon inside a name is not nesting" rule I did
  read) on the guess that a crawler wants declared dimensions.
- **That `description:`, `author:` and `date:` in frontmatter are how you *supply* the values the
  generated data reads.** `rules.md:54` says the JSON-LD is written from "its title, description,
  canonical, `og:image`, `author`, `date`, `lastmod`, and `lang`" and `rules.md:6` says the feed is
  written "from your title/description/canonical/dates" — but the list of keys with meaning is only
  `title`, `layout`, `class`, `lang`, `dir`, `schema`, "every other becomes `<meta name=…>`". Nowhere
  does it say `author:` is the `author` it reads, rather than, say, an `<address>` in the body. I
  wrote them as frontmatter keys, and only saw in `dist/` that `<meta name="author">` and
  `<meta name="date">` are what unify reads.
- **`schema: Article` over `BlogPosting`** for a dated field note — the doc allows three spellings and
  says nothing about which fits a diary entry. `Article` is my judgement call; it also decides that
  the post is a feed entry.
- **That a page needs a visible `<h1>`.** Nothing in the doc says so; I inferred it from a real page's
  needs, and the first `audit` run (`h1-missing` ×3) agreed.
- **Sorting the index by the date string.** I assumed `2026-09-27T09:15:00Z` strings sort newest-first
  lexicographically, and that the inventory passes my string through unchanged. Both checked in the
  output, not documented.
- **The address of the index itself.** I chose `notes/index.html` (published as `/library/notes/`)
  from "a page's address is its source path" plus the directory-link rule needing `notes/index.html`,
  and let the layout link `/notes/index.html` because "always link the real filename". Pretty-urls
  then rewrote it to `/library/notes/`, which I verified rather than read.
- **The feed `<link rel="alternate">` in the layout** and the "Feed" item in the nav: I checked the
  emitted head for a duplicate before keeping them.
- Everything not structural — the address, hours, variety names, the three notes' content, the
  colours, `body.home`/`body.visit`/`body.notes` active-nav CSS (`rules.md:47` says active nav is
  "not a feature", which I read as "yours to do in CSS").
- One thing I got wrong before I read it: with no `site/` present, `./unify` in this directory
  happily published `BRIEF.md`, `rules.md` and **the `unify` binary itself** into `dist/`. That is
  exactly what the source-root fallback (`rules.md:9`) says would happen; the surprise was that the
  tool ran a build rather than refusing to work in a directory full of non-site files. `site/` and
  `--clean` settled it.
