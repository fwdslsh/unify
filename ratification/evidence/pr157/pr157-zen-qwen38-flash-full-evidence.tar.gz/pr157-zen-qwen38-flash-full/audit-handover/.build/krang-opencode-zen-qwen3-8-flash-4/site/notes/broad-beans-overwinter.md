---
title: Broad beans over winter
description: Sowing beans in October, and the long pod that finally held on through the frost.
author: Wilfrid Dyce
date: "2026-09-14T16:00:00Z"
schema: Article
class: notes
og:image: /assets/seed-card.svg
og:image:width: 1200
og:image:height: 630
---

# Broad beans over winter

*Wilfrid Dyce — 14 September 2026*

Three winters back I borrowed the last packet of the old `Fernway Longpod` beans and
sowed them in October, which is what the library's leaflet tells you to do. Two of my
neighbours laughed. This year I have four pounds of the seed to give back, so let me
set down what actually happened.

## Sow before the ground goes cold

The trick is timing. Beans sown in the first fortnight of October root down before the
cold sets in and come away in March while spring-sown plants are still waking. I press
each seed two inches deep with a dibber, no richer than that, and put a cloche over the
row only for the first hard month.

## The year the frost took most of them

In 2024 a February snap of minus eight took the row back to the soil line. What grew
from the stools in April was late but healthy, and it cropped in July. The plants that
died were the ones sown too shallow. Deep seed survives a top-kill; shallow seed does
not. That single lesson is why I now say the Longpod is the hardiest thing on the
shelves.

## Return what you can

I bring back every dry bean I can spare, plus this note on paper, because a variety
without its instructions is only seed.
