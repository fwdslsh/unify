# Fernway Seed Library — handover report

## 1. Publish command

All publish options are saved in `unify.yaml` (`./unify build --base-url … --pretty-urls --generate … --save-config` was used once, then the config carries the build). From this directory:

```
./unify build
```

Equivalent explicit form (what the saved `unify.yaml` now encodes):

```
./unify build --base-url https://fernway.example/library/ --pretty-urls --generate _scripts/gen.mjs
```

`unify.yaml`:

```yaml
pretty-urls: true
base-url: https://fernway.example/library/
generate: site/_scripts/gen.mjs
```

## 2. Checks — final outputs

Every check the tool offers, including the non-blocking ones (`audit`, `audit --strict`, `audit --external`, `build --dry-run --strict`). All exit 0.

```
$ ./unify build
exit=0
```

```
$ ./unify audit
audit: nothing to report
exit=0
```

```
$ ./unify audit --strict
audit: nothing to report
exit=0
```

```
$ ./unify audit --external --strict
audit: nothing to report
exit=0
```

```
$ ./unify build --dry-run --strict
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 3 pages would gain a JSON-LD block
copy dist/assets/seed-card.svg (/library/assets/seed-card.svg) ← assets/seed-card.svg
copy dist/assets/style.css (/library/assets/style.css) ← assets/style.css
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/broad-beans-overwinter/index.html (/library/notes/broad-beans-overwinter/) ← notes/broad-beans-overwinter.md + _layout.html
write dist/notes/index.html (/library/notes/) ← generated + _layout.html
write dist/notes/returning-seed/index.html (/library/notes/returning-seed/) ← notes/returning-seed.md + _layout.html
write dist/notes/spring-openings/index.html (/library/notes/spring-openings/) ← notes/spring-openings.md + _layout.html
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 10 files to dist/
exit=0
```

Mid-build findings that were fixed (first `audit --strict` reported 4): missing `og:image:width`/`og:image:height` on the three posts (added as flat frontmatter keys) and no `<h1>` on the generated notes index (the generator now writes a `# Notes from the shelves` heading).

## 3. Honest answers

**What `rules.md` did not answer — the sentence I wanted and could not find.**
There is no sentence describing the generator script's calling contract. `rules.md` says only that the script "writes into the directory unify hands it" — it never says *how* it is handed that directory. I had to write a probe script and print `process.argv` to discover it is invoked as `node gen.mjs <sourceRoot> <generatedOverlayDir> <contextJsonPath>`, and find `ctx.inputs.sourcePages` inside that JSON to read the page inventory. Related gaps:
- Nothing lists what the checks look for. "Every check the tool offers" was clear (`audit`, `--strict`, `--external`, `build --dry-run --strict`, from `./unify --help`), but rules.md never mentions `h1-missing`, `image-missing-dimensions`, or the `incomplete`/`broken` categories at all — I learned them only by running `audit --strict` and being told.
- Nothing says whether files written into the generated overlay are still wrapped by the site's `_layout.html` (they are — confirmed in output), and whether a generated `.md` may use frontmatter (it may).
- Nothing states which options `--save-config` treats as saveable; I inferred baseUrl/pretty-urls/generate from the one-line it echoed.

**What I had to re-read, and why it did not land the first time.**
The Files section bullet — one unbroken paragraph mixing source-root resolution, `.fragment.html`, byte-for-byte copying, link spelling under `--pretty-urls` ("write `/about.html`, the build rewrites to `/about/`"), directory links, and `--base-url`. It didn't land because the key rule (always author the `.html` filename, even under pretty-urls) is the *middle* sentence of a seven-sentence paragraph; I had to re-read to be sure the post links in the generated index use `/notes/xxx.html` while the served URLs are pretty. Same for the schema/Markdown paragraph: the rule "a `date` unify cannot read as `2026-01-02` or `2026-01-02T09:30:00Z` is left out and reported" sits at its end — I first wrote quoted dates without checking the exact accepted formats, and the earlier feed sentence ("a `date:` with no time is … reported and left out") only made sense on a second pass. The Head bullet's override order (page `<meta>` replaces layout's same-name; `og:` defaults to final title/description/canonical) also took a second read to see that I only needed `og:image*` per post and no hand-written `og:title`.

**What I guessed or inferred rather than read.**
- The generator's argv/context contract — inferred by probing (see above); rules.md documents none of it.
- That the generator's output md should declare `layout: /_layout.html` rather than rely on nearest-layout discovery across the overlay — a guess; the dry-run shows it resolved.
- That frontmatter `og:image:width: 1200`/`og:image:height: 630` would silence the dimensions check — extrapolated from the flat-`og:image` example; rules.md never mentions dimensions.
- The feed `<link rel="alternate">` in the layout, the sitemap (rules.md says `--base-url` generates one, but adding the discoverable link was my call), the 1200×630 SVG card size, the en-GB date formatting in the index, and the `class`-on-`<body>` nav highlighting (that one *is* in rules.md).
- That `audit --external` passing means it treated the absolute `https://fernway.example/...` self-links as same-origin and skipped fetching; nothing is documented about how origin is decided, and `.example` would not resolve.
- Site content (hours, address, post text) is invented — the brief only required the pages to exist.
