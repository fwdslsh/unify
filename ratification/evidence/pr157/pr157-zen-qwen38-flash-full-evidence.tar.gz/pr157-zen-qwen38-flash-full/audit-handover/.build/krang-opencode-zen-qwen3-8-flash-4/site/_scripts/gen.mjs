import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const [, , srcRoot, overlay, ctxPath] = process.argv;
const ctx = JSON.parse(readFileSync(ctxPath, "utf8"));
const inventory = JSON.parse(readFileSync(ctx.inputs.sourcePages, "utf8"));

const metaOf = (page, key) => {
  const m = page.meta.find((x) => x.name === key || x.property === key);
  return m ? m.content : "";
};

const posts = inventory.pages
  .filter((p) => metaOf(p, "schema") === "Article" && p.date)
  .sort((a, b) => b.date.localeCompare(a.date));

const esc = (s) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const showDate = (iso) =>
  new Date(iso).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  });

const items = posts
  .map((p) => {
    const author = metaOf(p, "author");
    const who = author ? `${esc(author)}: ` : "";
    return `<dt><a href="${p.href}">${esc(p.title)}</a></dt>\n<dd>${showDate(p.date)} — ${who}${esc(p.description || "")}</dd>`;
  })
  .join("\n");

const md = [
  "---",
  "title: Notes",
  'description: "Field notes from Fernway Seed Library volunteers: what they sowed, saved, and learned, newest first."',
  "class: notes",
  "layout: /_layout.html",
  "---",
  "",
  "# Notes from the shelves",
  "",
  "Short field notes written by the volunteers who run the lending desk and tend the",
  "trial beds. Newest first.",
  "",
  `<dl class="post-list">`,
  items,
  `</dl>`,
  "",
].join("\n");

mkdirSync(join(overlay, "notes"), { recursive: true });
writeFileSync(join(overlay, "notes", "index.md"), md);
