---
title: The shelves open again
description: The first Saturday of the season, and what to make of the new tomato strain on the top shelf.
author: Ana Sorensen
date: "2026-03-02T10:15:00Z"
schema: Article
class: notes
og:image: /assets/seed-card.svg
og:image:width: 1200
og:image:height: 630
---

# The shelves open again

*Ana Sorensen — 2 March 2026*

We unlocked the seed room at nine-thirty on the first Saturday of March and by ten
there were six growers at the bench with their loan cards out. The season is properly
open.

## What is on the top shelf

This year the big change is a tomato the donors' list calls **Alder Lane Red**. It came
from four packets returned by two households on Alder Lane, grown out for two seasons
in the trial beds, and it ripens a fortnight ahead of anything else we have carried.
Ask the desk before you take it — it wants a warm wall and pinching out, and it will
disappoint a grower who treats it like a cordon.

## Borrowing rules, repeated gently

Five packets per household, loan card signed, and the promise to return seed in
autumn even if the season goes badly. If you are new, take lettuce, calendula, and one
thing you are curious about, and leave the beans to the October sowers.

## The return desk opens in September

Mark it now: the last Saturday of September onward. A packet tucked in a drawer until
November is how we lost the lavender last year.
