---
title: Returning seed at season's end
description: Drying, cleaning, and labelling the harvest you bring back to the lending shelves.
author: Ora Beake
date: "2026-10-18T09:30:00Z"
schema: Article
class: notes
og:image: /assets/seed-card.svg
og:image:width: 1200
og:image:height: 630
---

# Returning seed at season's end

*Ora Beake — 18 October 2026*

The October weekends at the desk are the busiest of my year, so a word on what
"returning fresh seed" actually asks of you.

## Dry first, then clean

Cut seed heads when the pods rattle but before they shatter, and spread them on a
screen or a plain dish towel in a dry room for a week. Seed that goes into a paper
envelope while it is still soft will mould before it reaches the shelves, and mouldy
seed cannot be saved by drying it out later.

Once brittle, thresh by hand over a tray. Winnow the chaff with a shallow bowl on a
breezy morning; a hair dryer on cool does the job in a kitchen.

## What the envelope needs

Every packet handed back must say, in pencil:

- the name as it came to you, from the loan card
- the year you grew it
- your initials, so the next borrower can ask you how it did

If your patch did something odd — early bolting, a colour that ran off type — say so
on the card. The quirk is often the useful part, and it is how the collection learns
what suits Fernway.

## Bring the card, even with no seed

A season can fail and you are still square with the library. Bring the loan card,
write what happened, and the desk will note it. No one owes the shelves a harvest;
the seed you return is what keeps the next grower's season whole.
