// Writes notes.html — the index of every note — from the posts unify has already read.
// unify.yaml names this file (generate: scripts/gen.mjs), so unify runs it itself
// before every build, dev rebuild and audit. It hands the script three paths:
// argv[2] the source root, argv[3] an overlay directory whose files join the build
// as ordinary pages — the layout wraps this one, its head merges, its links are
// checked — and argv[4] generator-context.json, which names source-pages.json:
// every source page's authored title, description, date and metas, read by unify's
// own frontmatter reader. Nothing here is written into site/.
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const [, , sourceRoot, outDir, contextPath] = process.argv;
if (!sourceRoot || !outDir || !contextPath) {
  throw new Error("gen.mjs: unify runs this (generate: scripts/gen.mjs in unify.yaml); run `unify build` to see its output");
}
const context = JSON.parse(readFileSync(contextPath, "utf8"));
if (!context.inputs?.sourcePages) {
  throw new Error("gen.mjs: needs the source page list; remove source-inventory: false from unify.yaml (it is on whenever generate: is set)");
}
const inventory = JSON.parse(readFileSync(context.inputs.sourcePages, "utf8"));

const LISTING_DESCRIPTION =
  "Every note from the Fernway Seed Library shelf hands, newest first — what dried, what crossed, and what came back.";

// Text, then attributes: one escaper cannot be right for both.
const esc = (s = "") => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const escAttr = (s = "") => esc(s).replace(/"/g, "&quot;");

// A note is a Markdown page under notes/. Newest first; ties broken by address,
// so two runs of this script can never disagree.
const notes = inventory.pages
  .filter((p) => p.source.startsWith("notes/") && p.source.endsWith(".md"))
  .map((p) => ({
    href: p.href,
    title: p.title || p.source,
    description: p.description || "",
    date: p.date || "",
    author: p.meta.find((m) => m.name === "author")?.content?.trim() ?? "",
  }))
  .sort((a, b) => (b.date < a.date ? -1 : b.date > a.date ? 1 : a.href < b.href ? -1 : a.href > b.href ? 1 : 0));

const listing = notes.length === 0
  ? "      <p>No notes on the shelf yet.</p>"
  : "      <ul class=\"note-list\">\n" + notes.map((n) => {
    // <time> splits the machine's value from the reader's: the attribute keeps
    // the whole instant, the text shows only the day.
    const when = n.date ? `<time datetime="${escAttr(n.date)}">${esc(n.date.slice(0, 10))}</time>` : "";
    const by = n.author ? ` · ${esc(n.author)}` : "";
    const blurb = n.description ? `\n          <p>${esc(n.description)}</p>` : "";
    return "        <li>\n"
      + `          <a class="note-title" href="${escAttr(n.href)}">${esc(n.title)}</a>\n`
      + `          <p class="note-meta">${when}${by}</p>${blurb}\n`
      + "        </li>";
  }).join("\n") + "\n      </ul>";

mkdirSync(outDir, { recursive: true });
writeFileSync(
  join(outDir, "notes.html"),
  "<!doctype html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"utf-8\">\n    <title>Notes</title>\n"
    + `    <meta name="description" content="${escAttr(LISTING_DESCRIPTION)}">\n`
    + "  </head>\n  <body class=\"notes\">\n    <main>\n"
    + "      <!-- written by scripts/gen.mjs from the pages under site/notes/ — edit a note, not this listing -->\n"
    + "      <h1>Notes</h1>\n"
    + "      <p>Dated entries from the volunteers who shelve the seed, newest first.</p>\n"
    + listing + "\n    </main>\n  </body>\n</html>\n",
);

console.log(`gen.mjs: wrote notes.html from ${notes.length} note(s)`);
