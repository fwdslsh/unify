---
title: "The courgette that refused to be named"
description: "A mystery squash came back to the shelf three seasons running with no parent packet, no story, and excellent seeds. Adela's field report."
author: Adela Kime
date: 2026-08-30T18:20:00Z
schema: BlogPosting
og:type: article
class: notes
---

# The courgette that refused to be named

Three springs ago a packet of yellow courgette came back full. Not emptied,
not "oops", *full* — and nobody claimed sowing it. That is how the unnamed
squash of Fernway Passage began: it grew in the shade of the coopers' loft,
ignored every label we tried to give it, and produced the best eating of the
season.

## Why it refuses

Courgettes cross where bees carry the pollen, and our bees are industrious
little gossips. The true story is probably: yellow courgette crossed with
who-knows-what from someone's window box two gardens up. The fruit is a
stubbled, deep-green club; the plant sprawls like it owns the passage. Nobody
has ever caught it being shy.

## The saving

I let three fruits go full size — arm-length, skin like old brass — then cut,
scooped, rinsed and dried the seed as usual. It germinated at almost
everything. The seedlings are vigorous, slightly rude in habit, and clearly
this library's own: nobody ordered them, everybody keeps them.

So this year, unnamed no longer: on the shelf it reads **Fernway Climber,
yellow-courgette kind, grown in the passage since 2023**. If you want a packet,
write to the lending book and say *why*. If you grow it, name it on the
envelope and bring back double. A squash that refuses to be named is only
half a story.
