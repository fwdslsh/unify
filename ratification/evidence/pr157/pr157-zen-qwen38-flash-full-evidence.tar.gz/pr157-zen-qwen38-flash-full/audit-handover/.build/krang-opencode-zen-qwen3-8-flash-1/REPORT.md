# Fernway Seed Library — build report

unify 0.11.18. Project layout: `site/` (sources), `scripts/gen.mjs` (writes the notes
index into the overlay unify builds from), `unify.yaml` (saves `generate:`,
`base-url: https://fernway.example/library/`, `pretty-urls: true`).

## 1. The publish command

```
./unify build --clean --audit --strict
```

Exit 0; `dist/` is the complete site published at `https://fernway.example/library/`
(the address itself is saved in `unify.yaml`; `--audit --strict` publishes only if the
whole audit is silent).

## 2. Every check, final output

All four ran against the final source state; each exited 0 and reported nothing.

`./unify build --dry-run --audit --strict` — the whole build and every check, writing nothing:

```
gen.mjs: wrote notes.html from 3 note(s)
audit: nothing to report
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 6 pages would gain a JSON-LD block
copy dist/assets/seed.svg (/library/assets/seed.svg) ← assets/seed.svg
copy dist/assets/share-card.svg (/library/assets/share-card.svg) ← assets/share-card.svg
copy dist/assets/style.css (/library/assets/style.css) ← assets/style.css
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/index.html (/library/notes/) ← generated + _layout.html
write dist/notes/labelling-jars/index.html (/library/notes/labelling-jars/) ← notes/labelling-jars.md + _layout.html
write dist/notes/porch-rail-beans/index.html (/library/notes/porch-rail-beans/) ← notes/porch-rail-beans.md + _layout.html
write dist/notes/unnamed-courgette/index.html (/library/notes/unnamed-courgette/) ← notes/unnamed-courgette.md + _layout.html
copy dist/robots.txt (/library/robots.txt) ← robots.txt
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 12 files to dist/
```

`./unify audit --strict` — the findings alone, advisories and `incomplete` findings included:

```
gen.mjs: wrote notes.html from 3 note(s)
audit: nothing to report
```

`./unify audit --strict --external` — the check that fetches every off-origin URL the site
emits (the site emits none; nothing was fetched):

```
gen.mjs: wrote notes.html from 3 note(s)
audit: nothing to report
```

`./unify audit --strict --format json` — same check, machine shape, tail of output:

```
    }
  ],
  "findings": []
}
```

`./unify build --clean --audit --strict` — the publish itself:

```
gen.mjs: wrote notes.html from 3 note(s)
audit: nothing to report
```

## 3. Honest answers

**What `rules.md` did not answer — the sentence I wanted.** It never documents
`unify audit` at all: no sentence like "the checks beyond the build are `unify audit`, whose
non-blocking findings — advisories and `incomplete` — only fail the exit code under
`--strict`, and whose `--external` check fetches off-origin URLs." The brief demands
every check including the non-blocking ones, and rules.md's only mention of checks is the
one line about `build --dry-run --strict`. I found audit from `./unify --help`, and the
convention (`build --audit --strict` before publishing) from the `unify init` scaffold's
own README.md and DEPLOY.md. Second gap: how a `generate:` script is run. The sentence I
wanted was "unify hands it argv[2] the source root, argv[3] an overlay directory whose
files join the build as ordinary pages, and argv[4] generator-context.json, which names
source-pages.json." rules.md says only "it writes into the directory unify hands it" —
what that directory is, and the whole shape of source-pages.json, are absent; I took them
from the blog template's `scripts/gen.mjs` comments and confirmed them with a throwaway
probe build. Third: rules.md says scripts live in `scripts/` "beside the site" while
`--help` says `--generate` takes a path "from the source root" — a contradiction neither
document resolves. I discovered empirically that they really differ: `--generate
scripts/probe.mjs` failed looking for `site/scripts/probe.mjs`, while `generate:` in
`unify.yaml` resolves beside `site/`. And rules.md never says `--canonical auto` is the
default once `--base-url` is set — only `--help` does.

**What I had to re-read, and why it didn't land the first time.** The opening
paragraph, re-read twice: one run-on paragraph covering composition, config, generator
scripts *and* feeds, so its closing clause — "a `date:` with no time is reported and left
out rather than guessed at" — did not register until I was wondering whether a bare
`date: 2026-10-14` was safe; once it landed, every post's date became a full
`…T…Z` instant, because a *report* of any kind would fail the handover check. The footer
rule ("A bare `<header>`/`<footer>` does not replace the layout's — only `slot=` fills, and
it fills the *contents* … write `<p slot="footer">`") needed three readings: "slot" names
both a layout element and a page attribute in the same sentence, and I had already written
the layout before the "a footer inside a footer" warning made sense. The head-merge
precedence chain ("page-head declarations win over derived values, which win over layout
fallbacks") misfired the first time — I assumed a *derived* value could override the
layout's og: tags; re-reading showed derivation covers only og:title/description/url, so a
layout-declared `og:image` survives onto every post, which is exactly what carries the
share card. And line 54's canonical sentence read as a dead end ("so write that page in
HTML") until the next clause — `--canonical auto` — landed; the posts stay Markdown because
of a clause after the one I'd stopped on.

**What I guessed at, or inferred rather than read.** That frontmatter `author:` and `date:`
reach the JSON-LD — rules.md names "author" and "date" among schema inputs but never shows
how to declare them; I inferred they are the generic `<meta name=…>` keys and confirmed the
BlogPosting block in `dist/` (headline, description, url, image, author, datePublished).
The exact source-pages.json field names (`href`, `date`, `meta[]`) — inferred from the
template script, then verified by printing the real inventory. That the "reported"
no-time date is an audit finding rather than a transient build note — I guessed it counts
and used full instants so the answer didn't matter. That SVG is acceptable for `og:image`:
real share crawlers are known to dislike it, but the brief mandates placeholder SVGs, rules.md
is silent on format, and audit — including `--external` — is silent; that is an inference
from the brief, not from the tool's docs. That `--clean` belongs in the publish line: rules.md
defines exit-0 `dist/` as "the complete site", which I read as excluding stale files, so a
clean build is my inference of what "publishes" means. That the generator's own
stdout ("gen.mjs: wrote notes.html from 3 note(s)") is not one of the checks "reporting
something" — the gate is audit's "nothing to report"; a pedantic reading of the handover
would need the coordinator's agreement that a generator log line is not a check. And the
active-nav recipe: rules.md shows `body.home .nav-home` as CSS, not a feature — applying
frontmatter `class:` to merge onto the layout's `<body>` (verified in output:
`<body class="notes">`) was inference from the root-attribute rule, never a demonstrated
example for a `.md` page.
