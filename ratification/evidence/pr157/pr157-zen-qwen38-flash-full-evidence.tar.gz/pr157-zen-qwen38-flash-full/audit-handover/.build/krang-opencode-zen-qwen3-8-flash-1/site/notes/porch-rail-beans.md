---
title: "What dried on the porch rail: a bean inventory"
description: "Twenty-one kinds of bean went up the porch rail this September; fourteen came back dry. Marta's honest tally of what worked."
author: Marta Oyelaran
date: 2026-10-14T16:40:00Z
schema: BlogPosting
og:type: article
class: notes
---

# What dried on the porch rail: a bean inventory

Twenty-one kinds of bean went up on the porch rail this September, in muslin
and in paper bags, because someone donated a sewing machine and I said I would
"just try a few". Fourteen came back dry enough to shell by hand. Here is the
tally, kept honestly, failures included.

## What worked

- **Scarlet Runner, 'Hestia'** — the champion. Six weeks on the rail, no mould,
  and the seeds came away from the pod like they were eager.
- **Blue Lake pole bean** — dried evenly in muslin, took a bit longer. A keeper.
- **Dragon Tongue** — handsome wet, handsome dry. Pod-edging held its colour.

## What did not

- **Borlottini, in paper bags** — four of the six went musty before I checked
  them. The rail is windy, but the bags held dawn damp. Muslin or nothing.
- **A yardlong bean nobody named** — it kept growing, kept ripening, and
  eventually took over a railing. It did not dry. I composted it with dignity.

## What I will do next September

Pull everything at the *leathery* stage, not the rattly one. Leathery pods
shell without grinding seed coats, and the plants give up three weeks earlier
than you think they will. Then it is just a matter of mesh, wind, and leaving
the porch light off so the moths leave my inventory alone.

Bring your own tallies to the first Sunday shelf — we compare and laugh, and
the winners get the good nail.
