---
title: "Labelling: a jar is only worth its pencil"
description: "Ink runs, sticker glue lets go, and marker vanishes in sun. Priam on what actually survives a season on the seed shelf."
author: Priam Raval
date: 2026-09-26T09:05:00Z
schema: BlogPosting
og:type: article
class: notes
---

# Labelling: a jar is only worth its pencil

We lost four jars this summer, and none of the seeds were wrong — the *labels*
were. One ran in the rain, one's sticker let go and was swept up, one spent
winter facing the window and went white as milk. The seed was fine. Nobody knew
what it was. That is the same as having no seed at all.

## The short list of what survives

1. **Graphite pencil on masking tape, stuck to glass, not paper.** Damp takes
   paper; pencil outlives everything. Soft pencil, heavy hand.
2. **Wax-lined envelope, folded twice, seed inside, name outside in pencil.**
   The library's own pattern: a strip cut from an old shopping bag works.
3. **Write the *year* every time.** The seed does not age on your shelf; it ages
   in your memory, and only the year tells you which is which at the February
   meeting.

## What does not

Felt-tip on anything, anywhere, ever. Ballpoint on tape: the letters sink into
the glue and go ghost-white in a month. And please stop writing on the lid
before the jar has been washed — we all know that tomato sauce jar is a
tomato sauce jar, but the asters disagree.

Pencil. Tape. Year. If the label outlives the seed, the jar can be washed and
the name kept, and the library goes on.
