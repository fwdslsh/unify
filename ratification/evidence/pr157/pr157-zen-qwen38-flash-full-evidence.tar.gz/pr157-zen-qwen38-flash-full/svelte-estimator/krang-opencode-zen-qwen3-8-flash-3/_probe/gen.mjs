import fs from 'node:fs';
console.log('ARGV:', JSON.stringify(process.argv));
console.log('CWD:', process.cwd());
const envKeys = Object.keys(process.env).filter(k => /UNIFY|GENER|SOURCE|OUTPUT|DIST|SITE|DIR/i.test(k));
for (const k of envKeys) console.log('ENV:', k, '=', process.env[k]);
try {
  const stdin = fs.readFileSync(0, 'utf8');
  console.log('STDIN(first 300):', stdin.slice(0, 300));
} catch (e) {
  console.log('STDIN error:', e.message);
}
