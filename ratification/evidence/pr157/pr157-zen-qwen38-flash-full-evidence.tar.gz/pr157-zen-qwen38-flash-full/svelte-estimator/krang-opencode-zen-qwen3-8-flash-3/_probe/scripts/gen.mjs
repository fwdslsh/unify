import fs from 'node:fs';
const [unify, self, srcRoot, overlay, ctxPath] = process.argv;
const ctx = JSON.parse(fs.readFileSync(ctxPath, 'utf8'));
console.log('SOURCE-PAGES:', fs.readFileSync(ctx.inputs.sourcePages, 'utf8'));
