import { writeFileSync, copyFileSync, existsSync } from 'node:fs';

const [sourceDir, overlayDir, contextPath] = process.argv.slice(2);
const report = { argv: process.argv.slice(2), cwd: process.cwd(), contextExists: existsSync(contextPath) };
console.log('PROBE', JSON.stringify(report, null, 2));
if (existsSync(contextPath)) copyFileSync(contextPath, 'context-from-probe.json');
writeFileSync(overlayDir + '/from-generator.html', '<!doctype html>\n<html>\n<head><title>FromGenerator</title></head>\n<body>\n<main><p>written by generator into overlay</p></main>\n</body>\n</html>\n');
