import fs from 'node:fs';
const ctx = JSON.parse(fs.readFileSync(process.argv[4],'utf8'));
const inv = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages,'utf8'));
console.log(JSON.stringify(inv.pages.filter(p=>p.source.includes('probe')),null,1));
