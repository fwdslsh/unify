import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const [,, sourceRoot, outDir, contextPath] = process.argv;
console.log("CONTEXT:", JSON.stringify({sourceRoot, outDir, contextPath}));
mkdirSync(join(outDir, "gen"), { recursive: true });
writeFileSync(join(outDir, "gen", "bundle.js"), "console.log('bundled estimator');\n");
writeFileSync(join(outDir, "gen", "style.css"), "h1{color:red}\n");
writeFileSync(join(outDir, "gen", "notes-index.html"), "<!doctype html>\n<html><head><title>Notes index</title><meta name=\"description\" content=\"Generated index of notes.\"></head><body><main><h1>Notes</h1></main></body></html>\n");
