import fs from 'node:fs';
const out = {
  argv: process.argv,
  cwd: process.cwd(),
  env: Object.fromEntries(Object.entries(process.env).filter(([k]) => /UNIFY|GENERATE|INVENTORY|SOURCE/i.test(k))),
};
fs.writeFileSync('/tmp/sandbox/probe-out.json', JSON.stringify(out, null, 2));
