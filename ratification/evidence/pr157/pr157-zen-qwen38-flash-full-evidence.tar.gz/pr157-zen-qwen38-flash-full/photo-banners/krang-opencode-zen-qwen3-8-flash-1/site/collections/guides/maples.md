---
title: The Maples
description: The maple collection on the slope behind the garden shed at Alderfen Arboretum, curated by Daniel Whorral.
---

# The Maples

The maples occupy the slope behind the garden shed, where the soil is shallow and free
draining and the afternoon light comes in low. Twenty-four species and forms are
established here, from the ordinary field maple that hedges every lane in the parish to
the Japanese full-moon maple that volunteers cover with a fleece horticultural blanket in
hard frost.

The collection is arranged by leaf rather than by geography, which is why the plantings
look odd from the path and make sense up close: five-lobed leaves on the upper terrace,
three-lobed below it, and the finely divided fern-leaved types along the fence where they
catch the light.

Bark is the second show. The paperbark maple by the top of the slope sheds cinnamon sheets
in August and is the tree most often photographed, to its curator's quiet delight.

Curator: Daniel Whorral.

At its best: November.
