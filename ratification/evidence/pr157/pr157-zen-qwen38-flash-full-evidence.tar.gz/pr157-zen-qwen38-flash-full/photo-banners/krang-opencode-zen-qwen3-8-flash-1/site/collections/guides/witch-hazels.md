---
title: The Witch Hazels
description: The winter-flowering witch hazel collection below the east gate at Alderfen Arboretum, curated by Ines Havelka.
---

# The Witch Hazels

Flowering in midwinter is the whole point. The witch hazel collection sits in the damp
corner below the east gate, where the ground holds water into January and the trees are
seen against the low grey light rather than against blue sky.

Nineteen plants are in the ground, a handful still in their third year. Hamamelis
mollis and its cultivars do most of the work: 'Pallida' with its large sulphur-yellow
spider-ribbon flowers, the deeper orange of 'Robert Calton', and the witch hazel the
volunteers call the Candle Tree for the way its racemes light up a mist. Scepter-line
shrub Hamamelis virginiana flowers last of all, and is the one that drops its petals in
a frost.

The scent carries on still, cold mornings, which is why the bench at the top of the corner
is almost always occupied in the first three weeks of the year.

Curator: Ines Havelka.

At its best: January.
