---
title: The Oaks
description: The oak collection at Alderfen Arboretum, along the north hedge, curated by Margaret Osei.
---

# The Oaks

The oak collection runs the full length of the north hedge, and it is the oldest part of
the arboretum: the first eleven trees were the reason the site was kept as open ground at
all. Today there are thirty-two specimens, a mix of native pedunculate and sessile oaks
with cork, Turkish and red oaks planted by successive cohorts of volunteers.

Walk it east to west and you move roughly from the 1970s plantings to the 2020s. The cork
oak by the second gate is the one to look for in summer, its furrowed bark nearly a hand's
width thick; the row of young Turkish oaks on the west lawn is the one to look for in ten
years.

Acorns are collected in the shed each autumn and sown for the village's own planting
scheme, so please leave the fallen crop where it is.

Curator: Margaret Osei.

At its best: October.
