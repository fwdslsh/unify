import { createServer } from 'node:http';
import { readFileSync, existsSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';

const DIST = '/tmp/sandbox/dist';
const BASE = '/arboretum/';
const TYPES = { '.html': 'text/html', '.css': 'text/css', '.png': 'image/png', '.xml': 'application/xml' };

// minimal emulator of the host: serves DIST under /arboretum/, directory -> index.html
const server = createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (!p.startsWith(BASE)) { res.statusCode = 404; return res.end('outside base'); }
  let f = join(DIST, p.slice(BASE.length));
  if (existsSync(f) && statSync(f).isDirectory()) f = join(f, 'index.html');
  if (!existsSync(f)) { res.statusCode = 404; return res.end('nope'); }
  res.setHeader('content-type', TYPES[extname(f)] || 'application/octet-stream');
  res.end(readFileSync(f));
});
await new Promise(r => server.listen(8123, r));

const origin = 'http://127.0.0.1:8123';
const urls = [
  '/arboretum/',
  '/arboretum/visit/',
  '/arboretum/collections/',
  '/arboretum/collections/oaks/',
  '/arboretum/collections/maples/',
  '/arboretum/collections/witch-hazels/',
  '/arboretum/styles.css',
  '/arboretum/images/logo.png',
  '/arboretum/images/home-wide.png',
  '/arboretum/images/visit-banner.png',
  '/arboretum/images/collections-banner.png',
  '/arboretum/sitemap.xml',
];
let bad = 0;
const queue = [...urls];
const fetched = new Map();
while (queue.length) {
  const u = queue.shift();
  const r = await fetch(origin + u);
  const body = await r.text();
  fetched.set(u, body);
  if (!r.ok) { console.log('HTTP', r.status, u); bad++; continue; }
  if (r.headers.get('content-type')?.includes('text/html')) {
    for (const m of body.matchAll(/(?:href|src)="([^"]+)"/g)) {
      let abs;
      try { abs = new URL(m[1], origin + '/arboretum/'); } catch { continue; }
      if (abs.origin !== origin) continue;
      if (!fetched.has(abs.pathname) && !queue.includes(abs.pathname)) queue.push(abs.pathname);
    }
  }
  console.log('OK', r.status, u, r.headers.get('content-type'));
}
// content spot-checks over HTTP
const home = fetched.get('/arboretum/');
const checks = [
  ['home shows name+welcome over photo', home.includes('banner-text') && home.includes('Alderfen Arboretum') && home.includes('home-wide.png')],
  ['visit banner', fetched.get('/arboretum/visit/').includes('visit-banner.png') && /<h1>Visit<\/h1>/.test(fetched.get('/arboretum/visit/'))],
  ['collections banner', fetched.get('/arboretum/collections/').includes('collections-banner.png')],
  ['oaks names curator+month', /Curator: Edith Harmon.*October/s.test(fetched.get('/arboretum/collections/oaks/'))],
  ['maples names curator+month', /Curator: Ruar\xed Bell.*November/s.test(fetched.get('/arboretum/collections/maples/'))],
  ['witch-hazels names curator+month', /Curator: Tessa Nunn.*January/s.test(fetched.get('/arboretum/collections/witch-hazels/'))],
];
for (const [name, ok] of checks) { console.log(ok ? 'PASS' : 'FAIL', '—', name); if (!ok) bad++; }
// PNG bodies really binary-intact
const png = await (await fetch(origin + '/arboretum/images/logo.png')).arrayBuffer();
const local = readFileSync('/tmp/sandbox/dist/images/logo.png');
console.log(png.byteLength === local.length && Buffer.from(png).equals(local) ? 'PASS — logo bytes ship intact' : 'FAIL — logo bytes');
server.close();
console.log(bad ? `FAILED (${bad})` : 'HTTP CHECKS PASSED');
process.exit(bad ? 1 : 0);
