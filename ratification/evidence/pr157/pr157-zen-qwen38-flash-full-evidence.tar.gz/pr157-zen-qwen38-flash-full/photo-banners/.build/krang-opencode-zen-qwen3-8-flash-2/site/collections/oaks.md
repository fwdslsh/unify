---
title: The Oaks
class: collections
author: Edith Harmon
best-month: October
description: Alderfen's oak collection — thirty-one species and varieties along the south ridge, at their best in October.
---

# The Oaks

*Curator: Edith Harmon. The collection is at its best in October.*

The oaks stand along the south ridge, where the soil thins to gravel and the
youngest plantings from 1987 have finally begun to look as if they belong. There
are thirty-one species and varieties in the collection, most of them grown from
acorns raised in the stable yard.

## What to look for

October is the month: the pedunculate oaks turn a deep, wine-dark russet before
they drop, and the cork oak — our oldest living plant, put in the year the
arboretum was founded — is shedding plates of bark you can hold in two hands.
The kermis oak still has acorns on it if you visit early in the month, and the
willow oaks, being half evergreen, are simply going gold underneath.

## Getting around them

The ridge path is firm all year. Edith runs an acorn walk on the first Saturday
of October at ten in the morning; it starts at the oak with the blue tag and
needs no booking. If you cannot manage the ridge, the two pedunculate oaks by
the gate show the same colour a week later.

[Back to the collections](/collections.html)
