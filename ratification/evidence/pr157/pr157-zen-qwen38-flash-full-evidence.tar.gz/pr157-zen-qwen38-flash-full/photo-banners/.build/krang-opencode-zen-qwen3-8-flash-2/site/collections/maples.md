---
title: The Maples
class: collections
author: Ruarí Bell
best-month: November
description: Alderfen's maple collection around the canal-side lawn, at its best in November.
---

# The Maples

*Curator: Ruarí Bell. The collection is at its best in November.*

Twelve maples ring the canal-side lawn, planted in 1994 the year the flood
bank was rebuilt. They are the loudest colour in the arboretum and the latest
to say so.

## What to look for

Come in November. The big-leaf maple goes yellow first, late in October, but
the red moment is November: the Japanese maples along the western path hold
crimson while everything deciduous around them is bare, and the field maples
drop their whole leaves in one week and carpet the lawn orange. In a mild year
the last trident maple on the north side holds its russet leaves until the
twelfth.

## Getting around them

The lawn circuit is level gravel and passable in all weather. The Japanese
maples are closest to the bench with the iron back; if you are only there ten
minutes, that is the bench to sit on.

[Back to the collections](/collections.html)
