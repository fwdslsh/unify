import { readFileSync, existsSync, statSync } from 'node:fs';
import { join } from 'node:path';

const DIST = '/tmp/sandbox/dist';
const BASE = 'https://alderfen.pages.dev/arboretum/';

const pages = [
  'index.html',
  'visit/index.html',
  'collections/index.html',
  'collections/maples/index.html',
  'collections/oaks/index.html',
  'collections/witch-hazels/index.html',
].map(p => '/' + p);

function fileFor(urlPath) {
  if (urlPath === '/arboretum/') return 'index.html';
  if (urlPath.startsWith('/arboretum/')) urlPath = urlPath.slice('/arboretum'.length);
  if (!urlPath.startsWith('/')) return null;
  const rel = decodeURIComponent(urlPath.replace(/^\//, ''));
  const direct = join(DIST, rel);
  if (existsSync(direct) && statSync(direct).isFile()) return rel;
  if (rel.endsWith('/') && existsSync(join(DIST, rel, 'index.html'))) return rel + 'index.html';
  return null;
}

let problems = 0;
const fail = (...a) => { console.log('PROBLEM:', ...a); problems++; };

const seen = new Set();
for (const page of pages) {
  const file = join(DIST, page.slice(1));
  if (!existsSync(file)) { fail('missing page', page); continue; }
  const html = readFileSync(file, 'utf8');
  if (!html.includes('site-header') || !html.includes('logo.png')) fail('header/logo missing on', page);
  if (!html.includes('site-footer')) fail('footer missing on', page);
  const t = (html.match(/<title>([^<]*)<\/title>/) || [])[1] || '';
  console.log('title', page, '→', JSON.stringify(t));
  for (const m of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
    const u = m[1];
    if (u.startsWith('mailto:')) continue;
    let urlObj;
    try { urlObj = new URL(u, BASE + page.slice(1)); } catch { fail('unparseable', u, 'on', page); continue; }
    if (urlObj.hostname !== 'alderfen.pages.dev') fail('wrong host', u, 'on', page);
    if (!urlObj.pathname.startsWith('/arboretum/')) fail('outside base path', u, 'on', page);
    if (/\.(html?|md)$/i.test(urlObj.pathname)) fail('source extension in URL', u, 'on', page);
    seen.add(urlObj.pathname);
    if (urlObj.pathname.endsWith('.css')) {
      if (!existsSync(join(DIST, urlObj.pathname.slice('/arboretum/'.length)))) fail('css missing', urlObj.pathname, 'linked from', page);
    } else if (!urlObj.pathname.endsWith('.xml')) {
      if (!fileFor(urlObj.pathname)) fail('unresolved', urlObj.pathname, 'linked from', page);
    }
  }
}

const want = (page, img) => {
  const html = readFileSync(join(DIST, page.slice(1)), 'utf8');
  if (!html.includes(img)) fail('expected image', img, 'not on', page);
};
want('/index.html', '/images/home-wide.png');
want('/visit/index.html', '/images/visit-banner.png');
want('/collections/index.html', '/images/collections-banner.png');
for (const page of pages) want(page, '/images/logo.png');

const sm = readFileSync(join(DIST, 'sitemap.xml'), 'utf8');
for (const p of pages) {
  const url = BASE + (p === '/index.html' ? '' : p.slice(1).replace(/index\.html$/, ''));
  if (!sm.includes(url)) fail('sitemap missing', url);
}

const css = readFileSync(join(DIST, 'styles.css'), 'utf8');
if (/url\(/.test(css)) fail('url() found in shipped CSS');

console.log('linked paths:');
for (const p of [...seen].sort()) console.log('  ' + p, fileFor(p) || (p.endsWith('.css') || p.endsWith('.xml') ? '(asset)' : 'MISSING'));
console.log(problems ? `FAILED: ${problems} problems` : 'ALL CHECKS PASSED');
process.exit(problems ? 1 : 0);
