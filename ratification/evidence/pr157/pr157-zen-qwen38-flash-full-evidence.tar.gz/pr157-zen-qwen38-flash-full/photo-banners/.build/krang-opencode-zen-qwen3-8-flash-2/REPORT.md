# Alderfen Arboretum — build report

Built with `./unify` (no JS, no template language). Source lives in `site/`, output in
`dist/`. The site is published to `https://alderfen.pages.dev/arboretum/` (a subdirectory),
and visitor URLs do not end in `.html`.

## 1. The command line that publishes the site

```
./unify build --clean --base-url https://alderfen.pages.dev/arboretum/ --pretty-urls
```

Run it once as a pre-flight check with no writing first, then to publish:

```
./unify build --dry-run --strict --base-url https://alderfen.pages.dev/arboretum/ --pretty-urls   # checks only, writes nothing
./unify build --clean        --base-url https://alderfen.pages.dev/arboretum/ --pretty-urls        # publishes dist/
```

Exit 0 means `dist/` is the complete site; non-zero means nothing was published. The two
flags that carry the brief's two publishing rules are `--base-url` (the whole `/arboretum/`
address, so links, photos and the stylesheet resolve under the subdirectory) and
`--pretty-urls` (`visit.html` → `visit/`, and rewrites internal links to match). Deploy
`dist/` at the site's root so it is served from `/arboretum/`.

Final build reported `BUILD EXIT=0` and produced 12 files. Verified separately
(`_verify.mjs`, `_serve_check.mjs`): every page and every photo returns 200 over an HTTP
server emulating the `/arboretum/` subdirectory, each page has exactly one `<header>` (with
`/arboretum/images/logo.png`), one `<main>` and one `<footer>`, the home banner carries
`home-wide.png`, the section banners carry `visit-banner.png` / `collections-banner.png`, no
`href`/`src` ends in `.html` or escapes the base path, and each guide names its curator and
best month.

## 2. Structure

- `site/_layout.html` — the shared chrome. Header (logo + nav), `<main><slot></slot></main>`,
  footer. Because unify wraps each page with the nearest `_layout.html` (own folder then
  parents), the guides one folder deeper inherit it automatically — the page "says nothing."
- `site/index.html`, `site/visit.html`, `site/collections.html` — HTML pages (own `<head>`,
  no frontmatter). Full-width banner home photo is `home-wide.png` (taller); the two section
  banners reuse the same `.banner` style and are shallower because their photos are 320×80
  vs 320×120.
- `site/collections/{oaks,maples,witch-hazels}.md` — three guides in Markdown, pure frontmatter
  + prose, no `<head>`. Each names its curator and best month in the body.
- `site/styles.css`, `site/images/` (copied, not newly authored, from `./images/`).

## 3. Honest answers

### What `rules.md` did not answer — the sentence I wanted and could not find

The rules explain `--base-url` and `--pretty-urls` **separately**, each in its own bullet, and
never show them **together**. There is no sentence anywhere stating that a link I wrote as
`/visit.html`, under both flags, becomes `https://alderfen.pages.dev/arboretum/visit/` — base
prefix *and* pretty rewrite composed. I wanted one worked example proving the two flags stack
cleanly rather than fight (e.g. base-prefix a `.html` that pretty-urls has already removed).
I had to trust the composition and then verify by reading the literal `href=` values in the
built `dist/` files.

A second sentence I looked for and did not find: whether Markdown `title:` frontmatter takes
part in the separator-join rule (that rule is written entirely for HTML `<title>`:
"the layout writes `<title>— My Site</title>`, a page writes only its own name"). The docs never
say the frontmatter `title` flows through the same join. It does — `The Oaks — Alderfen
Arboretum` appeared — but only by observation, not from the text.

### What I re-read, and why it did not land the first time

The "Merging a page into its layout" section (the bare-`<slot>` vs `slot=`-fill rules). It did
not land because the wording interleaves two different mechanisms — "everything else replaces
the layout's bare `<slot>`" and "the first default-content page main unwraps" — and my pages
wrap their content in `<main>` while my layout *also* has `<main><slot></slot></main>`. I was
worried I would ship a `<main>` nested inside a `<main>`, or lose the page content. I re-read
it twice before realising the page's `<main>` unwraps into the layout's slot, giving exactly one
`<main>`. I then confirmed it mechanically with `grep -c '<main>'` on every output page rather
than trusting my reading.

I also re-read the Styles/finishing note about `url()` in CSS ("a root-relative one misses the
`--base-url` prefix and 404s"). It did not land at first because I initially considered a
`background-image` for the banners; re-reading made me put every photo in an `<img>` instead, so
`--base-url` rewrites its `src` and there is no root-relative `url()` to 404. The shipped CSS has
zero `url()` (verified by grep).

### What I guessed at, or inferred rather than read

- **Flag combination:** that `--base-url` + `--pretty-urls` is *the* right pair for this brief.
  The rules describe each flag; pairing them was my inference from "subdirectory" + "no `.html`."
- **`--clean`:** not required, but I added it so a republish cannot leave stale `dist/` files. This
  is a judgement call, not something the rules mandate.
- **Markdown page into layout:** that a `.md` page's rendered body drops into the layout's bare
  `<slot>` inside `<main>` (the rules phrase merging around HTML pages). Inferred from the HTML
  rule, then confirmed in output.
- **Extra frontmatter keys:** I put `author:` and `best-month:` in frontmatter *and* restated
  curator + month in the body. The rules say an unrecognised key becomes a `<meta name=…>`; I
  did not want the brief's "names its curator" to depend on an invisible meta tag, so the visible
  requirement is met in prose. That split was a decision, not a documented instruction.
- **`class:` on `<body>`:** I used `class: collections` etc. for active-nav underlining, inferring
  from the "your classes are added" rule that frontmatter `class` merges onto the layout's
  `<body>`. My layout `<body>` has no class, so append-vs-replace never mattered and I did **not**
  verify that distinction — honest gap.
- **Images copied vs created:** the brief said "do not create new image files," so I copied the
  four provided files into `site/images/`. Choosing the copy (rather than `source: .`) because the
  source root is `site/` and "everything in the source root ships" — putting images elsewhere
  would not publish them, and pointing the root at `.` would ship `unify`, `rules.md` and `dist/`.
- **Sitemap URL form:** the directory URLs with trailing slashes — I inferred the shape, my first
  checker wrongly expected `/visit/index.html` and I corrected it after reading the real
  `dist/sitemap.xml`.
