---
title: The Witch Hazels
class: collections
author: Tessa Nunn
best-month: January
description: Alderfen's witch hazels on the stable slope, in flower in January, the bleakest month of the year.
---

# The Witch Hazels

*Curator: Tessa Nunn. The collection is at its best in January.*

Nine witch hazels — Hamamelis, and the related witch hazels of Asia — grow on
the slope behind the stables, where the ground stays cold and no one mows.
They are the reason Tessa insists the arboretum is worth visiting in the
bleakest month of the year.

## What to look for

January. The flowers open on bare wood, ribbon-thin and yellow to copper, and
on a mild day they smell of spice from three paces. The Arnold Promise opens
first, usually around the New Year; Diane and Jelena follow through the
month, and one purple-leaf specimen by the fence holds flowers into February.
In October and November the same bushes colour a clean clear yellow, if you
want a second reason to come.

## Getting around them

The slope path is steep in one corner; the level alternative is the fence-line
walk from the stable gate, which passes all nine from below. Tessa keeps a
thermos at the stable on Sunday mornings in January and will point out which
bush is openest that week.

[Back to the collections](/collections.html)
