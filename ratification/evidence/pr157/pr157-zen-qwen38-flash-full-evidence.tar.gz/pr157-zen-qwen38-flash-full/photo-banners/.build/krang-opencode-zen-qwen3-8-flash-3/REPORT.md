# Alderfen Arboretum — publishing report

## The command line that publishes the site

```
./unify build --base-url https://alderfen.pages.dev/arboretum/ --pretty-urls --clean
```

`pretty-urls` and `base-url` are also saved in `unify.yaml`, so a bare `./unify build`
publishes the same site. `clean` is deliberately **not** in `unify.yaml`: `--save-config`
wrote it there, and a saved `clean: true` makes `unify audit` exit 2 ("unify audit does not
take --clean"). Kept as a command-line flag, both work.

## What was built

```
site/
  _layout.html            header (logo + nav), <main><slot></slot></main>, footer
  index.html              home — full-height banner over /images/home-wide.png
  visit.html              Visit — shallower banner, opening times / getting here / accessibility
  collections.html        Collections — shallower banner, intro + links to the three guides
  collections/guides/     oaks.md  maples.md  witch-hazels.md (curator-ownable Markdown)
  styles.css
  images/                 the four provided photos, moved (not copied) in from ./images/
```

Guides are Markdown with `title`/`author`/`description`/`schema: Article`/`date`/`class`
frontmatter; curator and best month (October / November / January) are also in the visible
body text. Chrome is inherited automatically — the root `_layout.html` is the nearest layout
in every folder's parent chain.

## How I checked the output

- `./unify build --dry-run --strict` first, then the real build; exit 0 both times.
- `./unify audit --strict` on the final state: "nothing to report", exit 0.
- Inspected `dist/`: every `href`/`src` carries the `/arboretum/` prefix; no emitted link
  ends in `.html`; all six pages carry the header, footer and logo; the four photos are
  byte-identical copies.
- `_check.mjs` (scratch, at project root — outside the `site/` source root, so never
  shipped) serves `dist/` at `https://…/arboretum/` paths and follows every emitted link:
  **11 URLs, 0 failures** — the six pretty page URLs, `styles.css`, all four PNGs,
  `sitemap.xml`, and a `feed.xml` that unify generated for free (declared `Article` +
  `--base-url`, as the rules promised).

## What `rules.md` did not answer

The sentence I looked for and could not find: **what counts as the "real filename" when
linking to a Markdown page.** The rules say "Always link the real filename — `/about.html`,
not `/about/`", but every example is an `.html` source, and the real filename of the oaks
guide is `oaks.md`. I wrote `/collections/guides/oaks.html` and got silence from a strict
audit and the right `/arboretum/collections/guides/oaks/` in the output — proof after the
fact, not an answer.

Other things the documentation left open:

- Whether `--pretty-urls` turns the home page into `index/index.html`. The spec sentence
  (`about.html → about/index.html`) applied to the home file reads as a disaster; only the
  dry-run listing (`write dist/index.html (/arboretum/)`) answered it.
- Whether a frontmatter `title:` satisfies the "page emits an `<h1>`" expectation. The rules
  describe only the reverse direction ("No `title:` → first `# Heading`"); my first passing
  build had three guides that `audit --strict` then called `h1-missing`.
- Whether `class:` accepts more than one class (`class: collections guide` ships verbatim;
  confirmed in output, not documented).
- Which options are safe to save: nothing warns that a saved `clean:` poisons the `audit`
  subcommand.
- How assets living outside the source root ship at all — the rules only say "Everything in
  the source root ships". Moving the brief's `./images/` into `site/images/` was my answer.

## What I re-read, and why it did not land the first time

- **"Merging a page into its layout" plus the include/slots paragraph.** The word *slot*
  names three different mechanisms (include-fragment fills, the layout's bare `<slot></slot>`,
  and named `slot=` fills) and my first pass blended them — I nearly wrote `slot=` on the
  pages' `<main>` elements. Re-reading, the plain truth surfaced: a page's default `<main>`
  replaces a bare-slot layout with no marking at all; `slot=` is only for named slots.
- **The long sentence in "Files"** covering leading `/`, real filenames, pretty-URL rewriting,
  directory-link validity and `--base-url` in one breath. It took two re-reads to separate
  "what you write" from "what the build rewrites" and to notice that `--base-url` prefixing
  is what makes root-relative `/styles.css` resolve under `/arboretum/`.
- **`<title>— My Site</title>`, "no leading space".** It looks like a typo — a title that
  starts with an em-dash. It took the rest of the sentence to land that the layout's title is
  purely the suffix, joined to each page's own title.
- **"a `date:` with no time is reported and left out rather than guessed at"** — I first read
  it as a feed-only footnote. It also governs `schema: Article`, which is why every guide's
  `date` now carries a full `2026-09-20T10:00:00Z`-style timestamp.

## What I guessed or inferred rather than read

- The `.html` link to a `.md` page (above) — inference, later confirmed by build + audit.
- That pages should **not** repeat the layout's `<link rel="stylesheet">`: the head-merging
  rule says same-`name` metas replace but "everything else appends after", so re-listing the
  stylesheet would duplicate it. The docs settle the `<meta charset>` collision but say
  nothing about duplicate links.
- That the title separator join applies to Markdown `title:` values as well as HTML page
  titles (output confirms: "The Oaks — Alderfen Arboretum").
- That `author:` in frontmatter feeds both `<meta name=author>` and the Article JSON-LD
  author — the schema section lists `author` as a field taken "from what the page already
  declares" but never says md-`author:` is what produces it.
- The trailing slash on `--base-url` (taken from the help-text example
  `https://site.example/repo/`, not from a stated rule).
- That the brief's "do not create new image files" permits *moving* `images/` into `site/` —
  no file is created and nothing duplicated; the originals left the project root.
- The guides' `date:` values are invented publication stamps, chosen to quiet the strict
  audit's `schema-incomplete` finding.
- The banner technique itself (an `<img>` filling a positioned band with an overlaid
  semi-transparent text layer) is my CSS, no rule involved — but I used `<img>` rather than
  CSS `url()` deliberately, because the docs do warn that `url()` in a stylesheet never
  receives the base-url prefix.
