---
title: "The Oaks"
author: Rowan Ayres
description: "Curator's guide to the oak avenue at Alderfen Arboretum — what to look for and when."
schema: Article
date: 2026-09-20T10:00:00Z
class: collections guide
best-month: October
---

# The Oaks

The oak avenue is the oldest part of the arboretum: forty-two trees planted in 1979 along what
was then the drystone boundary, and the founders insisted on oaks because, as the minute book
puts it, "they will outlive everyone who argues about them." They have. Twenty-six kinds of
Quercus grow here, from the native English oak to the cork oak at the warm south end.

## What to look for

- **The avenue itself** — walk it end to end in low autumn sun; the leaf litter underfoot is
  four seasons deep and the light comes through the canopy sideways.
- **Acorns** — the quickest way to tell the kinds apart. The pin oak's caps are like wound
  metal; the swamp white oak's acorns sit on a long stalk and do not drop until December.
- **The galls** — oak apple, spangle, and the little rosette gall. Every October the leaves
  carry more insect architecture than leaves carry green.
- **Bark** — the chinkapin oak shingles in copper plates; the English oak furrows deeply.

## When to come

The collection is at its best in **October**, when the colour lands — oaks turn late, after the
maples have already gone — and the acorns are down. Curator: **Rowan Ayres**. Rowan leads the
free oak survey on the first Sunday of every month from the sundial; bring a notebook, the
labels are being redone.
