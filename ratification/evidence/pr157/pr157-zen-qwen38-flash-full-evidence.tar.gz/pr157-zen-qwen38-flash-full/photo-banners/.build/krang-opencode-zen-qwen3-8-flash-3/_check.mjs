import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.resolve('dist');
const MIME = { '.html': 'text/html', '.css': 'text/css', '.png': 'image/png', '.xml': 'application/xml' };

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (!p.startsWith('/arboretum')) return void res.writeHead(404).end();
  let file = path.join(ROOT, p.slice('/arboretum'.length) || '/');
  if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
  if (!fs.existsSync(file)) return void res.writeHead(404).end();
  res.writeHead(200, { 'content-type': MIME[path.extname(file)] ?? 'application/octet-stream' });
  res.end(fs.readFileSync(file));
});
await new Promise(r => server.listen(8777, r));

const seen = new Map(), queue = ['http://127.0.0.1:8777/arboretum/'];
while (queue.length) {
  const url = queue.pop();
  if (seen.has(url)) continue;
  const res = await fetch(url);
  const ct = res.headers.get('content-type') || '';
  const body = res.status === 200 && ct.includes('html') ? await res.text() : null;
  seen.set(url, res.status);
  if (body) for (const m of body.matchAll(/(?:href|src)="(\/arboretum\/[^"]*|https:\/\/alderfen\.pages\.dev\/arboretum\/[^"]*)"/g)) {
    const u = m[1].startsWith('http') ? 'http://127.0.0.1:8777' + new URL(m[1]).pathname : 'http://127.0.0.1:8777' + m[1];
    if (!seen.has(u)) queue.push(u);
  }
}
server.close();
let bad = 0;
for (const [u, s] of [...seen].sort()) { if (s !== 200) { bad++; console.log(s, u); } }
console.log(`${seen.size} URLs checked, ${bad} failures`);
console.log([...seen].filter(([u]) => u.endsWith('.html') || u.endsWith('/')).map(([u, s]) => `${s} ${u.replace('http://127.0.0.1:8777', 'https://alderfen.pages.dev')}`).sort().join('\n'));
