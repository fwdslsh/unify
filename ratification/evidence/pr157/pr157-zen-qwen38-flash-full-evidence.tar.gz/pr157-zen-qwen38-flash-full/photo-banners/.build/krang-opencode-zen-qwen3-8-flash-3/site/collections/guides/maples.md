---
title: "The Maples"
author: Ines Havelova
description: "Curator's guide to the maple hollow at Alderfen Arboretum — what to look for and when."
schema: Article
date: 2026-10-20T10:00:00Z
class: collections guide
best-month: November
---

# The Maples

The hollow below the avenue holds the wettest soil on the site, which is exactly why the maples
were put there: they are thirsty trees, and the cold air that settles in the dip makes the
autumn colour last a full fortnight. Thirty-one kinds of Acer grow in the hollow and along its
slopes, the big-leaved and trunks-you-can-hug collection that most visitors photograph.

## What to look for

- **The turning** — it starts at the pond edge and climbs the slope. Silver maples first,
  then the reds, and the Japanese full-moon maple last, going from cream to orange in a week.
- **The samaras** — every maple seeds by helicopter, but the wing shapes differ enough to ID a
  tree from the ground: the sycamore's hang in pairs, the trilobed maple's are stubby and red.
- **Bark in winter** — the striped maple is green with white lines; the manna ash bark crackles
  like old varnish. November is a bark month as much as a leaf month.
- **Spring** — the trunks of the paperbark maples peel in sheets you can lift off in your hand.

## When to come

The collection is at its best in **November**, later than the avenue because the hollow holds
the colour. Curator: **Ines Havelova**. Ines keeps the hand-painted route sheet for the hollow
at the warden's cabin, and puts out the chair — the one oak-bench under the full-moon maple —
on the two best weekends.
