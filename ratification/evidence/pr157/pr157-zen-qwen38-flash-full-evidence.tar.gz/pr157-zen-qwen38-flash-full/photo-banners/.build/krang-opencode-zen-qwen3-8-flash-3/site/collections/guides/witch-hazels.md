---
title: "The Witch Hazels"
author: Danny Okonjo
description: "Curator's guide to the witch hazel thicket at Alderfen Arboretum — what to look for and when."
schema: Article
date: 2025-12-20T10:00:00Z
class: collections guide
best-month: January
---

# The Witch Hazels

Hamamelis was Danny's argument for the pond side: ground that stays wet and shade nobody else
wanted, because the shrubs that love it flower when nobody comes. Nineteen kinds of witch hazel
grow along the damp walk, and in a hard winter the whole thicket is in ribboned yellow and rust
blossom from January into February, the scent strongest on the still, cold afternoons.

## What to look for

- **The flowers** — four narrow strap petals, curled like wood shavings, opening from the very
  tips of bare stems. Vase-shaped, and worth walking round twice for the two colours.
- **The scent** — the pandora hazel you smell before you see it; on a windless January
  afternoon the scent carries half the length of the pond.
- **The autumn colour** — almost everyone misses it, and it is the best in the arboretum for
  one week in early November: butter yellow, then a deep apricot, then nothing.
- **The seed pods** — from August the ripened pods crack open and shoot the hard black seed two,
  three metres into the netting, which is how the row of seedlings appeared behind the shed.

## When to come

The collection is at its best in **January**, in the dead of the year. Curator: **Danny
Okonjo**. Danny runs the winter walk from the east gate on the second Sunday of January; the
guide is a candle flame for the first hour, so bring warm gloves you do not mind losing.
