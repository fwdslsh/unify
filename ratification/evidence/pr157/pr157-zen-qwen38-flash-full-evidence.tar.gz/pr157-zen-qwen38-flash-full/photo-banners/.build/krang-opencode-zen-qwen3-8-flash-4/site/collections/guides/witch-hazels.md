---
title: "The Witch Hazels"
class: collections
description: "A curator's guide to the witch hazel collection at Alderfen Arboretum."
---

# The Witch Hazels

Curated by **Priya Raman**. The witch hazel collection is at its best in
**February**.

The witch hazels grow on the north slope, out of the wind, where the old
dairy wall holds the evening's cold. Thirty-one shrubs and small trees make up
the collection — among them the winter-blooming *Hamamelis* with their spidery
yellow, orange and red ribbons, and the Chinese witch hazels whose perfume
carries thirty metres on a still night.

## What to look for

Follow the boardwalk up from the tearoom barn; the slope path is level and the
handrail runs all the way. The first flowers open at the bottom of the slope
where the wall takes the sun — look for *Hamamelis mollis* 'Pallida', the
yellow that lights up on grey afternoons. Higher up, the orange Arnold Promises
flower a fortnight later and hold into March.

## Best in February

February is the month to walk the slope — the scent is strongest on a damp,
still afternoon and, with the flowers backlit, the ribbons glow as if lit from
inside. Priya runs the fragrance walk — a slow, silent mile for small groups —
every February Saturday at two o'clock.
