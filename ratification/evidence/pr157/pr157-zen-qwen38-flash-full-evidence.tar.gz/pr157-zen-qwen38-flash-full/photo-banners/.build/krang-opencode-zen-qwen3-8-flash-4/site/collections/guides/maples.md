---
title: "The Maples"
class: collections
description: "A curator's guide to the maple collection at Alderfen Arboretum."
---

# The Maples

Curated by **Daniel Okafor**. The maple collection is at its best in
**November**.

No visit to Alderfen is complete without walking the maple avenue — forty
 Norway maples planted in a single line in 1982, now touching crown to crown
over Green Lane. Behind it, the Japanese garden holds our smaller, quieter
treasures: fullmoon, palmate and the foxglove maple, which in a good year
blooms pink in May before it leafs.

## What to look for

The avenue is best entered from the pond end, with the low afternoon sun
behind the leaves. Compare the flaking, camouflage bark of the paperbark
maple with the smooth grey skin of the avenue's Norway maples. In the Japanese
garden, kneel and look at the leaf scars of the trunks — Daniel's labels give
the Latin names, but the shapes tell the story faster.

## Best in November

November is the colour month, and it is short: the peak usually runs eight to
ten days, most often in the second and third weeks. After the first hard frost
the samaras — the helicopter seeds — come in showers; the children's pond
bridge is the place to be. Daniel takes a group along the avenue on the last
Saturday of the month.
