# Alderfen Arboretum — build report

## Publishing

The site source is `site/`; the command that builds and publishes it (exit 0, `dist/` complete):

```
./unify build --base-url https://alderfen.pages.dev/arboretum/ --pretty-urls --clean --audit
```

`--audit` publishes only if `unify audit` would pass; drop it if you want the bare build. A
pre-flight `./unify build --dry-run --strict` reports every problem without writing `dist/`.

## What was built

- `site/index.html` — home, full-width banner over `home-wide.png` with name + welcome overlaid,
  intro below.
- `site/visit.html` — shallower `visit-banner.png` banner with "Visit", then opening times, getting
  here, accessibility.
- `site/collections.html` — shallower `collections-banner.png` banner with "Collections", then an
  intro and links to the three guides.
- `site/collections/guides/{oaks,maples,witch-hazels}.md` — pure Markdown by the curators; each
  names its curator (Marta Henly / Daniel Okafor / Priya Raman) and its best month (October /
  November / February).
- `site/_layout.html` — header with logo + nav and footer, applied to every page automatically
  (nearest `_layout.html`; guides one folder deeper still inherit it). Body classes per page drive
  active-nav CSS.
- `site/css/style.css` — one stylesheet; all photos are `<img src>`, never CSS `url()`, because
  unify only rewrites HTML `href`/`src` and a `url()` would miss the `/arboretum/` prefix.

Verified: `./unify audit --strict` reports nothing; every `href`/`src`/sitemap URL emitted by the
build resolves to a real file under `https://alderfen.pages.dev/arboretum/` (checked by a script
that walks `dist/`, and again over HTTP); no visitor-facing URL ends in `.html`; the six page
addresses are `/arboretum/`, `/arboretum/visit/`, `/arboretum/collections/`,
`/arboretum/collections/guides/{oaks,maples,witch-hazels}/`.

## What `rules.md` did not answer

- **Links to Markdown pages.** The docs say to link the real filename (`/about.html`, not
  `/about/`) and that this "stays true under `--pretty-urls`" — but only ever for `.html`. Nowhere
  is it stated that you write `oaks.md` and the build rewrites it to `/collections/guides/oaks/`.
  The sentence I wanted and could not find: "a link to a `.md` page names its `.md` file." I wrote
  `/collections/guides/oaks.md` on the collections page as the obvious extrapolation; the clean
  strict audit and my link-walk confirmed it.
- **Front matter `title` and the body `<h1>`.** Nothing says whether `title: "The Oaks"` also
  renders a heading. I guessed it would and omitted an `# heading`; `audit` reported
  `h1-missing`, telling me unify deliberately emits no `<h1>` for a titled page — the inverse of
  what "No `title:` → first `# Heading`" almost implies. Added `# The Oaks` etc.
- Whether `--dry-run --strict` output's `write … ← file + _layout.html` line means layout
  resolution succeeded or merely was attempted (docs promise the list, not its semantics).

## What I re-read, and why it did not land the first time

- **The Include/Merging section**, twice. I arrived expecting a template language and looked for
  variables to pass the page body into the layout; there are none, so the sentences about bare
  `<slot></slot>`, "everything else" replacing it, and "a bare `<header>`/`<footer>` does not
  replace the layout's" kept sliding past me as template-engine noise. On the second pass it
  clicked that `<main><slot></slot></main>` in the layout plus page top-level content is the whole
  mechanism, and that header/footer are simply *not* slot targets — which is exactly the shape I
  needed for shared chrome.
- **The head-merge rules (layout line 40–44).** I first skimmed it as generic SEO talk and wrote
  `<title>Alderfen Arboretum — Home</title>` in the layout and full titles on pages. Re-reading:
  the separator is authored *into the layout* (`<title>— My Site</title>`) and pages write only
  their own name; my first version would have shipped "Home — My Site — Alderfen Arboretum". Same
  near-miss with `canonical`: the docs forbid a layout from carrying one, so I relied on
  `--canonical auto` rather than touching it.
- **The "Styles, scripts, finishing" paragraph** — three readings. Its one long sentence mixes CSS
  scoping, `url()` non-rewriting, and fetched addresses, and I initially took "keep every `url()`
  … relative" as advice about relative-path syntax rather than as a warning that a root-relative
  `url()` in CSS 404s under `--base-url`. That risk is why every image went into HTML.

## What I guessed or inferred rather than read

- `--base-url` ending in `/arboretum/` yields clean addresses like `/arboretum/visit/` (the docs
  show a `/repo/` base but never walk a pretty-urls + subdirectory combination).
- `class: collections` in Markdown front matter is the way to mark the guides as part of the
  Collections section for active-nav CSS; reading "root attributes … your classes are added" made
  this plausible for HTML pages, and front matter is documented as equivalent, but the exact
  merge onto the layout's `<body>` is my inference (confirmed in `dist/`).
- The per-guide `description` front matter keys feeding `og:description` (docs say og defaults to
  final description; which front matter key counts as "the description" is not named for Markdown
  — `description` was the obvious guess and og output matched).
- Copy itself (history, curators' names, months, tearoom, bus 14) is invented to fill the structure
  the brief asked for; images were copied as-is into `site/images/` and no new image files created.
