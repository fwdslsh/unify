const fs = require('fs');
const path = require('path');
const DIST = path.join(__dirname, '..', 'dist');
const BASE = 'https://alderfen.pages.dev/arboretum/';

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out); else out.push(p);
  }
  return out;
}

const htmls = walk(DIST).filter(f => f.endsWith('.html'));
let problems = 0;
const fail = (page, msg) => { problems++; console.log(`FAIL [${page}] ${msg}`); };

for (const f of htmls) {
  const html = fs.readFileSync(f, 'utf8');
  const addr = BASE + path.relative(DIST, f).split(path.sep).join('/').replace(/index\.html$/, '');
  const urls = [...html.matchAll(/(?:href|src)="([^"]+)"/g)].map(m => m[1]);

  for (const u of urls) {
    if (u.startsWith('#') || u.startsWith('mailto:')) continue;
    let target;
    if (u.startsWith(BASE)) target = u.slice(BASE.length);
    else if (u.startsWith('/arboretum/')) target = u.slice('/arboretum/'.length);
    else if (u.startsWith('/')) { fail(addr, `root-relative url misses the /arboretum/ prefix: ${u}`); continue; }
    else fail(addr, `not an authored root url: ${u}`);
    target = target.split('#')[0];
    if (target === '') target = 'index.html';
    if (target.endsWith('/')) target += 'index.html';
    if (!fs.existsSync(path.join(DIST, decodeURIComponent(target)))) fail(addr, `unresolved: ${u}`);
  }

  if (/href="[^"]*\.html/i.test(html)) fail(addr, 'a link still ends in .html');
  for (const must of ['site-header', 'site-footer', '/arboretum/images/logo.png', '/arboretum/css/style.css'])
    if (!html.includes(must)) fail(addr, `missing ${must}`);
}

if (/url\(/.test(fs.readFileSync(path.join(DIST, 'css/style.css'), 'utf8'))) fail('css', 'url() is not rewritten by unify');

for (const [page, img, title] of [
  ['index.html', 'home-wide.png', 'Home — Alderfen Arboretum'],
  ['visit/index.html', 'visit-banner.png', 'Visit — Alderfen Arboretum'],
  ['collections/index.html', 'collections-banner.png', 'Collections — Alderfen Arboretum'],
  ['collections/guides/oaks/index.html', null, 'The Oaks — Alderfen Arboretum'],
  ['collections/guides/maples/index.html', null, 'The Maples — Alderfen Arboretum'],
  ['collections/guides/witch-hazels/index.html', null, 'The Witch Hazels — Alderfen Arboretum'],
]) {
  const html = fs.readFileSync(path.join(DIST, page), 'utf8');
  if (!html.includes(`<title>${title}</title>`)) fail(page, 'wrong merged title');
  if (img && !html.includes(`/arboretum/images/${img}`)) fail(page, `banner ${img} missing`);
  if (/<h1[\s>]/.test(html) === false) fail(page, 'no h1');
}

const guideTerms = {
  'collections/guides/oaks/index.html': ['Marta Henly', 'October'],
  'collections/guides/maples/index.html': ['Daniel Okafor', 'November'],
  'collections/guides/witch-hazels/index.html': ['Priya Raman', 'February'],
};
for (const [p, terms] of Object.entries(guideTerms)) {
  const html = fs.readFileSync(path.join(DIST, p), 'utf8');
  for (const t of terms) if (!html.includes(t)) fail(p, `missing "${t}"`);
  if (html.includes('<script')) fail(p, 'guide shipped a script');
}

console.log(problems === 0 ? `OK: ${htmls.length} pages; all links/assets resolve under /arboretum/; no .html urls; chrome+h1 on every page` : `${problems} problems`);
process.exit(problems ? 1 : 0);
