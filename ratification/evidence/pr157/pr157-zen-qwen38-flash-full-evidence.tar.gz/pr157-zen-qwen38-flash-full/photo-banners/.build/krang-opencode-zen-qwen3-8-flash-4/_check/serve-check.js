const http = require('http');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const WEB = path.join(__dirname, 'webroot');
fs.rmSync(WEB, { recursive: true, force: true });
fs.mkdirSync(WEB);
fs.symlinkSync(path.join(__dirname, '..', 'dist'), path.join(WEB, 'arboretum'));

const srv = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p.endsWith('/')) p += 'index.html';
  const f = path.join(WEB, p);
  fs.readFile(f, (e, d) => { e ? (res.writeHead(404), res.end('404')) : (res.writeHead(200), res.end(d)); });
});

const BASE = 'http://127.0.0.1:4171';
srv.listen(4171, async () => {
  const DIST = path.join(__dirname, '..', 'dist');
  const pages = execSync(`grep -rlo . --include='*.html' ${DIST} | sort`, { encoding: 'utf8' }).trim().split('\n');
  const urls = new Set();
  for (const pg of pages) {
    const html = fs.readFileSync(pg, 'utf8');
    for (const m of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
      let u = m[1];
      if (u.startsWith('#')) continue;
      if (u.startsWith('https://alderfen.pages.dev')) u = u.replace('https://alderfen.pages.dev', '');
      if (!u.startsWith('/arboretum')) continue;
      urls.add(u);
    }
  }
  const site = fs.readFileSync(path.join(DIST, 'sitemap.xml'), 'utf8');
  for (const m of site.matchAll(/<loc>([^<]+)<\/loc>/g)) urls.add(m[1].replace('https://alderfen.pages.dev', ''));
  let bad = 0;
  for (const u of [...urls].sort()) {
    const code = await new Promise(r => http.get(BASE + u, res => { res.resume(); r(res.statusCode); }).on('error', () => r('ERR')));
    if (code !== 200) { bad++; console.log(`BAD ${code} ${u}`); }
    else console.log(`200 ${u}`);
  }
  console.log(bad ? `${bad} failures` : `ALL ${urls.size} URLs served OK at /arboretum/`);
  srv.close();
  process.exit(bad ? 1 : 0);
});
