---
title: "The Oaks"
class: collections
description: "A curator's guide to the oak collection at Alderfen Arboretum."
---

# The Oaks

Curated by **Marta Henly**. The oak collection is at its best in **October**.

The oaks are the oldest part of the arboretum, planted in 1979 along what was
then the farm's eastern hedge. Sixty-two species and varieties now stand
there, from the common oak that every English lane knows to the swamp oak of
the Mississippi bottoms, whose leaves hang on the branches well into winter.

## What to look for

Start at the gate and turn left; the oak walk runs beside the meadow for four
hundred metres. The swamp and pin oaks are at the near end — note how their
leaf margins wave and bristle. Halfway along stands the parliament of
*Quercus robur* 'Cousin Red', grown from an acorn taken from the parish's own
cousin-tree in 1980.

In October the whole walk turns russet and bronze. Look up: the empty nests of
the grey squirrels are easiest to see now, high in the crown of the sessile
oaks.

## Best in October

Mist makes October mornings here; bring a flask and take your time. Marta
leads an acorn identification table on the first Sunday of the month, beside
the second bench.
