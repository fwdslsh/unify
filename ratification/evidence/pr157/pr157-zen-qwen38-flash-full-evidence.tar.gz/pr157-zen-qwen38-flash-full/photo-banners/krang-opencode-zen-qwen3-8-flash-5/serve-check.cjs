const http = require('http');
const fs = require('fs');
const path = require('path');
const DIST = '/tmp/sandbox/dist';
const MIME = { '.html': 'text/html', '.css': 'text/css', '.png': 'image/png', '.xml': 'application/xml' };

http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (!p.startsWith('/arboretum/')) { res.writeHead(404); return res.end('outside mount'); }
  p = '/' + p.slice('/arboretum/'.length);
  let f = path.join(DIST, p);
  if (p.endsWith('/')) f = path.join(f, 'index.html');
  if (!fs.existsSync(f) && fs.existsSync(f + '/index.html')) f = f + '/index.html';
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end('not found'); }
  res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
}).listen(8907, () => console.log('up'));
