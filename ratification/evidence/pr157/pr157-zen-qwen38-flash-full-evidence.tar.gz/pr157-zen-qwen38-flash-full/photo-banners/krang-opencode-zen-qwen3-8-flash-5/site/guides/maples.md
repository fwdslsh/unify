---
title: The Maples
description: A curator's guide to the maple collection at Alderfen Arboretum — who tends it, when it is at its best, and where to stand.
---

**Curated by Tomasz Bielak.** The collection is at its best in **November**.

Our maples grow at the top of the field, where the old hedges wind out of the
lowland and the ground begins to tip towards the escarpment. The collection is
young — most of it went in after the storm of 2011, when the veteran sycamores
came down and the volunteers decided the clearing should become something worth
planting. There are now thirty-odd kinds, mostly smaller trees, kept small on
purpose so the leaf can be seen from the path.

## Where to find them

Take the field-stile steps and follow the fence line uphill. The red leaves in
November are the *Acer campestre* and the trident maples; the coppery ones at the
top corner, by the stumps of the old sycamores, are the named plantings of the
last five winters.

## What to look for

- **The stripe-barked maples** near the gate at the top corner — in leaf they are
  unremarkable, but in December their winter bark is the best thing in the
  arboretum after the hazels have finished.
- **Leaf against light.** Walk the fence line in late afternoon in November; the
  low sun comes straight through the campestre hedge and the whole corner goes
  transparent.
- **The seed sails.** Any October, the ground under a maple is quilted with them.

November afternoons, low sun, uphill path. That is the visit.
