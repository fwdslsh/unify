---
title: The Witch Hazels
description: A curator's guide to the witch hazel collection at Alderfen Arboretum — who tends it, when it is at its best, and where to stand.
---

**Curated by Margaret Yee.** The collection is at its best in **February**.

Everyone comes to an arboretum in autumn. The witch hazels are my reason for
coming in February. The collection sits along the boardwalk in the damp corner,
where the fen water runs shallow under the planks — *Hamamelis* × *intermedia*
mostly, with the Chinese witch hazel *H. mollis* at the quiet end and a handful
of vernal and Ohio species that flower even later, into March.

## Where to find them

Enter by the west gate on the towpath and walk the boardwalk. The first third
of the railing is all *intermedia* — 'Pallida' and 'Arnold Promise', yellow and
sulphur, the two that will stop you mid-stride on the coldest day of the year.
Beyond the handrail gap at the bend, the *mollis* stand six deep along the water.

## What to look for

- **Blossom in frost.** The ribbon petals curl shut in hard weather and reopen
  the same afternoon. February is the only month that shows you both.
- **The scent.** Walk the boardwalk at noon, not early: the flowers need sun to
  give out the smell, and at two o'clock on a still day the bend is sweet.
- **Autumn, too.** 'Arnold Promise' turns clear scarlet in late October, so if
  February fails you, the same trees are worth a second trip.

The boardwalk is handrailed and level bar the one ramp; come on a dry morning
and I will probably be out there with the loppers.
