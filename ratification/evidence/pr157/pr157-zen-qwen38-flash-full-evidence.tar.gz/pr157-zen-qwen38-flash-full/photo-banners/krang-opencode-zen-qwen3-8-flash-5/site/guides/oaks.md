---
title: The Oaks
description: A curator's guide to the oak collection at Alderfen Arboretum — who tends it, when it is at its best, and where to stand.
---

**Curated by Eleanor Hartley.** The collection is at its best in **October**.

The oaks are what Alderfen was founded on. When the parish bought the fen in 1928,
the surveyor marked out the causeway line and the first hundred pedunculate oaks were
planted along it in a single winter. Many still stand, and their progeny — seedlings
kept back from the grassland every spring and potted on — line the broad walk behind
the gatehouse.

## Where to find them

Follow the causeway from the south gate: the founding trees are the heavy-limbed ones
with the iron rings at eye level, spaced twelve paces apart. Turn back along the broad
walk for the young plantings, and take the fen-side path to the two swamp oaks that
were tried in the wet corner in 1974 and never gave up.

## What to look for

- **The bull oak**, beside the seat at the causeway's midpoint — the fattest trunk in
  the collection, two metres across at the breast-height ring.
- **Acorn drop.** October is the month not for colour but for noise: sit under any of
  the founders after nine in the morning and you will hear them hit the ground.
- **The oak apple gall**, easy in June on the young plantings; I leave them alone and
  so should you.

Come in October, bring something to sit on, and stay for the drop.
