import fs from 'fs';
const [src, overlay] = process.argv.slice(2);
fs.mkdirSync(overlay + '/varieties/brassica', {recursive: true});
fs.mkdirSync(overlay + '/families', {recursive: true});
fs.writeFileSync(overlay + '/varieties/brassica/pea.html', '<!doctype html><html><head><title>Pea</title></head><body><main><h1>Pea</h1></main></body></html>');
fs.writeFileSync(overlay + '/families/brassica.fragment.html', '<ul><li><a href="../varieties/brassica/pea/">Pea</a></li></ul>');
