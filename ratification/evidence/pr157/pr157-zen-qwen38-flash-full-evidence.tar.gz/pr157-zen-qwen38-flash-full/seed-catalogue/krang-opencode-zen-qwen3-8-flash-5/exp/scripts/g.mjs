const out = {argv: process.argv, cwd: process.cwd(), env: Object.fromEntries(Object.entries(process.env).filter(([k])=>/unify|UNIFY|GEN|DIST|SITE|SOURCE|OUT/i.test(k)))};
import('fs').then(fs=>fs.writeFileSync('/tmp/sandbox/exp/geninfo.json', JSON.stringify(out,null,1)));
fs.writeFileSync('PLACEHOLDER_DO_NOT_WRITE', 'x');
