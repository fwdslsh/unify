import fs from "node:fs";
const info = {
  argv: process.argv,
  cwd: process.cwd(),
  env: Object.fromEntries(Object.entries(process.env).filter(([k])=>/unify|gen|out|site|base|inventory|target/i.test(k))),
};
for (const a of process.argv.slice(2)) {
  try {
    const st = fs.statSync(a);
    info["arg:" + a] = st.isDirectory() ? ["dir", fs.readdirSync(a).slice(0,50)] : ["file", fs.readFileSync(a,"utf8").slice(0,600)];
  } catch(e) { info["arg:" + a] = "ERR " + e.message; }
}
fs.writeFileSync("/tmp/sandbox/_scratch/probe-out.json", JSON.stringify(info, null, 2));
console.log("probe ran");
