import fs from "node:fs";
import path from "node:path";
const [,, srcRoot, overlay] = process.argv;
const w = (rel, s) => { fs.mkdirSync(path.dirname(path.join(overlay, rel)), {recursive:true}); fs.writeFileSync(path.join(overlay, rel), s); };
w("families/nav.fragment.html", '<nav class="famnav"><a class="fam" href="/families/brassica.html">Brassica</a></nav>');
w("families/brassica.html", '<!doctype html><html><head><title>Brassica</title><meta name="description" content="brassica list"></head><body><main><h1>Brassica</h1><div id="family-list" data-family="Brassica"><ul><li><a href="/varieties/probe.html">Probe</a></li></ul></div></main></body></html>');
w("varieties/probe.html", '<!doctype html><html><head><title>Probe</title><meta name="description" content="probe"></head><body><main><h1>Probe</h1><a href="/browse.html">Browse</a><a href="/families/brassica.html">Brassica</a></main></body></html>');
