import fs from "node:fs";
import path from "node:path";
const [,, srcRoot, overlay] = process.argv;
const w = (rel, s) => { fs.mkdirSync(path.dirname(path.join(overlay, rel)), {recursive:true}); fs.writeFileSync(path.join(overlay, rel), s); };
w("varieties/probe.html", '<!doctype html><html><head><title>Probe</title></head><body><main><h1>Probe</h1><a href="/index.html">home</a></main></body></html>');
w("families/brassica.fragment.html", '<ul><li><a href="/varieties/probe/">Probe</a></li></ul>');
