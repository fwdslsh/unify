import fs from "node:fs";
import path from "node:path";
const [,, srcRoot, overlay] = process.argv;
const w = (rel, s) => { fs.mkdirSync(path.dirname(path.join(overlay, rel)), {recursive:true}); fs.writeFileSync(path.join(overlay, rel), s); };
w("about.html", '<!doctype html><html><head><title>About</title></head><body><main><h1>About</h1><a href="/x.html">X</a><a href="/families/gen.fragment.html">gen frag</a><img src="/leaf.svg" alt="leaf"></main></body></html>');
w("families/gen.fragment.html", '<div class="fam"><a href="/x.html">to X from gen frag</a><p>loaded list</p></div>');
w("leaf.svg", '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"></svg>');
