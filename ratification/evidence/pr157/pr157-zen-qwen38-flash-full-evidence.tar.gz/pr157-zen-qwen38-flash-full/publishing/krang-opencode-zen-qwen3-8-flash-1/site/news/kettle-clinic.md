---
title: "Kettle clinic at the summer street fair"
date: "2026-08-29T18:45:00Z"
description: "A folding table, an extension lead and ninety-one kettles: our day on Bellwick Green, and what forty-two rescued elements taught us."
author: "Priya Raman"
schema: BlogPosting
og:image: /card.svg
---

We took a bench to the street fair on the Green, expecting to chat. By eleven we had
a queue of kettles and the next bench along was sending people over.

Ninety-one kettles came to the table. Forty-two of them needed nothing but a new
heating element or a descale — both things we carry six of, on purpose, because a
kettle is the most hopeful object in a house. Nine had stranger problems: a jammed
lid switch, a melted handle, one that had been stored damp and greeted us with a
small ecosystem.

## Numbers from the day

| Result | Count |
| --- | --- |
| Fixed on the spot | 42 |
| Booked for the workshop | 21 |
| Cleaned and safe, needs a part | 16 |
| Truly, finally dead | 12 |

## What I took from it

People are not sentimental about kettles. They want the kettle to work. The
sentimental thing is the five minutes at the table when someone realises they could
have done it themselves — that look is why I keep volunteering.

The extension lead survived. That was the real miracle.
