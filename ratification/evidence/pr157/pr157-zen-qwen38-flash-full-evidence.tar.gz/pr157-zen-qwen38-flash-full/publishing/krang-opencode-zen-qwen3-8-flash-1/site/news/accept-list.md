---
title: "What we can fix now: the updated accept list"
date: "2026-05-16T14:00:00Z"
description: "The bench has learned some new tricks and drawn a few hard lines. Here is the current list of what we take on and what we send home."
author: "Tom Ashby"
schema: BlogPosting
og:image: /card.svg
---

Our accept list used to be a sheet of tape on the wall with nine things on it. After
two years of Saturdays it has grown into the laminated card by the door. Here it is,
in full.

## Yes, we fix

- Small kitchen electrics: kettles, toasters, mixers, coffee machines
- Lamps and lighting (non-mains work only, please unplug at home first)
- Bicycles: brakes, gears, punctures, wobbly anything
- Textiles: zips, hems, buttons, lining a coat pocket
- Furniture: joints, wobbles, missing screws, a little paint
- Toys with batteries, and a surprising number of toys without

## No, we genuinely cannot

- Petrol anything, sealed fuel systems included
- CRT televisions and microwave ovens — the capacitors in those can bite long after
  the plug comes out
- Mattresses and carpet (no space, and nobody wants to)
- Smartphones and laptops beyond a battery or port swap

If we turn something away, we will still tell you where it *can* go. The council's
reuse page and the clock repairer up the lane have saved eleven of our rejects
between them.
