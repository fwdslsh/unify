---
title: "The tool library shelf is homeless: a call for donations"
date: "2026-11-07T09:15:00Z"
description: "Our shared tool shelf outgrown its corner in one weekend. We need a sturdier shelf and would love your unwanted bookcases."
author: "Dennis Whitlock"
schema: BlogPosting
og:image: /card.svg
---

The tool library started as a milk crate of everyone's second screwdriver. It is now
eleven sets of hex keys, three stud finders nobody has ever seen work, a mitre saw,
and a glue gun colony. Last Saturday the crate lost an argument with a broom handle
and gave out properly.

## What we are after

- A solid bookcase or shelf, at least a metre wide, that can wear a little paint
  and a lot of tools
- Anything to hang: a French cleat wall, pegboard, or the strong kind of hooks, not
  the suction kind
- A small lockable drawer for the expensive bits — not that anyone has stolen
  anything, but the saw worries me

There is a good side: while the crate convalesced on the floor, people simply
brought their own tools to the bench and showed each other how to use them. The
shelf is for keeping, but the library was never the wood.

If you have a shelf going spare, drop it at the yard gate any Tuesday or Saturday,
or write to hello@bellwick.example and we will arrange a carry.
