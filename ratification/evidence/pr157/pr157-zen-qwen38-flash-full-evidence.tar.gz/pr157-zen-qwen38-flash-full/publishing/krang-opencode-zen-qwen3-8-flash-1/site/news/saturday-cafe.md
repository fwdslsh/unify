---
title: "The Saturday café shifts into gear"
date: "2026-02-07T10:30:00Z"
description: "Six months of Saturday mornings: what we fixed, what beat us, and the community that grew around the bench."
author: "Nadia Karim"
schema: BlogPosting
og:image: /card.svg
---

We started the Saturday morning bench in August with one screwdriver kit, a borrowed
work light and a hand-painted sign. Yesterday we ran our thirtieth session, and the yard
was full of bicycles before ten o'clock.

## What went well

- **43 fixes logged.** Toasters and kettles still dominate, but we did our first
  record player belt and a proper re-gluing of a grandmother's rocking chair.
- **Two regulars joined the volunteer rota.** Dennis can now strip a plug in under a
  minute, and Priya has quietly become our textile whisperer.
- **The swap shelf paid for itself.** Nearly a third of repairs used a part rescued
  from it. Free parts, free repairs, the maths works.

## What beat us

We buried three things we couldn't save: a sealed espresso machine we were not
allowed to open, a laptop whose battery had swollen into a small pillow, and a
mattress (yes, someone tried). We now keep a polite no-list by the door, and it is
doing its job.

## Come next Saturday

Doors at ten, last drop-off at half past one. Bring a small broken thing and, if you
can, a mug. The kettle is communal but the tea is somebody's.
