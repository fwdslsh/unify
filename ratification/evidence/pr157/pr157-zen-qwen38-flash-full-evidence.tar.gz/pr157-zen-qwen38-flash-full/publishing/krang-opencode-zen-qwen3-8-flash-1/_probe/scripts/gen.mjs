import { writeFileSync, mkdirSync, readFileSync } from 'node:fs';
const [siteDir, overlayDir, ctxPath] = process.argv.slice(2);
const ctx = readFileSync(ctxPath, 'utf8');
const srcPages = JSON.parse(ctx).inputs.sourcePages;
writeFileSync('../probe-src.json', readFileSync(srcPages, 'utf8'));
writeFileSync(overlayDir + '/_ctxdump.json', ctx.slice(0, 4000));
mkdirSync(overlayDir + '/news', { recursive: true });
writeFileSync(overlayDir + '/news/index.html', '<!doctype html>\n<html lang="en">\n<head><meta charset="utf-8"><title>News</title></head>\n<body>\n<main><h1>News</h1><ul><li><a href="/news/one.html">First post</a></li></ul></main>\n</body>\n</html>\n');
console.log('ctx keys:', ctx.slice(0, 800));
