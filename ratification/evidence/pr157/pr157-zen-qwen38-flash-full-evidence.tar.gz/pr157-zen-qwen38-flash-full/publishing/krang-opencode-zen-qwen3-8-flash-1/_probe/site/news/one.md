---
title: First post
date: 2026-06-01T09:00:00Z
description: A first thing
schema: BlogPosting
---
Body one.
