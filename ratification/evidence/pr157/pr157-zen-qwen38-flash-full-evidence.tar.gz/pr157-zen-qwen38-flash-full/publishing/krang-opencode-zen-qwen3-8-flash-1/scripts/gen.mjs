import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

const [, , siteDir, overlayDir, ctxPath] = process.argv;
const ctx = JSON.parse(readFileSync(ctxPath, 'utf8'));
const inventory = JSON.parse(readFileSync(ctx.inputs.sourcePages, 'utf8'));

const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
  'August', 'September', 'October', 'November', 'December'];

const esc = (s) => s.replace(/[&<>"]/g, (c) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;',
}[c]));

const isPost = (p) =>
  (p.meta || []).some((m) => m.name === 'schema' &&
    (m.content === 'Article' || m.content === 'BlogPosting'));

const posts = inventory.pages
  .filter(isPost)
  .sort((a, b) => Date.parse(b.date || 0) - Date.parse(a.date || 0));

const pretty = (iso) => {
  const [y, m, d] = (iso || '').slice(0, 10).split('-');
  if (!y) return null;
  return `${Number(d)} ${months[Number(m) - 1]} ${y}`;
};

const items = posts.map((p) => {
  const date = pretty(p.date);
  const author = (p.meta || []).find((m) => m.name === 'author');
  return [
    '      <article>',
    `        <h2><a href="${esc(p.href)}">${esc(p.title)}</a></h2>`,
    `        <p class="post-meta">${date ? `<time datetime="${esc(p.date)}">${esc(date)}</time>` : ''}${author ? ` — ${esc(author.content)}` : ''}</p>`,
    p.description ? `        <p>${esc(p.description)}</p>` : '',
    '      </article>',
  ].filter(Boolean).join('\n');
}).join('\n');

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>News</title>
<meta name="description" content="News from the Bellwick Repair Collective: what we fixed, what we learned, and what the volunteers wrote down.">
</head>
<body class="news">
<main>
<h1>News</h1>
<p>Dispatches from the bench, written by the volunteers who were at it.
Newest first. Subscribe with the <a href="/feed.xml">Atom feed</a>.</p>
${items}
</main>
</body>
</html>
`;

const out = overlayDir + '/news/index.html';
mkdirSync(dirname(out), { recursive: true });
writeFileSync(out, html);
