---
title: "Fix-it Friday: thirty-eight kettles, one blender"
description: "Our biggest evening clinic yet — the kettle front took all night, and the blender came back from the dead."
date: 2026-10-09T20:30:00Z
author: Marta Silva
schema: Article
class: news
og:image: /assets/news-card.svg
og:image:width: 1200
og:image:height: 630
---
# Fix-it Friday: thirty-eight kettles, one blender

Friday's evening clinic took in thirty-eight kettles and one blender that had
been "scrap, honestly" according to its owner. Nine hours later the blender
blended and twenty-six kettles had new elements, descaled bases or a re-seated
lid clip.

The lesson, again: a kettle is a heating element, a switch and a bimetal strip.
Three parts, one multimeter, and half our "broken" pile is just limescale.

Our sincere condolences to the twelve kettles with cracked bodies — plastic
that has cooked from the inside is finished. We showed their owners which
replacement to buy second-hand, and that's still a win.
