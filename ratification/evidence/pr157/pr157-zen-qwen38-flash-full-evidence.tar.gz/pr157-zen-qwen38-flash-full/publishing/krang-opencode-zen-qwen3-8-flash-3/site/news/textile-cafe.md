---
title: "What the textile café taught us about denim"
description: "Six hours of patching lessons from Priya's table: chain-stitch hemming, and why pockets always go first."
date: 2026-10-17T12:00:00Z
author: Priya Raman
schema: Article
class: news
og:image: /assets/news-card.svg
og:image:width: 1200
og:image:height: 630
---
# What the textile café taught us about denim

The Saturday textile café mended fourteen pairs of jeans, nine jumpers and a
wedding-dress hem that nearly broke our best needle. Pockets: every single
pair of trousers failed at a pocket corner. Interior angles tear; reinforce
them before you need to.

We finally got the chain-stitch hemming jig working, which matters because a
chain-stitch hem on raw denim stretches and the machine-stitch one doesn't.
If you came away with a patched knee and a free cup of tea, that's the deal
we like.

Next café: bring shirts. Collar stands are the thing nobody knows how to fix.
