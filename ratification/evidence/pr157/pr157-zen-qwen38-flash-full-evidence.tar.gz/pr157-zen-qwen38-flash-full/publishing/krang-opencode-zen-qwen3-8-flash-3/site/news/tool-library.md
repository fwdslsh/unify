---
title: "The tool library shelf is open"
description: "Borrow a torque wrench for a week, not buy one for one job. Twelve donated tools, one honesty ledger."
date: 2026-11-02T09:30:00Z
author: Tom Okafor
schema: Article
class: news
og:image: /assets/news-card.svg
og:image:width: 1200
og:image:height: 630
---
# The tool library shelf is open

We cleared the east wall and built a shelf, and now the workshop runs a small
tool library: torque wrenches, a buttonhole foot, a bike truing stand, a heat
gun, a rivet gun, a leather punch set and a half-dozen things I've already
forgotten to write on the ledger.

Rules are simple. Sign the honesty ledger, take it, bring it back clean within
a week. If it breaks while it's yours, tell us — that's literally what this
place is for.

Thanks to the eleven neighbours who donated tools before we'd even asked.
Half a shelf is already spares.
