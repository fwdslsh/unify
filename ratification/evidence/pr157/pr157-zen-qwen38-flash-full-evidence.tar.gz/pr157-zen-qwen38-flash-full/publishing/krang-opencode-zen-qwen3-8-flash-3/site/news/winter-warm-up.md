---
title: "Winter warm-up: heaters checked, blankets patched"
description: "Before the cold sets in: forty-one fan heaters PAT-checked, three fires put out by a smoke alarm run, and a blanket swap that cleared the shelf."
date: 2026-11-07T10:15:00Z
author: Ada Fern
schema: Article
class: news
og:image: /assets/news-card.svg
og:image:width: 1200
og:image:height: 630
---
# Winter warm-up: heaters checked, blankets patched

Three Saturdays of winter prep. We tested forty-one fan heaters that had been
"spares" in people's cupboards since 2020: thirty-two passed, six needed a
new flex, three got melted plugs and were taken out back and disassembled in
the name of safety.

The blanket swap emptied our donation shelf and filled half of it again —
mostly wool, mostly mended, all claimed. If you arrived with a single glove
and left with a pair, you completed somebody else's winter too.

Smoke alarm clinic next, bring your old ones; eight dead detectors a week is
the statistic that actually saves lives here.
