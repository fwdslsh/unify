import fs from 'node:fs';
import path from 'node:path';

const [, , sourceRoot, generatedRoot, contextPath] = process.argv;
const context = JSON.parse(fs.readFileSync(contextPath, 'utf8'));
const inventory = JSON.parse(fs.readFileSync(context.inputs.sourcePages, 'utf8'));

const isArticle = (page) =>
  (page.meta ?? []).some(
    (m) => m.name === 'schema' && ['Article', 'BlogPosting'].includes(m.content),
  );

const posts = inventory.pages
  .filter((p) => isArticle(p) && p.source.startsWith('news/') && p.date)
  .sort((a, b) => b.date.localeCompare(a.date));

const yamlQuote = (value) => `"${String(value).replaceAll('\\', '\\\\').replaceAll('"', '\\"')}"`;
const escapeHtml = (value) =>
  String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

const rows = posts.map((p) => {
  const day = p.date.slice(0, 10);
  const author = (p.meta.find((m) => m.name === 'author') ?? {}).content ?? '';
  return [
    '  <li>',
    `    <h2><a href="/${p.source.replace(/\.(md|html)$/, '.html')}">${escapeHtml(p.title)}</a></h2>`,
    `    <p class="post-meta"><time datetime="${p.date}">${day}</time> · by ${escapeHtml(author)}</p>`,
    p.description ? `    <p>${escapeHtml(p.description)}</p>` : null,
    '  </li>',
  ]
    .filter(Boolean)
    .join('\n');
}).join('\n');

const page = `---
title: News
description: "News from the Bellwick Repair Collective: fix-it clinics, what came off the bench, what we learned. Newest first."
class: news
---

# News

Everything we have posted from the workshop bench, newest first.

<ul class="post-list">
${rows}
</ul>
`;

fs.mkdirSync(path.join(generatedRoot, 'news'), { recursive: true });
fs.writeFileSync(path.join(generatedRoot, 'news', 'index.md'), page);
console.log(`gen.mjs: wrote news/index.md listing ${posts.length} posts (newest first)`);
