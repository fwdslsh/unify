import fs from 'node:fs';
import path from 'node:path';

const BASE = 'https://bellwick.example/workshop/';
const BASEPATH = '/workshop/';
const DIST = 'dist';
let fails = 0;
const ok = (cond, msg) => {
  if (!cond) { fails++; console.log('FAIL', msg); } else console.log('ok  ', msg);
};
const read = (p) => fs.readFileSync(path.join(DIST, p), 'utf8');

const urlToFile = (href) => {
  if (!href.startsWith(BASE) && !href.startsWith(BASEPATH)) return null;
  const rel = href.startsWith(BASE) ? href.slice(BASE.length) : href.slice(BASEPATH.length);
  if (rel === '' || rel.endsWith('/')) return path.join(rel, 'index.html').replace(/^\.?\/?/, '');
  return rel;
};

const pages = ['index.html', 'visit/index.html', 'news/index.html',
  'news/kettle-clinic/index.html', 'news/textile-cafe/index.html',
  'news/tool-library/index.html', 'news/winter-warm-up/index.html'];

// 1. pages exist, share header (gear) + footer
for (const p of pages) {
  ok(fs.existsSync(path.join(DIST, p)), `page emitted: /${p.replace('index.html', '') || ''}`);
}
for (const p of pages) {
  const html = read(p);
  ok(html.includes('class="site-header"') && html.includes('<svg class="gear"'), `${p}: shared header with gear mark`);
  ok(html.includes('class="site-footer"') && html.includes('volunteers fixing household things'), `${p}: shared footer`);
  ok(!/href="\/(?!workshop\/)/.test(html) && !/src="\/(?!workshop\/)/.test(html), `${p}: every root-relative URL carries the /workshop/ prefix`);
}

// 2. every internal URL is absolute at the base address, ends in / (no .html), maps to a real file
for (const p of pages) {
  const html = read(p);
  const urls = [...html.matchAll(/(?:href|src|poster)="([^"]+)"/g)].map((m) => m[1]);
  for (const u of urls) {
    if (u.startsWith('mailto:') || u.startsWith('#')) continue;
    ok(u.startsWith(BASE) || u.startsWith(BASEPATH) || u.startsWith('data:'), `${p}: ${u} is on the published origin`);
    if (!u.startsWith(BASE)) continue;
    ok(!u.replace(/\/$/, '').endsWith('.html'), `${p}: ${u} does not end in .html`);
    const file = urlToFile(u);
    ok(fs.existsSync(path.join(DIST, file)), `${p}: ${u} resolves to emitted dist/${file}`);
  }
}

// 3. preview cards: og:image (+width/height), og:title, og:description, og:url on every post
const posts = ['news/kettle-clinic/index.html', 'news/textile-cafe/index.html', 'news/tool-library/index.html', 'news/winter-warm-up/index.html'];
for (const p of posts) {
  const html = read(p);
  const meta = (prop) => (html.match(new RegExp(`<meta property="${prop}" content="([^"]*)"`)) ?? [])[1];
  ok(/og:image" content="https:\/\/bellwick\.example\/workshop\/assets\/news-card\.svg"/.test(html), `${p}: og:image absolute`);
  ok(/og:image:(width|height)"/.test(html), `${p}: og:image dimensions`);
  const t = meta('og:title'), d = meta('og:description'), u = meta('og:url');
  ok(t && t.length > 0, `${p}: og:title "${(t ?? '').slice(0, 60)}"`);
  ok(d && d.length > 0, `${p}: og:description present`);
  ok(u && u.startsWith(BASE) && p.endsWith('index.html') && urlToFile(u) === p, `${p}: og:url = ${u}`);
  ok(/<h1(\s|>)/.test(html), `${p}: visible h1 heading`);
}

// 4. article JSON-LD: title, description, date, author — generated, not hand-written
for (const p of posts) {
  const html = read(p);
  const block = (html.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/) ?? [])[1];
  ok(!!block, `${p}: JSON-LD block present`);
  if (!block) continue;
  const ld = JSON.parse(block);
  ok(ld['@type'] === 'Article', `${p}: @type Article`);
  ok(typeof ld.headline === 'string' && ld.headline.length > 0, `${p}: headline "${ld.headline?.slice(0, 50)}"`);
  ok(typeof ld.description === 'string' && ld.description.length > 0, `${p}: description in JSON-LD`);
  ok(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/.test(ld.datePublished ?? ''), `${p}: datePublished ${ld.datePublished}`);
  ok(typeof ld.author === 'string' && ld.author.length > 0, `${p}: author ${JSON.stringify(ld.author)}`);
  ok((html.match(/application\/ld\+json/g) ?? []).length === 1, `${p}: exactly one JSON-LD block`);
}

// 5. Atom feed lists every post with title, address, date
const feed = read('feed.xml');
ok(feed.includes('xmlns="http://www.w3.org/2005/Atom"'), 'feed.xml is Atom');
const entries = [...feed.matchAll(/<entry>([\s\S]*?)<\/entry>/g)].map((m) => m[1]);
ok(entries.length === 4, `feed lists all 4 posts (found ${entries.length})`);
for (const e of entries) {
  const title = (e.match(/<title>([^<]*)<\/title>/) ?? [])[1];
  const link = (e.match(/<link rel="alternate" href="([^"]*)"/) ?? [])[1];
  const pub = (e.match(/<published>([^<]*)<\/published>/) ?? [])[1] ?? (e.match(/<updated>([^<]*)<\/updated>/) ?? [])[1];
  ok(!!title && !!link && !!pub, `entry "${title}": title + address ${link} + posted ${pub}`);
  ok(link?.startsWith(BASE) && fs.existsSync(path.join(DIST, urlToFile(link))), `entry link resolves to an emitted page`);
  ok(/^\d{4}-\d{2}-\d{2}T/.test(pub ?? ''), `entry "${title}" date is ISO with time`);
}
const feedPaths = entries.map((e) => urlToFile((e.match(/href="(https[^"]*)"/) ?? [])[1]));
for (const p of posts) ok(feedPaths.includes(p), `feed contains ${p}`);
ok(/rel="self" href="https:\/\/bellwick\.example\/workshop\/feed\.xml"/.test(feed), 'feed self-link absolute');
ok(read('index.html').includes('rel="alternate" type="application/atom+xml"'), 'pages link the feed in <head>');

// 6. news index lists every post, newest first
const idx = read('news/index.html');
const listed = [...idx.matchAll(/<a href="((?:https:\/\/bellwick\.example)?\/workshop\/news\/[a-z-]+\/)"/g)].map((m) => m[1].replace(/^https:\/\/bellwick\.example/, ''));
const order = ['winter-warm-up', 'tool-library', 'textile-cafe', 'kettle-clinic'].map((s) => BASE + 'news/' + s + '/');
for (const u of order) ok(listed.includes(u.replace(BASE, '/workshop/')), `index lists ${u}`);
ok(JSON.stringify(listed) === JSON.stringify(order.map((u) => u.replace(BASE, '/workshop/'))), 'index order is newest first');

// 7. sitemap
ok(read('sitemap.xml').includes(`${BASE}news/winter-warm-up/`), 'sitemap carries published URLs');

console.log(fails ? `\n${fails} FAILURES` : '\nALL CHECKS PASSED');
process.exit(fails ? 1 : 0);
