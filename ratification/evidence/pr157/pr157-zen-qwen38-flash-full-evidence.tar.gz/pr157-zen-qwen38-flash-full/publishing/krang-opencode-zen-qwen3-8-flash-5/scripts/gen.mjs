import fs from 'node:fs'

const [sourceRoot, generatedRoot, contextPath] = process.argv.slice(2)
const context = JSON.parse(fs.readFileSync(contextPath, 'utf8'))
const inventory = JSON.parse(fs.readFileSync(context.inputs.sourcePages, 'utf8'))

const esc = (s) =>
  s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December']

function niceDate(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso)
  if (!m) return iso
  return `${Number(m[3])} ${MONTHS[Number(m[2]) - 1]} ${m[1]}`
}

const meta = (page, name) => (page.meta.find((e) => e.name === name) || {}).content

const posts = inventory.pages
  .filter((p) => ['Article', 'BlogPosting'].includes(meta(p, 'schema')) && meta(p, 'date'))
  .sort((a, b) => meta(b, 'date').localeCompare(meta(a, 'date')))
  .map((p) => {
    const date = niceDate(meta(p, 'date'))
    return [
      '        <li>',
      `          <a href="${esc(p.href)}">${esc(meta(p, 'title') || p.title)}</a>`,
      `          <time datetime="${esc(meta(p, 'date'))}">${esc(date)}</time>`,
      meta(p, 'description') ? `          <p>${esc(meta(p, 'description'))}</p>` : '',
      meta(p, 'author') ? `          <p class="post-meta">by ${esc(meta(p, 'author'))}</p>` : '',
      '        </li>',
    ].filter(Boolean).join('\n')
  })
  .join('\n')

fs.writeFileSync(generatedRoot + '/news.html', `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>News</title>
    <meta name="description" content="News from the Bellwick Repair Collective workshop bench, newest first.">
  </head>
  <body class="news">
    <main>
      <h1>News</h1>
      <p>What has been happening at the bench. Newest first; subscribe via
        <a href="/feed.xml">the feed</a> if you read with a feed reader.</p>
      <ul class="post-list">
${posts}
      </ul>
    </main>
  </body>
</html>
`)
