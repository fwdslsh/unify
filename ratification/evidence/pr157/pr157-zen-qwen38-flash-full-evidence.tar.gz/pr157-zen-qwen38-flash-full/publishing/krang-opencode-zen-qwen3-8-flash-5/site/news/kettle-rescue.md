---
title: The great kettle rescue of February
description: Sixteen kettles on one bench, and the one strip heating element that explains almost all of them.
date: "2026-02-14T18:30:00Z"
author: Marek Nowak
class: news
schema: BlogPosting
og:image: /card.svg
og:image:width: 1200
og:image:height: 630
---

# The great kettle rescue of February

We have learned, the hard way, that February is when the kettles come.
Sixteen of them sat on the long bench last Wednesday, which sounds alarming
until you open one: nearly every fault is the same scale-caked strip heating
element, or a £3 thermostat.

De-scale first, check the switch second, buy nothing third. Thirteen of the
sixteen were back to boiling within the evening, and the lesson went around
the table like the soup.
