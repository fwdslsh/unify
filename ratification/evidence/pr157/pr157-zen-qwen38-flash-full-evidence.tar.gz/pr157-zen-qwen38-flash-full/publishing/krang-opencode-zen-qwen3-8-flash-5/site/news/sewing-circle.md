---
title: The sewing circle has found its second machine
description: A second-hand overlocker arrived on a roof rack, and torn hems are no longer the end of a garment's story.
date: "2026-04-04T14:00:00Z"
author: Ines Ferreira
class: news
schema: BlogPosting
og:image: /card.svg
og:image:width: 1200
og:image:height: 630
---

# The sewing circle has found its second machine

Our Sunday sewing circle outgrew a single domestic machine last month. Then a
neighbor two streets over moved house and left a working overlocker on the
curb — the one thing you must never put out, as it turns out, unless you want
it rescued.

It fits in the boot if you take the foot pedal off first. Jeans hems, jersey
T-shirts, and one prom dress with a truly ambitious slit later, the circle is
twice as fast and we can take on the fabric-and-thread bin that used to
disappear every February.
