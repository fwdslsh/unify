---
title: Fix-it Friday went off like a rocket stove
description: Forty-one things came through the door at our first late-night fix-it Friday; thirty-six of them walked back out working.
date: "2026-01-17T10:00:00Z"
author: Dana Whitfield
class: news
schema: BlogPosting
og:image: /card.svg
og:image:width: 1200
og:image:height: 630
---

# Fix-it Friday went off like a rocket stove

We tried something new last Friday: an evening session with hot soup from the
cafe next door. Forty-one items came in — a surprising number of toasters, one
genuinely antique iron, and a Christmas-light tangle that took two of us an
hour and a half.

Thirty-six things left working. The five that didn't needed parts we ordered
together on a shared list, and they will come back to the table next week.

If you were one of the twelve first-timers: you were brilliant, and the door
is open every Wednesday.
