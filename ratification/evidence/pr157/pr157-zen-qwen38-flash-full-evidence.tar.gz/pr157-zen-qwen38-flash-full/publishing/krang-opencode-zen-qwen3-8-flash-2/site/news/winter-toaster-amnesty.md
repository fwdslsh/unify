---
title: Winter toaster amnesty
description: Twelve toasters came in on Saturday and only one went to the scrap metal skip.
date: 2026-01-24T16:30:00Z
author: Desmond Hale
schema: BlogPosting
og:image: /assets/card.svg
class: news
---

# Winter toaster amnesty

Twelve toasters came to the Saturday social, which sounds like a lot of
toasters until you realise how many of them share the same two faults: a
crumb tray nobody has ever emptied, and a latch wire that has slipped its
spring. Ten went home toasting again inside twenty minutes.

One we stripped for parts — the element was cracked — and its nichrome went
into the parts jar for future jobs. The last was really fine; it just needed
its thermostat cleaned with isopropyl. The owner stood there apologising to
us for bringing in something that worked. That is the whole feeling we are
chasing: people have been trained to throw things away that only needed five
minutes and a screwdriver.
