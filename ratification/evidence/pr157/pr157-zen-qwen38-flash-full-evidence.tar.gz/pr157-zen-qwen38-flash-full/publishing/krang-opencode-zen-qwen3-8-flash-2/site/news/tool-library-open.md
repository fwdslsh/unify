---
title: The tool library is open
description: You can now borrow our good tools for the weekend instead of buying cheap ones.
date: 2026-04-11T10:00:00Z
author: Marisa Oyelaran
schema: BlogPosting
og:image: /assets/card.svg
class: news
---

# The tool library is open

The shelf by the door is now a lending library: cordless drills, a jigsaw,
a stapler gun, dressmaker's scissors, and — the star of the collection — a
hand plane that some anonymous donor left at a Saturday social with a note
saying only "it deserves better than a skip".

The rules are simple. Sign the sheet, take the tool, return it clean by the
next open session, and tell us what you made. No deposit, no membership fee;
we are volunteers, not a bureaucracy. Twelve tools have already gone out,
and eleven came back — the twelfth we found, of course, at the next repair.
