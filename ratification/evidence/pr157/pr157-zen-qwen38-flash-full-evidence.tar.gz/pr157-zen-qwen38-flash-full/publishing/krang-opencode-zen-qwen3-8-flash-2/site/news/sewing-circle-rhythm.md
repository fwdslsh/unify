---
title: The sewing circle has found its rhythm
description: Thursday mornings are now a steady table of hems, zips and invisible darns.
date: 2026-03-05T18:00:00Z
author: Priya Raman
schema: BlogPosting
og:image: /assets/card.svg
class: news
---

# The sewing circle has found its rhythm

Six weeks in, the Thursday textile table has its own regulars — three
volunteers and a revolving cast of neighbours with school uniforms, torn
jeans and one glorious wool coat with a split lining. The coat took an
afternoon and a cup of tea; the owner is a man in his seventies who said it
was his mother's, which is exactly why we do this.

New this month: a second machine, donated and serviced, so hemming does not
mean queueing. If you can run a straight stitch, we could use you — come and
sit in; nobody will hand you a clipboard.
