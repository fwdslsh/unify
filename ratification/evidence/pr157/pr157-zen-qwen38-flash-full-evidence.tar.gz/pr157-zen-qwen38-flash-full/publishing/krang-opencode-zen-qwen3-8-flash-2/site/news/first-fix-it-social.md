---
title: First fix-it social went well
description: Our first open Saturday filled every bench and ran three hours over.
date: 2026-02-14T09:00:00Z
author: Marisa Oyelaran
schema: BlogPosting
og:image: /assets/card.svg
class: news
---

# First fix-it social went well

We put out six benches and a tea urn, expecting maybe a dozen curious
neighbours. By eleven there was a queue from the green door to the corner,
and by one we had fixed a lamp, a music box, three zips, a wobbly chair,
and — our proudest moment — a hand-crank torch from 1974 that now works
better than it probably did in 1974.

The lesson for next time: two more benches, and someone whose only job is
triage, because we spent too long deciding what not to attempt. If you came
and left un-fixed, we are sorry — bring it back on Saturday the 28th and we
will start with yours.
