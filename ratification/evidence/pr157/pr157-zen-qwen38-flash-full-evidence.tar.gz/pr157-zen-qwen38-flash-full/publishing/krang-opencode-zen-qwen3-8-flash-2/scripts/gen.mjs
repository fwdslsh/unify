import { readFileSync, writeFileSync } from "node:fs";

const [, , sourceDir, overlayDir, contextFile] = process.argv;
const ctx = JSON.parse(readFileSync(contextFile, "utf8"));
const { pages } = JSON.parse(readFileSync(ctx.inputs.sourcePages, "utf8"));

const posts = pages
  .filter((p) => p.href.startsWith("/news/") && p.date)
  .sort((a, b) => b.date.localeCompare(a.date));

const esc = (s) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const day = new Intl.DateTimeFormat("en-GB", {
  day: "numeric",
  month: "long",
  year: "numeric",
  timeZone: "UTC",
});

const items = posts
  .map((p) => {
    const author = p.meta?.find((m) => m.name === "author")?.content;
    return [
      "        <li>",
      `          <a href="${p.href}">${esc(p.title)}</a>`,
      `          <time datetime="${p.date}">${day.format(new Date(p.date))}</time>`,
      author ? `          <span class="by">by ${esc(author)}</span>` : "",
      p.description ? `          <p>${esc(p.description)}</p>` : "",
      "        </li>",
    ]
      .filter(Boolean)
      .join("\n");
  })
  .join("\n");

const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>News</title>
  <meta name="description" content="News from the Bellwick Repair Collective — repairs, classes and open Saturdays.">
</head>
<body class="news">
  <main>
    <h1>News from the workshop</h1>
    <p>Written by the volunteers themselves. <a href="/feed.xml">Subscribe by feed</a> to get every post.</p>
    <ul class="post-list">
${items}
    </ul>
  </main>
</body>
</html>
`;

writeFileSync(`${overlayDir}/news.html`, html);
console.log(`gen: wrote news.html listing ${posts.length} posts, newest first`);
