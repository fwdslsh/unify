import { readFileSync, readdirSync, statSync } from "node:fs";
import path from "node:path";

const DIST = path.join(import.meta.dirname, "..", "dist");
const BASE = "https://bellwick.example/workshop/";
let fails = 0;
const ok = (cond, msg) => {
  console.log(`${cond ? "PASS" : "FAIL"} ${msg}`);
  if (!cond) fails++;
};

const walk = (d) =>
  readdirSync(d).flatMap((e) => {
    const p = path.join(d, e);
    return statSync(p).isDirectory() ? walk(p) : [p];
  });
const files = walk(DIST);
const htmls = files.filter((f) => f.endsWith(".html"));
const read = (f) => readFileSync(f, "utf8");

const postSlugs = [
  "winter-toaster-amnesty",
  "first-fix-it-social",
  "sewing-circle-rhythm",
  "tool-library-open",
];

// 1. no URLs in visitor-visible HTML end in .html; every page has pretty output path
ok(htmls.every((f) => f.endsWith("index.html")), "every page ships as .../index.html");
for (const f of htmls) {
  for (const m of read(f).matchAll(/(?:href|src)="([^"]+)"/g)) {
    ok(!m[1].endsWith(".html"), `no .html link in ${path.relative(DIST, f)}: ${m[1]}`);
  }
}

// 2. shared header (gear mark) + footer on every page
for (const f of htmls) {
  const s = read(f);
  ok(s.includes('class="gear"'), `gear header on ${path.relative(DIST, f)}`);
  ok(s.includes("site-footer") && s.includes("Bellwick Repair Collective"), `footer on ${path.relative(DIST, f)}`);
}

// 3. preview cards on every post: absolute og:title/description/url/image
for (const slug of postSlugs) {
  const f = path.join(DIST, "news", slug, "index.html");
  const s = read(f);
  const og = (p) => s.match(new RegExp(`<meta property="${p}" content="([^"]*)"`))?.[1];
  ok(og("og:title")?.length > 0, `${slug}: og:title "${og("og:title")}"`);
  ok(og("og:description")?.length > 0, `${slug}: og:description present`);
  ok(og("og:url")?.startsWith(BASE), `${slug}: og:url absolute ${og("og:url")}`);
  ok(og("og:image")?.startsWith(BASE), `${slug}: og:image absolute ${og("og:image")}`);
}

// 4. JSON-LD article data on every post (generated, parses, has the fields)
for (const slug of postSlugs) {
  const s = read(path.join(DIST, "news", slug, "index.html"));
  const m = s.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/);
  ok(!!m, `${slug}: JSON-LD block present`);
  if (!m) continue;
  const ld = JSON.parse(m[1]);
  ok(ld["@type"] === "BlogPosting", `${slug}: @type BlogPosting`);
  for (const k of ["headline", "description", "author", "datePublished", "image", "url"]) {
    ok(ld[k] != null, `${slug}: ld.${k} = ${JSON.stringify(ld[k])}`);
  }
  ok(ld.url === `${BASE}news/${slug}/`, `${slug}: ld.url is the published address`);
  ok(!s.includes("application/ld+json\" data-"), "x"); // noop
  ok(ld.datePublished.match(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/) != null, `${slug}: date parseable`);
}

// 5. feed.xml: Atom, all 4 posts, each with title, absolute link, dates, newest first
const feed = read(path.join(DIST, "feed.xml"));
ok(feed.includes("<feed xmlns=\"http://www.w3.org/2005/Atom\">"), "feed is Atom");
const entries = [...feed.matchAll(/<entry>([\s\S]*?)<\/entry>/g)].map((e) => e[1]);
ok(entries.length === 4, `feed lists every post (${entries.length} entries)`);
const dates = entries.map((e) => {
  const t = e.match(/<title>([^<]*)<\/title>/)?.[1];
  const l = e.match(/<link rel="alternate" href="([^"]*)"/)?.[1];
  const p = e.match(/<published>([^<]*)<\/published>/)?.[1];
  ok(!!t && !!l?.startsWith(BASE) && !!p, `feed entry has title+absolute link+published: ${t} ${l} ${p}`);
  return p;
});
ok(dates.every((d, i) => i === 0 || dates[i - 1] >= d), "feed newest first");

// 6. news index lists all posts newest first
const news = read(path.join(DIST, "news", indexOrDir()));
function indexOrDir() { return "index.html"; }
const listed = [...news.matchAll(/<li>\s*<a href="(\/workshop\/news\/[^"]+)\/">([^<]*)<\/a>\s*<time datetime="([^"]*)"/g)];
ok(listed.length === 4, `news index lists ${listed.length} posts`);
const ldates = listed.map((l) => l[3]);
ok(ldates.every((d, i) => i === 0 || ldates[i - 1] >= d), "news index newest first");

// 7. nothing loads from another website
for (const f of files) {
  if (f.endsWith(".css")) continue;
  const s = read(f);
  for (const m of s.matchAll(/(?:href|src)="(https?:\/\/[^"/]+)[^"]*"/g)) {
    if (m[1] !== "https://bellwick.example") ok(false, `external load in ${path.relative(DIST, f)}: ${m[1]}`);
  }
}
ok(true, "no off-site href/src fetches (only bellwick.example)");

// 8. every internal link resolves to a file in dist
const all = new Set(files.map((f) => f));
for (const f of htmls) {
  for (const m of read(f).matchAll(/href="(\/workshop\/[^"]*)"/g)) {
    const p = m[1].replace(/^\/workshop/, "");
    ok(all.has(path.join(DIST, p)) || all.has(path.join(DIST, p, "index.html")) || p === "" || p === "/", `link resolves: ${m[1]}`);
  }
}

// 9. sitemap generated with absolute post URLs
const sm = read(path.join(DIST, "sitemap.xml"));
ok(postSlugs.every((s) => sm.includes(`${BASE}news/${s}/`)), "sitemap lists all posts");

console.log(fails === 0 ? "\nALL CHECKS PASS" : `\n${fails} FAILURES`);
process.exit(fails === 0 ? 0 : 1);
