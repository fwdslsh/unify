import { createServer } from "node:http";
import { readFileSync, existsSync, statSync } from "node:fs";
import path from "node:path";
const DIST = path.join(import.meta.dirname, "..", "dist");
const TYPES = { ".html": "text/html", ".css": "text/css", ".svg": "image/svg+xml", ".xml": "application/atom+xml" };
const srv = createServer((req, res) => {
  let p = decodeURIComponent(req.url.split("?")[0]).replace(/^\/workshop/, "") || "/";
  let f = path.join(DIST, p);
  if (existsSync(f) && statSync(f).isDirectory()) f = path.join(f, "index.html");
  if (!existsSync(f)) { res.writeHead(404); return res.end("404"); }
  res.writeHead(200, { "content-type": TYPES[path.extname(f)] ?? "application/octet-stream" });
  res.end(readFileSync(f));
});
srv.listen(0);
await new Promise((r) => srv.once("listening", r));
const base = `http://127.0.0.1:${srv.address().port}/workshop/`;
const urls = ["", "visit/", "news/", ...[
  "news/winter-toaster-amnesty/", "news/first-fix-it-social/", "news/sewing-circle-rhythm/", "news/tool-library-open/",
], "feed.xml", "sitemap.xml", "assets/style.css", "assets/card.svg", "assets/gear.svg"];
let bad = 0;
for (const u of urls) {
  const r = await fetch(base + u);
  const ct = r.headers.get("content-type") ?? "";
  console.log(`${r.status} ${ct.padEnd(24)} ${base + u}`);
  if (r.status !== 200) bad++;
}
const feedTxt = await (await fetch(base + "feed.xml")).text();
console.log(`feed entries: ${(feedTxt.match(/<entry>/g) ?? []).length}`);
srv.close();
process.exit(bad ? 1 : 0);
