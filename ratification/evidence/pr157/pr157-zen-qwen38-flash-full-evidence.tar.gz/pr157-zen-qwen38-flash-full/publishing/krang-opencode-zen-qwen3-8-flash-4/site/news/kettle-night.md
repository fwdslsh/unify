---
title: "Kettle night: eleven boils and four resurrections"
description: "Fourteen kettles came to the bench on the first Saturday of November. Here is what actually failed in each one, and the two repairs anyone can do at home."
author: "Marta Diaz"
date: 2026-11-03T18:30:00Z
schema: BlogPosting
og:image: /assets/card.svg
---

# Kettle night: eleven boils and four resurrections

*Posted by Marta Diaz, 3 November 2026*

![Line drawing of an open electric kettle with the base plate lifted out](/assets/sketch-kettle.svg)

We got fourteen kettles in one afternoon. Eleven boiled afterwards, which is the best ratio
we have had all year. I wrote down every fault so that the next volunteer has somewhere to
start.

## What was actually wrong

| Symptom | Count | Cause | Fixed by |
| --- | --- | --- | --- |
| Clicks, no heat | 5 | Oxidised contacts in the on-switch | Working the switch fifty times, then replacing it |
| Stops early | 3 | Limescale holding the lid sensor open | Descale, then a rinse with citric acid |
| No light, no heat | 2 | Broken cord at the base, not the kettle | New cord, £2.40 in parts |
| Leaks at the seam | 3 | Split steam tube, cracked housing | One repaired, one cannibalised, one to the skip |

The lesson I keep repeating to myself: **the switch fails, not the element.** Four of these
kettles were full of limescale but otherwise honest.

## The two repairs you can do at home

1. **Descale properly.** Half a pint of white vinegar, topped with water, boiled and left
   overnight. Rinse twice. Do this before you open anything.
2. **Check the cord where it enters the base.** Strip it back with your fingers and bend it
   gently; if the kettle flickers to life, the wire inside is broken and the cord — not the
   kettle — is the spare part.

One warning, because three people asked. A kettle that smells burnt at the base is finished.
Nothing we do is worth the risk, and a new one from the reuse shelf costs nothing here.

## Next time

Kettle night runs again on the first Saturday of December, 10:00 to 16:00, at the workshop on
Kiln Yard. Bring the kettle, bring the cord, and read [what to bring before you
come](/visit.html) — it saves twenty minutes of hunting for a screwdriver.
