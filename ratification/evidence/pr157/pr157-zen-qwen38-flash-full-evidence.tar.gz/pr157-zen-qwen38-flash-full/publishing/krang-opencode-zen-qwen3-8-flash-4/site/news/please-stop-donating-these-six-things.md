---
title: "Please stop donating these six things"
description: "Our spares shelf is full of the parts nobody can use and short of the ones we run out of by noon. A shopping list from the bench, written by the volunteer who empties it."
author: "Tomasz Nowak"
date: 2026-08-15T09:30:00Z
schema: BlogPosting
og:image: /assets/card.svg
---

# Please stop donating these six things

*Posted by Tomasz Nowak, 15 August 2026*

I sort the donation box on Sunday nights with a cup of tea and a carrier bag, and this month the
bag got heavier than the shelf. So: a list, written with love, of what we cannot use and what we
desperately can.

## Please stop bringing these

- **Washing machines and dishwashers.** We have no lift, no van and no hose fittings. Take them to
  the council reuse centre, they collect free.
- **VHS players and the tangle of scart leads.** Nobody here can source a belt for them.
- **Mains chargers with no cable attached.** We cannot test them safely in ten minutes and we do
  not want them in the bin either; the shop on the High Street takes them.
- **Bicycles missing both wheels.** Please, bring a bicycle.
- **Anything with a swollen or leaking battery.** Ring us first and we will tell you the safe way
  to lose it.
- **Our own tools, back to us.** They are marked with paint. It is lovely, it is confusing.

## What we run out of before noon

1. Phillips #2 and #3 screwdriver bits — the tips round off weekly
2. 3 A and 13 A fuses, assorted, in the little plastic boxes
3. Cotton thread in black, navy and cream
4. Drawer-runner screws, the small countermachine ones
5. Silicone kitchen spatulas for spreading glue, and old credit cards for the same job
6. Kettle and iron **switches** — the elements never fail, the switches do

## How to give something we will actually use

Write on it. A rubber band with "3 A fuses, 20" on a twist-tie saves me an hour of guessing. If
you are clearing a house and there is a box of half-used DIY parts in it, bring the box: mixed
screws and odd hinges are the single most useful donation we get, and we split them out on slow
Saturday afternoons with the radio on.

The bench needs you more than the shelf does, if you can give an hour instead:
[the hours and the address](/visit.html).
