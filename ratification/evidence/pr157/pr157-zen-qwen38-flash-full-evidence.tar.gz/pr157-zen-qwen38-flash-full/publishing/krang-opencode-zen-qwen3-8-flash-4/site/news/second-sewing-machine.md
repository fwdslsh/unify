---
title: "The second sewing machine is alive"
description: "A donated 1960s machine, three hours, one new bobbin case and a great deal of clock oil. Notes for anyone else fighting a belt-driven machine."
author: "Priya Raman"
date: 2026-09-26T14:00:00Z
schema: BlogPosting
og:image: /assets/card.svg
---

# The second sewing machine is alive

*Posted by Priya Raman, 26 September 2026*

![Line drawing of a treadle sewing machine with the side cover off](/assets/sketch-sewing.svg)

Someone left two machines at the north door in a cardboard box marked "probably knackered". One
was a 1960s belt-driven thing with a hand-sewn case. It is now the best machine we own and it
took three hours.

## The order I do them in

1. **Turn it by hand before you plug anything in.** If the balance wheel will not move, stop.
   You have a seized bearing or a needle driven through itself, and electricity will not help.
2. **Clear the throat plate.** Four years of lint looks like felt and stops the feed dogs.
3. **Change the needle**, always, even if it looks fine. Half of "my machine skips stitches" is
   a blunt needle.
4. **Oil where the manual says, not where it is convenient.** Two drops on the race, one on the
   bobbin case. Wipe the excess; excess oil is what turns lint into glue.
5. **Check the belt tension last.** A slack belt slips under fabric load and reads as a dead
   motor.

## What it needed

New bobbin case (the old one had a notch worn by the needle), one belt, a bulb, and a clean. The
first three seams came out of the machine straighter than anything the old Singer had ever given
us.

## If you have a machine in your cupboard

Bring it on a Thursday. The sewing evening runs 18:30–21:00 and we have two machines and three
people who know them. We will not take it away from you, but we will very likely talk you
through opening the side cover yourself. [Visit page has the details](/visit.html), and the
donation list is in [this August's note](/news/please-stop-donating-these-six-things.html).
