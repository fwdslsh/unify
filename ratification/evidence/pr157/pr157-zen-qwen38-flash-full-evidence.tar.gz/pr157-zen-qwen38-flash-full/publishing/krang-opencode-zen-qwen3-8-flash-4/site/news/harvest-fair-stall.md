---
title: "What came in a bag to the Harvest Fair stall"
description: "We took a bench to the Harvest Fair on Bellwick Green. Sixty-one things arrived, thirty-eight left working, and a music box made the whole afternoon."
author: "Ife Thomas"
date: 2026-10-17T10:00:00Z
schema: BlogPosting
og:image: /assets/card.svg
---

# What came in a bag to the Harvest Fair stall

*Posted by Ife Thomas, 17 October 2026*

We set up two folding tables under the big chestnut and were sorry about it by half past ten,
because the queue never stopped. Sixty-one items, logged. Thirty-eight left working, nine went
home as "clean and honest, but the part is not worth £40", and the rest were explained to their
owners and dropped at the recycling marquee next door.

## The day in numbers

- Toasters: 9 — 6 fixed, all of them the same seized slide lever
- Lamps: 8 — 5 fixed, 3 with wiring nobody should touch
- Toys and small electronics: 12
- Jackets and bags: 11 — mostly zips
- Bicycles: 4, of which two were really one bicycle cut in half

> A woman brought in her father's music box and said it had not played since the funeral.
> The governor spring had slipped off its catch. We put it back in ninety seconds and she
> cried, and so did the man selling corn next to us.

## What I would do differently

1. **Bring a second torch.** Mine died at two o'clock and I borrowed one off a stranger.
2. **Write the log on clipboards**, not on one sheet that the wind kept taking.
3. **Say the quiet part early.** People assume we can fix anything; the honest answer about a
   fifteen-year-old washing machine is "no, and here is who says yes".

## Thank you

To the six volunteers who stood there for five hours, and to the pub next door that let us use
its toilet without argument. If you missed us, the same bench is set up every Saturday at Kiln
Yard — see [the hours](/visit.html).
