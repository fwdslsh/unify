import fs from 'node:fs';
import path from 'node:path';

const [, , sourceRoot, generatedRoot, ctxPath] = process.argv;
const ctx = JSON.parse(fs.readFileSync(ctxPath, 'utf8'));
const inventory = fs.existsSync(ctx.inputs.sourcePages)
  ? JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, 'utf8'))
  : { pages: [] };

const esc = (s) => String(s)
  .replaceAll('&', '&amp;').replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;').replaceAll('"', '&quot;');

function metaValue(page, name) {
  for (const m of page.meta ?? []) {
    if (typeof m === 'string') {
      const i = m.indexOf(':');
      if (m.slice(0, i === -1 ? m.length : i).trim() === name) return m.slice(i + 1).trim();
    } else if (m && typeof m === 'object') {
      const k = m.name ?? m.key;
      if (k === name) return m.value ?? m.content ?? null;
    }
  }
  return null;
}

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'];

function prettyDate(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  if (!m) return iso;
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  return `${days[d.getUTCDay()]} ${+m[3]} ${MONTHS[+m[2] - 1]} ${m[1]}`;
}

const entries = (inventory.pages ?? [])
  .filter((p) => (p.source ?? '').startsWith('log/') && p.source.endsWith('.md'))
  .map((p) => ({
    href: p.href ?? '/' + p.source.replace(/\.md$/, '.html'),
    title: p.title ?? p.source,
    date: p.date ?? metaValue(p, 'date') ?? '',
    author: p.author ?? metaValue(p, 'author') ?? '',
  }))
  .sort((a, b) => (b.date || '').localeCompare(a.date || '') || b.href.localeCompare(a.href));

const items = entries.map((e) => `        <li>
          <time datetime="${esc(e.date)}">${esc(prettyDate(e.date))}</time>
          <a href="${esc(e.href)}">${esc(e.title)}</a>${e.author ? ` <span class="byline">&mdash; ${esc(e.author)}</span>` : ''}
        </li>`).join('\n');

const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Observing Log</title>
  <meta name="description" content="Nights at Harrowgate Observatory, written up by the volunteers who were here. Newest first.">
</head>
<body class="log">
  <main>
    <h1>Observing Log</h1>
    <p>What we saw, in the words of the people who were out on the slab. Newest first.</p>
    <ul class="log-list">
${items}
    </ul>
  </main>
</body>
</html>
`;

fs.mkdirSync(path.join(generatedRoot, 'log'), { recursive: true });
fs.writeFileSync(path.join(generatedRoot, 'log', 'index.html'), html);
