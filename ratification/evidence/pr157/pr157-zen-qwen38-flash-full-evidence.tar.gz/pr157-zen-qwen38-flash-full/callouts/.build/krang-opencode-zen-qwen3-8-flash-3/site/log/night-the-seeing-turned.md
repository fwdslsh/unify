---
date: 2026-11-07
author: Margaret
class: log
description: "Jupiter steady at 180× on a clear Saturday, a queue from ten to two, and frost on the door by four."
---

# The night the seeing turned

*Saturday 7 November 2026 — logged by Margaret*

Third Saturday of the season and the forecast said cloud, so naturally it was the clearest night
we have had since September. Nine visitors on the slab and I lost count after that.

Jupiter sat so steady that we left the 180× in and people queued for it twice over. The Great Red
Spot was transiting near the middle — I have been looking at that planet for forty years and the
fringe on it still surprises me. Mars was low and small but Syrtis Major read clearly enough that
young Tom asked whether it was "on fire".

<include src="/_includes/equipment.fragment.html">
  <p slot="heading">8-inch Dobsonian "Big Ed"</p>
  <p slot="body">Worked flat out on the queue from ten to two. Collimated once at eleven, which is one time fewer than average.</p>
  <p slot="difficulty">Difficulty: easy for the visitor, hard on my back lifting the mirror box in</p>
</include>

Frost by half past four when I locked the door. Wind the heaters up, Margaret, and do it earlier next year.
