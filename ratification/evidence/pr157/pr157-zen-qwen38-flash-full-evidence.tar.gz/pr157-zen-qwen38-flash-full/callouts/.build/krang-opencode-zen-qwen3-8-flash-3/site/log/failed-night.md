---
date: 2026-10-03
author: Desmond
class: log
description: "Overcast and wet with six visitors and one star through one gap in the cloud: the nights the log keeps anyway."
---

# Failed night, decent conversation

*Saturday 3 October 2026 — logged by Desmond*

Overcast, wind from the east, and by nine the railings were wet. We opened anyway; six people
turned up, we made tea, and the refractor saw exactly one star through one gap in the cloud for
about ten seconds, which a small girl announced to the queue as "the engine star".

Some nights are like this. The log keeps them too, because the alternative is a website full of
nights that only looked good.
