---
date: 2026-10-11
author: Priya
class: log
description: "Forty minutes alone on the slab: Albireo gold and blue, the Moon's terminator through a 2× Barlow."
---

# A short cold one

*Sunday 11 October 2026 — logged by Priya*

Came up alone expecting company at eight; road ice forecast, everyone sensible. Stayed forty
minutes anyway because that is the rule I made for myself: the dome opens if I do.

Albireo split cleanly on the refractor, gold and blue, and I said the usual thing out loud to
nobody. Half the Moon through the Barlow, terminator full of craters that have no business being
that detailed. Then the cold got into my boots and I closed up.

<include src="/_includes/equipment.fragment.html">
  <p slot="heading">The 60&times; refractor plus the 2&times; Barlow</p>
  <p slot="body">Out of the left rack, no counterweights to fight. On a night this calm you can leave the tracking off for whole minutes at a time.</p>
  <p slot="difficulty">Difficulty: easy once the dew heater is on</p>
</include>

One night, one person, zero visitors. The log does not get to pretend this one was for anybody.
