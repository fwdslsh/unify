# Harrowgate Observatory — build report

## Publish command

```
./unify build --base-url https://harrowgate.pages.dev/observatory/ --pretty-urls --clean --audit
```

Exit 0 and `audit: nothing to report`. `dist/` is the complete published site for
`https://harrowgate.pages.dev/observatory/`.

## What was built

- `site/index.html` — home; `site/whats-up.html` — four seasonal objects; `site/visit.html` —
  location, opening-nights table, what to bring; `site/log/*.md` — four dated entries written in
  Markdown by volunteers.
- `site/_layout.html` — the single layout: header with the star-mark SVG and nav, footer with the
  star-mark again; every page picks it up automatically (nearest `_layout.html`).
- `site/_includes/equipment.fragment.html` — the equipment callout panel: border, telescope icon,
  layout, and three `<slot>`s (`heading`, `body`, `difficulty`). Nine callouts ship
  (4 What's Up, 2 Visit, 3 in the four log entries). A volunteer adds one by pasting only the
  three text lines — never the panel:

  ```html
  <include src="/_includes/equipment.fragment.html">
    <p slot="heading">8-inch Dobsonian "Big Ed"</p>
    <p slot="body">Parked at the east end of the slab…</p>
    <p slot="difficulty">Difficulty: easy</p>
  </include>
  ```

- `scripts/gen.mjs` (+ `unify.yaml: generate: scripts/gen.mjs`) — reads the `source-pages.json`
  inventory unify hands it, and writes the log index (`log/index.html` into the generated
  overlay) listing every entry newest-first. It ships through the normal page pipeline, so the
  build applies the layout and rewrites its links like any other page.
- `site/assets/dome.svg` — hand-written placeholder image; `site/styles.css` — all styling, no
  external fonts or resources.
- `drafts/` sits **outside** the source root (`site/`), so it can never ship; `_`-prefixed files
  are excluded by the default anyway.

## To change every callout's border at once

Edit the one rule `.equipment { border: 2px solid var(--accent); … }` in **`site/styles.css`**
(line 59). No page or log entry contains a border — each callout is just the fragment spliced in
with different words, and the fragment pulls its shape from that single class. A structural change
to the panel itself would be made in `site/_includes/equipment.fragment.html`, also one file.

## How I verified (no browser)

- `./unify build --dry-run --strict` and `./unify audit --strict` pass with zero problems; the
  publish build runs with `--audit`, so it refuses to write `dist/` unless the audit is clean.
- Grepped the published `dist/`: every emitted `href`/`src` starts with `/observatory/` or is the
  site's own absolute URL — nothing loads from another origin, and no visitor-facing URL ends in
  `.html` (each page is `…/index.html` under a directory, canonicals and `sitemap.xml` are absolute
  at the `harrowgate.pages.dev/observatory/` address, each unique).
- Confirmed all 8 pages carry the header, star mark and footer; exactly 9 `.equipment` panels in
  the output; the log index lists all four entries sorted by `date` descending; no leftover
  `slot=`, `<slot>` or `<include>` in any output; `drafts/` and every `_` file absent from `dist`.
- Rebuilding to a throwaway output produced byte-identical trees (deterministic), then published
  clean with `--clean`.

## 1. What `rules.md` did not answer

The interface of the `generate` script. "unify runs it before every build and it writes into the
directory unify hands it" — the sentence I wanted and could not find is: *"your script is invoked
with the source root, the generated-overlay directory, and a JSON context file as argv 2–4"* (and
what is inside that context). The CLI help adds that the script gets `source-pages.json`, but
neither says the overlay is a first-class source. I probed with a throwaway site and found argv =
`[unify, script, sourceRoot, overlay, generator-context.json]`, the context carrying `baseUrl`,
`prettyUrls`, `outputRoot`, `inputs.sourcePages` — and, crucially, that files written into the
overlay behave like real pages (they get the nearest `_layout.html`, title joining, and the
`--base-url`/`--pretty-urls` link rewrites).

Also unanswered: whether a "meaningless" `date:` frontmatter key surfaces in the inventory's `date`
field (it does), the exact shape of `source-pages.json`, and whether include-slot-filling works in
`.md` *with the slots nested inside the fragment's divs* — "fills reach that fragment's slots and
no deeper" implies it, but there is no example.

## 2. What I had to re-read, and why it didn't land first time

- **The Include paragraph** — three reads. "main elements stay intact and their children are not
  fills" is layout-merge vocabulary dropped mid-paragraph, and "fills reach that fragment's slots
  and no deeper" took a second pass to understand as *the fragment's own slots, wherever nested; a
  fill's inner markup never fills anything*.
- **The merge bullet on header/footer** — "A bare `<header>`/`<footer>` does not replace the
  layout's — only `slot=` fills, and it fills the *contents*… write `<p slot='footer'>`" read
  contradictory at first; it needed re-reading to separate "replace the slot" (named fills
  anywhere) from "fill the contents" (when the layout wraps its slot in its own `<footer>`).
  I nearly built the footer as a slot; re-reading convinced me the layout should just own it.
- **The title sentence** — `<title>— My Site</title>` "no leading space" seemed like a typo;
  I re-read it and copied the example literally, which is right ("Home — Harrowgate Observatory"
  in the output).
- **The styles paragraph** — which addresses get rewritten (`href`/`src`) versus ship as written
  (CSS `url()`, `fetch`) — read twice; it decided that the hero image goes in an `<img src>` and
  all styling lives in one linked stylesheet, never inline `url()`.

## 3. What I guessed or inferred rather than read

- That `drafts/` can simply live outside `site/` and be ignored — the doc states "everything in
  the source root ships"; the converse (outside the root is invisible) is nowhere said outright.
- That a derived index is meant to be a full HTML page written into the overlay (rather than a
  fragment or a file copied byte-for-byte). Nothing demonstrates a finished example; my
  `log/index.html` is that inference.
- That `<include>` with HTML children works in Markdown body as a raw-HTML block (rules say
  include works "and in `.md`", but give no combined example — the successful strict build is my
  confirmation).
- The trailing slash in `--base-url`: the one example ends with `/`, so I copied that shape.
- Body classes (`home`, `log`, …) driving the active-nav CSS is "not a feature" — the doc points
  at the CSS pattern, so the convention (every log page carrying `class: log`, including the one
  I generated) is my choice, not a rule.
- Site content — nights, objects, gear names, volunteer names, dates — is invented per the brief.
