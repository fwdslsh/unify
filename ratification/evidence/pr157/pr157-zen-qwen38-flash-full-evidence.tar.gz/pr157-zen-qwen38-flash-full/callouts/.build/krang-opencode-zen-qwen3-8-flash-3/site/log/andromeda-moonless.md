---
date: 2026-10-24
author: Desmond
class: log
description: "M31 on a proper moonless dark: dustbin-lid Andromeda on the wide mount, M32 a button, M110 a smear."
---

# Andromeda on a moonless dark

*Saturday 24 October 2026 — logged by Desmond*

Proper dark, the kind you cannot fake from town: no moon, high cloud gone by nine, and that cold
that makes the air look thin. I only came up for an hour and stayed till midnight, which is the
usual story.

M31 above the reservoir and almost due south by ten — through the wide mount it is a *dustbin lid*
of a galaxy, easily five full moon-widths if you let your eye relax onto it. M32 a button, M110 a
faint smear to its north. Two visitors who came for the planets left having said almost nothing,
which I took as the highest praise.

<include src="/_includes/equipment.fragment.html">
  <p slot="heading">The camera lens on the wide mount</p>
  <p slot="body">Only rig with a field big enough for the whole of Andromeda. Dew shield on, low mount, and a red torch taped to the altitude screw because I always lose the torch.</p>
  <p slot="difficulty">Difficulty: easy to aim, but your neck pays for it</p>
</include>
