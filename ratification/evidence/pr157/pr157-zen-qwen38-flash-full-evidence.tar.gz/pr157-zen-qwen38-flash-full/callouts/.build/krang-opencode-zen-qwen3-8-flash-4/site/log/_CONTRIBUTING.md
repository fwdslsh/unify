# Writing an observing log entry (for volunteers)

You only write words. The site builds itself; the list on the log page updates itself.

## A new entry

1. Copy an existing entry, or start from the template below.
2. Name the file `YYYY-MM-DD-short-title.md`, in this folder.
3. Write the date of the night, with the time, exactly as `date: 2026-11-08T21:20:00Z`.
4. Save. Do not add HTML head tags or anything that looks like a whole web page.

Template:

    ---
    title: "Your title here"
    date: 2026-11-22T20:30:00Z
    author: Your Name
    description: One sentence about the night, for the log index and the feed.
    schema: BlogPosting
    ---

    # Your title here

    *Logged by Your Name, Friday night.*

    Your prose goes here. Blank lines separate paragraphs. `*italics*` and
    `**bold**` and `-` lists all work.

## A half-written entry

Start the filename with an underscore (`_november.md`) and it stays private: the build
reads it but never publishes it. Delete the underscore when it is ready.

## An equipment callout

Do not copy the panel from someone else's page. Paste this block where you want the
callout, keep it as one block with **no blank line inside**, and change only the three
pieces of text:

    <include src="/_includes/callout.fragment.html">
    <h3 class="callout-title" slot="title">Name of the telescope or kit</h3>
    <p class="callout-body" slot="body">What you used it for and why.</p>
    <p class="callout-difficulty" slot="difficulty">Difficulty: easy &mdash; or moderate, or hard</p>
    </include>

The box, the border, the telescope icon and the layout are not yours to worry about —
they live in one file (`/_includes/callout.fragment.html`) and one stylesheet rule
(`.callout` in `/styles.css`), and the site is the same everywhere.
