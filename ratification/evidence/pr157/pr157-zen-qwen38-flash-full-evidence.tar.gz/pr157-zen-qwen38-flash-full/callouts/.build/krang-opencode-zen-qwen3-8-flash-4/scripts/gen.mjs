// Derives site/log/index.html (the observing-log index, newest entry first).
// unify runs this before every build and hands it: [sourceRoot, generatedRoot, contextJson].
// It writes only into generatedRoot — never into site/.

import fs from 'node:fs';
import path from 'node:path';

const [, , sourceRoot, generatedRoot, contextPath] = process.argv;

const ctx = JSON.parse(fs.readFileSync(contextPath, 'utf8'));
if (!ctx.inputs?.sourcePages) {
  console.error('gen: no source-pages inventory handed to the generator');
  process.exit(1);
}
const inventory = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, 'utf8'));

const isLogEntry = (p) =>
  p.source.startsWith('log/') &&
  p.source.endsWith('.md') &&
  !path.basename(p.source).startsWith('_');

const authorOf = (p) =>
  p.meta.find((m) => m.name === 'author')?.content ?? 'a volunteer';

const entries = inventory.pages
  .filter(isLogEntry)
  .filter((p) => p.date)
  .sort((a, b) => b.date.localeCompare(a.date));

if (entries.length !== inventory.pages.filter(isLogEntry).length) {
  console.warn('gen: log entries without a readable date were left off the index');
}

const esc = (s) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const showDate = (iso) =>
  new Date(iso).toLocaleDateString('en-GB', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC',
  });

const items = entries
  .map((p) =>
    `      <li>\n` +
    `        <a href="${esc(p.href)}">${esc(p.title)}</a>\n` +
    `        <p class="entry-meta">${showDate(p.date)} &middot; logged by ${esc(authorOf(p))}</p>\n` +
    (p.description ? `        <p class="entry-desc">${esc(p.description)}</p>\n` : '') +
    `      </li>`)
  .join('\n');

const page =
`<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Observing Log</title>
  <meta name="description" content="Every observing-log entry from Harrowgate volunteers, newest first.">
</head>
<body class="log">
<main>
  <h1>Observing log</h1>
  <p class="lede">Nights at the eyepiece, written up by the volunteers who were there.
  Newest first; nothing here is finished until it is cold.</p>
  <ol class="entry-list">
${items}
  </ol>
</main>
</body>
</html>
`;

fs.mkdirSync(path.join(generatedRoot, 'log'), { recursive: true });
fs.writeFileSync(path.join(generatedRoot, 'log', 'index.html'), page);
console.log(`gen: log index with ${entries.length} entries`);
