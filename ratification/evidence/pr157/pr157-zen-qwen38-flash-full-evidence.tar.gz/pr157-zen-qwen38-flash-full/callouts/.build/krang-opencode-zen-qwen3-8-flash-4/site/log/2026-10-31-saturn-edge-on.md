---
title: "Saturn on Halloween, rings nearly edge-on"
date: 2026-10-31T22:10:00Z
author: Tom Wray
description: Thin-ringed Saturn after dusk, shown to a fancy-dress crowd through the wall Dobsonian and the dome refractor.
schema: BlogPosting
class: log
---

# Saturn on Halloween, rings nearly edge-on

*Logged by Tom Wray. Cloud cover at 6 pm, cleared by 9. Two volunteers lost to trick-or-treaters.*

Halloween is our worst-expected and best-attended night. Six people in witch hats came up the
track for a planet, and got one: Saturn low in the southwest, and *thin*. The rings are
close enough to edge-on this month that the great hoop we all promise visitors has become a
needle, and the globe beside it is barely a yellow smudge.

That turned out to be a better story than a fat-ringed Saturn would have been. The queue
listened twice: first to &ldquo;this is the year the rings nearly disappear&rdquo;, then to
&ldquo;that pinch of light in the eyepiece is the whole ring system&rdquo;. One witch said
&ldquo;it looks like a engagement ring seen from the side&rdquo;, which goes in the book.

I split the night: Saturn on the Dob by the wall for the long looks, the dome refractor for
the queue-breakers, and Jupiter did well enough on its own to cover my ten minutes gone to
boiling water for the urn.

<include src="/_includes/callout.fragment.html">
<h3 class="callout-title" slot="title">The Dob and the 2&times; barlow, at the wall</h3>
<p class="callout-body" slot="body">Low-horizon Saturn is a portable telescope's hardest customer. We take the ten-inch to the wall where the houses stop eating the southwest, and stack the barlow only in the ten-minute windows when the air holds still &mdash; the ring needle shows best at 150 power and forgives nothing below it.</p>
<p class="callout-difficulty" slot="difficulty">Difficulty: moderate &mdash; a steady hour is worth two bright ones</p>
</include>
