# REPORT — Harrowgate Observatory

## The publish command line

Run from this directory (`/tmp/sandbox`):

```
./unify build
```

`unify.yaml` pins everything the build needs, so the bare command is the whole publish:

```yaml
pretty-urls: true
base-url: https://harrowgate.pages.dev/observatory/
generate: scripts/gen.mjs
```

The expanded equivalent of the same command is
`./unify build --base-url https://harrowgate.pages.dev/observatory/ --pretty-urls --generate scripts/gen.mjs`
(run the same from this directory; exit 0 means `dist/` is the complete site).
`--clean` empties `dist/` first — I used it between experiments, not needed for a normal publish.

## What is where

- `site/_layout.html` — shared chrome: star-mark header, nav, footer; `<main><slot></slot></main>`;
  the title separator per the rules (`<title>— Harrowgate Observatory</title>`).
- `site/index.html`, `site/whats-up.html`, `site/visit.html` — the three HTML pages.
- `site/log/2026-10-18-double-cluster.md` … `2026-11-15-albireo.md` — four volunteer Markdown
  entries (`schema: BlogPosting` → JSON-LD + Atom feed).
- `site/log/_CONTRIBUTING.md` — how-to for volunteers (underscore: read, never published).
- `site/_includes/callout.fragment.html` — **the** equipment-callout panel (border, telescope
  icon, layout) with three slots (`title`, `body`, `difficulty`); pages and `.md` entries fill
  it with `<include>` + `slot=` children. Nine callouts, none of them copies of the panel.
- `site/styles.css` — one stylesheet; `site/star.svg` — the favicon mark; inline SVG
  placeholders stand in for the dome photo and the map sketch.
- `scripts/gen.mjs` — derives the log index (newest first) from the source inventory into the
  generated overlay; `site/log/index.html` is never authored.
- `drafts/` stays outside the source root, so it can never ship; verified absent from `dist/`.

## How I verified the pages (no browser)

1. `./unify build --dry-run --strict` — the whole build, every check, exit 0, with each page
   listed beside the layout it resolved to and its output address (`/observatory/…`).
2. `./unify build` — exit 0; `dist/` holds 12 files and nothing else.
3. `./unify audit --strict` and `./unify audit --external --strict` — "nothing to report".
4. Greps over `dist/`: every `href`/`src` is `/observatory/…`,
   `https://harrowgate.pages.dev/observatory/…` (canonical/og/sitemap/feed) or a `#main`
   fragment; no emitted link ends in `.html`; no unprefixed root link; no `<slot`/`slot=`
   residue; exactly 9 `<aside class="callout">`; no string `draft`, `jupiter-log` or
   `CONTRIBUTING` anywhere in the output; the only off-origin URLs are XML namespace/schema
   identifiers that the browser never fetches.
5. Checked the log index lists all four entries newest-first, and that feed/sitemap entries
   carry absolute `/observatory/` URLs.
6. Derivation proof: added a throwaway dated entry, rebuilt — the index listed it at the top
   with no file edited; removed it, rebuilt clean.

## To change every callout's border at once

`site/styles.css`, the `border:` line of the single `.callout` rule (commented, ~line 117).
All nine panels are splices of `site/_includes/callout.fragment.html`, so if the border change
is structural (rounded/sectioned panel) the fragment is the one file; the ten callout sites
never hold border or panel markup.

## What `rules.md` did not answer — the sentence I wanted and could not find

The generator contract. The one relevant sentence is "unify runs it before every build and it
writes into the directory unify hands it, never into `site/`" — but nowhere does it say *how*
the directory is handed. I wanted: "your script is called as
`gen.mjs <sourceRoot> <generatedRoot> <context.json>`" — that is what the probe of argv
showed, plus the context naming `inputs.sourcePages`. Also never stated: the shape of
`source-pages.json` (I dumped one and read it), whether a page written into the generated
overlay is wrapped by the site's `_layout.html` like an authored page (it is), and whether
`--generate` (help: "a relative path is from the source root") and the yaml key `generate:`
resolve from the same base — they do not: the yaml path resolves from the working directory,
which is the only reading that makes "kept in `scripts/` beside the site" true. Nothing says
whether a blank line in a Markdown include-with-fills breaks the fills; I tested one (it
works) but kept the conservative advice in `_CONTRIBUTING.md`.

## What I had to re-read, and why it did not land the first time

- The Include paragraph. It defines the feature by negation — "no props, no attributes
  passed, no expressions: an include is still not a component" — while I was reading for a
  component with arguments, so "content between the tags fills slots … only when the target
  is a `*.fragment.html` declaring `<slot>`" slid past me. Two more passes, including
  "fills reach that fragment's slots and no deeper" (so a log-entry callout cannot push text
  past the fragment into anything nested), before the design — fragment plus three named
  slots — actually assembled itself in my head.
- The single bullet covering source-root fallback, fragments, byte-for-byte copies, leading
  `/`, "always link the real filename", the `--pretty-urls` rewrite, directory-link validity
  and `--base-url`. It contains about six rules; I skimmed it, then hit my own real missing
  file during a probe and half-suspected the docs had lied about link rewriting. Re-reading
  it line by line is what produced `/log/index.html`-style links plus the flags.
- "A bare `<header>`/`<footer>` does not replace the layout's — only `slot=` fills, and it
  fills the *contents*". Re-read at merge time to decide the shared footer needs no slot at
  all, which keeps "every page shares the footer" from becoming ten fills.

## Guessed, or inferred rather than read

- `unify.yaml`'s exact key names (`pretty-urls:`, `base-url:`, `generate:`) — inferred from
  the `--save-config` output during probing and copied, not from a documented schema.
- Full `date: …T21:20:00Z` timestamps in entry frontmatter — read that a `date:` without a
  time "is reported and left out" of the feed, and inferred the Z-form would satisfy both
  the feed and JSON-LD `datePublished`; verified only afterwards in `feed.xml`.
- That frontmatter `class: log` + the layout's body-class merge would give the active-nav CSS
  (`body.log .nav-log`) the probe page proved — the rules say class lands on `<body>` and
  active nav "is CSS", but the combination I inferred.
- The icon's exact geometry (viewBox arithmetic, one segment overrunning 24 that I fixed)
  and every word of the copy, of course — invented, being the site's subject matter.
- That overlay files are excluded from `dist/` by the same `_*` rules as sources — inferred
  from "the build still reads it, the output never contains it" and never tested with a
  generated `_` file.
