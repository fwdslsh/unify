---
title: "First light on the Double Cluster"
date: 2026-10-18T20:45:00Z
author: Priya Anand
description: "Opening-night write-up: the Double Cluster in Cassiopeia through the ten-inch, and a swarm of first-time visitors."
schema: BlogPosting
class: log
---

# First light on the Double Cluster

*Logged by Priya Anand, opening night of the season.*

The sky was better than any of us dared plan for. We rolled the Dob out at half past seven,
and by eight there was a queue past the wall.

The Double Cluster (NGC 869 and NGC 884) was the first thing we showed everyone, because it
works on every kind of night and every kind of visitor. In binoculars it is two salt spills.
Through the ten-inch at 40 power it is a rumour of a galaxy: pairs of orange and blue-white
stars packed so closely that people keep asking if they are doubles, and yes, and yes.

Two things went well that we had not planned:

- The moon does not rise before midnight this week, so the field stayed dark even by the gate.
- A clear 40 minutes after nine let us add Jupiter low in the east, and the first visitor to see
  its moons shouted, which is the correct response.

One went badly: we are down to one red headtorch between three people at the wall. Order more.

<include src="/_includes/callout.fragment.html">
<h3 class="callout-title" slot="title">The front-gate Dobsonian, back from collimation</h3>
<p class="callout-body" slot="body">Ten inches of mirror that Wes spent the whole summer re-aluminising. Tonight was its first light: quick, forgiving, and the only instrument on site that can show the Double Cluster as more than a smudge.</p>
<p class="callout-difficulty" slot="difficulty">Difficulty: easy &mdash; aim at Cassiopeia and let people queue</p>
</include>
