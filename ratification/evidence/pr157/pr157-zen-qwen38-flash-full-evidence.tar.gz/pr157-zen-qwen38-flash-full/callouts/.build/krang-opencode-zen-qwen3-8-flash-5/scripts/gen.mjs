import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const [, , sourceRoot, generatedRoot, contextPath] = process.argv;
const context = JSON.parse(readFileSync(contextPath, "utf8"));
const inventory = JSON.parse(readFileSync(context.inputs.sourcePages, "utf8"));

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function pretty(dateIso) {
  const [y, m, d] = dateIso.split("-");
  return `${d} ${MONTHS[Number(m) - 1]} ${y}`;
}

const entries = inventory.pages
  .filter((p) => p.source.startsWith("log/") && p.date)
  .sort((a, b) => (a.date < b.date ? 1 : -1));

const items = entries
  .map((p) => {
    const author = (p.meta.find((m) => m.name === "author") || {}).content;
    return `    <li>\n      <a href="${esc(p.href)}">${esc(p.title)}</a>\n      <span class="entry-meta">${pretty(p.date)}${author ? " — " + esc(author) : ""}</span>\n    </li>`;
  })
  .join("\n");

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Observing log</title>
<meta name="description" content="The observing log: dated notes from Harrowgate Observatory's volunteers, newest first.">
</head>
<body>
<main>
  <h1>The Observing Log</h1>
  <p>Notes from the people at the eyepiece, newest first. Every entry is written in
  Markdown by a volunteer.</p>
  <ul class="log-list">
${items}
  </ul>
</main>
</body>
</html>
`;

mkdirSync(join(generatedRoot, "log"), { recursive: true });
writeFileSync(join(generatedRoot, "log", "index.html"), html);
console.log(`gen.mjs: wrote log/index.html with ${entries.length} entries`);
