---
title: "Andromeda, and a very cold wind"
date: 2026-10-28
author: "Priya S."
description: "A gusty clear night on doubles in Andromeda with the 80mm refractor; deep sky given up to the wind."
---
# Andromeda, and a very cold wind

*28 October 2026 — logged by Priya S.*

Clear but gusty. Kept the refractor outside under the tarp and ran doubles all night —
Albireo split cleanly, and Struve 2782 (the "Northern Gem") got a gasp off the street
wherever we stopped. Gave up on deep sky by 10: the wind shook the mount more than
seeing did.

<include src="/_includes/callout.fragment.html">
  <span slot="heading">80mm refractor</span>
  <p slot="body">The night's star. Wide fields for the double-star hopping chart, and it
  doesn't mind a bit of breeze the way a long tube does.</p>
  <span slot="difficulty">Difficulty: easy</span>
</include>
