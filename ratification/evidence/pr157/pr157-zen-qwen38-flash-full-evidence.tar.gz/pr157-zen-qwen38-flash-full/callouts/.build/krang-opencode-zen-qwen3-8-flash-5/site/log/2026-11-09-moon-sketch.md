---
title: "Moon sketch evening"
date: 2026-11-09
author: "Priya S."
description: "Terminator sketches at 6mm: limb craters and the Straight Wall's first light, an hour late."
---
# Moon sketch evening

*9 November 2026 — logged by Priya S.*

Terminator study with the 6mm: Ruprecht's weight of craters near the limb, and the
straight cliff of Straight Wall catching its first light an hour later than the
textbook says. Sketches pinned to the noticeboard.
