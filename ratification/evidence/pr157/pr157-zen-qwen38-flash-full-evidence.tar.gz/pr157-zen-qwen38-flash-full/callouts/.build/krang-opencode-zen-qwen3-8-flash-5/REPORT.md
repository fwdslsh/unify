# Harrowgate Observatory — build report

## Publish command line

```
./unify build --base-url https://harrowgate.pages.dev/observatory/ --pretty-urls
```

(These two options were also saved into `unify.yaml` via `--save-config`, so a bare
`./unify build` now publishes identically. Exit code 0 means `dist/` is the complete,
correct site for that address.)

## What verified the output

No browser, so verification was all read-the-dist and read-the-tool:

1. `./unify build --dry-run --strict` — the whole build with every check, and its page →
   resolved-layout list (`gen.mjs: wrote log/index.html with 5 entries`, 18 files, each
   page shown merged with `_layout.html`).
2. `./unify audit --strict` on the composed site — exit 0, "nothing to report".
3. `grep` over `dist/`: every internal `href`/`src` is under `/observatory/` and none ends
   in `.html`; the only absolute URLs are canonical/og tags pointing at
   `https://harrowgate.pages.dev/observatory/` itself; `sitemap.xml` holds the nine pages;
   no `drafts/` content anywhere (`jupiter-log.md` appears nowhere in `dist/`).
4. Read the composed HTML of a Markdown entry and of "What's Up": the callout composes to
   valid nesting (9 copies, identical structure, different words, no `slot=` leaking).

## Changing every callout's border at once

Edit the single `.callout { border: … }` rule in `site/assets/styles.css`. The panel's
markup itself exists exactly once, in `site/_includes/callout.fragment.html`; the ten
sites of use are `<include>` calls that fill only the heading/body/difficulty slots — so
volunteers write no panel markup, and border/panel changes land in one file (plus that one
CSS rule, which is where the border style actually lives).

Drafts: the source root is `site/`, and `drafts/` sits beside it, so it is never scanned or
published; `_*` exclusion handles the rest.

---

## 1. What `rules.md` did not answer

The generate-script contract. The sentence I wanted and could not find: **"unify invokes
your script with `argv = [node, script, sourceRoot, generatedRoot, contextJsonPath]`"**
(or anything like it). rules.md says only that the script "writes into the directory unify
hands it" — it never says *how* the directory is handed: argv, an env var, the cwd? I had
to write a probe script that dumped `process.argv` and a `generator-context.json` to learn
the three positional arguments and the `inputs.sourcePages` inventory path. Nothing in the
docs says the generated files are then treated as source pages, nor that they get wrapped
by the site's `_layout.html` — I inferred both from the build report (`log/index.html
← generated + _layout.html`).

## 2. What I had to re-read, and why it didn't land the first time

- **Line 6, the generate/feed sentence.** "writes into the directory unify hands it, never
  into `site/`" initially read to me as *generated files cannot become part of the site* —
  so where would a generated index even live? It took three re-reads plus the probe to
  parse it: the directory is handed *to the script*, and unify merges it into the build.
  The one-sentence compression of a whole mechanism is what didn't land.
- **The Include section (lines 21–23), twice.** The phrase "that element replaces the slot,
  tag and all" is written in the *Layout* section for page→layout fills; the Include
  section never repeats it for fragment fills. My first Markdown entries filled slots with
  `<h3 slot="heading">` inside a fragment whose slot sat inside an `<h3>` — the build
  shipped `<h3><h3>`. Re-reading "replaces the slot, tag and all" made it clear the fill
  is spliced *in place of the `<slot>` element*, wrapper tags preserved, so heading and
  difficulty fills must be inline (`<span>`) and only the body a `<p>` (its wrapper is a
  `<div>`). The rules describe both halves in different sections and never join them.
- **"No `title:` → first `# Heading`."** Read once it means "title is derived"; the actual
  consequence — that a page *with* `title:` gets no `<h1>` at all unless you also write one
  — had to be re-read off the built page (a Markdown entry with an empty `<main>` heading
  area).

## 3. Guessed or inferred rather than read

- **How the generator is invoked** — probed, then relied on: argv order, the context file's
  `inputs.sourcePages`, and that root-relative hrefs written into a generated page get the
  same `--base-url`/`--pretty-urls` rewriting as authored pages (they did; I checked the
  output rather than finding it documented).
- **`unify.yaml` key names for the saved options** (`pretty-urls:`, `base-url:`) — rules.md
  documents only `generate:`; I let `--save-config` invent them and did not hand-write
  anything before testing.
- **Trailing slash on `--base-url`** — the rules' example `https://you.example/handbook/`
  implies it; applied by analogy.
- **Avoiding `schema:`/`feed.xml`** — two lines about bare-`date:` handling read as
  slightly contradictory to me ("a `date:` with no time is reported and left out" vs. dates
  unify "cannot read as `2026-01-02`" being the only failures), so I inferred a plain
  `date: 2026-11-04` would cause feed advisories and simply skipped the feed; the brief
  never asked for one. This is an inference I did not verify.
- **The `span`-fill convention** in the callout is inferred from the observed splice
  semantics above, not stated in rules.md.
- **That `drafts/` outside `site/` is "never published" rather than "hidden"** — rules.md
  only says things *not part of the site* go under `_`; placing the source root outside
  `drafts/` is my reading of "Source root is `site/` if it exists". Verified by grepping
  `dist/`.
