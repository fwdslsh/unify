---
title: "First light after the rewiring"
date: 2026-10-14
author: "D. Okafor"
description: "The dome turns again: collimation on the rebuilt Dobsonian, and Saturn's rings for six late-night kids."
---
# First light after the rewiring

*14 October 2026 — logged by D. Okafor*

Dome finally turns again. Spent the first hour just sweeping collimation on Whitby —
the mirror clip rattle is gone. Public night ran late; six kids saw Saturn's rings and
one of them said "it looks *painted* on". Fair.

<include src="/_includes/callout.fragment.html">
  <span slot="heading">10-inch Dobsonian “Whitby”</span>
  <p slot="body">Rebuilt this autumn: new mirror clips, spare 25mm eye-piece added to the
  eyepiece case. Still push-to, still the fastest way to anything.</p>
  <span slot="difficulty">Difficulty: easy — ask a member to point it for you</span>
</include>
