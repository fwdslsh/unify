import fs from "node:fs";
import path from "node:path";

const [sourceRoot, overlay, ctxPath] = process.argv.slice(2);
const ctx = JSON.parse(fs.readFileSync(ctxPath, "utf8"));
const inv = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, "utf8"));

const entries = inv.pages
  .filter((p) => p.date && p.source.startsWith("log/") && !p.source.endsWith("index.html"))
  .map((p) => {
    let title = p.title;
    if (!title) {
      const body = fs.readFileSync(path.join(sourceRoot, p.source), "utf8");
      const m = body.match(/^#\s+(.+)$/m);
      title = m ? m[1].trim() : p.source;
    }
    return { ...p, title };
  })
  .sort((a, b) => (a.date < b.date ? 1 : -1));

function esc(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function prettyDate(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return new Intl.DateTimeFormat("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(d);
}

const items = entries
  .map(
    (e) =>
      `      <li>\n` +
      `        <a href="${esc(e.href)}">${esc(e.title)}</a>\n` +
      `        <time datetime="${esc(e.date)}">${esc(prettyDate(e.date))}</time>\n` +
      (e.description ? `        <p>${esc(e.description)}</p>\n` : "") +
      `      </li>`
  )
  .join("\n");

const page = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Observing Log</title>
  <meta name="description" content="Nights at Harrowgate Observatory, written by the volunteers who were there. Newest first.">
</head>
<body class="log">
  <h1>Observing Log</h1>
  <p>Nights on the hill, written up by the volunteers who spent them. Newest first.</p>
  <ol class="log-list">
${items}
  </ol>
</body>
</html>
`;

fs.mkdirSync(path.join(overlay, "log"), { recursive: true });
fs.writeFileSync(path.join(overlay, "log", "index.html"), page);
