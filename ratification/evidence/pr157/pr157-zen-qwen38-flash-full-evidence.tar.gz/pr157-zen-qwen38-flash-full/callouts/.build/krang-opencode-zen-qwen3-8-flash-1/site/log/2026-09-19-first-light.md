---
date: 2026-09-19
description: "Two clear hours after weeks of cloud: Jupiter's moons, Albireo, and a dew heater borrowed from a member."
class: log
---

# First light after the rain

Two clear hours between a shower and a bank of cloud from the west, which is the whole of
autumn on the hill in miniature. Four of us climbed up with everything we could carry and got
the deck scope out in eleven minutes, a record we will not hold for long.

Jupiter was low but magnificent: all four moons strung out like a barcode, shadows transiting
one after another. Then a quick sweep for Albireo, the gold-and-sapphire double that starts
every new volunteer on the hobby, and then the cloud arrived on schedule and we drank tea in
the watch room until it passed. It did not pass, so we walked home in it.

<include src="/_includes/equipment.fragment.html"><strong slot="heading">Old Bess + borrowed dew heater</strong>
The deck reflector fogs over in minutes on a wet night like this one; a member's spare dew heater strap kept the mirror clear long enough for the Jupiter run. Straps belong in the drawer marked "heaters", not in a bag at home.
<small slot="difficulty">Difficulty: easy once dry, hopeless once wet</small></include>
