# Report — Harrowgate Observatory

## Publish command

```
./unify build --clean --pretty-urls --base-url https://harrowgate.pages.dev/observatory/
```

The same options are saved in `unify.yaml`, so `./unify build --clean` from this
directory is equivalent and can't forget the subdirectory. (`--clean` is left off
`unify.yaml` because `unify audit` refuses to run with `clean:` set.)

## Done-means answers

- **Build succeeds for that address:** verified output, not just local correctness —
  every emitted link is under `/observatory/` with no `.html` (e.g.
  `href="/observatory/whats-up/"`), canonicals and `og:url` are absolute
  `https://harrowgate.pages.dev/observatory/...`, and `sitemap.xml` is generated.
- **How I verified (no browser):**
  1. `./unify build --dry-run --strict` — full build + every check; it lists each page
     with the layout it resolved to (`← log/2026-10-16-saturn.md + _layout.html`), and
     earlier runs caught broken links (`/assets/site.css` not yet written) before they
     could ship.
  2. `./unify audit --strict` — exits 0, "nothing to report".
  3. Read `dist/` with grep: all 10 files are the 7 pages + 2 assets + sitemap;
     every page carries the header star and footer from `_layout.html`; exactly 9
     `<aside class="equipment">` blocks exist (4 What's Up, 1 Visit, 3 log entries,
     1 home), all identical in markup and differing only in the three fills; no
     `http(s)` URL points off `harrowgate.pages.dev`; nothing from `drafts/` appears
     (the draft's sentence "Seeing was poor" matches no output file — `drafts/` is
     outside the source root `site/`, and `_layout.html`/`_includes/` are hidden by
     the default `_*` exclude).
- **To change every callout's border at once:** edit the single rule
  `.equipment { border: … }` in `site/assets/site.css` — the panel markup itself
  lives in one file too (`site/_includes/equipment.fragment.html`) and is included,
  not copied, everywhere, including inside the volunteers' Markdown entries.

## 1. What `rules.md` did not answer

The sentence I wanted and could not find: *what the `generate` script is passed.*
Line 6 says the script "writes into the directory unify hands it" and nothing names
the hand. I had to run the script printing `process.argv` to learn it is handed
`(sourceRoot, generatedOverlay, contextJsonPath)`, and find the context JSON's
`inputs.sourcePages` path (the inventory file) there — `--help` names the inventory
but not these. Related: nothing states that **generated overlay files get the same
layout merging, link rewriting and `--pretty-urls` treatment as source pages**; I
observed `← generated + _layout.html` in the dry-run listing and trusted it after
that.

## 2. What I re-read

The Include paragraph (line 23) — three times. The first reading didn't land because
it compresses five rules into one paragraph and I was looking for "how do pages pass
content in", which it answers obliquely: "Everything else to the bare slot" means
a *text* fill (no element, no `slot=`) lands in the bare slot, and fills "reach that
fragment's slots and no deeper" — so my fragment's slots must be direct children,
with the fallback living inside the `<slot>` element. I also re-read the merging
section (lines 36–39) because of the "only `slot=` fills, and it fills the
*contents*" distinction — my layout puts the page into a bare `<slot>` inside
`<main>`, which is "everything else", not a named-slot fill.

## 3. Guessed or inferred rather than read

- That `<include>` with content between tags works in a `.md` page through a raw
  HTML block: line 23 says include "works in any file … and `.md`", but combining
  that with Markdown HTML-block behaviour is my inference — confirmed only after I
  probed the merge into `dist/` (heading, body and difficulty fills landed in the
  right slots) before writing the real entries.
- That a page's frontmatter `date:` is exposed to the generator as `date` on the
  inventory and nothing more (so a `log/index.html` generated from it needs sorting
  by `date` descending myself — that the requirement means).
- The exact inventory JSON shape (it wasn't documented anywhere) — inferred by
  printing it in a first throwaway `gen.mjs`.
- That generated `log/index.html` in the overlay, rather than a hand-written
  `site/log/index.html`, is what the rules intend by "a post index from a script" —
  inferred from line 6.
- That the trailing slash in `--base-url` is required ("the site's whole address" —
  line 12) — read, but the consequence (every emitted URL nests under
  `/observatory/`) confirmed only in `dist/`.
- `class: log` in Markdown frontmatter maps to `<body class>` per line 51 (read),
  but that the generated index page needs the same class written by hand in the
  generator's template is my inference about what counts as "a page".
