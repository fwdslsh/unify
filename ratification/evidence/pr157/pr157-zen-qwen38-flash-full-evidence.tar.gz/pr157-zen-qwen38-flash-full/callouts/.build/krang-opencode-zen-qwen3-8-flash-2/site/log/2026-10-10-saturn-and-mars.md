---
date: 2026-10-10T20:50:00Z
author: "Priya R."
description: "A short evening: Saturn sinking early, Mars bright and ruddy near the trees."
schema: BlogPosting
class: log
---

# Saturn low, Mars red
Twenty minutes either side of the clouds, which is how you know it is October.

Saturn sets before midnight now and gets low in a murkier sky — we caught it on the
dome scope at the beginning of the evening with the rings still open enough to enjoy,
then the cloud came for good. Before that we put everyone on Mars, which sits near the
pines looking properly red through anything. That colour is the second most convincing
thing we show people; the first is Saturn's rings at 100×.

No callout tonight and no new gear talk — the sky gave us twenty minutes and we spent
them looking instead of writing.
