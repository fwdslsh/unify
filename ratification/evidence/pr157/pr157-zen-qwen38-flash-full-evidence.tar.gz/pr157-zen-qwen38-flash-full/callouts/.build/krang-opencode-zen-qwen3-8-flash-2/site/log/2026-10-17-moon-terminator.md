---
date: 2026-10-17T21:15:00Z
author: "Doug"
description: "Climbing rilles at the terminator, then an hour fiddling with the Dobsonian's mirrors."
schema: BlogPosting
class: log
---

# Moon's terminator and a bad collimation night
Clear, cold, no wind — the good kind of Thursday. Nobody else came, so it was really a
working night.

The Moon along the terminator around ten o'clock is still the best show on the list.
With the dome scope I spent half an hour on a rille system near Rupes Recta, just
watching shadows shorten as the terminator crept. That is the whole hobby in miniature:
the same crater is a different object every night.

<include src="/_includes/callout.fragment.html">
  <strong class="callout-heading" slot="heading">Dome telescope — 13-inch reflector</strong>
  <p slot="body">High power, steady mount, no dew trouble under the dome. For lunar work there is nothing else we own that shows the rilles this cleanly.</p>
  <p class="callout-difficulty" slot="difficulty">Difficulty: easy — but check the collimation first, see below.</p>
</include>

Second job: the 8-inch Dobsonian has been showing fat donut stars, and tonight I found
why. The secondary vanishingly far off-centre after someone transported it without
checking. Took forty minutes with the collimation cap and a torch.

<include src="/_includes/callout.fragment.html">
  <strong class="callout-heading" slot="heading">Portable Dobsonian — 8-inch "Table Mountain"</strong>
  <p slot="body">The crowd-pleaser, but it is the one that gets shoved into car boots, and boots are where collimation goes to die. Check it before every open night, not after.</p>
  <p class="callout-difficulty" slot="difficulty">Difficulty: moderate — five minutes with a collimation cap if you remember, an evening of doubt if you do not.</p>
</include>

Both scopes sharp by eleven. No visitors, no stories, and this is still one of the
better entries I will write this month.
