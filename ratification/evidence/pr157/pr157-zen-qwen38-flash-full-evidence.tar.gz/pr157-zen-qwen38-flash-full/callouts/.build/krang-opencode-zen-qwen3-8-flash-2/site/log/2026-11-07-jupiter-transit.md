---
date: 2026-11-07T21:40:00Z
author: "Priya R."
description: "Io's shadow crosses Jupiter's cloud tops — the best transit we have had this year."
schema: BlogPosting
class: log
---

# Jupiter and the shadow transit
Clear and still from the start, which almost never happens. Priya on the dome,
call it a night by eleven.

We were on Jupiter within ten minutes of opening the shutter and it was steady right
away — seeing that behaves itself, bands sharp as printed lines. Then Io's shadow came
onto the disk at the limb, small and black and perfectly round, and for about half an
hour we just took turns not saying anything into the eyepiece. Callum saw the moon
itself as a pale dot against the equatorial belt. Nobody else could get it, which is
how it should be.

<include src="/_includes/callout.fragment.html">
  <strong class="callout-heading" slot="heading">Dome telescope — 13-inch reflector</strong>
  <p slot="body">The only scope we have on a tracking mount under a shutter we can open in a minute. Nights like this are the reason the dome is worth the maintenance.</p>
  <p class="callout-difficulty" slot="difficulty">Difficulty: easy — aligned before dusk, everything is buttoned up by the time visitors arrive.</p>
</include>

By the time we shut down the cloud had crept to the western horizon. Typical.
