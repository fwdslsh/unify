# Harrowgate Observatory — build report

## Publish command

```
./unify build --clean --base-url https://harrowgate.pages.dev/observatory/ --pretty-urls
```

`--base-url` is the site's whole address (subdirectory included), which prefixes every
link, makes canonicals/`og:` absolute, and emits `sitemap.xml` and `feed.xml`;
`--pretty-urls` turns `whats-up.html` into `/whats-up/` and rewrites internal links to
match. Exit was 0; `./unify audit --strict` afterwards reports "nothing to report".

## Structure

- `site/_layout.html` — shared header (star mark, nav) and footer; `<main><slot></slot></main>`.
- `site/_includes/callout.fragment.html` — the one equipment-callout panel (bordered panel,
  telescope SVG, heading/body/difficulty `<slot>`s with fallbacks). It renders in 10
  places across the site — 4 What's Up objects, the Visit nights table, and 5 across 4 of
  the 5 log entries —
  10 rendered callouts in `dist/`. A volunteer adds one with five lines of fill, no panel markup.
- `site/log/*.md` — five dated entries (Markdown, frontmatter `date`/`author`/`description`
  and `schema: BlogPosting` for auto JSON-LD).
- `scripts/gen.mjs` — writes `log/index.html` into the generator overlay from the
  source-pages inventory, newest first; `unify.yaml` names it (`generate: scripts/gen.mjs`).
- `drafts/` sits outside the source root (`site/`), so "everything in the source root ships"
  never sees it. Verified: no draft file in `dist/`.

## How I verified (no browser)

- `./unify build --dry-run --strict` — full check, page→layout list, nothing written.
- `./unify audit --strict` on the composed site — clean exit.
- Grepped the output tree: every `href`/`src` is prefixed `/observatory/…` or absolute
  `https://harrowgate.pages.dev/observatory/…`; zero visitor-facing URLs end in `.html`
  (`href="…\.html"` count = 0); `sitemap.xml` and `feed.xml` carry the full
  `https://harrowgate.pages.dev/observatory/` addresses; each of the 9 pages contains the
  shared `site-head`/`site-foot` chrome once; callout count and per-page counts checked;
  log index lists all five entries sorted by `datetime` descending.

## To change every callout's border at once

Edit the single `.callout { border: … }` rule in `site/styles.css` (line 122) — the only
place any callout border is declared. Nothing else has to be touched: no page or entry
copies panel markup.

## Honest answers

**1. What rules.md did not answer.** The sentence I wanted and could not find: what
arguments and what environment a generator script is actually run with. rules.md says
"unify runs it before every build and it writes into the directory unify hands it" — it
never says how that directory is handed to the script (argv? env var?). I had to
print `process.argv` and `generator-context.json` from a throwaway script to learn the
contract: `argv[2..4] = sourceRoot, overlay, contextPath`, plus `--source-inventory`'s
JSON path. rules.md also never says generated overlay files are treated as source pages
(i.e. that a `<include>` or `data-layout` inside them is processed); I inferred it from a
probe and confirmed it by grepping the built output. And it never says the source-pages
inventory reports `title: null` for a Markdown page whose title comes from its first `#`
heading — the "no `title:` → first `# Heading`" rule applies to the rendered page, not to
the inventory I feed `gen.mjs`, which I discovered only when the built log index listed
filenames as titles; the script now reads the heading itself as a fallback.

**2. What I had to re-read.** The Include and Merging-a-page sections, three times. They
land on first read as "reuse works like templates", but unify's rules are all exceptions
and negatives ("main elements stay intact and their children are not fills", "an unfilled
slot showing its fallback", "never inside `<pre>`/`<code>`"). The callout design hinges on
exactly those carve-outs, so I had to re-read them to work out that direct-child fills
replacing named slots was in fact what I wanted — the first read left me confident about
the mechanism but unsure about the boundary cases, and my first draft of `_layout.html`
still got it wrong (I wrote `<p slot="footer">` inside the layout, which per the merging
section fills nothing).

**3. Guessed or inferred.** (a) The generator's argv/env contract, as above — discovered,
not read. (b) That `scripts/` is safe outside the source root without an underscore:
"Source root is `site/` if it exists" + "everything in the source root ships" implies
siblings like `drafts/` and `scripts/` never ship, but it is stated only by implication.
(c) `--dry-run`'s exact inventory availability for generators; I assumed `sourcePages` is
populated on every build and it was. (d) The log entries' content itself is invented —
the brief gave no copy. (e) That putting `date`/`author`/`description` in frontmatter and
the title only as a Markdown `# heading` (no `title:` key, whose colon value I had to
quote per the YAML warning) yields correct feed entries and JSON-LD — inferred from the
schema paragraph, verified afterwards in `dist/feed.xml` and the built `<script type=
"application/ld+json">`.
