---
date: 2026-10-24T22:05:00Z
author: "Callum W."
description: "Double Cluster through the binoculars; the red-dot finder turns up in the hedge."
schema: BlogPosting
class: log
---

# Two clubs, and a lost finder scope
Friday, four visitors, wind dropping as the evening went on.

Started everyone on the Double Cluster with the binoculars on the ledge, which is the
single best opener we have — people who arrived saying "is that all there is" about
Jupiter went quiet at the eyepiece there. Then onto M31 with the widefield, and a
schoolteacher in the group found M32 before Callum did.

<include src="/_includes/callout.fragment.html">
  <strong class="callout-heading" slot="heading">Widefield refractor — 80 mm f/6</strong>
  <p slot="body">Tripod-mounted, hand-pointed, 3° of sky. The instrument for anything too big for the dome scope, and the one visitors are allowed to aim themselves.</p>
  <p class="callout-difficulty" slot="difficulty">Difficulty: easy to use, maddening to keep the finder on — ours came off again this week.</p>
</include>

The red-dot finder spent the better part of an hour in the hedge before anyone
admitted to knocking it. Found by the person who lost it, credit where due.
