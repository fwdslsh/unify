import fs from "node:fs";
import path from "node:path";

const [sourceRoot, overlay, contextPath] = process.argv.slice(2);

const ctx = JSON.parse(fs.readFileSync(contextPath, "utf8"));
const inventory = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, "utf8"));

const logPages = inventory.pages.filter((p) => {
  const rel = path.relative(sourceRoot, path.join(sourceRoot, p.source));
  return rel.startsWith("log" + path.sep) && p.source.endsWith(".md");
});

const metaOf = (page, name) =>
  (page.meta ?? []).find((m) => m.name === name)?.content ?? null;

const firstHeading = (source) => {
  try {
    const text = fs.readFileSync(path.join(sourceRoot, source), "utf8");
    const m = text.match(/^# (.+)$/m);
    return m ? m[1].trim() : null;
  } catch {
    return null;
  }
};

const entries = logPages
  .map((p) => ({
    href: p.href,
    title: p.title ?? firstHeading(p.source) ?? p.source,
    date: p.date ?? metaOf(p, "date"),
    author: metaOf(p, "author") ?? "a volunteer",
    description: p.description ?? "",
  }))
  .filter((e) => e.date)
  .sort((a, b) => (a.date < b.date ? 1 : -1));

const day = (iso) => iso.slice(0, 10);

const items = entries
  .map((e) => {
    const title = String(e.title).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    const desc = String(e.description)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
    const author = String(e.author).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    return `        <li>
          <h2><a href="${e.href}">${title}</a></h2>
          <p><time datetime="${e.date}">${day(e.date)}</time> — ${author}</p>
          <p class="muted">${desc}</p>
        </li>`;
  })
  .join("\n");

const html = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="description" content="The Harrowgate Observatory observing log, written by the volunteers who were there. Newest first." />
    <title>Observing Log</title>
  </head>
  <body class="log">
    <main>
      <h1>Observing Log</h1>
      <p>
        Notes from the nights we were here, written by whoever was on the ladder.
        Newest first. Instruments mentioned are described where they stand — the
        <a href="/whats-up.html">What's Up</a> page is where to look, and the
        <a href="/visit.html">visit page</a> is how to get here.
      </p>
      <ul class="log-list">
${items}
      </ul>
    </main>
  </body>
</html>
`;

fs.mkdirSync(path.join(overlay, "log"), { recursive: true });
fs.writeFileSync(path.join(overlay, "log", "index.html"), html);
console.log(`gen.mjs: wrote log/index.html with ${entries.length} entries`);
