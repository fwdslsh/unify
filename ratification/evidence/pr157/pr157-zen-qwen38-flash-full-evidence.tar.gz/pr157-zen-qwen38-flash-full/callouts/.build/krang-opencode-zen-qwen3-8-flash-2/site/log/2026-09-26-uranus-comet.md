---
date: 2026-09-26T22:30:00Z
author: "Sam"
description: "Star-hopping to Uranus with the 25×70s; the promised comet did not turn up."
schema: BlogPosting
class: log
---

# Uranus found, comet not
Saturday, six of us, and a hard lesson in what binoculars are actually for.

We had the sky charts out and spent forty good minutes star-hopping along the horns of
Capricornus until Uranus sat in the field like a tiny green-blue bead. The trouble is
that it looks exactly like a faint star — which is a fine way to learn the ecliptic. The
comet that the app promised was not there, or was one degree off the plotted track, and
by the time we had searched the box around the position the dew had started.

<include src="/_includes/callout.fragment.html">
  <strong class="callout-heading" slot="heading">Binoculars — 10×50 on a tabletop</strong>
  <p slot="body">What we own. For anything faint and moving the 10×50s are the wrong tool for a search and a very good one for a confirmation — once someone with a bigger instrument has found it.</p>
  <p class="callout-difficulty" slot="difficulty">Difficulty: moderate — star-hopping with binoculars is a skill you lose again if you do not practise it.</p>
</include>

Dew on the objectives by 23:15, which was always going to end it. Someone had the sense
to bring flask. On the whole a useful night: the sky is not a catalogue and the comet
did not care about our app.
