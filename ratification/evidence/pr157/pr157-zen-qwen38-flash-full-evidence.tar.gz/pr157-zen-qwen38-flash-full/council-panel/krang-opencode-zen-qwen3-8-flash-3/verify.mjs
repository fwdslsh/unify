import http from "node:http";
import fs from "node:fs";
import path from "node:path";

const ROOT = "/tmp/sandbox/dist";
const BASE = "/mill/";
const ORIGIN = "http://127.0.0.1:8765";
const TYPES = { ".html": "text/html", ".css": "text/css", ".js": "text/javascript", ".svg": "image/svg+xml", ".xml": "application/xml" };

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split("?")[0]);
  if (!p.startsWith(BASE)) return void res.writeHead(404).end("outside base");
  p = "/" + p.slice(BASE.length);
  let file = path.join(ROOT, p);
  if (p.endsWith("/")) file = path.join(file, "index.html");
  if (fs.existsSync(file) && fs.statSync(file).isFile()) {
    res.writeHead(200, { "content-type": TYPES[path.extname(file)] ?? "application/octet-stream" });
    fs.createReadStream(file).pipe(res);
  } else {
    res.writeHead(404).end("not found");
  }
});

await new Promise((r) => server.listen(8765, r));

const get = async (p) => {
  const r = await fetch(ORIGIN + p);
  return { status: r.status, type: r.headers.get("content-type"), body: await r.text() };
};

let failures = 0;
const check = (name, ok, detail = "") => {
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail ? "  — " + detail : ""}`);
  if (!ok) failures++;
};

// 1. the pages visitors see, at the published address, without .html
for (const url of [
  "/mill/",
  "/mill/visit/",
  "/mill/milling/",
  "/mill/milling/2026-11-07-dressing-the-stones/",
]) {
  const r = await get(url);
  check(`GET ${url}`, r.status === 200 && r.type === "text/html", `${r.status} ${r.type}`);
  check(`  ${url} has shared header + footer`, r.body.includes("/mill/sails.svg") && r.body.includes("site-footer"));
}

// 2. the council's fixed address: bare markup, no <html>/<head>/<body>
const council = await get("/mill/opening-hours.fragment.html");
check(
  "council GET /mill/opening-hours.fragment.html is bare markup",
  council.status === 200 && !/<\s*(html|head|body)\b/i.test(council.body) && council.body.includes("Opening hours"),
  `${council.status} tags=${/<\s*(html|head|body)\b/i.test(council.body)}`
);

// 3. the same panel is on the Visit page (one source, one edit)
const visit = await get("/mill/visit/");
const hoursNeedle = "<dt>Wednesday – Friday</dt>";
check(
  "Visit page contains the identical panel markup",
  visit.body.includes(hoursNeedle) && council.body.includes(hoursNeedle)
);

// 4. what the home page fetches when the visitor flips the month
const home = await get("/mill/");
for (const frag of ["/mill/milling/this-month.fragment.html", "/mill/milling/next-month.fragment.html"]) {
  check(`home offers href to ${frag}`, home.body.includes(`href="${frag}"`));
  const r = await get(frag);
  check(
    `month flip fetches ${frag} → bare markup`,
    r.status === 200 && !/<\s*(html|head|body)\b/i.test(r.body) && r.body.includes("milling-dates"),
    `${r.status}`
  );
}
const monthsJs = await get("/mill/js/months.js");
check(
  "no fetch until a click (js fetches only inside a click handler)",
  monthsJs.status === 200 && /addEventListener\("click"/.test(monthsJs.body) && (monthsJs.body.match(/fetch\(/g) ?? []).length === 1 && /click[\s\S]*fetch/.test(monthsJs.body)
);

// 5. index lists every note, newest first
const idx = await get("/mill/milling/");
const a = idx.body.indexOf("dressing-the-stones/\"");
const b = idx.body.indexOf("harvest-bake/\"");
const c = idx.body.indexOf("first-turn-since-the-repaint/\"");
check("milling index has all three notes, newest first", a > -1 && a < b && b < c, `order ${a}/${b}/${c}`);

// 6. every asset/page link the browser will follow from any page resolves under /mill/
const pages = [];
const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).forEach((e) => {
  const f = path.join(d, e.name);
  if (e.isDirectory()) walk(f);
  else if (e.name.endsWith(".html")) pages.push(BASE + path.relative(ROOT, f).replaceAll(path.sep, "/").replace(/index\.html$/, ""));
});
walk(ROOT);
const seen = new Set();
for (const page of pages) {
  const { body } = await get(page);
  for (const m of body.matchAll(/(?:href|src)="(\/mill\/[^"]+)"/g)) {
    const target = m[1];
    if (seen.has(page + target)) continue;
    seen.add(page + target);
    const r = await get(target);
    if (r.status !== 200) check(`broken link ${page} → ${target}`, false, String(r.status));
  }
}
check("all internal /mill/ links + assets resolve (crawl)", seen.size > 20 && [...seen].length > 0, `${seen.size} unique link checks, no misses`);

// 7. nothing from drafts/ was published
const draft = fs.readFileSync("/tmp/sandbox/drafts/winter-hours.md", "utf8").trim();
const leak = pages.filter(async () => true);
let leaked = false;
for (const page of pages) {
  const { body } = await get(page);
  if (body.includes("not for publication") || body.includes("have not agreed")) leaked = true;
}
check("no drafts content in any page", !leaked);
check("drafts/winter-hours is not published", !(await get("/mill/winter-hours/")).status && (await get("/mill/winter-hours/")).status === 404, "(drafts/ also sits outside site/, the source root)");

// 8. canonical/og are absolute for the real address
check("canonical is absolute at holtfen.pages.dev", home.body.includes(`href="https://holtfen.pages.dev/mill/"`));

server.close();
console.log(failures ? `\n${failures} FAILURES` : "\nall checks passed");
process.exit(failures ? 1 : 0);
