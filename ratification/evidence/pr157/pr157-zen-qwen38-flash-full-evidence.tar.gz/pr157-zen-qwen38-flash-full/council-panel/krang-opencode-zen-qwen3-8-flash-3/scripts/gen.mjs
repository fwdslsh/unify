import fs from "node:fs";
import path from "node:path";

const [, , sourceRoot, generatedRoot, contextPath] = process.argv;
const context = JSON.parse(fs.readFileSync(contextPath, "utf8"));
const inventory = JSON.parse(fs.readFileSync(context.inputs.sourcePages, "utf8"));

const notes = inventory.pages
  .filter((p) => p.source.startsWith("milling/") && p.source.endsWith(".md"))
  .sort((a, b) => String(b.date ?? "").localeCompare(String(a.date ?? "")));

const lines = [
  "---",
  "title: Milling days",
  "description: Notes from the volunteers who work the sails, newest first.",
  "class: milling",
  "---",
  "",
  "# Milling days",
  "",
  "Notes written by the volunteers after the mill runs, newest first. This list is",
  "built from the notes themselves, so it can never drift out of date.",
  "",
];

for (const note of notes) {
  const href = note.href.startsWith("/") ? note.href : "/" + note.href;
  const date = note.date ? String(note.date).slice(0, 10) : "undated";
  lines.push(`- [${note.title ?? path.basename(note.source)}](${href}) — ${date}`);
}

lines.push("");

const out = path.join(generatedRoot, "milling", "index.md");
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, lines.join("\n"));

console.log(`gen.mjs: wrote milling/index.md listing ${notes.length} notes (newest first)`);
