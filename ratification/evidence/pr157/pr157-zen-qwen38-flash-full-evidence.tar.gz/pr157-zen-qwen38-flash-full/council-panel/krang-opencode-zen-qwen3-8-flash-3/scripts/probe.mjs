import fs from "node:fs";

const [source, overlay, context] = process.argv.slice(2);
const ctx = JSON.parse(fs.readFileSync(context, "utf8"));
console.log("INVENTORY:\n" + fs.readFileSync(ctx.inputs.sourcePages, "utf8"));
