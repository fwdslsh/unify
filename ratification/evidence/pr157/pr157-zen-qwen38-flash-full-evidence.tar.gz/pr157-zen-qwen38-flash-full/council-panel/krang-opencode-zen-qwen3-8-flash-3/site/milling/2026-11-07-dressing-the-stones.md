---
title: Preparing the stones for November
date: 2026-11-07
---

Bill and I came up at dawn to dress the stones before Saturday's run. The runner
stone needed a new furrow pattern — five hours of chiselling between us, and the
dust gets into everything, as it always has.

The oil we put on last month held. If you can read this and the sails are going,
we got it right.
