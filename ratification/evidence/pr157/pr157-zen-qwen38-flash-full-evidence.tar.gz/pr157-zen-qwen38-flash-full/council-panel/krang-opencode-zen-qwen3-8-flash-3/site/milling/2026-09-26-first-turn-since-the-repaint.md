---
title: First turn since the repaint
date: 2026-09-26
---

The new stock sails threw their first shower of sparks today, quietly, the way
they are supposed to. Half the village turned up on the bank to watch.

Lesson for whoever comes next: ease the brake rather than lean on it, and the
whistle stays in the bin where it belongs.
