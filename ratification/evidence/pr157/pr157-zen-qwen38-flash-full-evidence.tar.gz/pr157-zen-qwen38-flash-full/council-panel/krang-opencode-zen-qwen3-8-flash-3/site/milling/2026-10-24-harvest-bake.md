---
title: Harvest bake, Saturday 24th
date: 2026-10-24
---

Six hundredweight of Skiff came off the stone by two o'clock, and Margaret fired
the ovens at the roundhouse for the bread stall. The lane was full of cars before
noon.

Mind the third step up to the bin floor — it has been loose since harvest began.
We have chocked it for now; it wants a proper repair before the frost.
