(function () {
  "use strict";

  var panel = document.getElementById("month-panel");
  if (!panel) return;

  var toggles = document.querySelectorAll(".month-toggle");
  var cache = {};
  var current = null;

  Array.prototype.forEach.call(toggles, function (link) {
    link.addEventListener("click", function (event) {
      event.preventDefault();
      show(link);
    });
  });

  function show(link) {
    if (link === current) return;
    current = link;
    Array.prototype.forEach.call(toggles, function (other) {
      other.classList.toggle("is-active", other === link);
    });
    var url = link.getAttribute("href");
    if (cache[url]) {
      render(cache[url]);
      return;
    }
    panel.innerHTML = "<p class='month-hint'>Loading " + link.textContent + "…</p>";
    fetch(url)
      .then(function (response) {
        if (!response.ok) throw new Error("HTTP " + response.status);
        return response.text();
      })
      .then(function (markup) {
        cache[url] = markup;
        render(markup);
      })
      .catch(function () {
        panel.innerHTML = "<p class='month-hint'>The dates could not be loaded. Please try again.</p>";
      });
  }

  function render(markup) {
    if (current) panel.innerHTML = markup;
  }
})();
