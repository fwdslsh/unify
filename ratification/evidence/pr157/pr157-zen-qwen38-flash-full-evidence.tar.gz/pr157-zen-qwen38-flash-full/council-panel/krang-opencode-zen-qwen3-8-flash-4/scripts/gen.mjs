import fs from 'node:fs';
import path from 'node:path';

const [, , sourceRoot, overlay, ctxPath] = process.argv;
const ctx = JSON.parse(fs.readFileSync(ctxPath, 'utf8'));

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'];
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function esc(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;').replaceAll("'", '&#39;');
}

function parts(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  if (!m) { return null; }
  return { y: Number(m[1]), mo: Number(m[2]), d: Number(m[3]), key: `${m[1]}-${m[2]}` };
}

function prettyDate(iso) {
  const p = parts(iso);
  if (!p) { return iso; }
  const weekday = DAYS[new Date(Date.UTC(p.y, p.mo - 1, p.d)).getUTCDay()];
  return `${weekday} ${p.d} ${MONTHS[p.mo - 1]} ${p.y}`;
}

const outDir = path.join(overlay, 'milling');
fs.mkdirSync(outDir, { recursive: true });

const inventory = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, 'utf8'));
const notes = inventory.pages
  .filter((p) => p.source.startsWith('milling/') && p.source.endsWith('.md') && p.date)
  .sort((a, b) => String(b.date).localeCompare(String(a.date)));

const items = notes.map((note) => {
  const when = note.date.slice(0, 10);
  const desc = note.description ? `<p>${esc(note.description)}</p>` : '';
  return `  <li><a href="${esc(note.href)}">${esc(note.title)}</a>`
    + `<time datetime="${esc(when)}">${esc(prettyDate(when))}</time>${desc}</li>`;
}).join('\n');

fs.writeFileSync(path.join(outDir, 'index.html'), `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Milling days</title>
<meta name="description" content="Notes from the volunteers on every day the mill ran, newest first.">
</head>
<body class="milling">
<main>
<h1>Milling days</h1>
<p>Every note our volunteers have written from the millfloor, newest first.
This index is generated when the site is built — a new note appears here by
itself, no hand-keeping needed.</p>
<ul class="note-list">
${items}
</ul>
</main>
</body>
</html>
`);

const calendar = JSON.parse(
  fs.readFileSync(path.join(sourceRoot, '_data', 'milling-days.json'), 'utf8'));

function monthFragment(key) {
  const [y, mo] = key.split('-').map(Number);
  const days = calendar.days
    .filter((day) => day.date.slice(0, 7) === key)
    .sort((a, b) => a.date.localeCompare(b.date));
  if (days.length === 0) {
    return `<section class="milling-month"><h2>No dates for ${MONTHS[mo - 1]} ${y} yet</h2>`
      + '<p>Nothing is on the calendar for this month — check the other month, '
      + 'or the milling days page for everything we have run.</p></section>\n';
  }
  const list = days.map((day) => `    <li><time datetime="${esc(day.date)}">`
    + `${esc(prettyDate(day.date))}</time> — ${esc(day.text)}</li>`).join('\n');
  return `<section class="milling-month"><h2>Milling days in ${MONTHS[mo - 1]} ${y}</h2>\n  <ul>\n${list}\n  </ul>\n</section>\n`;
}

const now = new Date();
const thisKey = `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, '0')}`;
const next = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));
const nextKey = `${next.getUTCFullYear()}-${String(next.getUTCMonth() + 1).padStart(2, '0')}`;

fs.writeFileSync(path.join(outDir, 'this-month.fragment.html'), monthFragment(thisKey));
fs.writeFileSync(path.join(outDir, 'next-month.fragment.html'), monthFragment(nextKey));
