(function () {
  var flip = document.querySelector('.month-flip');
  if (!flip) { return; }
  var panel = flip.querySelector('.flip-panel');
  var tabs = Array.prototype.slice.call(flip.querySelectorAll('.flip-tab'));
  var cache = {};

  function markTab(active) {
    tabs.forEach(function (t) {
      var on = t === active;
      t.classList.toggle('is-on', on);
      t.setAttribute('aria-selected', on ? 'true' : 'false');
    });
  }

  function show(button) {
    markTab(button);
    var src = flip.getAttribute(button.dataset.month === 'next' ? 'data-src-next' : 'data-src-this');
    var url = new URL(src, document.baseURI).href;
    if (cache[url]) { panel.innerHTML = cache[url]; return; }
    panel.textContent = 'Loading the calendar…';
    fetch(url).then(function (response) {
      if (!response.ok) { throw new Error('HTTP ' + response.status); }
      return response.text();
    }).then(function (html) {
      cache[url] = html;
      panel.innerHTML = html;
    }).catch(function () {
      panel.textContent = 'The calendar could not be loaded — the milling days page has every date.';
    });
  }

  tabs.forEach(function (t) {
    t.addEventListener('click', function () { show(t); });
  });
})();
