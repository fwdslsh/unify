---
date: 2026-11-02T09:30:00Z
description: "Notes from the day the new stones dressed and ran true for the first time."
class: milling
schema: BlogPosting
---

# The first grind in eighty years

Wind from the west, steady enough by ten. We dressed the runners on Monday, so
today was the first proper feed since the restoration.

Ran one pair only, the north stone, to keep the load gentle. By the third
hopperful the meal was coming down hot and sweet-smelling and Meg said the bolt
was as tight as she could want it. We took a sack of sharps for the shop and a
small sack of middlings for the bake tomorrow.

Spindles warm, no knock on the brass, brake band holding. Shut down at four in
softening wind. Best day's work we have had.
