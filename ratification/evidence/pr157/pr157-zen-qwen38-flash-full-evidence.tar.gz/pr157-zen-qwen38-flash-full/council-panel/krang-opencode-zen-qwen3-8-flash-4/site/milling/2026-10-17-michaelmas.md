---
date: 2026-10-17T12:00:00Z
description: "The ovens came back to the green for the first Michaelmas in a decade."
class: milling
schema: BlogPosting
---

# Michaelmas baking Saturday

Two grinds before the bakes even started, so the first loaves came out of the
field oven at noon with flour from the 17th's own wheat on them.

The school had forty children on the green by ten. Milling demo went long
because everyone wanted a turn on the hopper door. Tea tent broke even. Rusty
found three squirrels in the straw store and chased them for half an hour, so
less straw than planned but a good story for the leaflet.

We should do this every year. That is the whole point, isn't it.
