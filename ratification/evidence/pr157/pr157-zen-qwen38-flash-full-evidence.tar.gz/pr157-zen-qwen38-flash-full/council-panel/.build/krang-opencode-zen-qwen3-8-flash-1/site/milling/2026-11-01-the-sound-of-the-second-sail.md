---
date: 2026-11-01
description: The second sail runs true after the relaunch; a leaf-blocked gutter for the diary.
class: milling
---

# The sound of the second sail

A wet, blustering Sunday and only two sails wanted to drive, so we ran on the weather
pair and it was enough. Ground a farmer's rye from nine till it slackened after three.
The new second sail is bedded in nicely — no thumping at the top of the revolution any
more, which was the thing we feared after the spring relaunch. One thing for the diary:
the gutter over the cart shed is leaf-blocked again and pouring onto the door sill.
