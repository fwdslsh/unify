# Holt Fen Windmill — build report

## 1. The publish command line

```
./unify build --base-url https://holtfen.pages.dev/mill/ --pretty-urls --clean --audit
```

Exit 0 means `dist/` is the complete published site. `unify.yaml` (`generate: scripts/gen.mjs`)
makes the build run the generator first on every invocation. `--audit` publishes only if
`unify audit` would pass; I also ran `./unify audit --strict` standalone — exit 0, "nothing to report".

## 2. What was built, and the two panel decisions

- `site/_layout.html` carries the header (inline SVG sails mark + nav), footer and shared head;
  it wraps every page, including the generated index and the Markdown notes.
- **The council panel** is `site/hours.fragment.html`. Fragments ship as written, so its address
  is `https://holtfen.pages.dev/mill/hours.fragment.html` — bare markup (verified: zero
  `<html>`/`<head>`/`<body>` in the bytes) and **not renamed by `--pretty-urls`**, which is why the
  address is stable season after season. `site/visit.html` pulls it in with
  `<include src="/hours.fragment.html"></include>`. One file, one edit: I changed the closing
  time, rebuilt, and both `dist/hours.fragment.html` and the Visit page showed the change.
  It carries its own small `<style>` scoped to `.hf-hours`, because the council's page will not
  have our stylesheet.
- **The month flip.** `scripts/gen.mjs` (which unify runs before every build, writing into the
  generated overlay directory it is handed) reads the build's own source-page inventory and
  emits three files: `milling/index.html` (every note, newest first — volunteers never touch it),
  and `milling/this-month.fragment.html` / `next-month.fragment.html`, bucketed by note `date:`
  against the build's calendar month. The home page links them with `<link rel="alternate"
  id="src-this-month" href="/milling/this-month.fragment.html">` so unify rewrites the address to
  `/mill/...`; `months.js` reads the href back off the link (the rules' sanctioned pattern, since
  `fetch()` addresses ship as written) and fetches **only on click**, caching per address. No
  auto-fetch, no reload. Links inside the month fragments are page-relative (`milling/<slug>/`),
  because fragment bytes are not rewritten and they resolve against the home page's URL `/mill/`.
- `drafts/` sits outside the source root (`site/`), so it cannot ship; I also grepped every byte
  of `dist/` for its content — absent.

## 3. What `rules.md` did not answer

- **How the generator is invoked.** The docs say it "writes into the directory unify hands it"
  — that is all. The sentence I wanted, and could not find, is the calling convention: *what
  arguments, and where does it write so unify picks the files up*. I discovered by experiment
  that the script gets `argv[2]=source root, argv[3]=generated overlay, argv[4]=context JSON`,
  that the context names `site.baseUrl`, `site.prettyUrls`, and `inputs.sourcePages` (the page
  inventory), and that HTML written into the overlay is composed like a real page (layout,
  rewriting, canonical all applied) while a `.fragment.html` written there ships raw. None of
  that is written down anywhere.
- **Whether `--pretty-urls` touches fragments.** The docs define pretty-urls as
  `about.html → about/index.html` and define fragments as shipped "as written"; the interaction
  is unstated. This mattered enormously — the council's permanent address is a fragment. I had
  to verify empirically (it survives un-renamed). The sentence I wanted: *"a
  `*.fragment.html` keeps its exact output filename under `--pretty-urls`."*
- **Whether link rewriting reaches into fragments.** "Shipped as written" strongly implies no,
  but no line says it, and my index-vs-fragment links depend on the answer. I inferred it and
  then checked bytes.
- **CLI vs config path resolution for `--generate`.** The docs say scripts live in `scripts/`
  "beside the site" named in `unify.yaml`; the CLI help says "a relative path is from the
  source root". I followed the CLI first and got `site/scripts/gen.mjs: Module not found` —
  only then did the docs' spelling (yaml, beside `site/`) work. The two resolutions are never
  contrasted; I inferred the yaml path is relative to the project root.
- **The inventory's `title` for heading-titled pages.** The docs say "No `title:` → first
  `# Heading`", and I assumed the inventory's `title` field would carry the heading too. It
  doesn't — it reports the *authored* title only (null here), while the built page's `<title>`
  does use the heading. I caught this only because the generated index printed
  `2026-11-08-school-morning-on-the-stone-floor.html` as a note title; the generator now reads
  the heading back from the source file.
- `--audit` combined with `build` ("audit the composed site before publishing") — what counts
  as failing? The rules say only `broken` findings always exit 1, `incomplete`/advisories need
  `--strict`, so I fixed every advisory anyway so both gates pass.

## 4. What I re-read, and why it did not land the first time

- **The Include paragraph (lines 21–23).** Three readings. First pass I took "`<include>` splices
  a fragment" and stopped; it hid that content between the tags fills slots *only when the target
  declares `<slot>`* and "fills reach that fragment's slots and no deeper" — rules that decide how
  the shared panel could be shaped. It did not land because one paragraph mixes five distinct
  contracts (empty include, fills, main-element carve-out, no props) with no list or examples.
- **Line 6, the generate-script sentence.** A 90-word clause chain. The second reading caught
  "*never into `site/`*"; the third revealed what it means — write to the handed overlay, and
  the overlay is merged into the build. I initially wrote the generator to emit into `site/`
  and it would have been wrong in spirit; the handoff only made sense after the argv probe.
- **Line 58, fetch/`url()`/rewriting.** Re-read twice. First pass: "fetch addresses aren't
  rewritten, bad". Second pass: the fix is a designed pattern — "or read it back from an `href`
  unify rewrote" — which is exactly what the two `<link rel="alternate">` elements in the home
  page head are for. It did not land because that clause is an afterthought at the end of a
  sentence already carrying three other rules.

## 5. What I guessed or inferred rather than read

- That the council's permanent address should literally be `/mill/hours.fragment.html` — the
  brief never specifies one, and nothing says a `.fragment.html` suffix is acceptable in a URL;
  it is stable, bare, and `--pretty-urls` leaves it alone, which is what was actually required.
- That "this month/next month" should be resolved at **build** time from note dates against the
  build clock. The tool has no runtime and rules.md forbids *generated* dates from the clock in
  JSON-LD, but says nothing about generator logic; a static site can only re-bucket months by
  rebuilding, so the publish command is implied as the (re)publish rhythm. If December comes
  without a rebuild, "next month" empties — the generator prints "No milling days have been
  posted" instead.
- That an empty next month is acceptable behavior for the home flip (a "scheduled" note is
  dated 2026-12-06 so it is populated today).
- Relative-link resolution in the injected fragments (browser semantics, not a unify rule) and
  the `months.js` fetch/cache logic entirely — unify ships JS "byte-for-byte" and says nothing
  about writing it.
- That directory links written in a *generated* overlay page (`/milling/post-one.html` style)
  are rewritten exactly like authored pages; observed once in the probe, then relied on.

## 6. How I verified it (the "done means")

No browser, so I verified against the **published shape at the published address**: a Node
static server (`_verify.mjs`) mounts `dist/` under `/mill/` and I run 86 checks, all passing:

- **Pages:** `GET /mill/`, `/mill/visit/`, `/mill/milling/`, and all four note URLs → 200;
  every one carries the header (sails SVG) and footer. Visitor addresses contain no `.html`.
- **Everything resolves for that address:** a walker extracts every `href`/`src` from every
  emitted page and resolves it against its *own* URL; all fetch 200 under `/mill/`; every
  root-relative one already carries the `/mill/` prefix; no off-origin URL anywhere (the two
  inline SVGs are the only images). `styles.css`/`months.js` reachable at `/mill/...`.
- **The council's address:** `GET /mill/hours.fragment.html` → 200; regex over the bytes proves
  no `<html`/`<head`/`<body`; content has the hours. The Visit page's HTML contains the panel
  **byte-identical** — same source.
- **The month flip:** from the *served* home page I read the two rewritten link hrefs —
  `/mill/milling/this-month.fragment.html` and `.../next-month.fragment.html` — then execute
  `dist/months.js` in a `node:vm` sandbox with a fake DOM and instrumented `fetch`:
  zero fetches before any click; clicking "This month" fetches exactly the this-month address
  and the panel shows 8 November; "Next month" fetches exactly the next-month address (6
  December); a second click on "This month" is served from cache with **no new request**. Both
  fragments are bare markup and their relative note links resolve to live URLs from `/mill/`.
- **Drafts:** no `drafts/` path or content anywhere in `dist/` (byte grep over all 13 files).
- **Regeneration:** added a fifth dated note, rebuilt: index and this-month fragment updated
  themselves; removed it, rebuilt clean. `./unify audit --strict`: exit 0.
