---
date: 2026-11-08
description: Twenty-eight Year 4s grind wheat on an on-and-off wind; the shop sells out by four.
class: milling
---

# School morning on the stone floor

Wind was on and off, but we milled two hours with twenty-eight Year 4s from Holt CE
through it, which was the point of the day really. They took the wheat from sieve to
flour, guessed the stone's weight wrong by a ton, and one boy asked if the mill had a
"gear change" and I nearly wept with joy at the question. We only got one coat off the
wheat — teaching grinds are slow grinds — but the flour is lovely and the shop sold out
by four. Next school visit booked for the 29th, weather permitting.
