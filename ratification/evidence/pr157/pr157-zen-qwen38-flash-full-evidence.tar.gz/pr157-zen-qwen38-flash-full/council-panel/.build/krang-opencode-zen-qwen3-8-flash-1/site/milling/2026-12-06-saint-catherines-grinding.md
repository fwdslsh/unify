---
date: 2026-12-06
description: A planned Saint Catherine's grinding by the college volunteers, wind permitting.
class: milling
---

# Saint Catherine's grinding, if the wind consents

Not yet a milling day, more of a promise. The college students who helped re-hang the
third sail asked to come back and grind for the last Saint Catherine's day before the
mill closes for the winter break, and the trustees have said yes if the forecast holds.
We have two bushels of mixed grain waiting in the bin store and the long table cleared.
If it runs, I will write the note the same evening; if it does not, this stays as a
notice of good intentions.
