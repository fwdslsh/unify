import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import path from 'node:path';

const [sourceRoot, generatedRoot, ctxPath] = process.argv.slice(2);
const ctx = JSON.parse(readFileSync(ctxPath, 'utf8'));
const inventory = JSON.parse(readFileSync(ctx.inputs.sourcePages, 'utf8'));

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
  'August', 'September', 'October', 'November', 'December'];

function niceDate(iso) {
  const [y, m, d] = iso.split('-').map(Number);
  return `${d} ${MONTHS[m - 1]} ${y}`;
}

const notes = inventory.pages
  .filter((p) => /^milling\/[^/]+\.md$/.test(p.source))
  .sort((a, b) => (b.date ?? '').localeCompare(a.date ?? ''));

// source-pages.json reports the authored frontmatter title only; when the note
// takes its title from its first `#` heading (as the build does), read it back.
for (const n of notes) {
  if (n.title) continue;
  const md = readFileSync(path.join(sourceRoot, n.source), 'utf8');
  const m = md.match(/^# (.+)$/m);
  if (m) n.title = m[1];
}

function when(note) {
  return note.date
    ? `<time datetime="${note.date}">${niceDate(note.date)}</time>`
    : '<time>undated</time>';
}

// In a real page, link the true filename: unify rewrites it for the base URL
// and pretty urls.
function pageItem(note) {
  const title = note.title ?? path.basename(note.href);
  return `<li>${when(note)} — <a href="${note.href}">${title}</a></li>`;
}

// In a shipped-as-written fragment there is no rewriting, so link relative to
// the home page (which itself sits at the site root): no leading slash,
// ".html" becomes a directory, matching the built layout.
function fragmentItem(note) {
  const title = note.title ?? path.basename(note.href);
  const rel = note.href.slice(1).replace(/\.html$/, '/');
  return `<li>${when(note)} — <a href="${rel}">${title}</a></li>`;
}

function page(body, title) {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${title}</title>
<meta name="description" content="Notes from the volunteers of Holt Fen Windmill on the days the mill ran.">
</head>
<body class="milling">
<main>
${body}
</main>
</body>
</html>
`;
}

const mkdir = (rel) => {
  const dir = path.join(generatedRoot, rel);
  mkdirSync(dir, { recursive: true });
  return dir;
};

mkdir('milling');

const indexBody = `<h1>Milling days</h1>
<p>Dated notes from the volunteers, newest first. This list is written by
<code>scripts/gen.mjs</code> whenever the site is built — a new note in
<code>site/milling/</code> appears here on its own.</p>
<ul class="note-list">
${notes.map(pageItem).join('\n')}
</ul>
`;
writeFileSync(path.join(generatedRoot, 'milling', 'index.html'), page(indexBody, 'Milling days'));

const now = new Date();
const keyOf = (y, m) => `${y}-${String(m + 1).padStart(2, '0')}`;
const thisKey = keyOf(now.getUTCFullYear(), now.getUTCMonth());
const nextDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));
const nextKey = keyOf(nextDate.getUTCFullYear(), nextDate.getUTCMonth());

function monthName(ym) {
  const [y, m] = ym.split('-').map(Number);
  return `${MONTHS[m - 1]} ${y}`;
}

function monthFragment(ym) {
  const label = monthName(ym);
  const inMonth = notes.filter((n) => n.date && n.date.startsWith(ym));
  if (inMonth.length === 0) {
    return `<p>No milling days have been posted for ${label}.</p>\n`;
  }
  return `<h3>${label}</h3>
<ul>
${inMonth.map(fragmentItem).join('\n')}
</ul>
`;
}

writeFileSync(
  path.join(generatedRoot, 'milling', 'this-month.fragment.html'),
  monthFragment(thisKey)
);
writeFileSync(
  path.join(generatedRoot, 'milling', 'next-month.fragment.html'),
  monthFragment(nextKey)
);

console.log(`gen: ${notes.length} notes; index + this/next month fragments (${thisKey}, ${nextKey})`);
