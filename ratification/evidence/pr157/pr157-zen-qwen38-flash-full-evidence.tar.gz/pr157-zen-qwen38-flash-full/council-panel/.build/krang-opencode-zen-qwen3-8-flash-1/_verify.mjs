import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const DIST = '/tmp/sandbox/dist';
const BASE_PATH = '/mill';
const MIME = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.xml': 'application/xml' };

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (!p.startsWith(BASE_PATH)) { res.writeHead(404); return res.end('outside mount'); }
  let file = path.join(DIST, p.slice(BASE_PATH.length));
  if (file.endsWith('/')) file += 'index.html';
  if (!fs.existsSync(file) && fs.existsSync(file + '.html')) file += '.html';
  if (!fs.existsSync(file) || !file.startsWith(path.resolve(DIST))) { res.writeHead(404); return res.end('not found'); }
  res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'text/plain' });
  res.end(fs.readFileSync(file));
});

await new Promise((r) => server.listen(8123, r));
const origin = 'http://127.0.0.1:8123';
const get = async (p) => {
  const r = await fetch(origin + p);
  return { status: r.status, body: await r.text() };
};

let failures = 0;
const check = (name, ok, extra = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${extra ? '  — ' + extra : ''}`);
  if (!ok) failures++;
};

// 1. Pages resolve under /mill/ from every page, no .html in visitor addresses
const home = await get(BASE_PATH + '/');
check('GET /mill/ -> 200', home.status === 200);
check('home has header sails mark + footer', /sails-mark/.test(home.body) && /site-footer/.test(home.body));
for (const p of ['/visit/', '/milling/',
  '/milling/2026-12-06-saint-catherines-grinding/',
  '/milling/2026-11-08-school-morning-on-the-stone-floor/',
  '/milling/2026-11-01-the-sound-of-the-second-sail/',
  '/milling/2026-10-17-oats-at-last-light/']) {
  const r = await get(BASE_PATH + p);
  check(`GET ${p} -> 200`, r.status === 200);
  check(`GET ${p} shares header+footer`, /sails-mark/.test(r.body) && /site-footer/.test(r.body));
}
check('GET /mill/styles.css -> 200', (await get(BASE_PATH + '/styles.css')).status === 200);
check('GET /mill/months.js -> 200', (await get(BASE_PATH + '/months.js')).status === 200);

// 2. Every href/src on every page resolves under /mill/ (link check)
const pages = [];
const walk = (d) => { for (const f of fs.readdirSync(d)) { const q = path.join(d, f); if (fs.statSync(q).isDirectory()) walk(q); else if (q.endsWith('.html') && !q.endsWith('.fragment.html')) pages.push(q); } };
walk(DIST);
const allLinks = new Set();
for (const pg of pages) {
  const html = fs.readFileSync(pg, 'utf8');
  const rel = '/' + path.relative(DIST, pg).replace(/\\/g, '/').replace(/index\.html$/, '').replace(/^\/$/, '');
  const url = BASE_PATH + (rel === '/' ? '/' : rel);
  for (const m of html.matchAll(/(?<![\w-])(?:href|src)="([^"]+)"/g)) {
    const u = m[1];
    if (/^(https?:)?\/\//.test(u) || u.startsWith('mailto:') || u.startsWith('data:')) {
      if (/^https?:\/\/(?!holtfen\.pages\.dev)/.test(u)) check(`off-site URL on ${url}: ${u}`, false);
      continue;
    }
    let target;
    if (u.startsWith('/')) {
      check(`root-relative without /mill/ prefix on ${url}: ${u}`, u.startsWith(BASE_PATH + '/'), u);
      target = u;
    } else {
      target = new URL(u, origin + url).pathname;
    }
    allLinks.add(target);
    const r = await get(target);
    if (r.status !== 200) check(`link ${url} -> ${target} resolves`, false);
  }
}
check('all internal hrefs/srcs resolve under /mill/', failures === 0);

// 3. The council's fixed address: bare markup, season-stable
const hours = await get(BASE_PATH + '/hours.fragment.html');
check('GET /mill/hours.fragment.html -> 200', hours.status === 200);
check('council panel has no <html>/<head>/<body>', !/<html|<head|<body/i.test(hours.body));
check('council panel has opening hours content', /10:00/.test(hours.body) && /Opening hours/.test(hours.body));

// 3b. One panel, one source: the Visit page carries byte-identical panel markup
const visit = await get(BASE_PATH + '/visit/');
const visitPanel = hours.body.trim();
check('Visit page contains the identical panel', visit.body.includes(visitPanel));

// 4. The month flip: fetch addresses read back from the served home page's links,
//    months.js run under a fake DOM — only clicked month fetched, once.
const linkIds = { this: 'src-this-month', next: 'src-next-month' };
const hrefs = {};
for (const [k, id] of Object.entries(linkIds)) {
  const m = home.body.match(new RegExp(`id="${id}" href="([^"]+)"`));
  hrefs[k] = m && m[1];
}
check('home exposes two rewritten month links', hrefs.this === '/mill/milling/this-month.fragment.html' && hrefs.next === '/mill/milling/next-month.fragment.html', JSON.stringify(hrefs));

const listeners = {};
const mkEl = (id, cls, attrs = {}) => ({
  id, attrs: { ...attrs }, innerHTML: '', textContent: '', href: attrs.href, dataset: {},
  listeners,
  setAttribute(k, v) { this.attrs[k] = v; }, getAttribute(k) { return this.attrs[k]; },
  addEventListener(t, fn) { (listeners[id] ??= {})[t] = fn; },
});
const panelEl = mkEl('month-days', 'month-days');
const tabs = {
  this: mkEl('tab-this', 'month-tab', { 'data-month-src': 'src-this-month' }),
  next: mkEl('tab-next', 'month-tab', { 'data-month-src': 'src-next-month' }),
};
const links = {
  'src-this-month': mkEl('src-this-month', '', { href: origin + hrefs.this }),
  'src-next-month': mkEl('src-next-month', '', { href: origin + hrefs.next }),
};
const document = {
  getElementById: (id) => panelEl.id === id ? panelEl : (links[id] || (tabs.this.id === id ? tabs.this : null)),
  querySelectorAll: (sel) => sel === '.month-tab' ? [tabs.this, tabs.next] : [],
};
const fetchLog = [];
const sandboxFetch = (u) => { fetchLog.push(u); return globalThis.fetch(u); };
const monthsJs = fs.readFileSync(DIST + '/months.js', 'utf8');
const ctx = vm.createContext({ document, fetch: sandboxFetch, Object, Array, Error, Promise, String, console });
vm.runInContext(monthsJs, ctx);
check('no fetch before any click', fetchLog.length === 0, `fetchLog=${fetchLog.length}`);
const thisBody = (await get(hrefs.this)).body;
const nextBody = (await get(hrefs.next)).body;
check('this-month fragment is bare markup', !/<html|<head|<body/i.test(thisBody) && /8 November 2026/.test(thisBody));
check('next-month fragment is bare markup', !/<html|<head|<body/i.test(nextBody) && /6 December 2026/.test(nextBody));
check('this-month links resolve from home URL', await (async () => {
  const hrefs = [...thisBody.matchAll(/href="([^"]+)"/g)].map((m) => new URL(m[1], origin + BASE_PATH + '/').pathname);
  for (const t of hrefs) if ((await get(t)).status !== 200) return false;
  return hrefs.length === 2;
})());
check('next-month links resolve from home URL', await (async () => {
  const hrefs = [...nextBody.matchAll(/href="([^"]+)"/g)].map((m) => new URL(m[1], origin + BASE_PATH + '/').pathname);
  for (const t of hrefs) if ((await get(t)).status !== 200) return false;
  return hrefs.length === 1;
})());

listeners['tab-this'].click();
check('click "This month" fetches the this-month address', fetchLog.length === 1 && fetchLog[0] === origin + hrefs.this);
await new Promise((r) => setTimeout(r, 100));
check('panel shows this month', /8 November 2026/.test(panelEl.innerHTML) && /November 2026/.test(panelEl.innerHTML));
listeners['tab-next'].click();
check('click "Next month" fetches only the next-month address', fetchLog.length === 2 && fetchLog[1] === origin + hrefs.next);
await new Promise((r) => setTimeout(r, 100));
check('panel shows next month', /6 December 2026/.test(panelEl.innerHTML));
listeners['tab-this'].click();
check('re-click reuses cache (no new fetch)', fetchLog.length === 2);

// 5. Drafts never published
const allDist = [];
const walkAll = (d) => { for (const f of fs.readdirSync(d)) { const q = path.join(d, f); if (fs.statSync(q).isDirectory()) walkAll(q); else allDist.push(q); } };
walkAll(DIST);
const distText = allDist.map((p) => fs.readFileSync(p, 'utf8')).join('');
check('drafts/ content absent from dist', !/winter hours|not for publication|DRAFT/i.test(distText));
check('no drafts directory in dist', !fs.existsSync(DIST + '/drafts'));

server.close();
console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} FAILURES`);
process.exit(failures === 0 ? 0 : 1);
