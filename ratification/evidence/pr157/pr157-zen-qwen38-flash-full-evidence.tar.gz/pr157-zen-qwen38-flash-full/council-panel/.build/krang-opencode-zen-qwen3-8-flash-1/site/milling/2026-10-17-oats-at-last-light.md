---
date: 2026-10-17
description: Four bushels of fen oats on a steady westerly, and the brake band holding again.
class: milling
---

# Oats at last light

Four bushels of fen oats in by two o'clock, and a steady westerly gave us the whole
afternoon. We had the first two coats out by four and the third one going on as the
swallows came over. Margaret boxed thirty bags for the shop. The brake band is holding
again now that we re-stitched it, though I would not take the last coat in a gale until
we have looked at the stitching next month. Wind dropped right off at six and we trammed
the floor, oiled the sails and locked up by half past seven.
