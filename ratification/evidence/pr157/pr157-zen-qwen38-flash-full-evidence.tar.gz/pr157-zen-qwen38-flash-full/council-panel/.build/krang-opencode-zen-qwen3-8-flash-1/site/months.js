(function () {
  var panel = document.getElementById('month-days');
  if (!panel) return;
  var tabs = Array.prototype.slice.call(document.querySelectorAll('.month-tab'));
  var cache = {};

  function choose(btn) {
    tabs.forEach(function (t) {
      t.setAttribute('aria-selected', t === btn ? 'true' : 'false');
    });
  }

  function show(url, html) {
    panel.innerHTML = html;
    panel.dataset.monthSource = url;
  }

  tabs.forEach(function (btn) {
    btn.addEventListener('click', function () {
      var link = document.getElementById(btn.getAttribute('data-month-src'));
      if (!link) return;
      var url = link.href;
      choose(btn);
      if (Object.prototype.hasOwnProperty.call(cache, url)) {
        show(url, cache[url]);
        return;
      }
      panel.innerHTML = '<p>Loading…</p>';
      fetch(url)
        .then(function (r) {
          if (!r.ok) throw new Error('HTTP ' + r.status);
          return r.text();
        })
        .then(function (text) {
          cache[url] = text;
          show(url, text);
        })
        .catch(function () {
          panel.innerHTML = '<p>The milling days could not be loaded just now. Please try again.</p>';
        });
    });
  });
})();
