---
date: 2026-12-05
description: "Posted plan: the mill aims to run on the first Sunday of December, weather allowing."
---
# December posting

This is the day we are aiming at, posted early for the sake of the bakery. The mill runs the first Sunday of December, 11:00 to 15:00, weather allowing and if the oats are through the dress. The porter will put the ration book and the tea urn on the floor by ten. If the wind fails us on the day, this becomes a standing day with no flour: the sails will tell you before you set out.
