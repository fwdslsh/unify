---
date: 2026-11-01
description: "First flour of the autumn from the new season's oats, with the old stones warmed back up."
---
# First flour of the autumn

We warmed the stones back up after a fortnight idle and ran half a tonne of oats for the Holt Common herd share. The wind sat on its shoulder all morning, just enough to hold four sails. The oat flour came out sweet and the miller smiled for the first time since August. Only trouble was the elevator belt slipping when the hopper ran low — a five-minute job with the key, noted for next time. Nine volunteers on site, which is nearly a record for a Sunday.
