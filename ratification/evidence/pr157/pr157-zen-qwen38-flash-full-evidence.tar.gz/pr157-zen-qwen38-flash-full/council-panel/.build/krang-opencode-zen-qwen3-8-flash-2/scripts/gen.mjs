import fs from 'node:fs'
import path from 'node:path'

const [sourceRoot, generatedRoot, ctxPath] = process.argv.slice(2)
const ctx = JSON.parse(fs.readFileSync(ctxPath, 'utf8'))
const base = ctx.site.baseUrl || '/'
const inventory = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, 'utf8'))

const notes = inventory.pages
  .filter((p) => /^milling\/.+\.md$/.test(p.source))
  .map((p) => {
    const date = p.date || dateFromSource(p.source) || dateFromBody(p.source)
    return {
      source: p.source,
      href: p.href,
      title: p.title || headingFromBody(p.source),
      description: p.description || '',
      date,
    }
  })
  .filter((n) => n.date)
  .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0))

function fileOf(source) {
  return path.join(sourceRoot, source)
}
function dateFromSource(source) {
  const m = source.match(/(\d{4}-\d{2}-\d{2})/)
  return m ? m[1] : null
}
function dateFromBody(source) {
  const m = fs.readFileSync(fileOf(source), 'utf8').match(/^date:\s*(\d{4}-\d{2}-\d{2})/m)
  return m ? m[1] : null
}
function headingFromBody(source) {
  const m = fs.readFileSync(fileOf(source), 'utf8').match(/^# (.+)$/m)
  return m ? m[1] : path.basename(source, '.md')
}

function prettyHref(href) {
  const p = href.replace(/^\//, '')
  if (!ctx.site.prettyUrls) return p
  if (p === 'index.html') return ''
  return p.replace(/\.html$/, '/')
}
function toBase(href) {
  return base + prettyHref(href)
}

function dayLabel(iso) {
  const d = new Date(iso + 'T12:00:00Z')
  return new Intl.DateTimeFormat('en-GB', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC',
  }).format(d)
}

function esc(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

const entries = notes.map((n) => ({
  href: n.href,
  url: toBase(n.href),
  title: esc(n.title || headingFromBody(n.source)),
  desc: esc(n.description || ''),
  iso: n.date,
  label: dayLabel(n.date),
}))

const listItems = entries
  .map((e) =>
    `      <li>\n        <h2><a href="${e.href}">${e.title}</a></h2>\n` +
    `        <span class="when"><time datetime="${e.iso}">${e.label}</time></span>\n` +
    (e.desc ? `        <p>${e.desc}</p>\n` : '') +
    `      </li>`
  )
  .join('\n')

const indexPage = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Milling days</title>
<meta name="description" content="Volunteers' notes from the days the mill ran, newest first.">
</head>
<body class="milling">
<main>
  <h1>Milling days</h1>
  <p>Notes written by the volunteers on the days the mill ran, newest first. The mill runs when the wind and the wheat allow; this list is generated at build time from the notes, so nobody has to keep an index by hand.</p>
  <ol class="note-list">
${listItems}
  </ol>
</main>
</body>
</html>
`

function monthKey(offset) {
  const now = new Date()
  const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + offset, 1))
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`
}

function monthFragment(offset) {
  const key = monthKey(offset)
  const rows = entries.filter((e) => e.iso.startsWith(key))
  const body = rows.length
    ? rows
        .map((e) => `    <li><time datetime="${e.iso}">${dayLabel(e.iso).replace(/ \d{4}$/, '')}</time> <a href="${e.url}">${e.title}</a></li>`)
        .join('\n')
    : '    <li>No milling days posted for this month yet &mdash; check back, or watch the sails.</li>'
  return `<ul class="milling-day-list">\n${body}\n</ul>\n`
}

fs.mkdirSync(path.join(generatedRoot, 'milling'), { recursive: true })
fs.writeFileSync(path.join(generatedRoot, 'milling/index.html'), indexPage)
fs.writeFileSync(path.join(generatedRoot, 'milling/this-month.fragment.html'), monthFragment(0))
fs.writeFileSync(path.join(generatedRoot, 'milling/next-month.fragment.html'), monthFragment(1))
