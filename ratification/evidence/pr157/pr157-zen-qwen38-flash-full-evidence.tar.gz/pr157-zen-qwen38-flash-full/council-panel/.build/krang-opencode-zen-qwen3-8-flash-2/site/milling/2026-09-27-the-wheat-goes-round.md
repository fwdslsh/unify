---
date: 2026-09-27
description: "First run of the harvest: two tonnes of a winter wheat variety, and the stones behaved."
---
# The wheat goes round

Two tonnes of a old winter wheat came in from the Graveny farm, and the wind held from noon till nearly dusk. The stones ran true all afternoon and the bolting cloth is still good. We filled 140 sacks of wholemeal and the tea urn went empty twice. The trick with this variety is the feed rate — go slow or the stones chill and the flour goes grey. We stopped the third hour short; the miller reckons the last of the corn is not worth dressing the sails for.
