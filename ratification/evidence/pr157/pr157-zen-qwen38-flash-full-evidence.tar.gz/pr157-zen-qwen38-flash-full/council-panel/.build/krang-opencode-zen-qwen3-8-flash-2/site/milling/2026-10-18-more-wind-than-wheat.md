---
date: 2026-10-18
description: "An autumn milling day with more wind than wheat, and a school group that got the full story."
---
# More wind than wheat

A grey, blowy Sunday. We had booked half a tonne from the allotments association and the wind gave us four hours of hard running for it. The brake band smoked a bit on the last stop, so that is on the list for Wednesday. A primary school group turned up unannounced with eight parents and got the full story on the floor from the gate post. One small boy has drawn us a picture of the sails which is now pinned by the office door. Flour sold out by two.
