# Holt Fen Windmill — build report

## Publish command

```
./unify build --base-url https://holtfen.pages.dev/mill/ --pretty-urls --clean --audit --strict
```

These options are also saved in `unify.yaml` (which additionally holds `generate: scripts/gen.mjs`),
so a plain `./unify build` publishes the identical site — but the line above is the exact,
self-contained publish command. It exits 0 and `dist/` is the complete site.

## Layout of the site

- `site/_layout.html` — chrome: `<include>`s `_includes/masthead.html` (sails-mark inline SVG +
  nav) and `_includes/colophon.html` (footer) around a bare `<slot>`. Title separator lives in
  the layout: pages write only their own name.
- `site/index.html` — home story + month flip (inline JS).
- `site/visit.html` — embeds the panel with `<include src="/opening-hours.fragment.html">`.
- `site/opening-hours.fragment.html` — the one panel. Shipped bare at
  `/mill/opening-hours.fragment.html` and spliced verbatim into Visit: one edit updates both.
- `site/milling/*.md` — five dated volunteer notes, frontmatter only.
- `scripts/gen.mjs` (named by `generate:` in `unify.yaml`) — reads `source-pages.json`,
  writes `milling/index.html` plus the two month fragments into the generated directory
  unify hands the script (argv: source root, generated dir, context JSON).

## How I verified

- **Pages.** Strict audit reports nothing (`./unify audit` exits 0). `dist/` holds exactly
  13 files: 8 pages under pretty URLs (`/mill/`, `/mill/visit/`, `/mill/milling/`, five notes),
  three fragments, `styles.css`, `sitemap.xml` (all `<loc>` prefixed `https://holtfen.pages.dev/mill/`).
  Every visitor-clickable `href` in the output resolves under `/mill/` and none ends in `.html`
  (checked by grep over all `href=` values). `_includes/`, `_layout.html`, `scripts/`, `drafts/`,
  `BRIEF.md`, `rules.md` are outside `dist/` or under `_` — nothing of `drafts/` ships.
- **Council address.** `https://holtfen.pages.dev/mill/opening-hours.fragment.html` ships
  byte-identical to its source (`cmp` clean) and contains zero matches for `<html`, `<head>`
  or `<body>`. The path is stable: fragments keep their literal name under `--pretty-urls`
  (proven in a probe build and in the final `dist/`), so the address will not move across
  seasons, and editing the one file updates Visit and the council response together.
- **Month flip.** The home page fetches **only** on a button click — nothing loads until asked
  (there is no preload; initial panel text says "Choose a month"). The two addresses are
  page-relative, exactly as the rules advise for `fetch`: `milling/this-month.fragment.html`
  and `milling/next-month.fragment.html`, which from `/mill/` resolve to
  `https://holtfen.pages.dev/mill/milling/this-month.fragment.html` (and `next-month`). Both
  exist in `dist/` as bare `<ul>` fragments with absolute links into the site.
- **Workflow.** I added a sixth dated note and rebuilt without touching any index: the generated
  list (newest-first) and the next-month fragment both picked it up automatically, strict audit
  still passed. The test note was then removed and the final build re-run.

## What `rules.md` did not answer

**Whether a generator's output is composed like a page or shipped verbatim.** The sentence I
wanted and could not find, on line 6 — "it writes into the directory unify hands it" — stops
exactly there. Nothing distinguishes the two `milling/index.html` outcomes (a composed
document with chrome) from the fragments (verbatim copies). The dry-run report label
`← generated + _layout.html` is the only place the behavior appears, and I found it by
getting it wrong: my first generator hand-spliced the header and footer into the index, and
the build wrapped them in the layout chrome too — two mastheads, one list, a doubled title.
`unify audit` had even told me my probe page was "composed with no layout"; I read that as
"generated files never get a layout", when it really meant "my probe had no `_layout.html`
to find". Once I knew the rule, the generated index became a plain page-shaped document
that writes `/milling/…html` links and lets unify rewrite them like any other page's —
which also means the masthead and footer are maintained in one place for all nine pages
including the generated one.

## What I had to re-read, and why it didn't land

- **Lines 5–6, the generator paragraph.** First pass I read only "writes into the directory
  unify hands it, never into `site/`" and slotted it as "generated files are copied like
  assets", because everything before it in the doc treats written files as shipped-as-written
  (fragments, byte-for-byte copies). The word "never into `site/`" was doing real work —
  it implies the generated dir participates in composition — and I missed it because I was
  pattern-matching to the fragment behaviour I'd just learned.
- **Lines 33–39 ("Merging a page into its layout").** I re-read it twice; "The first
  default-content page main unwraps" only made sense once I watched the layout's `<slot>`
  eat a page's `<main>`. The head-merge rules (line 40-44) also took a second pass — my
  page heads now rely on layout's charset/viewport and only add title + description.
- **Line 12, the directory-link clause** (`/guides/` builds only when the output has a
  `guides/index.html` — "one `--pretty-urls` made"). I needed to see that a *generated*
  `milling/index.html` counts as that file, so the nav's `/milling/` link is not broken;
  confirmed when the strict audit stayed silent with the generated index in place and the
  earlier probe build *failed* the same check when the file was missing.

## What I guessed or inferred

- **The council's panel URL ends in `.fragment.html`, which contains `.html`.** The brief says
  addresses *visitors see* must not end in `.html`; I inferred that a machine endpoint the
  council's server fetches is not "seen" by visitors, since only `.fragment.html` makes unify
  ship a bare snippet, and that name is the documented convention for embeds/`fetch`. An
  extensionless copy (`site/opening-hours`, copied byte-for-byte) would also work and reads
  cleaner, but I guessed Cloudflare Pages would then serve it as `application/octet-stream`
  and the council's loader might choke on the content type — so I chose the documented path.
  Nothing in either document states the MIME rule.
- **`fetch` resolution.** "keep every fetched address relative to the page" — I inferred that
  means relative to the *served* page URL, and since home is at `/mill/`, `milling/this-month.fragment.html`
  resolves to `/mill/milling/…`. Verified by the emitted file's location, not by the doc.
- **"This month" vs "next month."** The rules say dates are never taken from the clock — but
  only about feed/schema `date:` values. For the calendar widget I inferred the generator may
  use the build clock (context gives `baseUrl`, `prettyUrls`, dates), and both fragments are
  regenerated on every build under stable names, so the addresses never change while the
  contents roll forward season to season.
- **`generate:` in `unify.yaml` resolves from the project root**, so `scripts/` can live
  "beside the site" as line 5 says, unlike `--generate`, which line 61 says resolves from the
  source root. I confirmed by running it, not by reading it — the doc states one and implies
  the other without spelling out the difference.
- The `<a class="brand" href="/index.html">` and nav targets are real filenames per line 11;
  I inferred `/index.html` (not `/`) because the doc insists you "link the real filename".
