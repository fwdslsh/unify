---
date: 2026-11-08
description: "A cold, clear milling day; the visitor book broke open at four in the afternoon."
---
# A cold, clear day

The coldest Saturday of the year so far and the clearest — you could see the wash from the gate. We dressed the sails early and ran from ten till four between customers. Two hundred pounds of wheat for the bakery in town, and they have asked for the same again when the next crop is dressed. The visitor book broke open at four and we ran out of the plain flour by half past. Rakes swept the stone floor, brake tested, cap luffed and locked. See you the first weekend of December, weather allowing.
