---
date: 2026-09-19
class: milling
author: Beatrice Achebe
description: "A midweek gale gave the mill a proper blow, and the sweeps did their job."
---
# The great wind of Michaelmas

No milling day booked, but the tower was up early with the gale and we could not let it
go to waste. Four sails canvassed and the mill ran against the wind from ten until we
took the sails off at three, out of respect for the gear-case more than the weather.

Everything that should have turned, turned. The governor balls looked like they enjoyed
themselves. One word of warning: *the weathering on the north cap joint has started to
lift* — nothing urgent, but put it on the winter list.

Ground eleven stone of barley for the farm down the causeway, which is what the mill is
for.
