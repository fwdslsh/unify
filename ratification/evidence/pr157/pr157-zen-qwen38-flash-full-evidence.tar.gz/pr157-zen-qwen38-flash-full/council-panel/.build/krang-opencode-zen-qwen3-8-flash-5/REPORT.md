# Holt Fen Windmill — build report

## Publishing

    ./unify build --clean --pretty-urls --base-url https://holtfen.pages.dev/mill/ --audit

This reads `unify.yaml` in the working directory, which carries the single line
`generate: scripts/gen.mjs` — the command above does nothing about the milling-days index;
the config names the script that runs before every build. Exit 0 means `dist/` holds the
complete site; `--audit` refuses to publish anything the standalone audit would fail.
Before the real build I ran `./unify build --dry-run --strict --pretty-urls --base-url …`
and got exit 0 with the full write-list (15 files).

Site layout (everything else in the directory — `BRIEF.md`, `rules.md`, `unify`,
`drafts/`, `scripts/`, `verify.mjs` — sits outside `site/`, so none of it can ship):

    site/_layout.html                        header (inline sails SVG), nav, footer — wraps every page
    site/index.html                          home: the mill's story + the month flip
    site/visit.html                          Visit: hours panel (included), directions + map placeholder SVG, tour prices
    site/panels/opening-hours.fragment.html  the one panel, in one place
    site/milling/*.md                        five dated volunteer notes (Markdown, no HTML, no <head>)
    site/css/site.css, site/js/month-flip.js, site/assets/sails.svg
    scripts/gen.mjs                          writes into the directory unify hands it:
                                             milling/index.html (every note, newest first),
                                             milling/this-month.fragment.html, milling/next-month.fragment.html

The council fetches **`https://holtfen.pages.dev/mill/panels/opening-hours.fragment.html`**.
`*.fragment.html` ships as written — no `<html>`/`<head>`/`<body>` ever wraps it, even under
`--pretty-urls` (verified: the fragment keeps its literal `.fragment.html` path while page
links are prettified). The path is the source path and the source file never moves, so the
address survives season after season; the panel contains no links, `src`s or `url()`s at all,
and carries its own class-prefixed `<style>` block, so the bytes render on the council's
pages with nothing to resolve. The Visit page `<include>`s the same file, so one edit of
`site/panels/opening-hours.fragment.html` updates both.

The month flip: the home page's JS fetches only on click, from the `href` of two hidden
anchors (`#this-month-src`, `#next-month-src`) — the rewrite-safe way to get an address
under the `/mill/` prefix: `https://holtfen.pages.dev/mill/milling/this-month.fragment.html`
and `…/next-month.fragment.html`. The fetched lists link to notes relative to the home page
(`milling/last-sails-of-the-year/`), because no rewriting happens inside shipped fragments.

## How I verified

No browser: `node verify.mjs` serves `dist/` at exactly `…/mill/` (a local http server that
maps only that prefix) and makes real `fetch` calls — **40 checks, 40 passed**:

- every page (`/mill/`, `/mill/visit/`, `/mill/milling/`, all five notes) → 200, sails
  header and footer present, no visible link ending `.html`;
- the council address → 200, body has zero `<html|<head|<body>`, **byte-identical** to the
  source panel, and the same hours string appears on the Visit page;
- the home page's advertised flip URLs parse to the two fragment addresses above; both
  fetch → 200 (`this-month` lists November 2026's notes, `next-month` returns the December
  "announced yet" state); a link inside the fetched fragment resolves to 200 from the home
  page;
- css/js/favicon under `/mill/` → 200; no draft strings, no `.md`, no `drafts/` or
  `scripts/` in `dist` (15 files); sitemap/canonical/og all absolute under `/mill/`;
- forgetting test: I added a sixth note, rebuilt without touching any index, and both the
  index and the this-month fragment had it. Then removed it and re-published.

## What `rules.md` did not answer

The sentence I wanted and could not find: something like *"URL attributes inside a shipped
`*.fragment.html` are/are not rewritten."* §Files says fragments ship "as written"; §Styles
says unify "rewrites only HTML's own URL attributes (`href`, `src`)". Both sentences are
true and they disagree for this one file, and the whole design (no links in the panel;
page-relative links baked by the generator into the month fragments) turns on which wins.
Experiment decided it: shipped bytes win, the included copy is rewritten separately.

Also unanswerable from the rules, and learned by probing: that a generated (overlay) page
participates in nearest-`_layout.html` wrapping, title join, and link rewriting — the rules
say a derived index "comes from a script", not that the script's output is composed like a
source page; that `--pretty-urls` leaves `.fragment.html` paths literal; the exact contract
of the generate script (the rules say only "the directory unify hands it"; the argv shape
`[sourceRoot, overlay, context.json]` and the context's `site.baseUrl/prettyUrls` fields are
help-adjacent at best); and that the inventory's `title` for a note without `title:`
frontmatter is null rather than the first heading the §Markdown promises the page itself.

## What I re-read, and why it did not land the first time

- The **Styles, scripts, finishing** paragraph, twice. The first read slid past "or read
  back from an `href` unify rewrote" because it was the tail of a sentence; it is actually
  the load-bearing trick — under `--base-url`, JS must not hard-code `/milling/…`, so the
  flip fetches an anchor's `href` instead. It only clicked when I designed the flip.
- The **Include** section, twice — "main elements stay intact and their children are not
  fills" only parsed once I'd read the Layout section's slot rules; on the first pass it
  competed for attention with "never inside `<pre>`".
- The **Files** bullets on link spelling (three sentences each carry two rules: write real
  filenames, pretty-urls rewrites them, directory links need a real `index.html`, `--base-url`
  is the whole address). I wrote `/milling/index.html` in the nav first and had to check the
  rules confirmed that spelling.
- §Markdown's sentence about `schema`/JSON-LD — it repeats "nothing is guessed" twice and
  buries that a `date` unify can't parse is dropped with a report; I re-read to be sure
  ISO dates were required for the notes' `date:`.

## What I guessed or inferred

- **The flip's month addresses** (`/mill/milling/this-month.fragment.html`) — the rules
  never say fragments are for `fetch`; §Files says "for `<include>`, embeds, or
  `fetch`/`hx-get`" — that sentence did land, but the hidden-anchor pattern is my inference.
- **"This month" means at build time** — the generator uses the build clock (UTC); "the
  address must keep working season after season" implies rebuilds per season; nothing says
  so, and a future-dated note would still land in `this-month`, which I judged better than
  baking month names into URLs that would rot.
- **The council will fetch that fixed URL over HTTPS with the `/mill/` prefix** — the brief
  gives the site address but not the council's exact URL; the panel's address is a design
  choice I'm stating for them.
- **"Plain HTML and CSS you write yourself"** still allows ~20 lines of my own JavaScript
  for the flip (the brief demands no-reload fetches; §Styles mentions fetched addresses
  approvingly). No third-party files are loaded.
- **Volunteers' frontmatter** (`date`, `author`, `description`; title as the first `#`
  heading, no `title:` key): the rules bless these as keys; how volunteers choose to write
  them I invented, and the generator tolerates missing dates.
- That `--clean` belongs in the publish line (keeps `dist/` truthful to this build) and that
  a `description` should be per-page, not in the layout (the audit's `description-duplicate`
  advisory inferred that; the rules only say the layout head is a "base").
- The winter-hours panel content (Nov–Mar closed) is mine — `drafts/winter-hours.md` is
  explicitly unagreed, so it was neither published nor consulted, only confirmed absent
  from `dist`.
