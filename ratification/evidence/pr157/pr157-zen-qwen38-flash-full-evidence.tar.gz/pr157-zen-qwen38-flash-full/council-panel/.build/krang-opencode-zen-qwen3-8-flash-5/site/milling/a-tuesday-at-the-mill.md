---
date: 2026-11-03
class: milling
author: Tilly Vance
description: "A Tuesday group day: two school classes and a threshing-bin lesson."
---
# A Tuesday at the mill

Weekday visit by arrangement: Year 5 and Year 6 from the village school, forty children
split over two hours. The wind held, one pair of stones ran, and the children ground a
peck of barley between them and took it home in paper sacks.

Notes for the next group day:

1. The stair is too narrow for two lines; one way up, one way down works but needs a
   steward on the stone deck.
2. The striker on the left stone wants packing.
3. One child recited the sail numbers off the notice in the yard, in order, without
   being taught.

We had tea on the yard at half past four and the mill looked very pleased with itself.
