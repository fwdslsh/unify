---
date: 2026-08-15
class: milling
author: Walter Pocock
description: "First Saturday of the harvest run; the wind failed by afternoon."
---
# Harvest run, first Saturday

Ground eighty stone of wheat between ten and four. The wind was steady until half past
two, then dropped so we finished the last bin by hand crank, which nobody is too young
for but nobody should have to do twice in one afternoon.

- Brake band needs a new bolt before the next run.
- The dresser threw flour over the stairs again. I have said it before.

Tea on the yard at five. Six visitors watched the sack hoist work and were properly
impressed.
