const src = {
  this: document.getElementById("this-month-src").href,
  next: document.getElementById("next-month-src").href,
};
const out = document.getElementById("month-days");
const buttons = Array.from(document.querySelectorAll(".month-flip button"));

async function show(which) {
  for (const b of buttons) b.setAttribute("aria-pressed", String(b.dataset.month === which));
  out.textContent = "Loading…";
  try {
    const res = await fetch(src[which]);
    if (!res.ok) throw new Error(String(res.status));
    out.innerHTML = await res.text();
  } catch (err) {
    out.textContent = "The milling days could not be loaded just now — please ask at the door.";
  }
}

for (const b of buttons) b.addEventListener("click", () => show(b.dataset.month));
