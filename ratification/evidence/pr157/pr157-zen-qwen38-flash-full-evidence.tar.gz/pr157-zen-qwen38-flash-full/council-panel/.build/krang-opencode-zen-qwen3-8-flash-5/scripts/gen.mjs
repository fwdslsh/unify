import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join, dirname } from "node:path";

const [,, sourceRoot, overlay, ctxPath] = process.argv;
const ctx = JSON.parse(readFileSync(ctxPath, "utf8"));
const inventory = JSON.parse(readFileSync(ctx.inputs.sourcePages, "utf8"));
const pretty = ctx.site.prettyUrls === true;

const notes = inventory.pages
  .filter(p => /^milling\//.test(p.source) && /\.md$/.test(p.source))
  .map(p => {
    let title = p.title;
    if (!title) {
      const body = readFileSync(join(sourceRoot, p.source), "utf8");
      const h1 = body.match(/^#\s+(.+?)\s*$/m);
      if (h1) title = h1[1];
    }
    return {
      ...p,
      title,
      dateObj: /^\d{4}-\d{2}-\d{2}$/.test(p.date || "") ? new Date(p.date + "T00:00:00Z") : null,
    };
  })
  .sort((a, b) => (b.dateObj?.getTime() ?? 0) - (a.dateObj?.getTime() ?? 0)
    || a.source.localeCompare(b.source));

const esc = s => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const fmtDate = iso => new Intl.DateTimeFormat("en-GB", {
  weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "UTC",
}).format(new Date(iso + "T00:00:00Z"));
const label = ym => new Intl.DateTimeFormat("en-GB", { month: "long", year: "numeric", timeZone: "UTC" })
  .format(new Date(ym + "-01T00:00:00Z"));

// The index page — a complete document; the layout supplies the chrome,
// and hrefs written in source form (/milling/x.html) are rewritten by the build.
const items = notes.map(n => `
    <li>
      <a href="${esc(n.href)}">${esc(n.title ?? n.source)}</a>
      ${n.date ? `<time datetime="${n.date}">${fmtDate(n.date)}</time>` : ""}
      ${n.description ? `<p>${esc(n.description)}</p>` : ""}
    </li>`).join("");

const indexPage = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Milling days</title>
<meta name="description" content="Notes from the volunteers, newest first, written on the days the mill runs.">
</head>
<body class="milling">
<main>
<h1>Milling days</h1>
<p>Notes written by the volunteers on the days the mill ran, newest first. This list is
built by itself whenever the site is built — nobody has to remember to update it.</p>
<ul class="note-list">${items}
</ul>
</main>
</body>
</html>
`;

// The two month fragments ship as written (no rewriting happens inside a
// *.fragment.html), so their links are already in the final page-relative form.
function monthFragment(ym) {
  const inMonth = notes.filter(n => n.date && n.date.startsWith(ym));
  if (inMonth.length === 0) {
    return `<p class="hf-none">No milling days announced for ${label(ym)} yet.</p>\n`;
  }
  const rows = inMonth.map(n => {
    const rel = pretty ? n.href.replace(/^\//, "").replace(/\.html$/, "/") : n.href.replace(/^\//, "");
    return `  <li><a href="${esc(rel)}">${esc(n.title ?? n.source)}</a> <time datetime="${n.date}">${fmtDate(n.date)}</time></li>`;
  }).join("\n");
  return `<h2>Milling days, ${label(ym)}</h2>\n<ul class="hf-month">\n${rows}\n</ul>\n`;
}

const now = new Date();
const ym = (y, m) => `${y}-${String(m + 1).padStart(2, "0")}`;
const thisMonth = ym(now.getUTCFullYear(), now.getUTCMonth());
const nextDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));
const nextMonth = ym(nextDate.getUTCFullYear(), nextDate.getUTCMonth());

for (const [name, content] of [
  ["milling/index.html", indexPage],
  ["milling/this-month.fragment.html", monthFragment(thisMonth)],
  ["milling/next-month.fragment.html", monthFragment(nextMonth)],
]) {
  const dest = join(overlay, name);
  mkdirSync(dirname(dest), { recursive: true });
  writeFileSync(dest, content);
}
