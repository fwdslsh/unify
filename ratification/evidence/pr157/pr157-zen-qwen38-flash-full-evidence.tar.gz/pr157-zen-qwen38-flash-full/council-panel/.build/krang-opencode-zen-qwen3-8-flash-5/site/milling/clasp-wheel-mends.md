---
date: 2026-10-24
class: milling
author: Beatrice Achebe
description: "Lifting the clasp wheel back onto its axle after a week of splicing."
---
# The clasp wheel mends

We lifted the clasp wheel back onto its axle today, and it sat down as if it had never
left. That is the splicing finished — the hoop will not show a light gap for another ten
years at this rate.

Because the wheel was off, the last two milling days went with one pair of stones only,
and we told people honestly at the door. Nobody minded. The queue for the stair was to
the gate by two, and Tom says we have out-toured the café.

Grinding done: nine stone of rye, two of maslin. The rye came out fine as flour and the
stones sounded happy by four o'clock, which was the point of the day.
