import { createServer } from "node:http";
import { readFileSync } from "node:fs";
import { join } from "node:path";

const DIST = "/tmp/sandbox/dist";
const BASE = "/mill/";

const server = createServer((req, res) => {
  const url = decodeURIComponent(req.url.split("?")[0]);
  if (!url.startsWith(BASE)) { res.writeHead(404); res.end("off-mill"); return; }
  const rel = url.slice(BASE.length);
  const p = rel === "" || rel.endsWith("/") ? join(DIST, rel, "index.html") : join(DIST, rel);
  let body;
  try { body = readFileSync(p); } catch { res.writeHead(404); res.end("not found"); return; }
  const type = p.endsWith(".css") ? "text/css" : p.endsWith(".js") ? "text/javascript"
    : p.endsWith(".svg") ? "image/svg+xml" : p.endsWith(".xml") ? "application/xml" : "text/html";
  res.writeHead(200, { "content-type": type });
  res.end(body);
});

let pass = 0, fail = 0;
const check = (name, ok, detail = "") => {
  if (ok) { pass++; console.log("PASS", name, detail ? `(${detail})` : ""); }
  else { fail++; console.log("FAIL", name, detail); }
};
const get = async path => {
  const r = await fetch("http://127.0.0.1:8123" + path);
  return { status: r.status, text: await r.text() };
};

await new Promise(r => server.listen(8123, r));

const pages = ["/mill/", "/mill/visit/", "/mill/milling/",
  "/mill/milling/last-sails-of-the-year/", "/mill/milling/a-tuesday-at-the-mill/",
  "/mill/milling/clasp-wheel-mends/", "/mill/milling/great-wind-michaelmas/",
  "/mill/milling/harvest-first-saturday/"];
const fetched = {};
for (const p of pages) fetched[p] = await get(p);

for (const p of pages) {
  const r = fetched[p];
  check("page 200 " + p, r.status === 200);
  check("chrome on " + p, r.text.includes("Holt Fen Windmill") && r.text.includes("registered charity")
    && r.text.includes('class="sails"'), "sails header + footer");
  check("no .html page links on " + p,
    !/["]\/mill\/[^"]*\.html"/.test(r.text.replace(/\.fragment\.html/g, "")));
}

// council panel: fixed address, bare markup, unchanged bytes
const frag = await get("/mill/panels/opening-hours.fragment.html");
check("council address 200", frag.status === 200);
check("council markup is bare", !/<(html|head|body)\b/i.test(frag.text));
check("council bytes match source",
  readFileSync("/tmp/sandbox/site/panels/opening-hours.fragment.html", "utf8") === frag.text);
check("panel is one source, on Visit too",
  fetched["/mill/visit/"].text.includes("10:30 to 16:00 (mill floor closes 15:30)"));

// home month flip: fetch exactly the URLs the page advertises
const home = fetched["/mill/"];
const hrefOf = id => (home.text.match(new RegExp(`id="${id}-src" href="([^"]+)"`) ?? []) || [])[1];
const thisHref = hrefOf("this-month"), nextHref = hrefOf("next-month");
check("home advertises this-month address", thisHref === "/mill/milling/this-month.fragment.html", String(thisHref));
check("home advertises next-month address", nextHref === "/mill/milling/next-month.fragment.html", String(nextHref));
const tm = await get(thisHref), nm = await get(nextHref);
check("this-month fetch 200 + lists Nov days", tm.status === 200 && tm.text.includes("November 2026")
  && tm.text.includes("Last canvas before winter"));
check("next-month fetch 200 + announced state", nm.status === 200 && nm.text.includes("December 2026"));
const rel = tm.text.match(/href="([^"]+)"/)[1];
check("fragment links resolve from home", (await get("/mill/" + rel)).status === 200, rel);

// assets fetched by every page
for (const a of ["/mill/css/site.css", "/mill/js/month-flip.js", "/mill/assets/sails.svg"])
  check("asset 200 " + a, (await get(a)).status === 200);

// privacy, freshness, portability
const allHtml = Object.values(fetched).map(r => r.text).join("");
check("no drafts in site", !/winter hours|not for publication|DRAFT/i.test(allHtml));
check("no root-relative url() in css", !/url\(["']?\//.test(readFileSync(join(DIST, "css/site.css"), "utf8")));
const dates = (fetched["/mill/milling/"].text.match(/datetime="[\d-]+"/g) ?? []);
check("index has all five notes, newest first",
  dates.length === 5 && dates[0] === 'datetime="2026-11-07"' && dates[4] === 'datetime="2026-08-15"');
const sitemap = (await get("/mill/sitemap.xml")).text;
check("sitemap under /mill/", sitemap.includes("https://holtfen.pages.dev/mill/visit/"));

server.close();
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
