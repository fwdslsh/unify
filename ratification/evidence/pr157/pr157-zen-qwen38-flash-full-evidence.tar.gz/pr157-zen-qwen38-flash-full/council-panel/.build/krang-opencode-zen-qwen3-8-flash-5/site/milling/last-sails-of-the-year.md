---
date: 2026-11-07
class: milling
author: Walter Pocock
description: "Last milling Saturday before the sails come in for the winter works."
---
# Last canvas before winter

Saturday and the sails up for the final run of the season. Twelve stone of wheat and
what the miller called *a fair day's noise*: both stones in gear, the hoist singing,
the brake smelling of hot hemp.

We struck canvas at four and weathered the cap for the winter. The sails come down in
December for the second spur wheel, and the yard will look bare without them — but that
is a job for the winter list, not for this note.

Thank you to everyone who came out in the wind this year. The first Saturday in January
will find the sails up and the oil cans full.
