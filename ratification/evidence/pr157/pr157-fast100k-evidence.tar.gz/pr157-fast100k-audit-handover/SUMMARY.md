# Ratification round pr157-fast100k-audit-handover

- **unify** 0.11.18 at `b61dcfe5ee78` (working tree)
- **rules** `fb07d931bd36` · **prompt** `456131468750` · **agent** opencode 1.18.25 · **models** krang/local/fast · **isolation** mount namespace, probe clean
- 2026-11-09T02:57:37.716Z to 2026-11-09T03:03:15.713Z; scored 2026-11-09T03:03:15.714Z

## Score

**1 of 1 samples completed their brief: every scored check passed (100%).**

The protocol's bar, at least 4 of 5 samples of a model on each brief: not measured: the bar needs at least 5 samples per brief and model, so this score is indicative.

| Brief | Model | Passed | Checks that failed |
|---|---|---|---|
| audit-handover | krang/local/fast | 1/1 | — |

## audit-handover — Hand over only when every check the tool offers reports nothing

*round 28; checks follow its pre-registered V1-V4, plus the brief's extensionless addresses.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | audit-strict | article-data | share-cards | ran-audit | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-local-fast-1 | 5m38s | 101 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |

- krang-local-fast-1 · **ran-audit** (not scored): 6 runs matching /unify audit/

What the agents said the rules did not answer:

**krang-local-fast-1**

> ## What did `rules.md` not answer?
> 
> **The sentence I wanted and could not find:** How does the build handle `<slot>` inside a layout's `<head>` versus `<body>`. The rules say "a page contributes its own `<head>` and the two are merged (§8)" — but §8 is referenced in the text as an inline reference that doesn't exist as a section. I had to re-read this sentence three times: *"the layout's is the base, and where both declare `<meta charset>` the layout's wins"* (from rules line 36) before it landed that head elements are merged rather than replaced.
> 
> **What I guessed:** Whether `og:image` in frontmatter emits `property="og:image"` or `name="og:image"`. The rules say "A key named `og:…` emits `property=` instead", which clarified this, but the sentence is buried inside a long paragraph on line 49 — I had to re-read it because I expected JSON-LD-style keys (`ogImage`, camelCase) rather than YAML frontmatter conventions.
> 
> **What I inferred:** That `<slot></slot>` in the layout's head was unnecessary since page heads are merged, not inherited. The rules only explain body-slot merging in detail (sections 5-8 of the implied structure), leaving head-merging as a single sentence that I had to trust on first read and then verify through failed builds.
> 
> **What I guessed or inferred rather than read:** That `schema: BlogPosting` would auto-generate JSON-LD including author, datePublished, and headline — the rules mention these fields in the schema generation paragraph but don't explicitly list them as auto-populated; I had to infer from "from what the page already declares" that all those values flow through automatically.


---

`✓` passed, `✗` failed, `(i)` reported but not scored. Each sample's directory is `<brief>/<sample>/`, its OpenCode event stream and session data are in `<brief>/.harness/<sample>/`, and the build the checks read is `<brief>/.build/<sample>/`. Triage every failure with ratification/ratification-protocol.md before changing anything.
