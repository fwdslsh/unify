# Report — Fernway Seed Library site

## Publish command line

```bash
./unify build --pretty-urls --base-url https://fernway.example/library/
```

## Check outputs

**Build (exit 0)**: `./unify build --pretty-urls --base-url https://fernway.example/library/`

```
BUILD EXIT: 0
```

**Audit strict (nothing to report, exit 0)**: `./unify audit --strict`

```
audit: nothing to report
AUDIT EXIT: 0
```

**Dry-run + strict (exit 0)**: `./unify build --pretty-urls --base-url https://fernway.example/library/ --clean --dry-run --strict`

```
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 3 pages would gain a JSON-LD block
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
copy dist/images/card.svg (/library/images/card.svg) ← images/card.svg
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/cosmos-from-saved-seed/index.html (/library/notes/cosmos-from-saved-seed/) ← notes/cosmos-from-saved-seed.md + _layout.html
write dist/notes/index.html (/library/notes/) ← notes/index.html + _layout.html
write dist/notes/saving-bean-seed/index.html (/library/notes/saving-bean-seed/) ← notes/saving-bean-seed.md + _layout.html
write dist/notes/tomato-swap/index.html (/library/notes/tomato-swap/) ← notes/tomato-swap.md + _layout.html
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
copy dist/style.css (/library/style.css) ← style.css
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 10 files to dist/
DRY-RUN STRICT EXIT: 0
```

## What did `rules.md` not answer?

**The sentence I wanted and could not find:** How does the build handle `<slot>` inside a layout's `<head>` versus `<body>`. The rules say "a page contributes its own `<head>` and the two are merged (§8)" — but §8 is referenced in the text as an inline reference that doesn't exist as a section. I had to re-read this sentence three times: *"the layout's is the base, and where both declare `<meta charset>` the layout's wins"* (from rules line 36) before it landed that head elements are merged rather than replaced.

**What I guessed:** Whether `og:image` in frontmatter emits `property="og:image"` or `name="og:image"`. The rules say "A key named `og:…` emits `property=` instead", which clarified this, but the sentence is buried inside a long paragraph on line 49 — I had to re-read it because I expected JSON-LD-style keys (`ogImage`, camelCase) rather than YAML frontmatter conventions.

**What I inferred:** That `<slot></slot>` in the layout's head was unnecessary since page heads are merged, not inherited. The rules only explain body-slot merging in detail (sections 5-8 of the implied structure), leaving head-merging as a single sentence that I had to trust on first read and then verify through failed builds.

**What I guessed or inferred rather than read:** That `schema: BlogPosting` would auto-generate JSON-LD including author, datePublished, and headline — the rules mention these fields in the schema generation paragraph but don't explicitly list them as auto-populated; I had to infer from "from what the page already declares" that all those values flow through automatically.
