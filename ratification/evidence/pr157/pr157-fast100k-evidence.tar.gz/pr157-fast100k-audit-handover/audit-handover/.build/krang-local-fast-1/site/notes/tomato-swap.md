---
title: The Great Tomato Seed Swap at Fernway
date: 2025-09-10T09:00:00Z
author: Anne-Marie Voss
description: In August we hosted our first seed swap — growers brought back what they'd saved and traded. Five varieties came together, and the conversations were as rich as the seed itself.
layout: /_layout.html
schema: BlogPosting
og:image: /images/card.svg
og:image:width: 1200
og:image:height: 630
---

# The Great Tomato Seed Swap at Fernway

In mid-August the Fernway Seed Library hosted its very first seed swap — a small gathering in the community garden where we brought back whatever seed each of us had saved, and traded as we pleased. It was a lovely day, and I want to write down what happened while it is still fresh.

## Five varieties came together

We ended up with five tomato varieties represented:

- **Black Krim** — a dark, rich variety that keeps its seed well if you scoop the gel rather than scrape dry.
- **Sungold cherry** — surprisingly easy to save; I got about forty seeds from one fruit.
- **Green Zebra** — my first time saving these; the seed extraction was messier than expected but the germination rate looks good in the trays now.
- **Brandywine** — everyone wanted Brandywine seed. It is a big favourite and I brought extra to share with three people who didn't have any saved yet.
- **Marmande** — a late-season French heirloom that came from two growers each bringing their own selection.

## How the swap went

We laid everything on a long table, numbered each type by variety name, and then everyone had a small sheet of paper to write down what they wanted to take and trade for. It was less formal than I expected, which felt right. No pressure, no judging — just seeds passing hand to hand and people talking about how each one grew in their garden that season.

## What I took home

I left with Green Zebra seed (to try a different selection of the same type) and Sungold from a grower three streets away whose fruit was even smaller than mine — clearly selected for size over flavour, which is exactly what you want in cherry tomatoes. We will see how it goes next spring when I sow them into trays.
