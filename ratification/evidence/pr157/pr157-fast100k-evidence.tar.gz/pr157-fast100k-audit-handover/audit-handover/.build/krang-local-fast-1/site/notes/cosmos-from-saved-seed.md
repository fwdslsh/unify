---
title: Cosmos from Saved Seed — Third Year Running
date: 2025-09-28T09:00:00Z
author: Tom Bradley
description: Third year now growing cosmos I saved from the library's packet. The colours are getting deeper, and the bees seem to prefer them even more than store-bought seed. A note on thinning and spacing too.
layout: /_layout.html
schema: BlogPosting
og:image: /images/card.svg
og:image:width: 1200
og:image:height: 630
---

# Cosmos from Saved Seed — Third Year Running

It is my third year growing cosmos I saved from a Fernway Seed Library packet, and I keep coming back to them because they are generous with flowers and honest about seed. Here are some observations after three rounds of borrow–grow–return.

## What has changed across the years

In my first season the blooms were bright but sparse — mostly pale pink and one white. The second year I saved seed from a denser patch, and those plants came in stronger. This year's seed came back deeper crimson than anything I'd seen before. It seems like saving seed year after year is slowly selecting for colour intensity in this garden microclimate.

## Thinning tips

I used to plant cosmos thickly — every other inch or so — and wonder why they were leggy. The answer is simple: thin them early. Once the second set of true leaves appears, I space them 30 cm apart. Give or take. Cosmos like their roots to spread a bit, and air flowing between stems keeps powdery mildew at bay later in summer.

## Bee notes

The honey bees on cosmos are something else. Last June I sat on the garden bench for twenty minutes watching them land on individual flower heads — they were clearly choosing deeper colours over paler ones. I haven't done a formal study, but it was striking enough to mention here. If anyone has a bee-friendly planting plan, I would love to trade notes at Fernway next visit.
