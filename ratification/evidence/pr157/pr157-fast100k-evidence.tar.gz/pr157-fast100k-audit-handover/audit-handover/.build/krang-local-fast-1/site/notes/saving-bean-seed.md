---
title: "Saving Bean Seed: What Worked and What Didn't"
date: 2025-10-15T09:00:00Z
author: Maria Chen
description: "Last season I borrowed bush bean seeds from Fernway. This year's return had a mix — some pods were clean, others needed more drying. Here is what I learned about moisture, colour sorting, and why patience matters."
layout: /_layout.html
schema: BlogPosting
og:image: /images/card.svg
og:image:width: 1200
og:image:height: 630
---

# Saving Bean Seed: What Worked and What Didn't

Last season I borrowed a packet of **Provider bush bean** seeds from the Fernway Seed Library. By September I had more pods than I knew what to do with — and that was exactly the point. This is my report on saving them for return in October.

## Timing matters

You want beans that are fully dry on the vine. Green, fleshy pods won't work. Wait until the pod shell is brown and brittle, and if you shake it and hear the seeds rattling inside — that is your signal.

## Drying and threshing

I spread the pods on a mesh rack for two more weeks after picking them in. A dehumidifier in the garage helped; without one the seed would have moulded inside the pod. Once dry, I crushed each pod between my palms over a large bowl. The bean seeds fell right out — they are the easiest seed to save by far.

## Sorting and storage

I floated the seeds in water and removed anything that was shrivelled or light-coloured. What stayed at the bottom were plump and healthy. I labelled a paper envelope with the variety, my name, and today's date. Paper is important — plastic traps moisture.

## Returning

The library asked for seed returned by 6 November in labelled envelopes. I brought three small bags this year: two with Provider beans and one with an older local bean we tried for the first time. The varieties that didn't save cleanly will need a different approach next season.

If you are saving bean seed for the first time, start with dry beans — they are forgiving and hardy. Snap peas work too. Wet beans (like snap or green shell) are trickier but rewarding once you get the hang of it.
