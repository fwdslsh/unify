# Ratification round pr157-qwen-fragment-audit-rescore

- **unify** 0.11.18 at `f5bf8e9b6ab2` (commit)
- **rules** `fb07d931bd36` · **prompt** `456131468750` · **agent** opencode 1.18.25 · **models** krang/opencode-zen/qwen3.8-flash · **isolation** mount namespace, probe clean
- 2026-11-09T01:39:47.851840+00:00; scored 2026-11-09T01:42:06.257Z

## Score

**33 of 35 samples completed their brief: every scored check passed (94%).**

The protocol's bar, at least 4 of 5 samples of a model on each brief: **met**.

| Brief | Model | Passed | Checks that failed |
|---|---|---|---|
| audit-handover | krang/opencode-zen/qwen3.8-flash | 5/5 | — |
| callouts | krang/opencode-zen/qwen3.8-flash | 5/5 | — |
| council-panel | krang/opencode-zen/qwen3.8-flash | 5/5 | — |
| photo-banners | krang/opencode-zen/qwen3.8-flash | 5/5 | — |
| publishing | krang/opencode-zen/qwen3.8-flash | 4/5 | agent-finished (1) |
| seed-catalogue | krang/opencode-zen/qwen3.8-flash | 5/5 | — |
| svelte-estimator | krang/opencode-zen/qwen3.8-flash | 4/5 | strict-build (1), fresh-build (1), addresses (1), drafts-unpublished (1) |

## audit-handover — Hand over only when every check the tool offers reports nothing

*round 28; checks follow its pre-registered V1-V4, plus the brief's extensionless addresses.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | audit-strict | article-data | share-cards | ran-audit | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 10m11s | 49 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | 6m22s | 46 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-3 | 6m35s | 55 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-4 | 6m23s | 42 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-5 | 5m22s | 45 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |

- krang-opencode-zen-qwen3-8-flash-1 · **ran-audit** (not scored): 9 runs matching /unify audit/
- krang-opencode-zen-qwen3-8-flash-2 · **ran-audit** (not scored): 7 runs matching /unify audit/
- krang-opencode-zen-qwen3-8-flash-3 · **ran-audit** (not scored): 9 runs matching /unify audit/
- krang-opencode-zen-qwen3-8-flash-4 · **ran-audit** (not scored): 7 runs matching /unify audit/
- krang-opencode-zen-qwen3-8-flash-5 · **ran-audit** (not scored): 7 runs matching /unify audit/

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> **What `rules.md` did not answer — the sentence I wanted.** It never documents
> `unify audit` at all: no sentence like "the checks beyond the build are `unify audit`, whose
> non-blocking findings — advisories and `incomplete` — only fail the exit code under
> `--strict`, and whose `--external` check fetches off-origin URLs." The brief demands
> every check including the non-blocking ones, and rules.md's only mention of checks is the
> one line about `build --dry-run --strict`. I found audit from `./unify --help`, and the
> convention (`build --audit --strict` before publishing) from the `unify init` scaffold's
> own README.md and DEPLOY.md. Second gap: how a `generate:` script is run. The sentence I
> wanted was "unify hands it argv[2] the source root, argv[3] an overlay directory whose
> files join the build as ordinary pages, and argv[4] generator-context.json, which names
> source-pages.json." rules.md says only "it writes into the directory unify hands it" —
> what that directory is, and the whole shape of source-pages.json, are absent; I took them

**krang-opencode-zen-qwen3-8-flash-2**

> ## What `rules.md` did not answer
> 
> The generate-script calling contract. The sentence I wanted — and could not find — is
> "unify runs the script with the generated directory as argv[3] and the path of a
> generator-context file as argv[4]". The docs only say the script "writes into the directory
> unify hands it"; *how* it is handed that directory, and where `source-pages.json` lives, are
> nowhere stated. I discovered the argv order and the context JSON (which contains
> `inputs.sourcePages`) by running a probe script that dumped `process.argv`, `process.cwd()`,
> and the context file. Related gaps: nothing says `unify audit` refuses a saved `clean:`
> config key (it errored `exit=2` until I removed it), and nothing warns that
> `build --dry-run --strict` passes while `audit --strict` fails — dry-run did not report the
> image-dimension incompletes, so relying on it alone would have shipped a rejected site.

**krang-opencode-zen-qwen3-8-flash-3**

> **What `rules.md` did not answer — the sentence I wanted and could not find.**
> Nothing in the file tells you how a generator is actually invoked. The sentence I kept
> looking for was some form of *"unify runs it as `node gen.mjs <sourceRoot> <generatedRoot> <context.json>`"*:
> "it writes into the directory unify hands it" never names the handoff — the generated
> root arrives as `argv[3]` and the pointer to `source-pages.json` sits in a context JSON
> (`argv[4]` → `inputs.sourcePages`). I instrumented a probe script and read the printed
> argv to find this. Two more missing sentences: whether `generate:` in `unify.yaml`
> resolves relative to the yaml (it does) or the source root like the `--generate` flag
> (it doesn't — that looked for `site/scripts/` and failed); and whether the inventory's
> "authored title" includes a Markdown page's heading-derived title — it doesn't
> (`title: null`), so the posts keep both a `title:` key *and* an `<h1>` heading, which
> the prose neither requires nor forbids.

**krang-opencode-zen-qwen3-8-flash-4**

> **What `rules.md` did not answer — the sentence I wanted and could not find.**
> There is no sentence describing the generator script's calling contract. `rules.md` says only that the script "writes into the directory unify hands it" — it never says *how* it is handed that directory. I had to write a probe script and print `process.argv` to discover it is invoked as `node gen.mjs <sourceRoot> <generatedOverlayDir> <contextJsonPath>`, and find `ctx.inputs.sourcePages` inside that JSON to read the page inventory. Related gaps:
> - Nothing lists what the checks look for. "Every check the tool offers" was clear (`audit`, `--strict`, `--external`, `build --dry-run --strict`, from `./unify --help`), but rules.md never mentions `h1-missing`, `image-missing-dimensions`, or the `incomplete`/`broken` categories at all — I learned them only by running `audit --strict` and being told.
> - Nothing says whether files written into the generated overlay are still wrapped by the site's `_layout.html` (they are — confirmed in output), and whether a generated `.md` may use frontmatter (it may).
> - Nothing states which options `--save-config` treats as saveable; I inferred baseUrl/pretty-urls/generate from the one-line it echoed.
> 
> **What I had to re-read, and why it did not land the first time.**
> The Files section bullet — one unbroken paragraph mixing source-root resolution, `.fragment.html`, byte-for-byte copying, link spelling under `--pretty-urls` ("write `/about.html`, the build rewrites to `/about/`"), directory links, and `--base-url`. It didn't land because the key rule (always author the `.html` filename, even under pretty-urls) is the *middle* sentence of a seven-sentence paragraph; I had to re-read to be sure the post links in the generated index use `/notes/xxx.html` while the served URLs are pretty. Same for the schema/Markdown paragraph: the rule "a `date` unify cannot read as `2026-01-02` or `2026-01-02T09:30:00Z` is left out and reported" sits at its end — I first wrote quoted dates without checking the exact accepted formats, and the earlier feed sentence ("a `date:` with no time is … reported and left out") only made sense on a second pass. The Head bullet's override order (page `<meta>` replaces layout's same-name; `og:` defaults to final title/description/canonical) also took a second read to see that I only needed `og:image*` per post and no hand-written `og:title`.
> 
> **What I guessed or inferred rather than read.**
> - The generator's argv/context contract — inferred by probing (see above); rules.md documents none of it.
> - That the generator's output md should declare `layout: /_layout.html` rather than rely on nearest-layout discovery across the overlay — a guess; the dry-run shows it resolved.

**krang-opencode-zen-qwen3-8-flash-5**

> ## What `rules.md` did not answer
> 
> **The sentence I wanted most and could not find:** something like *"unify runs the
> generate script with three arguments — the source root, the generated overlay
> directory it may write into, and a JSON context file naming `inputs.sourcePages`"* .
> `rules.md` only says the script "writes into the directory unify hands it" without
> ever saying **how the directory is handed over** (argv? env? cwd?), nor that the
> hand-written script receives the pages' titles/dates via the source inventory. I
> found the contract by making `scripts/gen.mjs` print `process.argv`, `process.cwd()`
> and a directory listing during a dry-run build. Even the inventory itself
> (`--source-inventory`, "on by default with `--generate`") exists only in `--help`,
> not in `rules.md` at all.


## callouts — One equipment callout in ten places with different words, its border changed in one file

*round 26, the slotted-include ship condition (conformance spec §32.7).*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-unpublished | no-slot-shipped | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 6m43s | 53 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | 8m57s | 94 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-3 | 8m43s | 41 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-4 | 8m56s | 49 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-5 | 5m57s | 38 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> ## 1. What `rules.md` did not answer
> 
> The sentence I wanted and could not find: *what the `generate` script is passed.*
> Line 6 says the script "writes into the directory unify hands it" and nothing names
> the hand. I had to run the script printing `process.argv` to learn it is handed
> `(sourceRoot, generatedOverlay, contextJsonPath)`, and find the context JSON's
> `inputs.sourcePages` path (the inventory file) there — `--help` names the inventory
> but not these. Related: nothing states that **generated overlay files get the same
> layout merging, link rewriting and `--pretty-urls` treatment as source pages**; I
> observed `← generated + _layout.html` in the dry-run listing and trusted it after
> that.

**krang-opencode-zen-qwen3-8-flash-2**

> **1. What rules.md did not answer.** The sentence I wanted and could not find: what
> arguments and what environment a generator script is actually run with. rules.md says
> "unify runs it before every build and it writes into the directory unify hands it" — it
> never says how that directory is handed to the script (argv? env var?). I had to
> print `process.argv` and `generator-context.json` from a throwaway script to learn the
> contract: `argv[2..4] = sourceRoot, overlay, contextPath`, plus `--source-inventory`'s
> JSON path. rules.md also never says generated overlay files are treated as source pages
> (i.e. that a `<include>` or `data-layout` inside them is processed); I inferred it from a
> probe and confirmed it by grepping the built output. And it never says the source-pages
> inventory reports `title: null` for a Markdown page whose title comes from its first `#`
> heading — the "no `title:` → first `# Heading`" rule applies to the rendered page, not to
> the inventory I feed `gen.mjs`, which I discovered only when the built log index listed

**krang-opencode-zen-qwen3-8-flash-3**

> ## 1. What `rules.md` did not answer
> 
> The interface of the `generate` script. "unify runs it before every build and it writes into the
> directory unify hands it" — the sentence I wanted and could not find is: *"your script is invoked
> with the source root, the generated-overlay directory, and a JSON context file as argv 2–4"* (and
> what is inside that context). The CLI help adds that the script gets `source-pages.json`, but
> neither says the overlay is a first-class source. I probed with a throwaway site and found argv =
> `[unify, script, sourceRoot, overlay, generator-context.json]`, the context carrying `baseUrl`,
> `prettyUrls`, `outputRoot`, `inputs.sourcePages` — and, crucially, that files written into the
> overlay behave like real pages (they get the nearest `_layout.html`, title joining, and the
> `--base-url`/`--pretty-urls` link rewrites).

**krang-opencode-zen-qwen3-8-flash-4**

> ## What `rules.md` did not answer — the sentence I wanted and could not find
> 
> The generator contract. The one relevant sentence is "unify runs it before every build and it
> writes into the directory unify hands it, never into `site/`" — but nowhere does it say *how*
> the directory is handed. I wanted: "your script is called as
> `gen.mjs <sourceRoot> <generatedRoot> <context.json>`" — that is what the probe of argv
> showed, plus the context naming `inputs.sourcePages`. Also never stated: the shape of
> `source-pages.json` (I dumped one and read it), whether a page written into the generated
> overlay is wrapped by the site's `_layout.html` like an authored page (it is), and whether
> `--generate` (help: "a relative path is from the source root") and the yaml key `generate:`
> resolve from the same base — they do not: the yaml path resolves from the working directory,
> which is the only reading that makes "kept in `scripts/` beside the site" true. Nothing says

**krang-opencode-zen-qwen3-8-flash-5**

> ## 1. What `rules.md` did not answer
> 
> The generate-script contract. The sentence I wanted and could not find: **"unify invokes
> your script with `argv = [node, script, sourceRoot, generatedRoot, contextJsonPath]`"**
> (or anything like it). rules.md says only that the script "writes into the directory unify
> hands it" — it never says *how* the directory is handed: argv, an env var, the cwd? I had
> to write a probe script that dumped `process.argv` and a `generator-context.json` to learn
> the three positional arguments and the `inputs.sourcePages` inventory path. Nothing in the
> docs says the generated files are then treated as source pages, nor that they get wrapped
> by the site's `_layout.html` — I inferred both from the build report (`log/index.html
> ← generated + _layout.html`).


## council-panel — A bare opening-hours panel another site fetches, kept in one place, and month lists fetched on demand

*round 23, the first exposure of *.fragment.html.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-unpublished | bare-fragment | fetch-targets | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 7m52s | 52 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | 7m11s | 36 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-3 | 6m27s | 35 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-4 | 10m48s | 50 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-5 | 8m40s | 51 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |

- krang-opencode-zen-qwen3-8-flash-1 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-opencode-zen-qwen3-8-flash-2 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-opencode-zen-qwen3-8-flash-3 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-opencode-zen-qwen3-8-flash-4 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-opencode-zen-qwen3-8-flash-5 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> ## 3. What `rules.md` did not answer
> 
> - **How the generator is invoked.** The docs say it "writes into the directory unify hands it"
>   — that is all. The sentence I wanted, and could not find, is the calling convention: *what
>   arguments, and where does it write so unify picks the files up*. I discovered by experiment
>   that the script gets `argv[2]=source root, argv[3]=generated overlay, argv[4]=context JSON`,
>   that the context names `site.baseUrl`, `site.prettyUrls`, and `inputs.sourcePages` (the page
>   inventory), and that HTML written into the overlay is composed like a real page (layout,
>   rewriting, canonical all applied) while a `.fragment.html` written there ships raw. None of
>   that is written down anywhere.
> - **Whether `--pretty-urls` touches fragments.** The docs define pretty-urls as
>   `about.html → about/index.html` and define fragments as shipped "as written"; the interaction

**krang-opencode-zen-qwen3-8-flash-2**

> ## What `rules.md` did not answer
> 
> **Whether a generator's output is composed like a page or shipped verbatim.** The sentence I
> wanted and could not find, on line 6 — "it writes into the directory unify hands it" — stops
> exactly there. Nothing distinguishes the two `milling/index.html` outcomes (a composed
> document with chrome) from the fragments (verbatim copies). The dry-run report label
> `← generated + _layout.html` is the only place the behavior appears, and I found it by
> getting it wrong: my first generator hand-spliced the header and footer into the index, and
> the build wrapped them in the layout chrome too — two mastheads, one list, a doubled title.
> `unify audit` had even told me my probe page was "composed with no layout"; I read that as
> "generated files never get a layout", when it really meant "my probe had no `_layout.html`
> to find". Once I knew the rule, the generated index became a plain page-shaped document

**krang-opencode-zen-qwen3-8-flash-3**

> ## 3. What `rules.md` did not answer
> 
> The **URL a `.fragment.html` ends up at under `--pretty-urls`**. The doc says
> fragments are "shipped as written" and separately that pretty-urls rewrites
> `about.html` → `about/` — it never says whether the pretty treatment is *exempt*
> for fragments, and the "no `.html` addresses" rule then becomes a judgement call.
> The sentence I wanted and could not find, in words close to: *"fragments are not
> pretty-ised; their served address keeps the `.fragment.html` suffix."* I learned
> it only by building: the report line is `copy dist/hours.fragment.html
> (/mill/hours.fragment.html) ← generated`. I read the brief's "addresses visitors
> see" as scoping the no-`.html` rule to human navigation, which leaves the two
> machine addresses (the council's fetch, the JS month lists) legally `.html`.

**krang-opencode-zen-qwen3-8-flash-4**

> ## What `rules.md` did not answer
> 
> - **The generate script's whole interface.** The docs say only "it writes into the directory unify
>   hands it". They never say how the script learns which directory that is or where the inventory is.
>   The sentence I wanted, and could not find: *"the script is invoked as
>   `… gen.mjs <sourceRoot> <generatedDir> <generator-context.json>` and the context names
>   `inputs.sourcePages`."* I probed with a throwaway script that printed `process.argv` and the
>   context file.
> - **Whether the generated overlay is composed or merely copied.** "Writes into the directory unify
>   hands it" is silent on what happens to those files next. They are composed as sources — layout,
>   base-url rewriting, pretty-urls — which is what makes a script-generated *index page* sane. I
>   found this by experiment, and it changed my design (the index is a plain page with authored links,

**krang-opencode-zen-qwen3-8-flash-5**

> ## What rules.md did not answer
> 
> - **The generator's calling contract.** The sentence I wanted — and there is none — is one that
>   says *how* `generate:` runs the script. I only learned by probing: unify runs it as
>   `node scripts/gen.mjs <sourceRoot> <generatedOverlayDir> <generator-context.json>` with cwd
>   = source root, hands paths absolutely, runs it before every build (including `--dry-run` and
>   `audit`), and files written into the overlay participate in the build *as if they were sources*
>   (layout applied, links rewritten). Rules says only "it writes into the directory unify hands
>   it" — which directory that is, and what a file written there becomes, you must discover.
> - **Whether `--pretty-urls` touches fragment paths.** "Every file … copies byte-for-byte to the
>   same path" plus the fragment definition implies `/mill/hours.fragment.html` stays exactly that,
>   but I wanted the explicit "a `.fragment.html` name keeps its `.html` suffix under


## photo-banners — Photo banners on every section under a subpath, with extensionless addresses

*round 22: does anyone ship a root-relative url() that 404s under the subpath.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | css-urls | Result |
|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 5m15s | 21 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | 5m32s | 37 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-3 | 4m56s | 32 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-4 | 4m54s | 32 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-5 | 3m43s | 17 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> ## What `rules.md` did not answer
> 
> The sentence I wanted and could not find: **how to link to a page whose source is
> Markdown.** The rule says "Always link the real filename — `/about.html`, not
> `/about/`", but my guides are `oaks.md`, whose "real filename" is neither of the two
> spellings a link needs. Is it `/collections/oaks.md`? `/collections/oaks.html`? Nothing
> says. I wrote `/collections/oaks.html`, and `--dry-run --strict` reported no broken
> link and rewrote it to `/arboretum/collections/oaks/` — so it holds, but by experiment,
> not by reading.
> 
> Closely related and also unanswered: the docs never spell out **what the
> `--base-url` prefix looks like in the emitted HTML** — root-relative `/arboretum/...`

**krang-opencode-zen-qwen3-8-flash-2**

> ### What `rules.md` did not answer — the sentence I wanted and could not find
> 
> The rules explain `--base-url` and `--pretty-urls` **separately**, each in its own bullet, and
> never show them **together**. There is no sentence anywhere stating that a link I wrote as
> `/visit.html`, under both flags, becomes `https://alderfen.pages.dev/arboretum/visit/` — base
> prefix *and* pretty rewrite composed. I wanted one worked example proving the two flags stack
> cleanly rather than fight (e.g. base-prefix a `.html` that pretty-urls has already removed).
> I had to trust the composition and then verify by reading the literal `href=` values in the
> built `dist/` files.
> 
> A second sentence I looked for and did not find: whether Markdown `title:` frontmatter takes
> part in the separator-join rule (that rule is written entirely for HTML `<title>`:

**krang-opencode-zen-qwen3-8-flash-3**

> ## What `rules.md` did not answer
> 
> The sentence I looked for and could not find: **what counts as the "real filename" when
> linking to a Markdown page.** The rules say "Always link the real filename — `/about.html`,
> not `/about/`", but every example is an `.html` source, and the real filename of the oaks
> guide is `oaks.md`. I wrote `/collections/guides/oaks.html` and got silence from a strict
> audit and the right `/arboretum/collections/guides/oaks/` in the output — proof after the
> fact, not an answer.
> 
> Other things the documentation left open:
> 
> - Whether `--pretty-urls` turns the home page into `index/index.html`. The spec sentence

**krang-opencode-zen-qwen3-8-flash-4**

> ## What `rules.md` did not answer
> 
> - **Links to Markdown pages.** The docs say to link the real filename (`/about.html`, not
>   `/about/`) and that this "stays true under `--pretty-urls`" — but only ever for `.html`. Nowhere
>   is it stated that you write `oaks.md` and the build rewrites it to `/collections/guides/oaks/`.
>   The sentence I wanted and could not find: "a link to a `.md` page names its `.md` file." I wrote
>   `/collections/guides/oaks.md` on the collections page as the obvious extrapolation; the clean
>   strict audit and my link-walk confirmed it.
> - **Front matter `title` and the body `<h1>`.** Nothing says whether `title: "The Oaks"` also
>   renders a heading. I guessed it would and omitted an `# heading`; `audit` reported
>   `h1-missing`, telling me unify deliberately emits no `<h1>` for a titled page — the inverse of
>   what "No `title:` → first `# Heading`" almost implies. Added `# The Oaks` etc.

**krang-opencode-zen-qwen3-8-flash-5**

> ## What `rules.md` did not answer
> 
> - **Nothing about `index.html` under `--pretty-urls`.** The rule shown is
>   `about.html → about/index.html`; would the root page fold to a directory too? I found
>   out from the dry-run report (`write dist/index.html (/arboretum/)`), not from the docs.
> - **Nothing about `--pretty-urls` + `--base-url` interaction on the links I wrote.** I
>   wrote `/index.html` in the nav; the output shows it became `/arboretum/`. That the home
>   link folds all the way to the base URL is plausible, but nowhere stated.
> - **The sitemap.** I only knew `--base-url` "generates sitemap.xml" from `./unify --help`;
>   `rules.md` never mentions it. Likewise it doesn't say (in prose) that the *default*
>   `--canonical auto` gives every page that authors none its absolute URL — the Markdown
>   section only warns that a layout must never set canonical.


## publishing — Publishing surface: schema:, og: share cards, dated posts, a feed, a subpath

*round 27, re-run unchanged in round 29; checks follow round 27's pre-registered V1-V5.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | feed | article-data | share-cards | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 6m30s | 47 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | 7m33s | 42 | $0.00 | ✗ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | fail |
| krang-opencode-zen-qwen3-8-flash-3 | 6m07s | 41 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-4 | 5m35s | 34 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-5 | 5m32s | 31 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |

- krang-opencode-zen-qwen3-8-flash-2 · **agent-finished**: exit 1, agent error: The user has specified a rule which prevents you from using this specific tool call. Here are some of the relevant rules [{"permission":"*","action":"allow","pattern":"*"},{"permission":"doom_loop","action":"ask","pattern":"*"},{"permission":"doom_loop","action":"deny","pattern":"*"}], wrote REPORT.md

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> ## 1. What `rules.md` did not answer
> 
> The sentence I wanted and could not find: **"unify runs the generate script as
> `node <script> <sourceRoot> <overlayDir> <contextFile>`, the context file names
> `source-pages.json`, and files written into the overlay are composed like source pages."**
> rules.md says the script "writes into the directory unify hands it" and never says *how* it
> is handed, in which argument, that a context JSON exists at all, what `source-pages.json`
> contains, or whether a generated file gets the layout applied. I discovered all of that by
> running throwaway probes that printed `process.argv`, the context file, and the inventory.
> Two smaller gaps: `--source-inventory`/`source-pages.json` and `sitemap.xml` exist only in
> `./unify --help`, not in the rules; and nothing says a Markdown post must write its own
> `# heading` — a page's `title:` does **not** emit an `<h1>` (the audit's `h1-missing`

**krang-opencode-zen-qwen3-8-flash-2**

> **1. What rules.md did not answer — the sentence I wanted and could not find.**
> rules.md says the generator script "writes into the directory unify hands it" but never
> says *how* the directory is handed over, nor how the script learns what the posts are.
> The sentence I wanted — "the script is invoked as
> `process.argv = [source root, generated directory, context JSON path]`" — does not
> exist. I found it by writing a throwaway probe that dumped `process.argv` and reading
> the `generator-context.json` it names. The context file's `inputs.sourcePages` pointer
> to `source-pages.json` (the per-page title/date/meta inventory I built the index from)
> is not mentioned in rules.md at all — only `--help` says it is "on by default with
> --generate". rules.md also never states whether files the generator writes get the
> layout wrapped around them; I had to believe the dry-run report line
> `dist/news/index.html ← generated + _layout.html`.

**krang-opencode-zen-qwen3-8-flash-3**

> ## 1. What `rules.md` did not answer
> 
> The sentence I wanted and could not find was, in effect: **"unify runs the
> generator with the source directory, the generated directory and a context JSON
> file as its arguments."** Line 6 says only that the script "writes into the
> directory unify hands it" — it never says *how* it is handed. `rules.md` also
> never documents `source-pages.json`'s shape (the CLI help calls it "authored
> title" but no schema), and never says whether files written into that directory
> are treated as pages (layout-applied, links rewritten). I discovered
> `argv = [script, srcDir, overlayDir, context.json]` and
> `generator-context.json`'s `paths.generatedRoot` / `inputs.sourcePages` by
> running a probe script. Related gap: the inventory's `title` is null for a post

**krang-opencode-zen-qwen3-8-flash-4**

> ### 1. What `rules.md` did not answer
> 
> The sentence I wanted and could not find: **how the generator script is invoked — what
> arguments, what working directory, and how it is handed "the directory unify hands it" —
> and where `source-pages.json` lives.** Line 6 says a derived index comes from "a script
> you write… and it writes into the directory unify hands it", full stop. I only learned the
> answer by writing a probe generator that dumped `process.argv`/`process.cwd`: it is called
> with (source root, overlay dir, context JSON), the context JSON points at
> `source-pages.json`, and files written into the overlay ship as if authored (the layout
> wraps them). `source-pages.json` itself appears nowhere in `rules.md` — only in
> `--help`. Other gaps: `rules.md` never mentions `sitemap.xml` (the help does), never says
> `--canonical` defaults to `auto` under `--base-url` (I needed that for canonical/og:url),

**krang-opencode-zen-qwen3-8-flash-5**

> ## 1. What `rules.md` did not answer
> 
> The sentence I wanted and could not find: **how the generator is "handed" its directory, and
> whether files the script writes are treated as source pages.** The rules say "it writes into
> the directory unify hands it, never into `site/`" — but never say it is handed as `argv[3]`
> (next to `argv[2]` = source root and `argv[4]` = `generator-context.json`), never mention
> that a `generator-context.json` or `source-pages.json` exists at all (that is `--help` and
> `--source-inventory` territory), and never state whether an `index.html` written into the
> overlay gets layout wrapping and link rewriting or ships verbatim. A probe script that dumped
> `process.argv` plus a line in the dry-run report (`← generated + _layout.html`) settled both.
> Related gaps: the rules' example `generate: scripts/gen.mjs` reads as project-root-relative
> while the CLI says `--generate` paths are "from the source root" — in practice the YAML


## seed-catalogue — A 225-variety catalogue generated from a JSON export, fetched one family at a time

*round 20; the judge's default marker and privacy fields are this brief's.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-and-export-unpublished | private-data | variety-pages | fetch-targets | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 8m03s | 40 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | — | 59 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-3 | — | 41 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-4 | — | 46 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-5 | — | 44 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |

- krang-opencode-zen-qwen3-8-flash-1 · **fetch-targets** (not scored): 0 of 0 resolved, 0 built at runtime (no base URL (none in config, none in the command) — skipped)
- krang-opencode-zen-qwen3-8-flash-2 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-opencode-zen-qwen3-8-flash-3 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-opencode-zen-qwen3-8-flash-4 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-opencode-zen-qwen3-8-flash-5 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> ## What `rules.md` did not answer
> 
> - **Whether a `.fragment.html` file's links get rewritten.** The file rules say a
>   fragment is "shipped as written"; the finishing section says the build "rewrites
>   only HTML's own URL attributes (`href`, `src`)" — and also that "`fetch()`/`hx-get`
>   address[es] ship as written". The sentence I wanted and could not find is the
>   tie-breaker: *do `--base-url`/`--pretty-urls` rewrite `<a href>` inside a fragment,
>   or does "as written" win?* I tested it: as written wins — a fragment in `dist/`
>   still carried `/variety/nine-star-pea-1.html`, no prefix, no pretty form. That
>   decided the architecture: the family lists ship as real generated pages
>   (rewritten by the build like everything else), and `browse.js` fetches the page
>   and injects its `<main>` — so only that family's varieties arrive, at URLs that

**krang-opencode-zen-qwen3-8-flash-2**

> ## What `rules.md` did not answer
> 
> - **How the generator is invoked.** The rules say the script "writes into the
>   directory unify hands it" but never say what it is handed. The sentence I
>   wanted: *what argv does a `--generate` script receive?* I discovered by
>   printing: `[unify, script, sourceRoot, generatedRoot, generator-context.json]`
>   — after a first attempt wrote straight into `site/` because I guessed argv[2].
> - **Whether "shipped as written" for fragments also exempts them from
>   rewriting and from link resolution.** Line 57 says unify "rewrites only
>   HTML's own URL attributes" and line 10 says fragments ship "as written" — but
>   nowhere states that the `href`s *inside a fragment* keep the exact bytes the
>   generator wrote and are not rewritten by `--base-url`. I learned it by

**krang-opencode-zen-qwen3-8-flash-3**

> ## What `rules.md` did not answer
> 
> **The sentence I wanted and could not find: how the `--generate` script is invoked.** The
> docs say "unify runs it before every build and it writes into the directory unify hands
> it" — but never *how the directory is handed over*: no documented argv order, working
> directory, or context file. I found it by running a probe script that dumped
> `process.argv`: it is `node <script> <sourceRoot> <generatedRoot> <context.json>`, cwd =
> the source root, and the fourth argument is a JSON file containing `paths`, `site`
> (including `baseUrl` and `prettyUrls`) and the source-pages inventory. Nothing in the
> documentation mentions that context file except the `--source-inventory` flag line.
> 
> Related unanswered questions I resolved only by building a probe site:

**krang-opencode-zen-qwen3-8-flash-4**

> ## What `rules.md` did not answer
> 
> The sentence I wanted and could not find: **what happens to files the generate script writes
> into the directory it is handed.** The docs say a script exists, runs before every build, and
> "writes into the directory unify hands it" — but never say that those files are composed like
> normal source pages. I had to test it: overlay pages pick up the root `_layout.html` (two
> levels deep), get `--pretty-urls` and `--base-url` rewriting, canonicals and sitemap entries.
> Related gaps: *which* argument is that directory (I guessed argv[2] — the source root — and
> the script wrote into `site/`, the one place the docs forbid; the contract turns out to be
> `[unify, script, sourceRoot, generatedRoot, generatorContext.json]`); and the
> generator-context.json inventory, which the docs only hint at via `--source-inventory`
> ("on by default with `--generate`") without saying where that file is — argv[4], with

**krang-opencode-zen-qwen3-8-flash-5**

> ## What `rules.md` did not answer
> 
> The sentence I wanted and could not find, in order of how much it cost me:
> 
> - **How the `generate:` script is actually invoked.** `rules.md` says it "writes into the
>   directory unify hands it" — but never says *what it is handed*: the working directory,
>   the argument order (source root, generated root, context path), or that
>   `generator-context.json` contains `baseUrl`/`prettyUrls`/`sourcePages`. I learned all of
>   that by running a probe script that printed `process.argv` and dumped the context file.
>   A sentence like "unify runs `node <script> <source-root> <generated-root> <context.json>`
>   from the source root" would have saved the whole first experiment.
> - **Whether the contents of the generated directory get the same treatment as source files.**


## svelte-estimator — A Svelte component compiled to a browser asset by one repeatable command

*round 24 (round 25 re-ran it with docs/integrations.md seeded); needs the npm registry.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-unpublished | Result |
|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | — | 50 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | — | 74 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-3 | — | 50 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-4 | — | 53 | $0.00 | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-opencode-zen-qwen3-8-flash-5 | — | 53 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |

- krang-opencode-zen-qwen3-8-flash-4 · **strict-build**: exit 1: 1 problems, 0 advisories — site/scripts/gen.mjs: problem: --generate scripts/gen.mjs failed (exit 1): error: Module not found "/tmp/sandbox/site/scripts/gen.mjs"
- krang-opencode-zen-qwen3-8-flash-4 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-4 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-4 · **drafts-unpublished**: no build output

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> ## What `rules.md` did not answer
> 
> The generator-script contract. rules.md says the script "writes into the directory unify hands
> it" — the sentence I wanted and could not find is **how it is handed over**. Nothing in
> rules.md; the CLI help doesn't say either. I found it only by making a script dump
> `process.argv`: `[unify, script, sourceRoot, generatedRoot, generator-context.json]`, and the
> context JSON reveals `paths`, `site` options and `inputs.sourcePages`. The second clue was
> unify's error message, which prints `BUN_BE_BUN=1 unify scripts/gen.mjs` — so generators run
> under Bun, which is nowhere stated; that's why `gen.mjs` stays runtime-agnostic and spawns
> `node` explicitly for the esbuild/svelte step.
> 
> Also unanswered:

**krang-opencode-zen-qwen3-8-flash-2**

> ## What `rules.md` did not answer
> 
> **The generator's invocation contract.** The docs say "unify runs it before every build and it
> writes into the directory unify hands it" — but never *how the hand is given*. There is no
> documented argv order, no documented context file, and no documented cwd. I had to write a
> probe generator that printed `process.argv` and the file unify passes it
> (`<generator-context.json>`, which names `generatedRoot`, the source inventory path, and the
> effective `baseUrl`/`prettyUrls`) to learn: `unify <script.mjs> <sourceRoot> <generatedOverlay>
> <context.json>`, cwd = source root, run by unify's own runtime (so the generator itself must
> stay plain Node — I shell out to `node` for the Svelte/esbuild step rather than import them
> under whatever runtime unify uses).

**krang-opencode-zen-qwen3-8-flash-3**

> ## 4. What `rules.md` did not answer
> 
> - **What happens to the directory the generator writes into.** The one sentence I wanted and
>   could not find: *"the generated directory is composed as if it were source files under the
>   source root."* Rules only say the script "writes into the directory unify hands it, never
>   into `site/`" — not that those files get wrapped by the site's `_layout.html`, rewritten
>   under `--pretty-urls`, prefixed by `--base-url`, or that assets placed there are copied
>   like source assets. All of that was true, and all of it I had to discover with probe
>   builds.
> - **How the generator is handed anything.** Nothing in `rules.md` says the script receives
>   the generated directory and a `generator-context.json` (with `inputs.sourcePages` pointing
>   at the inventory) as `process.argv[3]`/`argv[4]`. `--help` hints "give that file

**krang-opencode-zen-qwen3-8-flash-4**

> ## What `rules.md` did not answer
> 
> The sentences I looked for and could not find:

**krang-opencode-zen-qwen3-8-flash-5**

> ## What `rules.md` did not answer
> 
> - It never says **how the generate script receives the "directory unify hands it"** —
>   not as argv, not as env, just "it writes into the directory". I discovered by running
>   one: `argv[2]` = source root, `argv[3]` = a generated *overlay* directory, `argv[4]` =
>   a context JSON whose `inputs.sourcePages` points at the inventory. The sentence I
>   wanted and could not find: *"The generate script is called with the source root, the
>   generated overlay directory and a context file as its arguments."*
> - It does not say that **files written into the overlay get the full treatment** — layout,
>   `--base-url` prefixing, `--pretty-urls` — though everything works that way. I inferred
>   it from "Derived files (a post index)", then tested it before relying on it.
> - The **shape of `source-pages.json`** is undocumented (keys `source/href/title/date/…`),


---

`✓` passed, `✗` failed, `(i)` reported but not scored. Each sample's directory is `<brief>/<sample>/`, its OpenCode event stream and session data are in `<brief>/.harness/<sample>/`, and the build the checks read is `<brief>/.build/<sample>/`. Triage every failure with ratification/ratification-protocol.md before changing anything.
