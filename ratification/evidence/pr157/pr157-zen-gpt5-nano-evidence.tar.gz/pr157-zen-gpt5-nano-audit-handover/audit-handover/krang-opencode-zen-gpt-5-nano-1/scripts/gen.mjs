// Lightweight no-op generator for unify
export async function generate() {
  // Intentionally do nothing; this ensures build runs in tests
}

export default async function generate() {
  // Default export as fallback; no-op
}
