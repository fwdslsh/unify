---
title: "Volunteer Journal: Harvest Day"
date: 2026-08-02
author: "Volunteer C"
description: "A short journal entry from harvest day at the library."
og:description: "A short journal entry from harvest day at the library."
layout: none
---

We harvested sunflowers, lettuce, and beans. The community pitched in, and the seed saving station ran smoothly.
