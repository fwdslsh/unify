---
title: Seed Sharing Practices
layout: /layouts/default.html
author: Volunteer B
date: 2026-11-05T09:00:00Z
description: How we manage seed borrowing and returns.
schema: Article
---

We discuss how we borrow seeds and how we ensure seeds are kept true to type and quality.
