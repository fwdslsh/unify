---
title: First Notes from the Fernway Garden
layout: /layouts/default.html
author: Volunteer A
date: 2026-11-01T09:00:00Z
description: A note from the garden about seed sharing and community.
schema: Article
---

This is the first post from our notes collection. We are sharing seeds and stories from our garden.
