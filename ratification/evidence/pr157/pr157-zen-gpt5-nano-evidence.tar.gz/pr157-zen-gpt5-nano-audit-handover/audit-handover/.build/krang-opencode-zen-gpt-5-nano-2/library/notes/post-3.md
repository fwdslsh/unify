---
title: A Year in Seeds
layout: /layouts/default.html
author: Volunteer C
date: 2026-11-08T09:00:00Z
description: Reflections on the season and the joy of seed returns.
schema: Article
---

A reflection on what we learned this year, and a thank-you to everyone who helped.
