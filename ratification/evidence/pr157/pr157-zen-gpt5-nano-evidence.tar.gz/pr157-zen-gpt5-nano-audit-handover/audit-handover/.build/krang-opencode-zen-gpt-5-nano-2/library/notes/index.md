---
title: Notes Archive
layout: layouts/default.html
schema: BlogPosting
date: 2026-11-08T09:00:00Z
author: Fernway Volunteers
---

# Notes

- [Post 3](/library/notes/post-3.html) - A fresh note from today.
- [Post 2](/library/notes/post-2.html) - Reflections from volunteers.
- [Post 1](/library/notes/post-1.html) - First draft of notes.
