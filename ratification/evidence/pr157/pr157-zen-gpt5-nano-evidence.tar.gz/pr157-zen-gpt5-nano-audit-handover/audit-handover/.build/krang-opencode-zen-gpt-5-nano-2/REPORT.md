```bash
./unify build --base-url https://fernway.example/library/ --output dist/ --strict
```

Publish command: above command was run to attempt a publish of the site under the subdirectory /library/.

Checks run and outputs
Block 1: final publish attempt (no --dry-run)
```
serving from https://fernway.example/library/
canonical completion: 9 pages would gain a canonical link
structured data: 4 pages would gain a JSON-LD block
write dist/BRIEF.html (/library/BRIEF.html) ← BRIEF.md (no layout)
write dist/layouts/default.html (/library/layouts/default.html) ← layouts/default.html (no layout)
write dist/library/index.html (/library/library/) ← library/index.html + layouts/default.html
write dist/library/notes/index.html (/library/library/notes/) ← library/notes/index.md + layouts/default.html
write dist/library/notes/post-1.html (/library/library/notes/post-1.html) ← library/notes/post-1.md + layouts/default.html
write dist/library/notes/post-2.html (/library/library/notes/post-2.html) ← library/notes/post-2.md + layouts/default.html
write dist/library/notes/post-3.html (/library/library/notes/post-3.html) ← library/notes/post-3.md + layouts/default.html
write dist/library/visit.html (/library/library/visit.html) ← library/visit.html + layouts/default.html
write dist/rules.html (/library/rules.html) ← rules.md (no layout)
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
copy dist/unify (/library/unify) ← unify
would publish nothing — 2 problems; dist/ would be left untouched
```

Block 2: dry-run (to surface issues without writing)
```
layouts/default.html: advisory: layouts/default.html is used as a layout or include and also ships as its own page
layouts/default.html:6: problem: /styles.css does not resolve to any emitted file
  in: /styles.css
  fix: check the path spelling and casing
library/notes/index.md: advisory: date is "2026-11-08", which names a day rather than an instant — this page is not in feed.xml
  fix: give the date a time and a time zone — "2026-11-08" becomes "2026-11-08T09:00:00Z"
library/notes/post-1.md: advisory: date is "2026-11-01", which names a day rather than an instant — this page is not in feed.xml
  fix: give the date a time and a time zone — "2026-11-01" becomes "2026-11-01T09:00:00Z"
library/notes/post-2.md: advisory: date is "2026-11-05", which names a day rather than an instant — this page is not in feed.xml
  fix: give the date a time and a time zone — "2026-11-05" becomes "2026-11-05T09:00:00Z"
library/notes/post-3.md: advisory: date is "2026-11-08", which names a day rather than an instant — this page is not in feed.xml
  fix: give the date a time and a time zone — "2026-11-08" becomes "2026-11-08T09:00:00Z"
building from the working directory (no site/ or src/ here): 2 files will be copied as-is — run unify build --dry-run to list them
```

What did rules.md not answer? The exact, project-specific guidance for composing the Notes index and the social preview card integration beyond generic JSON-LD hints. In particular, rules.md does not specify:
- How to generate the Notes index listing newest posts first and automatically reflect new posts.
- The exact structure and assets for social preview cards (the image, title, and description placement) beyond the general statement that a preview should exist.

What did I have to re-read, and why did it not land the first time? I re-read BRIEF.md to confirm expectations for the Notes feature (three dated Markdown posts and an index) and the requirement that every page share header/footer and publish under a subdirectory. Some constraints were phrased in BRIEF.md but require interpretation by the tool (e.g., proper canonical and base URL behavior) which rules.md alone did not fully translate into concrete steps in my first iteration.

What did I guess at or infer rather than read? I inferred a minimal but coherent layout and header/footer across all pages, and I inferred a placeholder seed-mark SVG and simple CSS pathing. I also inferred the folder structure for a small static site (library/ as the public root) and the need to place assets under dist/ for publish.
