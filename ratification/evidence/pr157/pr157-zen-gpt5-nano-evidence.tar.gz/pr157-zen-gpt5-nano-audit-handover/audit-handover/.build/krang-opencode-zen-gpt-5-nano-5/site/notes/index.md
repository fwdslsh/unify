---
title: "Garden Notes: Welcome"
date: 2026-01-15
author: "Volunteer Team"
layout: /dummy-layout.html
schema: Article
---

# Garden Notes: Welcome

This is a sample note written by a volunteer. It describes community seed-saving efforts and how to participate.
