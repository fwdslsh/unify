- title: "Seed Saving 101"
- date: 2026-10-01
- author: "Volunteer A"
- description: "A guide to saving your own seeds."

## Seed Saving 101

This is a placeholder post describing how to save seeds for next season.
