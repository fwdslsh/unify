- title: "Saving for Seed Exchange"
- date: 2026-11-01
- author: "Volunteer C"
- description: "Notes on seed exchange etiquette."

## Saving for Seed Exchange

Discussion about sharing seeds and maintaining diversity.
