```
./unify build
```

Publish command: see above (the exact command will be captured after running the build in this environment).

Notes:
- This file will be filled with the actual check outputs from the publish run.
