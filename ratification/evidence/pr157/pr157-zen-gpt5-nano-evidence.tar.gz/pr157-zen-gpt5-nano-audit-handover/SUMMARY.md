# Ratification round pr157-zen-gpt5-nano-audit-handover

- **unify** 0.11.18 at `83bc115168cb` (working tree)
- **rules** `fb07d931bd36` · **prompt** `456131468750` · **agent** opencode 1.18.25 · **models** krang/opencode-zen/gpt-5-nano · **isolation** mount namespace, probe clean
- 2026-11-08T23:37:41.251Z to 2026-11-08T23:41:19.553Z; scored 2026-11-08T23:41:19.554Z

## Score

**0 of 5 samples completed their brief: every scored check passed (0%).**

The protocol's bar, at least 4 of 5 samples of a model on each brief: **not met**.

| Brief | Model | Passed | Checks that failed |
|---|---|---|---|
| audit-handover | krang/opencode-zen/gpt-5-nano | 0/5 | strict-build (4), fresh-build (4), addresses (4), audit-strict (5), article-data (5), share-cards (5) |

## audit-handover — Hand over only when every check the tool offers reports nothing

*round 28; checks follow its pre-registered V1-V4, plus the brief's extensionless addresses.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | audit-strict | article-data | share-cards | ran-audit | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-gpt-5-nano-1 | 2m53s | 59 | $0.00 | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-opencode-zen-gpt-5-nano-2 | 2m48s | 46 | $0.00 | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-opencode-zen-gpt-5-nano-3 | 53s | 10 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-opencode-zen-gpt-5-nano-4 | 2m17s | 33 | $0.00 | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-opencode-zen-gpt-5-nano-5 | 2m18s | 33 | $0.00 | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |

- krang-opencode-zen-gpt-5-nano-1 · **strict-build**: exit 1: 1 problems, 0 advisories — site/scripts/gen.mjs: problem: --generate scripts/gen.mjs failed (exit 1): error: Module not found "/tmp/sandbox/site/scripts/gen.mjs"
- krang-opencode-zen-gpt-5-nano-1 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-gpt-5-nano-1 · **addresses**: no build output
- krang-opencode-zen-gpt-5-nano-1 · **audit-strict**: exit 1: /work/unify/ratification/scripts/isolate.sh: line 36: cd: /work/unify/ratification/rounds/pr157-zen-gpt5-nano-audit-handover/audit-handover/.build/krang-opencode-zen-gpt-5-nano-1: No such file or directory
- krang-opencode-zen-gpt-5-nano-1 · **article-data**: no build output
- krang-opencode-zen-gpt-5-nano-1 · **share-cards**: no build output
- krang-opencode-zen-gpt-5-nano-1 · **ran-audit** (not scored): 0 runs matching /unify audit/
- krang-opencode-zen-gpt-5-nano-2 · **strict-build**: exit 1: 2 problems, 1 advisories — layouts/default.html: advisory: layouts/default.html is used as a layout or include and also ships as its own page
- krang-opencode-zen-gpt-5-nano-2 · **fresh-build**: exit 1:   fix: create it, or point layout at an existing .html file /   fix: check the path spelling and casing /  / building from the working directory (no site/ or src/ here): 2 files will be copied as-is — run unify build --dry-run to list them
- krang-opencode-zen-gpt-5-nano-2 · **addresses**: no build output
- krang-opencode-zen-gpt-5-nano-2 · **audit-strict**: exit 1:   fix: create it, or point layout at an existing .html file /   fix: check the path spelling and casing
- krang-opencode-zen-gpt-5-nano-2 · **article-data**: no build output
- krang-opencode-zen-gpt-5-nano-2 · **share-cards**: no build output
- krang-opencode-zen-gpt-5-nano-2 · **ran-audit** (not scored): 0 runs matching /unify audit/
- krang-opencode-zen-gpt-5-nano-3 · **audit-strict**: exit 1:   fix: add a <title> to the page, or to its layout for a site-wide suffix / audit: 0 broken, 13 incomplete
- krang-opencode-zen-gpt-5-nano-3 · **article-data**: 0 dated pages (needs 3)
- krang-opencode-zen-gpt-5-nano-3 · **share-cards**: 0 dated pages (needs 3)
- krang-opencode-zen-gpt-5-nano-3 · **ran-audit** (not scored): 0 runs matching /unify audit/
- krang-opencode-zen-gpt-5-nano-4 · **strict-build**: exit 1: 2 problems, 0 advisories — site/layouts/default.html:7: problem: <slot> in a page fills nothing — only a layout declares slots
- krang-opencode-zen-gpt-5-nano-4 · **fresh-build**: exit 1:   fix: to fill a layout slot, put slot= on a real element: <footer slot="footer">…</footer> / site/notes/index.md:6: problem: layout not found: /default.html /   fix: create it, or point layout at an existing .html file /   fix: check the path spelling and casing
- krang-opencode-zen-gpt-5-nano-4 · **addresses**: no build output
- krang-opencode-zen-gpt-5-nano-4 · **audit-strict**: exit 1:   fix: create it, or point layout at an existing .html file /   fix: check the path spelling and casing
- krang-opencode-zen-gpt-5-nano-4 · **article-data**: no build output
- krang-opencode-zen-gpt-5-nano-4 · **share-cards**: no build output
- krang-opencode-zen-gpt-5-nano-4 · **ran-audit** (not scored): 0 runs matching /unify audit/
- krang-opencode-zen-gpt-5-nano-5 · **strict-build**: exit 1: 4 problems, 0 advisories — site/dummy-layout.html:14: problem: <slot> in a page fills nothing — only a layout declares slots
- krang-opencode-zen-gpt-5-nano-5 · **fresh-build**: exit 1: site/notes/2026-02-01-busy.md:8: problem: slug has no meaning in unify — this page's address is its source path /   fix: rename the source file to change the last segment of its address / site/notes/2026-03-01-cropping.md:8: problem: slug has no meaning in unify — this page's address is its source path /   fix: rename the source file to change the last segment of its address
- krang-opencode-zen-gpt-5-nano-5 · **addresses**: no build output
- krang-opencode-zen-gpt-5-nano-5 · **audit-strict**: exit 1: site/notes/2026-03-01-cropping.md:8: problem: slug has no meaning in unify — this page's address is its source path /   fix: rename the source file to change the last segment of its address
- krang-opencode-zen-gpt-5-nano-5 · **article-data**: no build output
- krang-opencode-zen-gpt-5-nano-5 · **share-cards**: no build output
- krang-opencode-zen-gpt-5-nano-5 · **ran-audit** (not scored): 0 runs matching /unify audit/

What the agents said the rules did not answer:

**krang-opencode-zen-gpt-5-nano-1**

> What the rules.md did not answer
> - The exact shape and behavior of the post index generator script and how to wire it to produce a navigable index at /notes/. The sentence I wanted: "Derived files (a post index) come from a script you write, kept in `scripts/` beside the site and named in `unify.yaml` (`generate: scripts/gen.mjs`): unify runs it before every build and it writes into the directory unify hands it, never into `site/`." I needed concrete guidance on the output location and expected interface of that script.
> 
> What I re-read and why
> - I re-read BRIEF.md and rules.md to confirm requirements (pages, header/footer, notes, social preview, SEO metadata, and base publishing URL). It did not land the first time because the YAML config semantics for unify.yaml vs CLI options were not entirely clear; I iterated on removing/adjusting keys and observed the CLI’s expected options in the help output.
> 
> What I inferred (rather than read directly)
> - I inferred the site structure and navigation, and that a seed header would be embedded on every page, plus a placeholder SVG seed graphic. I also assumed a simple static notes index with three Markdown posts would be generated by a script, even though the exact generation steps were not detailed in rules.md.

**krang-opencode-zen-gpt-5-nano-2**

> What did rules.md not answer? The exact, project-specific guidance for composing the Notes index and the social preview card integration beyond generic JSON-LD hints. In particular, rules.md does not specify:
> - How to generate the Notes index listing newest posts first and automatically reflect new posts.
> - The exact structure and assets for social preview cards (the image, title, and description placement) beyond the general statement that a preview should exist.
> 
> What did I have to re-read, and why did it not land the first time? I re-read BRIEF.md to confirm expectations for the Notes feature (three dated Markdown posts and an index) and the requirement that every page share header/footer and publish under a subdirectory. Some constraints were phrased in BRIEF.md but require interpretation by the tool (e.g., proper canonical and base URL behavior) which rules.md alone did not fully translate into concrete steps in my first iteration.
> 
> What did I guess at or infer rather than read? I inferred a minimal but coherent layout and header/footer across all pages, and I inferred a placeholder seed-mark SVG and simple CSS pathing. I also inferred the folder structure for a small static site (library/ as the public root) and the need to place assets under dist/ for publish.

**krang-opencode-zen-gpt-5-nano-3**

> - What did rules.md not answer? Name the sentence you wanted and could not find.
>   The exact sentence from BRIEF.md that rules.md did not state is:
>   "The library's coordinator accepts the site only after running **every check** the tool offers — including the ones that do not block a build — and rejects it if any check reports anything at all."
>   This handover condition is referenced in BRIEF.md but not stated verbatim in rules.md.
> 
> - What did you have to re-read, and why did it not land the first time?
>   I re-read BRIEF.md to confirm the handover/check expectations and the target publish URL. It did not land initially because rules.md describes the generic build/check semantics but does not reproduce the exact handover policy text from BRIEF.md.
> 
> - What did you guess at, or infer rather than read?
>   I inferred that the publish action corresponds to running ./unify build and that the dry-run output indicates what would be published to dist/ (3 files: BRIEF.html, rules.html, and the dist/unify binary). I also inferred that dist/ is the public publication directory and that the final URLs must be pretty-URLs under /library/.

**krang-opencode-zen-gpt-5-nano-5**

> What did rules.md not answer?
> - The exact requirement for ordering and rendering the Notes index (e.g., "notes index must show newest first"). I wanted a sentence like: "The notes index must order posts newest first" but it isn’t stated in rules.md.
> 
> What did I re-read, and why did it not land the first time?
> - I re-read BRIEF.md to confirm the Notes requirement and rules.md to understand how layout and JSON-LD are handled. The missing Notes ordering guidance and the exact front-matter interactions caused it not to land on first reading.
> 
> What did I guess or infer rather than read?
> - I inferred that a minimal dummy layout would satisfy the publish flow and that the public pages would be served from site/ with a base URL; I also inferred the need to provide a dummy layout file and adjusted front-matter paths accordingly to attempt a successful build.


---

`✓` passed, `✗` failed, `(i)` reported but not scored. Each sample's directory is `<brief>/<sample>/`, its OpenCode event stream and session data are in `<brief>/.harness/<sample>/`, and the build the checks read is `<brief>/.build/<sample>/`. Triage every failure with ratification/ratification-protocol.md before changing anything.
