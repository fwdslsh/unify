# Alderfen Arboretum — build report

## Publishing command line

From this directory, publish with exactly:

```
./unify build --clean --pretty-urls --base-url https://alderfen.pages.dev/arboretum/
```

Exit 0 means `dist/` is the complete site ready to serve at
`https://alderfen.pages.dev/arboretum/`. (`--clean` drops stale files from earlier
builds; `--dry-run --strict` can precede it as a write-free full check.)

## What was built

```
site/
  _layout.html      shared header (logo) + footer + head, for every page
  index.html        home, full-width banner: name + welcome over home-wide.png
  visit.html        Visit: shallower banner over visit-banner.png; times, getting here, accessibility
  collections.html  Collections: shallower banner over collections-banner.png; intro + guide links
  collections/      three curator guides in Markdown (oaks, maples, witch-hazels),
                    each naming its curator and best month (in the prose, and as meta)
  style.css         one stylesheet; banners use <img> tags, no url() (see below)
  images/           the four provided photos, copied unchanged
```

`--pretty-urls` gives `/arboretum/`, `/arboretum/visit/`,
`/arboretum/collections/oaks/`, … — no `.html` in any visitor address.
`--base-url` prefixes every `href`/`src` with `/arboretum/` and makes canonical/og
absolute; it also generates `sitemap.xml`. Verified by serving `dist/` under
`/arboretum/` and fetching all 11 emitted addresses: every page, the stylesheet and
every photo returned 200, images byte-identical to the provided files, every page
(including all three guides) carries the shared header and footer.

## What `rules.md` did not answer

The sentence I wanted and could not find: **how to link to a page whose source is
Markdown.** The rule says "Always link the real filename — `/about.html`, not
`/about/`", but my guides are `oaks.md`, whose "real filename" is neither of the two
spellings a link needs. Is it `/collections/oaks.md`? `/collections/oaks.html`? Nothing
says. I wrote `/collections/oaks.html`, and `--dry-run --strict` reported no broken
link and rewrote it to `/arboretum/collections/oaks/` — so it holds, but by experiment,
not by reading.

Closely related and also unanswered: the docs never spell out **what the
`--base-url` prefix looks like in the emitted HTML** — root-relative `/arboretum/...`
or fully absolute `https://.../arboretum/...`. It says links are "prefixed" and
only og:/canonical are made "absolute", which I read as implying the prefix on links
is path-only. The output confirms that reading, but a sentence stating it would have
saved the doubt.

## What I had to re-read, and why it did not land the first time

The merging section, twice. The paragraph on bare `<header>`/`<footer>` first says an
`slot=` element "replaces the slot, tag and all", then a breath later says a
`slot="footer"` fill "fills the *contents*" of the layout's own `<footer>` — those read
as contradictions until you notice they describe two different layouts (slot bare in
`<main>` vs. slot wrapped in `<footer>`). I re-read it to work out whether I must give
my footer content `slot=` fills at all; the answer, for my shape (header, slot, and
footer all living in the layout, pages supplying only `<main>` content), is no — but
only the second reading made that visible. The same density bit me on "The first
default-content page main unwraps": it took a second pass to realise my pages should
each wrap their content in a `<main>` and it will merge cleanly into the layout's
`<main><slot></slot></main>` without a main-in-main.

## What I guessed at, or inferred rather than read

- **One root `_layout.html` wraps everything**, guides one folder down, because the
  search is "its own folder, then each parent". Stated for HTML pages; I inferred it
  also applies to Markdown pages with no `layout:` key, and the build's layout listing
  (`--dry-run` names each page with the layout it resolved to) confirmed it.
- **Omitting `title:` in the guides** and letting the first `# The Oaks` heading become
  the page title is a reading of "No `title:` → first `# Heading`" pushed slightly
  beyond what it literally says (it never shows the heading still rendering on the
  page too). Output confirms both.
- **`curator:` and `best:` frontmatter keys** do nothing but emit `<meta name=…>` —
  I inferred the curator's name and the best month must also stand in the visible
  prose to satisfy the brief; the visible naming is in the body.
- **Banners as `<img>` + overlaid text instead of CSS `background-image`** was a
  deliberate dodge, not a documented requirement: the docs warn that `url()` in a
  stylesheet ships as written and misses the `--base-url` prefix. Keeping photos in
  `src` attributes puts every image URL in the one place unify does rewrite. I inferred
  nothing breaks — confirmed: `style.css` contains no `url()`.
- **Active-nav CSS** (`body.home .nav-home {…}`) I got from the docs, but I initially
  matched on `href$="visit.html"` — my own guess, and wrong under `--pretty-urls`,
  because the built hrefs end in `/visit/`. Caught while checking output, fixed to the
  documented class pattern. The docs warn active nav is "CSS, not a feature" but don't
  warn that href-suffix matching goes stale once the build rewrites addresses.
