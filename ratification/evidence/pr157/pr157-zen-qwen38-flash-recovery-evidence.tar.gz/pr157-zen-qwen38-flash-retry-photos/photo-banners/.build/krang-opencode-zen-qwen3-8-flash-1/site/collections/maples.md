---
class: guide
curator: Tom Berisford
best: "the last week of October"
---

# The Maples

Curated by **Tom Berisford** — at its best in **the last week of October**, when the
slope above the pond goes red and the tea-room puts the long benches outside.

## Autumn colour on the pond slope

Forty-two maples climb the south slope in three drifts, chosen so the colour moves down
the hill over a fortnight rather than flaring and dying in one weekend. The first to turn
are the Japanese maples at the top, then the trunks of the big leaves, and last the
sycamores by the water, which go late and gold.

## What to look for

- **Full-moon maples** along the upper path hold their colour longest — visit twice in
  one October and you will see two different hills.
- **The paperbark maple** by the pond steps is worth studying in summer, not autumn: its
  cinnamon bark peels in sheets you could almost write on. Please don't.
- **Map seeds** — the spinning "helicopters" — fall in such quantity under the field
  maples that the path needs sweeping twice a week in September. This is normal, and the
  seedlings are potting material for next spring's planting days.

## Curation notes

Shade on this slope is managed for colour, not timber: suckers and self-seeded elders are
cut back each February by volunteers, and the young plantings are watered through drought
summers. Tom writes a one-page colour forecast every September — ask at the tea-room.
