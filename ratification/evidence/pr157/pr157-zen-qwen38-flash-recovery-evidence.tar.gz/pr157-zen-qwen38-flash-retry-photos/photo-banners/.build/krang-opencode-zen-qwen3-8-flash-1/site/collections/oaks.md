---
class: guide
curator: Ruth Ackroyd
best: "late October"
---

# The Oaks

Curated by **Ruth Ackroyd** — at its best in **late October**, when the leaves turn the
colour of wet bark and fall thick on the rail path.

## The oldest planting

The oak collection runs the length of the east wall, where the 1887 hawthorn hedge still
shelters the younger trees. Most of what you see was planted in the first fifteen years of
the arboretum: sixty-one specimens in eighteen species, from the common oak that anchors
the far corner to the slender Japanese *Quercus crispula* by the gate.

## What to look for

- **The veteran common oak** at the path's midpoint is the oldest tree in the arboretum —
  planted the spring after the first flood, and hollowed by a lightning strike that the
  beetles have long since made home.
- **Evergreen oaks** near the wall hold their leaves into June; look for the coppery
  flush just as the buds break, which is when the whole row glows.
- **Pin oaks** on the open lawn are the sharpest silhouette in frost — their leaves stay
  until the first hard night, then fall in a single week.

## Curation notes

The oaks need no feeding and little water; the wall does the work. Volunteers prune only
deadwood, and only in the close season. If you find a label rubbed blank, tell anyone in
a green apron — Ruth will know the tree by name.
