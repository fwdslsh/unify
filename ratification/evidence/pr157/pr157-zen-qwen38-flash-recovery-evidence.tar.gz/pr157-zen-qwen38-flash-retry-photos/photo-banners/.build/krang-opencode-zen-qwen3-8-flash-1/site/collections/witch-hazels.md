---
class: guide
curator: Priya Ramnani
best: "February"
---

# The Witch Hazels

Curated by **Priya Ramnani** — at its best in **February**, when almost nothing else
flowering exists and the shrubs by the tea-room open their ribbon-like yellow petals on
the coldest mornings of the year.

## Flowers in the depths of winter

Twenty-nine witch hazels and their relatives — *Hamamelis*, but also the Chinese
flowering-hazels that the collection has grown since 2015 — sit in the sheltered dip
beside the tea-room, where the frost lingers and the wind cannot reach. The winter flower
is the reason for the dip: fragrant on still, cold days, and open best just after dawn
before the petals curl again against midday.

## What to look for

- **The Arnold Promise strain** nearest the tea-room wall flowers a fortnight before the
  others and carries the strongest scent — walk the wall on a calm January morning.
- **Corkscrew hazel** at the end of the row is here for its winter twig architecture,
  not its flower: the twist shows best after the first snow or, failing that, after rain.
- **Autumn colour is not the point**, but *Hamamelis virginiana*, the western witch
  hazel, flowers alone in October — find it by the low metal guard and you have two
  seasons in one visit.

## Curation notes

The dip is mulched annually with leaf mould from the oak collection, and pruning is
minimal: one cross-shaped cut to keep air movement, made by Priya herself after the last
flower falls. Please resist the urge to break a scented twig for indoors — the whole
collection is short, and February visitors come for what is on the plant, not in a vase.
