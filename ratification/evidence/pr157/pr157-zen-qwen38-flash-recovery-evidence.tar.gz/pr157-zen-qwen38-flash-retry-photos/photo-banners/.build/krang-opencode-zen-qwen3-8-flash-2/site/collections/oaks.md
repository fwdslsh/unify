---
title: The Oaks
description: A curator's guide to the oak collection at Alderfen Arboretum.
class: collections
---

The oak collection is kept by **Margaret Tully**, who has grown most of it from acorns
picked in the lane itself. The collection is at its best in **October**, when the leaves
go from bronze to the colour of cold tea and the crop of acorns lands.

## What is here

Forty-one specimens in twelve species, planted along the ridge path and in the wide glade
visible from the gate. The founder tree — a pedunculate oak (*Quercus robur*) planted in
1974, the year the field was bought — stands at the centre of the glade and carries the
only brass plate in the arboretum. Beside it are the Sessile oaks from the western woods,
and down the slope a small cork oak that no one expected to survive our winters and does.

## Walking it

Start at the founder tree and follow the ridge path east; the labels are at eye level and
numbered in Margaret's register. In October the ground under the pedunculate oaks is worth
looking at closely — we re-bury the good acorns, and mark the flats with a white stake so
nobody walks on the seedlings.

## When to come again

Leaf-out in May is quieter but lovely; the glade is then full of bluebells we are too late
to plant. If you come in October, come twice: the colour holds for about ten days.
