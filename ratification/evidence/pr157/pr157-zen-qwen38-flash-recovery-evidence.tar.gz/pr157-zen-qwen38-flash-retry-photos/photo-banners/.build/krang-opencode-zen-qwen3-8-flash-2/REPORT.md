# Alderfen Arboretum — build report

## Publish command

    ./unify build --base-url https://alderfen.pages.dev/arboretum/ --pretty-urls --clean

That is the command I ran last and verified (exit 0, `dist/` is the complete site).
Before the real build I ran the same command with `--dry-run --strict`, which
`rules.md` calls "the whole build and every check": it passed with no problems.
The source lives in `site/` (the auto-detected source root); the provided photos were
copied to `site/images/` so they ship; `./unify` is a CLI tool and nothing is served
from the working directory itself.

## What I checked, not just assumed

- `--dry-run --strict` listed all 6 pages resolved to `_layout.html` — including the
  three Markdown guides one folder down, confirming the nearest-layout search.
- I then walked every `href`/`src` in every file in `dist/` and mapped it back to a
  file under `dist/` after stripping `https://alderfen.pages.dev/arboretum/` or
  `/arboretum/`: **all resolve** (0 broken). Every page: logo (header image + favicon),
  stylesheet; home banner → `home-wide.png`, Visit → `visit-banner.png`, Collections →
  `collections-banner.png`.
- No emitted address ends in `.html`; the sitemap lists exactly the six pretty URLs.
- `style.css` contains no `url()` at all — every photo is an `<img>` whose `src` unify
  rewrites, so nothing can miss the `/arboretum/` prefix. (The stylesheet is served from
  the site root, so even a relative `url()` would have been fine, but I did not want to
  bet on it.)
- Rendered HTML spot-checks: title join (`The Oaks — Alderfen Arboretum`), body class
  merge (`body.home`, `body.visit`, `body.collections` on the guides, so the plain-CSS
  active-nav rule covers the whole section), canonical/og:url absolute and per-page.

## What `rules.md` did not answer

- **Nothing about `index.html` under `--pretty-urls`.** The rule shown is
  `about.html → about/index.html`; would the root page fold to a directory too? I found
  out from the dry-run report (`write dist/index.html (/arboretum/)`), not from the docs.
- **Nothing about `--pretty-urls` + `--base-url` interaction on the links I wrote.** I
  wrote `/index.html` in the nav; the output shows it became `/arboretum/`. That the home
  link folds all the way to the base URL is plausible, but nowhere stated.
- **The sitemap.** I only knew `--base-url` "generates sitemap.xml" from `./unify --help`;
  `rules.md` never mentions it. Likewise it doesn't say (in prose) that the *default*
  `--canonical auto` gives every page that authors none its absolute URL — the Markdown
  section only warns that a layout must never set canonical.
- **Whether linking a `.md` page means writing `.md` or `.html`.** "Always link the real
  filename" — the real filename is `oaks.md`, but the output filename is `oaks.html`. I
  wrote `/collections/oaks.html`, and the strict pass reported no broken links, so I
  believe the output name is what "real" means.

**The sentence I wanted and could not find:** one worked example of a layout and a page
side by side, showing what the merged output looks like. Every merge rule is stated once,
in prose, across four dense bullet points — `The first default-content page main unwraps,
even for a bare slot outside a layout main; write complete semantic documents` is a whole
design decision in a half-clause. An example would have made several of the next section
unnecessary.

## What I re-read, and why it did not land

- **The styles paragraph** ("keep every `url()` in a stylesheet file and every fetched
  address relative to the page — or read it back from an `href` unify rewrote"). It reads
  as one instruction but is two, and "relative to the page" matches neither of them the
  way a browser does: a CSS `url()` is resolved relative to the *stylesheet*, not the
  page. The first read failed because I was looking for CSS semantics in a sentence about
  build-time rewriting. I stopped relying on the reading entirely and used no `url()`s.
- **"The page says nothing" vs "Pick one with `data-layout`"** in the Layout section.
  Contradictory on first pass. Second read: picking is optional; the nearest `_layout.html`
  applies automatically, and a page deeper down inherits the root layout. That's the one
  mechanism the whole brief's "every page shares the header and footer" turns on, so I
  then sat with the "then each parent" phrase until I'd confirmed there is no need for a
  second layout (there isn't, and layouts could not chain anyway).
- **"Fills reach that fragment's slots and no deeper"** and the `slot=` bullets — not
  applicable in the end; the site has zero named slots and zero `<include>`s (a layout
  plus a static footer covers every requirement), but I re-read them once before I was
  confident nothing needed them.

## What I guessed at, or inferred rather than read

- **Copying the images into `site/images/`.** `rules.md` says everything ships from the
  source root, so the photos must live under `site/`; the brief says "do not create new
  image files", which I read as "don't author new photos", not "don't move the ones
  provided". `cp -r images site/images` — byte-for-byte copies, no new files invented.
- **`/index.html` as the home link** (rather than `/` or `""`) — inferred from "always
  link the real filename"; the build confirmed it folds to `/arboretum/`.
- **Linking guides by their `.html` output name** — see the gap above; validated by a
  strict build with no broken-link findings.
- **`class: collections` in guide frontmatter** so guides get `body.collections` and the
  Collections nav item stays highlighted one folder down — inferred by combining the
  "class (on `<body>`)" frontmatter rule with the root-attributes merge rule; checked in
  the emitted HTML.
- **No feed.** `rules.md` says a feed is written if you declare `schema:` and build with
  `--base-url`. I declare no schema anywhere; `dist/feed.xml` does not appear, which
  confirms the reading that schema is the trigger. (If it had appeared, that would have
  been fine too — it wasn't asked for.)
- **Static-host behaviour**: that `https://alderfen.pages.dev/arboretum/visit/` resolves
  to `visit/index.html` in `dist/`. Universal convention, but nothing in either document
  says it, and the whole pretty-URL requirement rests on it.
- **Design judgement calls** the brief left open: "shallower" became 55vh home banner vs
  28vh section banners (`object-fit: cover` so the full window width always fills);
  readability over the photo via a dark gradient overlay plus text-shadow; invented
  curator names, best months (October / November / February), and section copy.

## Layout of the source, for the record

- `site/_layout.html` — header (logo, nav), `<main><slot></slot></main>`, footer; title
  carries the `— ` separator; stylesheet and favicon links, canonical deliberately absent.
- `site/index.html`, `site/visit.html`, `site/collections.html` — complete HTML documents;
  each page contributes a full-bleed banner (`<img>` + overlay) and its `<main>` content.
- `site/collections/oaks.md`, `maples.md`, `witch-hazels.md` — pure Markdown + YAML
  frontmatter; curators never touch HTML.
- `site/style.css`, `site/images/` (copies of the four provided photos).
