---
title: The Witch Hazels
description: A curator's guide to the witch hazel collection at Alderfen Arboretum.
class: collections
---

The witch hazels are kept by **Priya Nandal**, our youngest curator, who joined on a
working-party day and stayed for the winter flowers. The collection is at its best in
**February**, when nothing else in the arboretum is flowering and the glen smells of
honey and smoke.

## What is here

Twenty-two shrubs, most of them *Hamamelis* × *intermedia* cultivars — 'Jelena' in copper,
'Arnold Promise' in clear lemon, 'Diane' in red — with three Virginiana at the stream end
and a paller-looking old 'Pallida' by the boardwalk that predates the planting scheme.
Every one is named on the register; half of them are named in pencil too, on tags that
Priya keeps replacing until the paint takes.

## Walking it

Come in at the bridge and walk against the scent; you will find the glen before the sign.
The flowers open and curl back in cold weather, so a mild February week — not a warm one —
is the moment. From the upper viewing platform you can see the whole glen at once, and
there are no steps to the platform from the main loop.

## When to come again

Autumn, for the yellow of the leaves, which is a better secret than the flowers; and May,
when the young seeds pop and throw their cases a metre, if you are very still.
