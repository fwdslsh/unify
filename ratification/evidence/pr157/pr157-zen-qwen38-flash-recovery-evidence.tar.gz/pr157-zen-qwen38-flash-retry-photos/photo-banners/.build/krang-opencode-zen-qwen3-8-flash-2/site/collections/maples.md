---
title: The Maples
description: A curator's guide to the maple collection at Alderfen Arboretum.
class: collections
---

The maples are the collection of **Edmund Hale**, a retired joiner who took over the west
slope in 1990 and has never quite let go of it. The collection is at its best in
**November**, when the slope turns and can be seen from the church tower.

## What is here

Thirty-six trees in nine species. The Japaneses — a dozen cultivars, each worth its
patience — line the stepped path up the west slope; the larger trunks are our own
field maples and two Norways that have outgrown their label and everyone's plan. The
palmate at the top of the steps is Edmund's favourite, and he will tell you so if you
catch him sweeping.

## Walking it

Climb the stepped path slowly; the colour is best from halfway up, looking down with the
low November sun behind the leaves. The bench at the crown was cut by Edmund from a wind-
thrown sycamore — a tree he does not count in the collection and is right about.

## When to come again

Late April, for the red seed heads of the field maples, and a calm frosty morning in
November — the leaves shine wet and the whole slope looks lit from inside.
