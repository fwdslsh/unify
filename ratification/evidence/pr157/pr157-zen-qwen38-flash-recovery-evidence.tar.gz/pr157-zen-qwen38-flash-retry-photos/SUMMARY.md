# Ratification round pr157-zen-qwen38-flash-retry-photos

- **unify** 0.11.18 at `83bc115168cb` (working tree)
- **rules** `fb07d931bd36` · **prompt** `456131468750` · **agent** opencode 1.18.25 · **models** krang/opencode-zen/qwen3.8-flash · **isolation** mount namespace, probe clean
- 2026-11-09T00:40:53.180Z to 2026-11-09T00:46:08.657Z; scored 2026-11-09T00:46:08.661Z

## Score

**2 of 2 samples completed their brief: every scored check passed (100%).**

The protocol's bar, at least 4 of 5 samples of a model on each brief: not measured: the bar needs at least 5 samples per brief and model, so this score is indicative.

| Brief | Model | Passed | Checks that failed |
|---|---|---|---|
| photo-banners | krang/opencode-zen/qwen3.8-flash | 2/2 | — |

## photo-banners — Photo banners on every section under a subpath, with extensionless addresses

*round 22: does anyone ship a root-relative url() that 404s under the subpath.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | css-urls | Result |
|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 5m15s | 21 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | 3m43s | 17 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> ## What `rules.md` did not answer
> 
> The sentence I wanted and could not find: **how to link to a page whose source is
> Markdown.** The rule says "Always link the real filename — `/about.html`, not
> `/about/`", but my guides are `oaks.md`, whose "real filename" is neither of the two
> spellings a link needs. Is it `/collections/oaks.md`? `/collections/oaks.html`? Nothing
> says. I wrote `/collections/oaks.html`, and `--dry-run --strict` reported no broken
> link and rewrote it to `/arboretum/collections/oaks/` — so it holds, but by experiment,
> not by reading.
> 
> Closely related and also unanswered: the docs never spell out **what the
> `--base-url` prefix looks like in the emitted HTML** — root-relative `/arboretum/...`

**krang-opencode-zen-qwen3-8-flash-2**

> ## What `rules.md` did not answer
> 
> - **Nothing about `index.html` under `--pretty-urls`.** The rule shown is
>   `about.html → about/index.html`; would the root page fold to a directory too? I found
>   out from the dry-run report (`write dist/index.html (/arboretum/)`), not from the docs.
> - **Nothing about `--pretty-urls` + `--base-url` interaction on the links I wrote.** I
>   wrote `/index.html` in the nav; the output shows it became `/arboretum/`. That the home
>   link folds all the way to the base URL is plausible, but nowhere stated.
> - **The sitemap.** I only knew `--base-url` "generates sitemap.xml" from `./unify --help`;
>   `rules.md` never mentions it. Likewise it doesn't say (in prose) that the *default*
>   `--canonical auto` gives every page that authors none its absolute URL — the Markdown
>   section only warns that a layout must never set canonical.


---

`✓` passed, `✗` failed, `(i)` reported but not scored. Each sample's directory is `<brief>/<sample>/`, its OpenCode event stream and session data are in `<brief>/.harness/<sample>/`, and the build the checks read is `<brief>/.build/<sample>/`. Triage every failure with ratification/ratification-protocol.md before changing anything.
