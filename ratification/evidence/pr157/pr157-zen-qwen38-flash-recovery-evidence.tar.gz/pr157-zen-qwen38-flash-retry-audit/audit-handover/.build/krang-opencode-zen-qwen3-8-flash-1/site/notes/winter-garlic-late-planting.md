---
title: Winter garlic went in late this year
description: "Garlic notes from the community bed: why the cloves went in two weeks late, and what we expect from the hardneck rows."
date: 2026-11-07T16:30:00Z
author: Marta Ilves
schema: Article
og:type: article
---

# Winter garlic went in late this year

Every autumn I mean to have the garlic in the ground by the end of October. This
year the bed stayed waterlogged past All Saints, and the hardneck cloves only
went into their trenches this week — about two weeks later than I would like.

The rule of thumb the library teaches is simple: garlic wants six cold weeks
before it starts pushing a scape. A late planting usually answers by making a
smaller bulb, not by failing. I mulched the rows with seed-free straw as soon
as the cloves were covered, which keeps the soil workable and stops the frost
heaving the shallow roots.

If you took *Musanovskij* or *Czech Red* from our shelf this spring, save the
biggest, cleanest cloves for next October — a late season needs strong cloves.
Label the jar with the variety name, the way you found it.
