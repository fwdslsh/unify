# Fernway Seed Library — handover report

## Publish command

```
./unify build
```

The address options live in `unify.yaml` (written with `--save-config` after the first
good build), so the bare command publishes the site for `https://fernway.example/library/`:

```yaml
pretty-urls: true
base-url: https://fernway.example/library/
generate: site/_scripts/gen.mjs
```

## Checks run — final outputs

`./unify build --dry-run --strict` — every check in one pass; also lists each page with
the layout it resolved to:

```
$ ./unify build --dry-run --strict
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 3 pages would gain a JSON-LD block
copy dist/assets/card.svg (/library/assets/card.svg) ← assets/card.svg
copy dist/assets/seed.svg (/library/assets/seed.svg) ← assets/seed.svg
copy dist/assets/style.css (/library/assets/style.css) ← assets/style.css
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/index.html (/library/notes/) ← generated + _layout.html
write dist/notes/march-shelf-from-cards/index.html (/library/notes/march-shelf-from-cards/) ← notes/march-shelf-from-cards.md + _layout.html
write dist/notes/return-day-harvest/index.html (/library/notes/return-day-harvest/) ← notes/return-day-harvest.md + _layout.html
write dist/notes/winter-garlic-late-planting/index.html (/library/notes/winter-garlic-late-planting/) ← notes/winter-garlic-late-planting.md + _layout.html
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 11 files to dist/
exit=0
```

`./unify audit` — the blocking check:

```
$ ./unify audit
audit: nothing to report
exit=0
```

`./unify audit --strict` — counts non-blocking findings (`incomplete`, advisories); this is the
one that initially failed, with six `image-missing-dimensions` reports that I fixed by adding
`og:image:width`/`og:image:height` to the layout:

```
$ ./unify audit --strict
audit: nothing to report
exit=0
```

`./unify audit --strict --external` — fetches every off-origin URL the site emits; the site
emits none (nothing loads from another website), so there was nothing to resolve:

```
$ ./unify audit --strict --external
audit: nothing to report
exit=0
```

## What `rules.md` did not answer

The generate-script calling contract. The sentence I wanted — and could not find — is
"unify runs the script with the generated directory as argv[3] and the path of a
generator-context file as argv[4]". The docs only say the script "writes into the directory
unify hands it"; *how* it is handed that directory, and where `source-pages.json` lives, are
nowhere stated. I discovered the argv order and the context JSON (which contains
`inputs.sourcePages`) by running a probe script that dumped `process.argv`, `process.cwd()`,
and the context file. Related gaps: nothing says `unify audit` refuses a saved `clean:`
config key (it errored `exit=2` until I removed it), and nothing warns that
`build --dry-run --strict` passes while `audit --strict` fails — dry-run did not report the
image-dimension incompletes, so relying on it alone would have shipped a rejected site.
The check surface itself (`audit`, `--strict`, `--external`) is not in rules.md at all; only
in `--help`.

## What I re-read, and why it did not land the first time

- The Files paragraph about `--base-url`. It buries the load-bearing clause "makes
  og:/canonical absolute" inside a sentence that opens on trailing slashes, so my first read
  was "I must write absolute og: URLs myself"; re-reading it against the output ("a leading
  `/` means the source root, in any path you write") is what made me write `/assets/card.svg`
  in the layout and trust the build.
- The Head-merge paragraph: "og:title/og:description/og:url default to final
  title/description/canonical … No missing value or Twitter tag is invented." It did not land
  because "invented" reads two ways at speed — the point is that unify fills og: tags you never
  wrote, but will not add `twitter:card` for you; I needed a second pass to see which half was
  a promise and which was a warning.
- The Layout/Merging sections generally: "the first default-content page main unwraps, even
  for a bare slot outside a layout main" took three readings; I still cannot fully explain it,
  so I sidestepped by putting page content in the body without a `main` and verified in the
  output that the layout's `<main>` wrapped it correctly.
- "Scripts go under a leading underscore" versus the example `generate: scripts/gen.mjs`: the
  example and the rule appeared to contradict, which made me re-read the underscore rule and
  realize scripts in the source root must be `_`-prefixed to stay out of the published output.

## What I guessed at or inferred rather than read

- Script location: the example writes `scripts/gen.mjs` but the underscore rule says scripts
  must live under `_` to not ship, so I guessed `site/_scripts/gen.mjs`; the tool's own
  `--save-config` later confirmed that spelling (`generate: site/_scripts/gen.mjs`).
- That a layout-declared `og:image` propagates to every page and into the generated
  JSON-LD's `image` — inferred from "everything else appends after"; rules only spell out the
  defaults for og:title/description/url.
- That `twitter:card` belongs in the layout head and merges onto pages; and that `og:type`
  per page overrides the layout's via "your `<meta>` replaces the same-`property`".
- Dates: I inferred `2026-11-07T16:30:00Z` is the safe spelling because the docs say
  time-less dates are "reported and left out" of the feed, and JSON-LD lists
  `2026-01-02T09:30:00Z` as a readable form.
- That the notes index belongs in the overlay as `notes/index.html` and would be treated as a
  page (wrapped by `_layout.html`, rewritten by `--pretty-urls`) — nothing says a generated
  overlay file joins the page set; the dry-run listing confirmed it after the fact.
- That "every check the tool offers, including the ones that do not block a build" means
  `audit --strict` plus `--external` in addition to the dry-run — the phrase is from the
  brief, not from rules.md.
- The `headline` suffix: JSON-LD carries `"<post title> — Fernway Seed Library"` because the
  schema uses the final joined title. Whether that's desirable for an article headline isn't
  documented; I accepted it rather than fight it (a per-page override would require
  hand-writing JSON-LD, which the brief forbids).
- The SVG placeholder for `og:image`: nothing says crawlers accept SVG, and no rule forbids
  it; the brief's "write a small placeholder SVG wherever one is needed" is the only guidance.
