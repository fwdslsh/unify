---
title: Ordering the March shelf from last year's cards
description: "How we turn the little signed cards inside each packet into next season's borrowing list — and which three varieties the valley asked for that we cannot supply yet."
date: 2026-09-30T18:00:00Z
author: Priya Nandakumar
schema: Article
og:type: article
---

# Ordering the March shelf from last year's cards

Every packet at Fernway carries a small card, and every card is a data point.
This week the sorting table was covered in them: who grew what, whether it
held true, and how big the return was.

Four seasons of cards tell a clear story. *Caullet Blanc* early cauliflower is
quietly the valley's favorite — borrowed nine times, returned nine times, all
labeled true. The tomatoes split two ways: the cherry types fly off the shelf
and come back doubled; the big beefsteaks are borrowed once or twice a year
and sometimes do not come back at all.

Three varieties were requested that we cannot supply: a saving onion for the
heavy soil down by the mill, a flint corn for winter porridge, and — asked for
by two separate schoolteachers — a sunflower short enough for a classroom
windowsill. If you are saving any of these and would trust us to lend them
on, bring the seed to Return Saturday and we will start a card for you.
