import fs from 'node:fs'
import path from 'node:path'

const [, , sourceRoot, generatedRoot, ctxPath] = process.argv
const ctx = JSON.parse(fs.readFileSync(ctxPath, 'utf8'))
const inv = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, 'utf8'))

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December']

const posts = inv.pages
  .filter(p => /^notes\/[^_].*\.md$/.test(p.source))
  .map(p => ({ ...p, moment: Date.parse(p.date ?? '') }))
  .filter(p => Number.isFinite(p.moment))
  .sort((a, b) => b.moment - a.moment)

const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')

function entry (p) {
  const d = new Date(p.moment)
  const label = `${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]} ${d.getUTCFullYear()}`
  const iso = p.date.slice(0, 10)
  const author = (p.meta.find(m => m.name === 'author') || {}).content ?? ''
  return `      <article class="note-teaser">
        <h2><a href="${esc(p.href)}">${esc(p.title)}</a></h2>
        <p class="note-meta"><time datetime="${esc(iso)}">${esc(label)}</time> · ${esc(author)}</p>
        <p>${esc(p.description)}</p>
      </article>`
}

const body = posts.length
  ? posts.map(entry).join('\n')
  : '      <p>No notes yet.</p>'

const page = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Field Notes</title>
<meta name="description" content="Field notes from Fernway Seed Library volunteers — seed-saving logs, return-day tallies, and shelf plans, newest first.">
</head>
<body class="notes">
<h1>Field Notes</h1>
<p>Notes kept by the volunteers who tend the shelf, newest first.</p>
<div class="note-list">
${body}
</div>
</body>
</html>
`

const out = path.join(generatedRoot, 'notes', 'index.html')
fs.mkdirSync(path.dirname(out), { recursive: true })
fs.writeFileSync(out, page)
