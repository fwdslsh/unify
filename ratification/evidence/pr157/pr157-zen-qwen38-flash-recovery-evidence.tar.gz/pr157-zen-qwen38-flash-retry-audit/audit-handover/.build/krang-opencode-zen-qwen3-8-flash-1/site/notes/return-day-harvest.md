---
title: "Return day: what came back, and what it cost us"
description: "Notes from the October return table — clean seed by weight, three unlabeled jars, and one packet of mystery beans we are choosing to trust."
date: 2026-10-24T09:00:00Z
author: Oskar Rein
schema: Article
og:type: article
---

# Return day: what came back, and what it cost us

Return Saturday filled the whole potting bench. By noon we had weighed, counted
and shelved:

- 3.1 kg of *Provider* runner bean seed from four households
- 640 g of *Nigella* losses, mostly clean, one jar with a lot of chaff
- A shoebox of dahlias' dried seed heads, still to be threshed

Not everything came back honest. Three jars had no variety slip in them, so
they go on the unlabeled shelf at the back, priced at two packets each: you
may take two, but you tell us where they came from. One grower returned
beans that look nothing like the *Provider* they borrowed — smaller, pale
green, and they climb the wrong way. We are keeping them as *Fernway Mystery
Climber* and lending them next year on the honor of whoever saved them.

Thank you to everyone who dried, winnowed and labeled before coming. The
cleaner your return, the faster the shelf fills for March.
