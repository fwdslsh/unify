# Ratification round pr157-zen-qwen38-flash-retry-audit

- **unify** 0.11.18 at `83bc115168cb` (working tree)
- **rules** `fb07d931bd36` · **prompt** `456131468750` · **agent** opencode 1.18.25 · **models** krang/opencode-zen/qwen3.8-flash · **isolation** mount namespace, probe clean
- 2026-11-09T00:39:33.496Z to 2026-11-09T00:45:55.651Z; scored 2026-11-09T00:45:55.652Z

## Score

**1 of 1 samples completed their brief: every scored check passed (100%).**

The protocol's bar, at least 4 of 5 samples of a model on each brief: not measured: the bar needs at least 5 samples per brief and model, so this score is indicative.

| Brief | Model | Passed | Checks that failed |
|---|---|---|---|
| audit-handover | krang/opencode-zen/qwen3.8-flash | 1/1 | — |

## audit-handover — Hand over only when every check the tool offers reports nothing

*round 28; checks follow its pre-registered V1-V4, plus the brief's extensionless addresses.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | audit-strict | article-data | share-cards | ran-audit | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 6m22s | 46 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |

- krang-opencode-zen-qwen3-8-flash-1 · **ran-audit** (not scored): 7 runs matching /unify audit/

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> ## What `rules.md` did not answer
> 
> The generate-script calling contract. The sentence I wanted — and could not find — is
> "unify runs the script with the generated directory as argv[3] and the path of a
> generator-context file as argv[4]". The docs only say the script "writes into the directory
> unify hands it"; *how* it is handed that directory, and where `source-pages.json` lives, are
> nowhere stated. I discovered the argv order and the context JSON (which contains
> `inputs.sourcePages`) by running a probe script that dumped `process.argv`, `process.cwd()`,
> and the context file. Related gaps: nothing says `unify audit` refuses a saved `clean:`
> config key (it errored `exit=2` until I removed it), and nothing warns that
> `build --dry-run --strict` passes while `audit --strict` fails — dry-run did not report the
> image-dimension incompletes, so relying on it alone would have shipped a rejected site.


---

`✓` passed, `✗` failed, `(i)` reported but not scored. Each sample's directory is `<brief>/<sample>/`, its OpenCode event stream and session data are in `<brief>/.harness/<sample>/`, and the build the checks read is `<brief>/.build/<sample>/`. Triage every failure with ratification/ratification-protocol.md before changing anything.
