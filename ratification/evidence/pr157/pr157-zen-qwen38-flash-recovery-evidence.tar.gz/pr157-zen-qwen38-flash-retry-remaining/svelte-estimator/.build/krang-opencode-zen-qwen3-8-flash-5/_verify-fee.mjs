import fs from 'node:fs';
import { JSDOM } from 'jsdom';

const dom = new JSDOM(fs.readFileSync('dist/courses/index.html', 'utf8'), {
  runScripts: 'dangerously',
  url: 'https://thistleknap.pages.dev/forge/courses/',
});

// jsdom won't fetch the script src by default unless resources; feed it manually.
const fee = fs.readFileSync('dist/fee.js', 'utf8');
dom.window.eval(fee);

const { document } = dom.window;
const calc = document.querySelector('.fee-calc');
if (!calc) throw new Error('component did not mount into #fee-calculator');

const [people, hours] = calc.querySelectorAll('input[type=number]');
const total = calc.querySelector('p');

function check(label, expected) {
  const got = total.textContent.trim();
  if (got !== expected) throw new Error(`${label}: expected "${expected}", got "${got}"`);
  console.log(`OK  ${label} -> ${got}`);
}

async function type(input, v) {
  input.value = v;
  input.dispatchEvent(new dom.window.Event('input', { bubbles: true }));
  await new Promise((r) => setTimeout(r, 0)); // let Svelte flush its DOM update
}

// defaults: 2 people, 3 hours -> 2*3*18 + 2*12 = 132
check('defaults', 'Estimated cost: £132');

// 5 people: 5*3*18 + 5*12 = 270 + 60 = 330
await type(people, '5');
check('5 people', 'Estimated cost: £330');

// 5 people, 4 hours: 5*4*18 + 60 = 360 + 60 = 420
await type(hours, '4');
check('4 hours', 'Estimated cost: £420');

if (!dom.window.document.head.querySelector('style[data-svelte]')) {
  console.log('NOTE: no injected <style> (component has no styles — fine)');
} else {
  console.log('OK  injected component CSS present');
}
console.log('PASS: estimator is live in the DOM, updating on input without a reload');
