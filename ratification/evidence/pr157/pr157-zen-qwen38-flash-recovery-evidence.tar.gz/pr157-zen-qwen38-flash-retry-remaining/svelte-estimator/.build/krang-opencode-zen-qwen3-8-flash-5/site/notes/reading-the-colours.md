---
date: 2026-04-25T20:30:00Z
description: "Session notes from the April beginner evening — fire colours, and why two of us scorched a taper."
schema: BlogPosting
---

# First Fire: reading the colours

Six tongs pulled, one warped hinge, and a lot of good heat. Notes for the next group:

- The steel tells you when it is ready. Cherry red is soft; orange is where you want to
  be; yellow means get it on the anvil *now* or you are burning carbon out of it.
  Half the class spent too long admiring yellow. The anvil does not admire it back.
- Keep the blow low while you bring a cold bar up. Cranking the blower straight away is
  how we scorched Tuesday's taper — bright yellow outside, still cold in the middle.
- Turn the stock a quarter every few seconds over the fire. Forgetting is how the hinge
  came out of the fire already bent.

Homework: look at the photos on the notice board and learn the difference between
cherry, orange and yellow before Friday. — M. Arden
