import FeeCalculator from '../components/FeeCalculator.svelte';

function mount() {
  const target = document.getElementById('fee-calculator');
  if (!target) return;
  target.innerHTML = '';
  new FeeCalculator({ target });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', mount);
} else {
  mount();
}
