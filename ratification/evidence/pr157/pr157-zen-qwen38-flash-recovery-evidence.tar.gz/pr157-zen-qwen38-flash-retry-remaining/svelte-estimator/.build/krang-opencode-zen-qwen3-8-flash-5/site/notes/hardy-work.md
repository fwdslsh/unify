---
date: 2026-05-30T13:15:00Z
description: "Tools-for-the-Bench Saturday: punching, the drifting chain, and keeping the hardy steady."
schema: BlogPosting
---

# Hardy work and the punch that wandered

Good turnout for the Saturday tools session. What we learned, in order of pain:

- Punch early and punch hot. The hole that wandered across the chisel was punched at
  dull-red heat from one side only. Flip the stock and punch the shoulder from the back,
  and the punch goes where you put it.
- Drift, don't drill. Everything forged gets its final shape from the drift, so make the
  punch hole an honest start and let the taper do the talking.
- A hardy that rocks in the square is a safety problem, not an accuracy problem. Shim
  with the tapered keys, never with folded plate, and check the anvil's hardy hole for
  swarf before every bench.

The finished split chisels came out beautifully — four of five hardened and tempered
without a crack. The fifth taught us why you quench point-first. — M. Arden
