---
date: 2026-05-09T18:45:00Z
description: "Mid-May bench session — drawing tapers, the washing problem, and the flat-finish cure."
schema: BlogPosting
---

# Drawing out without washing

Tonight's bench was all drawing out: square to round, round to point, and learning what
"drawing" is not.

- Drawing is many light blows travelling along the bar, not hard blows in one place.
  Everyone's first taper had a shoulder in it until they started walking the hammer.
- "Washing" — that crinkled, folded skin on a taper — came from working below forging
  heat and from a dirty fire. Clean fire, hotter steel, lighter blows. Two of three
  tapers went smooth the second heat.
- Finish on the flat of the face for the last few blows. The class could see the
  difference across the room, which is how you know it matters.

Mind for next week: we start scrolling, and everybody should practise turning the bar
with the left hand first. — J. Cove
