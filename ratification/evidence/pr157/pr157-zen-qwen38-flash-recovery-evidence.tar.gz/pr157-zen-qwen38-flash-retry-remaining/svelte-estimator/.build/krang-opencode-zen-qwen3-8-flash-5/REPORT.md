# Thistleknap Forge — build report

## The publish command

From this directory, after a one-time `npm install`:

```
./unify build
```

That is the complete, repeatable publish: it compiles the Svelte estimator, regenerates
the notes index, and writes the whole site to `dist/`, correct for
`https://thistleknap.pages.dev/forge/`. The options live in `unify.yaml`:

```yaml
generate: scripts/gen.mjs
pretty-urls: true
base-url: https://thistleknap.pages.dev/forge/
```

(`base-url`/`pretty-urls` were persisted by `./unify build --base-url … --pretty-urls
--save-config`; the equivalent explicit command line is
`./unify build --base-url https://thistleknap.pages.dev/forge/ --pretty-urls`.)

## The estimator's build command

Nobody runs it directly — `scripts/gen.mjs`, registered as `generate:`, is run by unify
before every build, so the single `./unify build` above **is** the one command the
collective runs when a new revision of `components/FeeCalculator.svelte` arrives. Inside
the hook it performs the equivalent of:

```
esbuild fee-src/entry.js --bundle --format=iife --define:process.env.NODE_ENV='"production"' --outfile=<overlay>/fee.js   # with the esbuild-svelte plugin, compilerOptions: { css: 'injected' }
```

so the shipped `fee.js` contains the developer's component **plus the Svelte runtime**,
inlined — nothing is fetched from another website. Toolchain: `svelte@4` (the component
is `export let` / `$:` Svelte-4 syntax), `esbuild`, `esbuild-svelte`.

## How it is put together

- `site/_layout.html` carries the anvil-mark header (inline SVG), nav, footer, stylesheet
  and favicon link; every page, including the generated index, is wrapped by it.
- Pages: `index.html`, `courses.html`, `visit.html`, plus three dated Markdown notes in
  `site/notes/` (front matter `date:` with time, `schema: BlogPosting`, quoted `description`).
  `--pretty-urls` gives addresses like `/forge/courses/`; `--base-url` prefixes every
  link and generates `feed.xml` + `sitemap.xml` at the site's own address.
- `scripts/gen.mjs` writes two things into the overlay directory unify hands it:
  `fee.js`, and `notes/index.html` — the index is derived from the build's
  `source-pages.json` inventory, sorted newest date first (with a first-heading fallback
  for notes whose author skipped `title:`), so it can never drift when someone forgets
  to update it by hand.
- The Courses page links its own `<script src="/fee.js" defer></script>` — unify rewrites
  that to `/forge/fee.js` — and mounts the component into `#fee-calculator`; a `<noscript>`
  states the arithmetic.
- `drafts/` sits outside the source root (`site/`) and never ships; no CSS `url()` or
  `fetch`/`hx-get` exists that could miss the base prefix.

## Verification (no browser; against the built `dist/`)

1. `./unify build --dry-run --strict`, then `./unify build` (exit 0) and
   `./unify audit --strict` → "nothing to report".
2. `find dist`: exactly 13 files — no `.md`, no `drafts` content anywhere (grep).
3. `node _check-links.mjs`: every `href`/`src` in every built page starts with `/forge/`,
   none ends in `.html`, and all 17 resolve to a real file in `dist` at that address.
4. `node _verify-fee.mjs` (jsdom): loads the actual `dist/courses/index.html`, evals the
   actual `dist/fee.js`, and checks the component mounts and the total updates on `input`
   **without a reload**: defaults £132 → 5 people £330 → 4 hours £420. So yes — the
   estimator's code reaches the visitor's browser at
   `https://thistleknap.pages.dev/forge/courses/`.
5. Repeat-rability proven: I changed `hourlyRate` 18 → 20 in the `.svelte` file, ran plain
   `./unify build`, and jsdom then computed £144 from the rebuilt `dist/fee.js`. Reverted
   and rebuilt. Also dropped a fourth dated note into `site/notes/`: the rebuilt index
   listed it first, untouched by hand; removing it and rebuilding restored three items.

## What `rules.md` did not answer

- It never says **how the generate script receives the "directory unify hands it"** —
  not as argv, not as env, just "it writes into the directory". I discovered by running
  one: `argv[2]` = source root, `argv[3]` = a generated *overlay* directory, `argv[4]` =
  a context JSON whose `inputs.sourcePages` points at the inventory. The sentence I
  wanted and could not find: *"The generate script is called with the source root, the
  generated overlay directory and a context file as its arguments."*
- It does not say that **files written into the overlay get the full treatment** — layout,
  `--base-url` prefixing, `--pretty-urls` — though everything works that way. I inferred
  it from "Derived files (a post index)", then tested it before relying on it.
- The **shape of `source-pages.json`** is undocumented (keys `source/href/title/date/…`),
  including that `href` for a `.md` page names the `.md`, so my index maps `.md` → `.html`
  itself — a guess the passing audit and link checker confirmed.
- Undocumented: the inventory's `title` is only the *authored* front-matter title — a note
  titled by its first `# heading` reports `title: null` even though the rendered page
  title follows rule line 54. I hit "Untitled note" in the index and added the
  first-heading fallback.
- Whether a `<script src>` attribute is one of "HTML's own URL attributes" that unify
  rewrites is implied but not enumerated; the built page shows `/forge/fee.js`, so yes.
- The `unify.yaml` vocabulary beyond `generate:` (and that `base-url`/`pretty-urls` are
  even valid keys) is not in `rules.md`; `--save-config` from the CLI help told me.

## What I re-read, and why it didn't land the first time

- The Include/fragment paragraphs (rule lines 21–23). I read them three times: the
  "content between the tags fills slots" case, "fills reach that fragment's slots and no
  deeper", and the `slot=`-on-children grammar are one dense block, and I was trying to
  decide whether to use fragments for the notes index — until I realized the layout
  already does all shared chrome and I need no includes at all.
- The Head-merge block (line 44). The key sentence — "your `<meta>` replaces the layout's
  same-`name`/`property`" — sat mid-paragraph behind the title-separator etiquette; it
  only clicked on the second read, when I needed per-page descriptions to clear the
  `description-duplicate` audit finding.
- Lines 5–6: the generate-script convention lives inside a flowing prose sentence about
  feeds, not a section of its own, so I initially missed `generate: scripts/gen.mjs` and
  built my first test with `--generate` only.

## What I guessed at or inferred rather than read

- The entire Svelte toolchain choice (Svelte 4 because of `export let`/`$:`, esbuild +
  esbuild-svelte, `css: 'injected'`, IIFE, mounting from a small `fee-src/entry.js`) —
  neither document says anything about JS compilation; rules.md is explicitly about a
  build that "never… injects CSS/JS", and I honored that by making the *script* produce
  the bundle, not unify.
- That `scripts/gen.mjs` can `import` from `node_modules` under unify's bundled runner
  (it runs on an embedded bun — hinted only by an error message quoting `BUN_BE_BUN=1`).
  I verified esbuild's native binary works there before designing around it.
- The publish command as a bare `./unify build` depends on saved `unify.yaml` options;
  "or save settings in `unify.yaml` when useful" is the license I inferred it from.
- The 4th-note test, the link checker, and `--save-config` for config persistence were my
  own inventions to satisfy "correct for that address", not steps either document mandates.
