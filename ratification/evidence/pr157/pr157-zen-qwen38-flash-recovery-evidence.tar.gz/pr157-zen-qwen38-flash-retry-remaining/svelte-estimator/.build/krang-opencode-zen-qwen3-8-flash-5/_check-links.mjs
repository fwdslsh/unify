import fs from 'node:fs';
import path from 'node:path';
const dist = 'dist';
const files = [];
(function walk(d) { for (const e of fs.readdirSync(d, {withFileTypes:true})) {
  const p = path.join(d, e.name);
  e.isDirectory() ? walk(p) : files.push(p); } }) (dist);
const urls = new Set();
for (const f of files.filter(f => f.endsWith('.html'))) {
  const html = fs.readFileSync(f, 'utf8');
  for (const m of html.matchAll(/(?:href|src)="([^"]+)"/g)) urls.add(m[1]);
}
let bad = 0;
for (const u of urls) {
  if (u.startsWith('http')) {
    if (!u.startsWith('https://thistleknap.pages.dev/') && !u.includes('www.w3.org')) { console.log('EXTERNAL LOAD?', u); bad++; }
    continue;
  }
  if (u.startsWith('mailto:') || u.startsWith('#')) continue;
  if (!u.startsWith('/forge/')) { console.log('MISSING PREFIX', u); bad++; continue; }
  if (u.endsWith('.html')) { console.log('HTML IN URL', u); bad++; continue; }
  const rel = u.slice('/forge/'.length) || 'index.html';
  const asIs = path.join(dist, rel);
  const asDir = path.join(dist, rel, 'index.html');
  if (!fs.existsSync(asIs) && !fs.existsSync(asDir)) { console.log('404 AT ADDRESS', u); bad++; }
}
console.log(bad ? `FAIL ${bad}` : `PASS ${urls.size} emitted URLs all resolve under https://thistleknap.pages.dev/forge/`);
process.exit(bad ? 1 : 0);
