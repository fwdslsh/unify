import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { build } from 'esbuild';
import sveltePlugin from 'esbuild-svelte';

const sourceRoot = process.argv[2];
const overlay = process.argv[3];
const contextPath = process.argv[4];
const projectRoot = path.dirname(sourceRoot);

const context = JSON.parse(fs.readFileSync(contextPath, 'utf8'));
const inventory = JSON.parse(fs.readFileSync(context.inputs.sourcePages, 'utf8'));

// 1. Compile the volunteer developer's Svelte component into a browser bundle.
//    Everything in the bundle ships as one generated file, fee.js.
await build({
  entryPoints: [path.join(projectRoot, 'fee-src', 'entry.js')],
  outfile: path.join(overlay, 'fee.js'),
  bundle: true,
  format: 'iife',
  platform: 'browser',
  define: { 'process.env.NODE_ENV': '"production"' },
  legalComments: 'none',
  plugins: [sveltePlugin({ compilerOptions: { css: 'injected', dev: false } })],
});

// 2. Regenerate the notes index from the page inventory, newest date first.
//    The index can never drift from the notes, because nobody writes it by hand.
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'];

const notes = inventory.pages
  .filter((p) => p.source.startsWith('notes/') && p.source.endsWith('.md'))
  .sort((a, b) => String(b.date ?? '').localeCompare(String(a.date ?? '')));

function titleOf(p) {
  if (p.title) return p.title;
  let body = fs.readFileSync(path.join(sourceRoot, p.source), 'utf8');
  body = body.replace(/^---\n[\s\S]*?\n---\n/, '');
  const m = body.match(/^# (.+)$/m);
  return m ? m[1].trim() : 'Untitled note';
}

const items = notes.map((p) => {
  const href = p.href.replace(/\.md$/, '.html');
  const d = p.date ? new Date(p.date) : null;
  const label = d && !Number.isNaN(d.getTime())
    ? `${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]} ${d.getUTCFullYear()}`
    : 'undated';
  const iso = String(p.date ?? '').slice(0, 10);
  const desc = p.description ? ` — ${p.description}` : '';
  return `  <li>
    <h3><a href="${href}">${esc(titleOf(p))}</a></h3>
    <p class="note-meta"><time datetime="${iso}">${label}</time>${esc(desc)}</p>
  </li>`;
}).join('\n');

fs.mkdirSync(path.join(overlay, 'notes'), { recursive: true });
fs.writeFileSync(path.join(overlay, 'notes', 'index.html'), `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Course notes</title>
<meta name="description" content="Working notes from Thistleknap Forge course sessions, newest first.">
</head>
<body class="notes">
<main>
<h1>Course notes</h1>
<p>Written up after most sessions by the instructors. This list is generated from the
  notes themselves on every publish, newest first — it cannot go out of date.</p>
<ol class="note-list">
${items}
</ol>
</main>
</body>
</html>
`);

function esc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
