---
title: "Knife Weekend: the ones that warped"
description: "Saturday's knife group — why three blades came out of the quench curved, and the straightening drill for next time."
date: 2026-11-02T20:45:00Z
author: "Marta"
---

# Knife Weekend: the ones that warped

Three of our six blades came out of the quench with a bend along the spine, so tonight was
less about handles than about why.

## What we covered

- Stock selection: the warped ones were all cut slightly off the centreline of the bar. When the
  grind lines don't run the length of the bar, quench stress pulls the blade toward the heavy side.
- Quench technique again: two people hesitated at the surface and rocked the blade instead of
  drawing it straight down. Slow and straight, full length, no rocking. We practised with cold
  stock above the bucket until everyone looked boring at it.
- Straightening by hand: warm the spine *very* gently with a low flame, sight down the blade on
  the flat plate, tap high spots with a hammer held loose. Marta demonstrated on a scrap first —
  nobody touches a finished bevel with this.

## Practise before next month

Spend ten minutes sighting an old ruler down its length before you heat anything. If you can
spot a warp in a cold ruler you will spot one in a hot blade. Next session: handles, so bring
your (straight) blade — the ones that warped go back in the forge for a lesson we are all paying
for together.
