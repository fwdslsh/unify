import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const ctx = JSON.parse(fs.readFileSync(process.argv[4], 'utf8'));
const generatedRoot = ctx.paths.generatedRoot;
const inventory = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, 'utf8'));

const projectRoot = path.dirname(path.dirname(fs.realpathSync(process.argv[1])));

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'];

function formatDate(value) {
  const time = Date.parse(value);
  if (Number.isNaN(time)) return value;
  const d = new Date(time);
  return `${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]} ${d.getUTCFullYear()}`;
}

function sortKey(page) {
  const time = Date.parse(page.date ?? '');
  return Number.isNaN(time) ? -Infinity : time;
}

const notes = inventory.pages
  .filter((p) => /^notes\/[^/]+\.md$/.test(p.source) && p.href !== '/notes/index.html')
  .sort((a, b) => sortKey(b) - sortKey(a));

const items = notes.map((p) => {
  const date = p.date ? `<time datetime="${escapeHtml(p.date)}">${escapeHtml(formatDate(p.date))}</time>` : '<time>(undated)</time>';
  const description = p.description ? ` — <span class="note-desc">${escapeHtml(p.description)}</span>` : '';
  return `      <li>${date} <a href="${escapeHtml(p.href)}">${escapeHtml(p.title)}</a>${description}</li>`;
}).join('\n');

const list = notes.length === 0
  ? '<p class="note-list-empty">No course notes have been published yet. Check back after the next session.</p>'
  : `    <ul class="note-list">\n${items}\n    </ul>`;

fs.mkdirSync(path.join(generatedRoot, '_includes'), { recursive: true });
fs.writeFileSync(
  path.join(generatedRoot, '_includes', 'notes-index.fragment.html'),
  `<section class="notes-index" aria-labelledby="notes-index-heading">\n    <h2 id="notes-index-heading">Course notes <span class="note-count">(${notes.length} note${notes.length === 1 ? '' : 's'})</span></h2>\n${list}\n    <p><a class="notes-feed-link" href="/feed.xml">Subscribe to the notes feed</a></p>\n  </section>\n`,
);

fs.mkdirSync(path.join(generatedRoot, 'notes'), { recursive: true });
fs.writeFileSync(
  path.join(generatedRoot, 'notes', 'index.html'),
  `<!doctype html>\n<html lang="en" data-layout="/_layout.html">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>Course notes index</title>\n<meta name="description" content="Every course note from Thistleknap Forge, newest first.">\n</head>\n<body class="notes">\n<main>\n<h1>Course notes</h1>\n<p>Working notes from our instructors after each session, newest first. This index is rebuilt automatically from the notes in <code>site/notes/</code> on every build — nobody has to remember to update it by hand.</p>\n${list}\n</main>\n</body>\n</html>\n`,
);

execFileSync('node', [path.join(projectRoot, 'scripts', 'build-estimator.mjs'), path.join(generatedRoot, 'assets')], {
  cwd: projectRoot,
  stdio: 'inherit',
});
