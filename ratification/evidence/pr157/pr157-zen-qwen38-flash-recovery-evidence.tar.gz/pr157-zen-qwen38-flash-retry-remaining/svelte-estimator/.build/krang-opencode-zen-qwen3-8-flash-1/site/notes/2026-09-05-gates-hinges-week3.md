---
title: "Gates & Hinges week 3: hinges that actually swing"
description: "Hinge geometry, why two leaves sag equally, and the trick with the punch before you rivet."
date: 2026-09-05T16:00:00Z
author: "Devi"
---

# Gates & Hinges week 3: hinges that actually swing

Week three of the six-week gate course.

## What went well

Strap hinge layout with the 3-4-5 triangle worked for every pair this time — the leaves sat
parallel and the pin line was dead straight before a single rivet went in. If you skipped week
one: the punch goes through both leaves *before* fitting, with the leaves clamped square in the
vice. Mark, punch, check, *then* check again.

## What to practise

- The drift: round holes want a tapered drift, not a drill, and never force one.
- Rivet heat: cherry red, two solid taps, then let the blacksmith's patience do the rest.
- Bringing the gate: next week we hang mock-ups on the yard frame, all two of you who forgot it
  this week included.
