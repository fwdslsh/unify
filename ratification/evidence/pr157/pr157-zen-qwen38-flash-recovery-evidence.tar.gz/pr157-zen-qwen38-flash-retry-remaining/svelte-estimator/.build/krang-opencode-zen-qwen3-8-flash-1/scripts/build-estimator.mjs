import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, rmSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { compile } from 'svelte/compiler';
import { build } from 'esbuild';

const targetDir = process.argv[2];
if (!targetDir) {
  console.error('usage: node scripts/build-estimator.mjs <output-dir>   (writes <output-dir>/fee-calculator.js)');
  process.exit(2);
}

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const source = readFileSync(join(root, 'components', 'FeeCalculator.svelte'), 'utf8');
const { js, css } = compile(source, { generate: 'dom', dev: false });

const entry = `
import FeeCalculator from './FeeCalculator.js';
const injectedCss = ${JSON.stringify(css.code)};

function mount() {
  const target = document.getElementById('fee-calculator');
  if (!target || target.__feeCalculatorMounted) return;
  target.__feeCalculatorMounted = true;
  if (injectedCss && !document.getElementById('fee-calculator-styles')) {
    const style = document.createElement('style');
    style.id = 'fee-calculator-styles';
    style.textContent = injectedCss;
    document.head.appendChild(style);
  }
  new FeeCalculator({ target });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', mount);
} else {
  mount();
}
`;

const work = mkdtempSync(join(root, '.fee-calculator-build-'));
try {
  writeFileSync(join(work, 'FeeCalculator.js'), js.code);
  writeFileSync(join(work, 'entry.js'), entry);
  mkdirSync(resolve(targetDir), { recursive: true });
  await build({
    entryPoints: [join(work, 'entry.js')],
    bundle: true,
    format: 'iife',
    platform: 'browser',
    target: ['es2020'],
    minify: true,
    legalComments: 'none',
    outfile: join(resolve(targetDir), 'fee-calculator.js'),
  });
} finally {
  rmSync(work, { recursive: true, force: true });
}

console.log(`fee estimator built -> ${join(resolve(targetDir), 'fee-calculator.js')}`);
