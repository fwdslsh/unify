---
title: "First Strike Saturday: hooks, eyes and fire control"
description: "The beginner group's notes — drawing out taper, the three types of eye, and keeping a fire for four hours."
date: 2026-10-19T17:30:00Z
author: "Ivor"
---

# First Strike Saturday: hooks, eyes and fire control

Six beginners, two forges, one very good turnout for raking the fire.

## The work

Everyone started with a square bar and drew it out to a taper — heat, turn, hammer, repeat, and
keep the weld-ready glow in your head. Then the three classic eyes: the spiral eye for a hook,
the outward scroll, and the simple drive hanger. Half the group made the scroll look designed;
the other half made it look *interesting*. Both are fine on a first Saturday.

## Fire notes

- A happy fire is a small bright cone, not a volcano. If the coals glow up past the forge lip,
  you are burning money and your steel will scale like a rusted bucket.
- Rake, then dimple, then bury the work piece to a depth of about two fingers.
- The blower pedal is a suggestion, not an instruction. Hands up before you step on it.

## For next time

Bring a written list of three things at home you would like to hang on things. We will make the
hangers for them. And the usual: boots, glasses, sleeves. See you on the 26th.
