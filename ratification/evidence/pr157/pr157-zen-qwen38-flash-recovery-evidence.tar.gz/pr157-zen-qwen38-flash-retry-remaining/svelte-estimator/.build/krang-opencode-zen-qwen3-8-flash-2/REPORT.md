# Thistleknap Forge — build report

## Publish

One-time setup: `npm install` (pulls `svelte@4` and `esbuild`, the only tools the estimator build uses).

The publish command line:

```
./unify build --clean
```

`base-url`, `pretty-urls` and `generate` live in `unify.yaml`, so this is the whole command.
The equivalent spelled-out form is
`./unify build --clean --base-url https://thistleknap.pages.dev/forge/ --pretty-urls`.
Exit 0 means `dist/` is the complete site; non-zero publishes nothing.

The site tree is `site/` (source root), which is what keeps `drafts/`, `components/`,
`scripts/` and `node_modules/` out of `dist/`.

## Estimator build

The developer's `components/FeeCalculator.svelte` stays Svelte. It is compiled with the
Svelte 4 compiler and bundled (with `svelte/internal`) into a self-contained IIFE with
esbuild by `scripts/build-estimator.mjs`. Standalone, its build command is:

```
node scripts/build-estimator.mjs build        # or: npm run build:estimator
```

For publishing it is wired into the build itself: `unify.yaml` sets `generate: scripts/gen.mjs`,
and that generator calls the estimator build (plus writes the notes index) into the directory
unify hands it, before every build. So when a new revision of the `.svelte` file arrives, the
collective still runs exactly one command: `./unify build --clean`. The bundle is emitted as
`/assets/fee-estimator.js` (+ extracted `/assets/fee-estimator.css`, kept as a real stylesheet
because unify does not rewrite `url()` or injected CSS) and referenced from the Courses page
with `<link>`/`<script src>` — HTML attributes unify prefixes with `--base-url`.

The notes index works the same way: `scripts/gen.mjs` reads the per-build source inventory
(`source-pages.json`), collects every page under `notes/`, sorts by `date` newest first, and
writes `_gen/notes-index.fragment.html` into the generated directory, which the Courses page
`<include>`s. Instructors drop a new dated `.md` into `site/notes/` and the index regenerates
itself on the next publish — no hand-edited index.

## How I verified

- `./unify build --dry-run --strict` → exit 0; its report lists every page with the layout it
  resolved to (all seven pages on `_layout.html`).
- `./unify audit --strict` → "nothing to report", exit 0. (First run flagged the four note
  pages for no `<h1>` — Markdown with `title:` frontmatter emits no heading by itself — fixed
  by writing the visible H1 into each note and re-running.)
- `scripts/verify-dist.mjs`: walks `dist/`, extracts all 72 `href`/`src` values across the
  12 files; every one resolves under `/forge/` to a real file in `dist/`, none ends in `.html`,
  none is off-origin. Also asserts no draft paths/files in output.
- grep over `dist/`: every page carries the shared header, footer and the anvil-mark SVG twice
  each (header + footer); the Visit page has its own placeholder map SVG; no string from
  `drafts/forge-welding-notes.md` appears; CSS contains no `url()`.
- `scripts/test-estimator.mjs`: jsdom loads the actual built `dist/courses/index.html` with
  document URL `https://thistleknap.pages.dev/forge/courses/` and an interceptor that serves
  every subresource out of `dist/` by its published URL and **throws on any request not under
  that address** — so the test proves both that the estimator's code reaches a visitor's
  browser at the real address and that the page loads nothing foreign. The bundled Svelte
  component mounts into `#fee-calculator`, defaults to £132 (2 people, 3 h), and reacts to
  typed input without reload: 3×4 → £252, 8×6 → £960 — each matching
  `people × hours × £18 + people × £12`.
- Repeatability: I changed `hourlyRate` in the `.svelte` file, ran `./unify build`, confirmed
  the new value in `dist/assets/fee-estimator.js`, reverted, rebuilt, and re-ran the jsdom test.

## What `rules.md` did not answer

**The generator's invocation contract.** The docs say "unify runs it before every build and it
writes into the directory unify hands it" — but never *how the hand is given*. There is no
documented argv order, no documented context file, and no documented cwd. I had to write a
probe generator that printed `process.argv` and the file unify passes it
(`<generator-context.json>`, which names `generatedRoot`, the source inventory path, and the
effective `baseUrl`/`prettyUrls`) to learn: `unify <script.mjs> <sourceRoot> <generatedOverlay>
<context.json>`, cwd = source root, run by unify's own runtime (so the generator itself must
stay plain Node — I shell out to `node` for the Svelte/esbuild step rather than import them
under whatever runtime unify uses).

The sentence I wanted and could not find: **"files written to the generated directory are
part of the root that `/` resolves from — pages can `<include>` them."** The docs say `include`
with a leading `/` resolves from the *source* root, and say generated files "write into the
directory unify hands it, never into `site/`". Read literally, my `/_gen/notes-index.fragment.html`
include should have failed to resolve. It works (probe-verified, and links inside that fragment
are still rewritten to `/forge/notes/…/`), but I learned that from unify, not from the rules.

Other things I inferred or probed rather than read:

- That the generated overlay participates in pretty-urls/canonical/sitemap as if it were
  source (probe: a generated `gen-index.html` got `/forge/gen-index/`, a canonical, and layout
  merging). That generated `.js` files are byte-for-byte copies like any other file.
- That `unify.yaml` keys are spelled `pretty-urls:` / `base-url:` / `generate:` — `--save-config`
  confirmed it after the fact.
- That `source-pages.json` carries Markdown `date`/`description`/frontmatter-as-`meta` in the
  shape I parse (documented only as "authored title, description, date, meta and links").
- That a page's `<script>` tag inside its `<main>` survives merging and still runs (nothing
  says either way).
- That a link to a directory (`/courses.html#notes` style anchors, `/visit.html` from the
  footer) is checked against emitted files — it is; my first build failed on `/notes.html`
  when I removed that page, which I take as the link checker working.

## What I re-read, and why it did not land

The "Merging a page into its layout" section, twice. I write pages as complete documents
with their own `<main>`, and I could not predict where that `<main>` would go — the paragraph
says the layout's bare `<slot>` inside its `<main>` receives "everything else", *and* that
"the first default-content page main unwraps". It didn't land the first time because the
two halves describe one mechanism (page main's children replace the slot; the wrapper tag is
dropped) and I was reading them as two competing rules; a probe build made it obvious. I also
re-read the sentence "a bare `<header>`/`<footer>` does not replace the layout's — only
`slot=` fills", because my layout puts header/footer *outside* `<main>` and I had to confirm
pages couldn't clobber them, and the `head`-merge sentence about the title separator
(`<title>— Thistleknap Forge</title>` with no leading space) — the exact placement of the
separator character is easy to misread.

## What I guessed

- Svelte internals I assumed from experience, not from these docs: the component's
  `export let` props (unused here, so no props are passed), `bind:value` reacting to an
  `input` event, and that Svelte flushes DOM updates in a microtask — my first jsdom run
  "failed" with a stale total because I asserted synchronously; the fix was in my test, not
  in the site.
- That `css: "external"` + esbuild `iife` is a sound pipeline for Svelte 4 (it is; verified by
  running the bundle).
- Content itself: prices matching the component's default props (£18/£12), fictional
  instructors/dates/notes, and the SVGs' shapes as plain placeholders.

## Gaps I did not close

- I never saw a browser render; every check is static or jsdom. Computed layout, contrast and
  actual "update as they type" feel are unverified.
- Whether unify would emit or exclude a *non*-underscore file ending `.fragment.html` in the
  generated directory is still a mystery; I sidestepped it by writing the fragment under
  `_gen/`, where the `_*` exclusion rule surely applies.
- I did not use the `--feed`/`schema`/`--catalog` features; nothing in the brief required them.
