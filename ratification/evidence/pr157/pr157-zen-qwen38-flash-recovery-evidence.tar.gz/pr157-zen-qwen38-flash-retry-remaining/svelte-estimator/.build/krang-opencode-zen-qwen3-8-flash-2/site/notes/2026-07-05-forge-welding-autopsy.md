---
title: "Forge Welding: an Autopsy of a Failed Weld"
date: 2026-07-05
description: Intensive session two — we cut open Wednesday's bad welds and looked at why.
author: Ines Duarte
---

# Forge Welding: an Autopsy of a Failed Weld

## The scene

Of six welds attempted last Wednesday, two were clean, one was cold-shut,
three were halfway. We cut all six with an angle grinder and looked.

## What the cross-sections said

- **Cold-shut**: the fold line stayed bright and smooth. Cause: flux was
  already burning off *before* the halves met. Fix: flux at orange, weld at
  white, and the heat comes up while you read the colour, not after.
- **Halfway**: silvery skin where scale got trapped. Cause: too long at
  welding heat with the blower flat out. The bar was oxidising faster than
  the flux could clear it.
- The two good welds were both made by the quietest member of the group.
  She waits. The loud ones hammer.

## Rules of thumb agreed

1. Borax goes on at orange, never at yellow.
2. Two flash-heats beats one long soak.
3. First set of blows is a *location*, not a shape — light, fast, and check
   the register.
4. If the fire is going off, the weld is going off with it. Rebuild before
   you decide the steel is bad.

## Next session

Billets: three layers of 15N20 and 1084. Stock is labelled; if the label is
gone, ask, don't guess.
