import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { compile } from "svelte/compiler";
import * as esbuild from "esbuild";

const here = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(here, "..");

export async function buildEstimator(outDir) {
  const src = readFileSync(resolve(projectRoot, "components/FeeCalculator.svelte"), "utf8");
  const { js, css } = compile(src, {
    generate: "dom",
    name: "FeeCalculator",
    css: "external",
    filename: "FeeCalculator.svelte",
  });
  const tmp = resolve(projectRoot, "build/.svelte-tmp");
  mkdirSync(tmp, { recursive: true });
  writeFileSync(resolve(tmp, "FeeCalculator.js"), js.code);
  writeFileSync(
    resolve(tmp, "entry.js"),
    'import FeeCalculator from "./FeeCalculator.js";\n' +
      'const target = document.querySelector("#fee-calculator");\n' +
      "if (target) new FeeCalculator({ target });\n"
  );
  mkdirSync(resolve(outDir, "assets"), { recursive: true });
  await esbuild.build({
    entryPoints: [resolve(tmp, "entry.js")],
    bundle: true,
    format: "iife",
    minify: true,
    outfile: resolve(outDir, "assets/fee-estimator.js"),
  });
  writeFileSync(resolve(outDir, "assets/fee-estimator.css"), css.code || "");
  return resolve(outDir, "assets/fee-estimator.js");
}

if (process.argv[1] && resolve(process.argv[1]) === resolve(here, "build-estimator.mjs")) {
  const out = await buildEstimator(process.argv[2] ? resolve(process.argv[2]) : resolve(projectRoot, "build"));
  console.log("built", out);
}
