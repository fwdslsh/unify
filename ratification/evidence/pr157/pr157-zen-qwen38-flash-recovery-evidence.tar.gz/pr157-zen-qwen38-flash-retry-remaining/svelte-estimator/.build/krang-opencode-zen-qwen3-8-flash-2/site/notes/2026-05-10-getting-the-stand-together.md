---
title: Getting the Stand Together
date: 2026-05-10
description: First session of the spring beginners group — fire building, and why half the group's coal went out at once.
author: Marta Colby
---

# Getting the Stand Together

## What we did

Nine people, four forges, one pile of good coke. We built fires from cold and
practiced keeping a *white* welding heat without burning the stock.

- Lighting: newspaper, small charcoal, air on low until the coal is lit
  through. Nobody rushed this, and it showed — first fires were ready by
  10:40.
- Drawing out: taper from the centre, turn every third blow. The classic
  mistake today was hammering the *cold* end first and wondering why the bar
  went banana-shaped.

## What cracked

Two tongs joints opened up because people quenched red-hot steel into the
water barrel without letting it come down first. It is named the water
barrel, not the panic button.

## Next week

Upsetting and scrolling. Bring a drawing of one hook design — any hook — and
we will forge it.
