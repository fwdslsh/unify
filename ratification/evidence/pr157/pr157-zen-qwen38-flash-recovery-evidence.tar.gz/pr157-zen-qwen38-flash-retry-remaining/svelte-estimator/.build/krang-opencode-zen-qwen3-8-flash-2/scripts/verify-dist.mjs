import { readFileSync, readdirSync, statSync, existsSync } from "node:fs";
import { join, resolve, dirname } from "node:path";

const BASE_PATH = "/forge/";
const root = resolve(process.argv[2] || "dist");

const files = [];
(function walk(d) {
  for (const e of readdirSync(d)) {
    const p = join(d, e);
    if (statSync(p).isDirectory()) walk(p);
    else files.push(p);
  }
})(root);

const problems = [];
const urls = [];

for (const f of files) {
  if (!f.endsWith(".html")) continue;
  const html = readFileSync(f, "utf8");
  for (const m of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
    urls.push({ file: f, url: m[1] });
  }
}

for (const { file, url } of urls) {
  if (url.startsWith("mailto:")) continue;
  if (/^https?:\/\//.test(url)) {
    if (!url.startsWith("https://thistleknap.pages.dev/")) {
      problems.push(`${rel(file)}: loads from another website: ${url}`);
    }
    continue;
  }
  if (url.startsWith("#")) continue;
  let path = url.split("#")[0];
  if (path === "") continue;
  if (!path.startsWith(BASE_PATH)) {
    problems.push(`${rel(file)}: not under ${BASE_PATH}: ${url}`);
    continue;
  }
  const relPath = path.slice(BASE_PATH.length - 1); // keep leading /
  if (relPath.endsWith(".html")) {
    problems.push(`${rel(file)}: visitor URL ends in .html: ${url}`);
    continue;
  }
  const onDisk = resolve(root, "." + relPath);
  if (existsSync(onDisk)) continue;
  if (statSyncSafe(onDisk) && statSyncSafe(onDisk).isDirectory()) {
    if (!existsSync(join(onDisk, "index.html")))
      problems.push(`${rel(file)}: directory URL with no index.html: ${url}`);
    continue;
  }
  if (!path.endsWith("/") || !existsSync(onDisk + "/index.html"))
    problems.push(`${rel(file)}: unresolved URL: ${url}`);
}

function statSyncSafe(p) { try { return statSync(p); } catch { return null; } }
function rel(p) { return p.slice(root.length + 1); }

console.log(`checked ${files.length} files, ${urls.length} href/src values`);
if (problems.length) {
  console.log("PROBLEMS:");
  for (const p of problems) console.log("  " + p);
  process.exit(1);
}
console.log("all href/src resolve under " + BASE_PATH + ", none end in .html, none are off-origin");

const banned = files.filter((f) => /draft/i.test(f));
console.log(banned.length ? "LEAKED DRAFTS: " + banned : "no draft files in output");
