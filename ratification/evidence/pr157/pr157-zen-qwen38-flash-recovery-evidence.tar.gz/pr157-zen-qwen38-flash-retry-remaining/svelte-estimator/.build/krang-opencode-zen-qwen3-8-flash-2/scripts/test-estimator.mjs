import { readFileSync } from "node:fs";
import pkg from "jsdom";
const { JSDOM, VirtualConsole, requestInterceptor } = pkg;

const BASE = "https://thistleknap.pages.dev/forge/";

const interceptors = [
  requestInterceptor((request) => {
    const url = request.url;
    if (!url.startsWith(BASE)) {
      throw new Error("the page tried to load from another website: " + url);
    }
    const rel = url.slice(BASE.length);
    const path = rel.endsWith("/") ? rel + "index.html" : rel;
    let body, type;
    if (path.endsWith(".js")) type = "text/javascript";
    else if (path.endsWith(".css")) type = "text/css";
    else type = "text/html";
    try {
      body = readFileSync("dist/" + path);
    } catch {
      return new Response("not found", { status: 404 });
    }
    return new Response(body, { headers: { "Content-Type": type } });
  }),
];

const vc = new VirtualConsole();
vc.on("jsdomError", (e) => console.log("JSDOM ERROR:", e.message));

const dom = await JSDOM.fromFile("dist/courses/index.html", {
  url: BASE + "courses/",
  runScripts: "dangerously",
  resources: { interceptors },
  virtualConsole: vc,
});

await new Promise((res, rej) => {
  dom.window.addEventListener("load", res);
  setTimeout(() => rej(new Error("load event never fired")), 10000);
});

const doc = dom.window.document;
const calc = doc.querySelector("#fee-calculator .fee-calc");
if (!calc) throw new Error("estimator did not mount into #fee-calculator");

const inputs = [...doc.querySelectorAll("#fee-calculator input")];
const out = () => doc.querySelector("#fee-calculator p").textContent;
console.log("mounted. defaults:", inputs.map((i) => i.value).join(", "), "->", out());

const flush = () => new Promise((res) => setTimeout(res, 0));
const set = async (i, v) => {
  inputs[i].value = String(v);
  inputs[i].dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  await flush();
};
await set(0, 3); await set(1, 4);
const expected = 3 * 4 * 18 + 3 * 12;
console.log("after people=3 hours=4 ->", out(), "| expected £" + expected);
if (!out().includes(String(expected))) throw new Error("reactivity wrong");
await set(0, 8); await set(1, 6);
const exp2 = 8 * 6 * 18 + 8 * 12;
if (!out().includes(String(exp2))) throw new Error("reactivity wrong: " + out());
console.log("after people=8 hours=6 ->", out(), "| expected £" + exp2);
console.log("ESTIMATOR RUNTIME OK at " + BASE + "courses/");
dom.window.close();
