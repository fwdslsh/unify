---
title: Making Tongs True
date: 2026-06-07
description: Tool-making week one — riveting tongs, and the two ways joints go loose.
author: Marta Colby
---

# Making Tongs True

## What worked

Riveting on the *upset* not the punch: heat the collar to bright yellow, two
solid blows, done. Every joint seated today.

## What went loose

Two pairs of tongs opened up overnight — both made by people who peened the
rivet *cold* "to tighten it". Cold peening a hot-set rivet undoes it. If it
is loose when warm, it was never tight.

- Rivet holes: punch, then drill 5% over. Drilled-only holes make oval joints.
- Check the jaws on a flat bar before the rivet goes in, not after.

## Next week

Hardy tools — hot-cut and the spring hardy. Bring ear protection; the
power hammer gets used for the first time this term.
