---
title: "Drawing Out, Slowly: the knife blanks"
date: 2026-05-24
description: Week three — everyone made a blank, six of the eleven are actually straight.
author: Peter Akwesi
---

# Drawing Out, Slowly: the knife blanks

## Session

We forged 52100-ish bar down to knife blanks for the beginners group. Priorities:
flat tangs, even shoulders, and *not* decarburising the edges by camping at
orange heat for twenty minutes.

1. Draw out the point first, always. The point is where everyone's hammering
   goes wrong — too many light taps, cold work, wavy edges.
2. Shoulders off the horn, not the face. Three people learned this the noisy
   way.
3. Length comes from a long blow with the bar moving, not six short ones in
   the same place.

## Numbers people asked for

- Set hammer on 4 for thinning, hand hammer for everything before that.
- If the scale is flaking off *clean metal*, the bar is too hot — drop it
  half a colour.

## Homework

Watch your own edge-on the blank tomorrow: any dip you can see with the
naked eye you will pay for at the grinder.
