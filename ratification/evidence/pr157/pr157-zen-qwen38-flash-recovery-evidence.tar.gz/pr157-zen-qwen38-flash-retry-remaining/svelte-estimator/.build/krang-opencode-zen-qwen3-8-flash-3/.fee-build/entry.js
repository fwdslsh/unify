import FeeCalculator from './FeeCalculator.js';
function mount() {
  const target = document.getElementById('fee-calculator');
  if (target) new FeeCalculator({ target });
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);
else mount();