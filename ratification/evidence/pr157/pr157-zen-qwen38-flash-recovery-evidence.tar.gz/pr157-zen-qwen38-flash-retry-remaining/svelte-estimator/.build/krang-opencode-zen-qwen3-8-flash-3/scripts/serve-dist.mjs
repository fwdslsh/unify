// Serves ./dist at http://127.0.0.1:8123/forge/ the way the real address will.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve('dist');
const PORT = 8123;

http
  .createServer((req, res) => {
    let p = decodeURIComponent(req.url.split('?')[0]);
    if (!p.startsWith('/forge/')) {
      res.writeHead(404);
      res.end('outside the site prefix');
      return;
    }
    let file = path.join(root, p.slice('/forge'.length));
    if (!file.startsWith(root)) {
      res.writeHead(403);
      res.end('no');
      return;
    }
    if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
    if (!fs.existsSync(file)) {
      res.writeHead(404);
      res.end('not found: ' + p);
      return;
    }
    const types = {
      '.html': 'text/html; charset=utf-8',
      '.css': 'text/css; charset=utf-8',
      '.svg': 'image/svg+xml',
      '.js': 'text/javascript; charset=utf-8',
      '.xml': 'application/xml',
    };
    res.writeHead(200, { 'content-type': types[path.extname(file)] || 'application/octet-stream' });
    res.end(fs.readFileSync(file));
  })
  .listen(PORT, () => console.log(`serving dist at http://127.0.0.1:${PORT}/forge/`));
