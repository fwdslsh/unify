// unify generator: runs before every build (unify.yaml: generate: scripts/gen.mjs).
// Writes into the directory unify hands over (argv[3] / context generatedRoot):
//   notes.html                — the course-notes index, every note, newest first
//   assets/fee-calculator.js  — the compiled Svelte fee estimator
import fs from 'node:fs';
import path from 'node:path';
import { buildFee } from './build-fee.mjs';

const ctxPath = process.argv[4];
if (!ctxPath || !fs.existsSync(ctxPath)) {
  console.error('gen: expected to be run by `unify build` (no generator context found)');
  process.exit(1);
}
const ctx = JSON.parse(fs.readFileSync(ctxPath, 'utf8'));
const generatedRoot = ctx.paths.generatedRoot;
const inventory = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, 'utf8'));

const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const longDate = (iso) => {
  if (!iso) return 'undated';
  const d = new Date(iso.length === 10 ? iso + 'T00:00:00Z' : iso);
  if (Number.isNaN(d.getTime())) return esc(iso);
  return new Intl.DateTimeFormat('en-GB', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }).format(d);
};

const notes = inventory.pages
  .filter((p) => p.source.startsWith('notes/') && !p.source.startsWith('notes/_'))
  .sort((a, b) => (b.date || '').localeCompare(a.date || '') || a.href.localeCompare(b.href));

const items = notes
  .map((p) => {
    const author = (p.meta.find((m) => m.name === 'author') || {}).content;
    return [
      '      <li>',
      `        <span class="note-date"><time datetime="${esc(p.date || '')}">${longDate(p.date)}</time></span>`,
      `        <a class="note-title" href="${esc(p.href)}">${esc(p.title || p.source)}</a>`,
      `        <p class="note-desc">${esc(p.description || '')}</p>`,
      author ? `        <p class="note-byline">by ${esc(author)}</p>` : null,
      '      </li>',
    ].filter(Boolean).join('\n');
  })
  .join('\n');

const page = `<!doctype html>
<html lang="en-GB">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Course notes</title>
    <meta name="description" content="Working notes from Thistleknap Forge course sessions, written up by the instructors. Newest first.">
  </head>
  <body class="notes">
    <h1>Course notes</h1>
    <p>Written up by the instructors after most sessions. ${notes.length} note${notes.length === 1 ? '' : 's'}, newest first.
      This index is rebuilt by the site build — add a dated note under <code>site/notes/</code> and it appears here.</p>
    <ol class="note-index">
${items}
    </ol>
  </body>
</html>
`;

fs.mkdirSync(generatedRoot, { recursive: true });
fs.writeFileSync(path.join(generatedRoot, 'notes.html'), page);
console.log(`gen: notes.html with ${notes.length} notes, newest ${notes[0] ? notes[0].date : 'none'}`);

await buildFee(path.join(generatedRoot, 'assets', 'fee-calculator.js'));
