// Builds components/FeeCalculator.svelte into one self-contained browser script.
// Called by scripts/gen.mjs before every unify build; can also be run by hand:
//   node scripts/build-fee.mjs dist/assets/fee-calculator.js
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { compile } from 'svelte/compiler';
import { build } from 'esbuild';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export async function buildFee(dest) {
  const source = fs.readFileSync(path.join(root, 'components', 'FeeCalculator.svelte'), 'utf8');
  const { js } = compile(source, { generate: 'client', dev: false });

  const scratch = path.join(root, '.fee-build');
  fs.mkdirSync(scratch, { recursive: true });
  fs.writeFileSync(path.join(scratch, 'FeeCalculator.js'), js.code);
  fs.writeFileSync(
    path.join(scratch, 'entry.js'),
    [
      "import FeeCalculator from './FeeCalculator.js';",
      'function mount() {',
      "  const target = document.getElementById('fee-calculator');",
      '  if (target) new FeeCalculator({ target });',
      '}',
      "if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);",
      'else mount();',
    ].join('\n'),
  );

  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const result = await build({
    entryPoints: [path.join(scratch, 'entry.js')],
    absWorkingDir: scratch,
    bundle: true,
    format: 'iife',
    target: 'es2017',
    legalComments: 'none',
    outfile: dest,
    metafile: true,
  });
  const inlined = Object.keys(result.metafile.inputs).filter((f) => f.includes('svelte'));
  console.log(`build-fee: ${dest} (${fs.statSync(dest).size} bytes; svelte runtime bundled: ${inlined.length ? 'yes' : 'no'})`);
  return dest;
}

const dest = process.argv[2];
const invokedDirectly = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  if (!dest) {
    console.error('usage: node scripts/build-fee.mjs <output.js>');
    process.exit(1);
  }
  await buildFee(path.resolve(process.cwd(), dest));
}
