// Walks dist/ and reports every reference that would not resolve under
// https://thistleknap.pages.dev/forge/ , plus leaks of unpublished source.
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve('dist');
const problems = [];
const files = [];
(function walk(d) {
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    const f = path.join(d, e.name);
    if (e.isDirectory()) walk(f);
    else files.push(f);
  }
})(root);

// 1. no .html should be part of a visitor address: only index.html on disk, no *.html except index
for (const f of files) {
  const base = path.basename(f);
  if (base.endsWith('.html') && base !== 'index.html') problems.push(`${f}: emitted a non-index .html page`);
}

// 2. scan HTML for references
for (const f of files.filter((x) => x.endsWith('.html'))) {
  const html = fs.readFileSync(f, 'utf8');
  const rel = path.relative(root, f);
  for (const m of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
    const u = m[1];
    if (u.startsWith('#') || u.startsWith('mailto:')) continue;
    if (u.startsWith('/')) {
      if (!u.startsWith('/forge/')) problems.push(`${rel}: root-relative ref without /forge/ prefix: ${u}`);
      continue;
    }
    if (/^https?:\/\//.test(u)) {
      if (!u.startsWith('https://thistleknap.pages.dev/forge/')) problems.push(`${rel}: off-origin absolute URL: ${u}`);
      continue;
    }
    // relative reference: resolve against the page and check it exists
    const pageDir = path.dirname(f);
    const target = path.resolve(pageDir, u);
    if (!fs.existsSync(target) && !fs.existsSync(target + '/index.html')) problems.push(`${rel}: relative ref does not resolve: ${u}`);
  }
  // 3. every page must have the shared chrome
  for (const needle of ['class="site-header"', 'Thistleknap Forge anvil mark', 'class="site-footer"']) {
    if (!html.includes(needle)) problems.push(`${rel}: missing shared chrome marker: ${needle}`);
  }
}

// 4. JS and CSS must not reach off-site
for (const f of files.filter((x) => /\.(js|css)$/.test(x))) {
  const text = fs.readFileSync(f, 'utf8');
  for (const m of text.matchAll(/https?:\/\/[^"'`\s)]+/g)) {
    if (m[0].includes('w3.org')) continue; // XML namespace, not a fetch
    problems.push(`${path.relative(root, f)}: off-site URL in asset: ${m[0]}`);
  }
}

// 5. unpublished material must not leak into dist at all
for (const f of files) {
  const text = fs.readFileSync(f, 'utf8');
  if (text.includes('DRAFT') || text.includes('flux quantities')) problems.push(`${path.relative(root, f)}: drafts/ content leaked`);
}

// 6. the fee estimator must actually be in the bundle and wired from the courses page
const js = fs.readFileSync(path.join(root, 'assets/fee-calculator.js'), 'utf8');
for (const needle of ['fee-calc', 'Estimated cost', 'People', 'Hours']) {
  if (!js.includes(needle)) problems.push(`fee-calculator.js missing compiled component string: ${needle}`);
}
if (/from\s*["']svelte/.test(js)) problems.push('fee-calculator.js has unresolved svelte imports');
const courses = fs.readFileSync(path.join(root, 'courses/index.html'), 'utf8');
if (!courses.includes('/forge/assets/fee-calculator.js')) problems.push('courses page does not load the estimator bundle at the /forge/ path');
if (!courses.includes('id="fee-calculator"')) problems.push('courses page lacks the mount point');

console.log(`checked ${files.length} files`);
if (problems.length) {
  for (const p of problems) console.log('PROBLEM: ' + p);
  process.exit(1);
}
console.log('all checks passed');
