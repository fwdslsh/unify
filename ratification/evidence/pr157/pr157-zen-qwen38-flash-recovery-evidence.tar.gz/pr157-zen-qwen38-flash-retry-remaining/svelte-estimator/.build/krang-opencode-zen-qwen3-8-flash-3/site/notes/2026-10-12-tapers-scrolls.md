---
date: 2026-10-12
class: notes
author: Marta Y.
description: Week one of the scrollwork block — scrolling irons, the London vs common eye, and tongs that were a little too tight.
---

# Tapers, eyes and scrolls

Block two week one. Everyone got their practice bar up to a nice taper ratio; the trick
was marking with a soapstone before the heat, not after.

- Eyes: we cut the scroll with the bar standing on end, bending around the big horn. Two
  people kept getting "ears" on their scrolls — the bend started above the shoulder of the
  scroll, not at the tip. Start lower, commit more.
- The London eye is the good eye. If your scroll curls back into itself like a sleepy
  snail, you over-turned the last inch.
- Tongs check: the scroll bars we made today, if you can pull the tongs off with a thumb,
  they are a hair too tight. File, do not heat-adjust, the joints — I keep teaching this.

For next week: rough out your panel design on paper with the two scroll sizes you have
learned. No forging the panel yet — the gas forge is on service Thursday.
