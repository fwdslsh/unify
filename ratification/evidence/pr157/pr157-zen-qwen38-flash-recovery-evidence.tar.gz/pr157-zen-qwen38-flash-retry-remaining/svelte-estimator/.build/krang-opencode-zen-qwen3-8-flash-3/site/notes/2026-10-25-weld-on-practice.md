---
date: 2026-10-25
class: notes
author: Dezi O.
description: Gasforge session on forge-welding hooks to a strap — flux mix, white heat discipline, and the good news about borax.
---

# Weld-on practice: hooks onto bands

Four members, one gas forge, thirty hook-and-band welds between us. This is the note I
wish someone had written for me:

- Flux: straight borax off a damp brush is fine at our scale. The fear of "too much flux"
  is overrated; too *little* is what dehydrates the weld and gives you that ugly grey
  skin. Swirl the piece in the flame and dust it, do not build a snowman.
- Welding heat is brighter than you think, and gone faster. Count under your breath from
  the last yellow flash; by two seconds you are at the anvil or you re-heat. Nobody who
  hesitated got a clean weld today, and no weld was ruined by a second heat.
- The band wants about a 10% overlap upset. Measure it: two bands came apart at the toe
  because the overlap was guesswork.
- Quench nothing today except the tool steel. Let the welds air cool and you can pick
  them up at the end of the night, which is exactly what forge welding is for.

Next session we try welds on mild-steel scrap with a *cold* anvil face, on purpose, to
see how forgiving a good heat really is. Bring ear pro — the chipping of scale is loud.
