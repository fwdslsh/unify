---
date: 2026-09-27
class: notes
author: Marta Y.
description: Session notes for Fire & hammer basics — drawing out, the flat splice, and why everyone's first hook came out wavy.
---

# First heats and flat bar

Six beginners, two forges, and by 20:00 everybody had drawn a point without cracking it,
which I will take as a win.

What we covered:

- Reading heat colours. Coal flash is not heat; if you cannot tell yellow from orange by
  squinting, you are guessing.
- Drawing out on the anvil face, turning the bar a quarter every blow. The hooks that came
  out wavy were all people who "helped" the taper with an off-hand blow.
- The flat splice. Nobody got a *true* weld today — two heats were too cold — but Bo's
  second attempt held on the twist test, and that is the lesson: heat, flux, then committed
  hammer blows. Half-hearted welding is just folded rust.

Practise before next Thursday: hammering in rhythm with a partner calling "turn". Bring
your own hook if you want it finished off; the box of scraps by the bench is fair game.
