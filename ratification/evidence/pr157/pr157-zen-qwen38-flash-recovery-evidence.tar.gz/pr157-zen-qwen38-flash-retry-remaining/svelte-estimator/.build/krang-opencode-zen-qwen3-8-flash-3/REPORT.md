# Thistleknap Forge — build report

## 1. Publish command

```
./unify build
```

That is the whole thing. The saveable options are persisted in `unify.yaml`
(`base-url`, `pretty-urls`, `clean`, `audit`, `generate`), so the bare command publishes
correctly **for `https://thistleknap.pages.dev/forge/`**. The equivalent explicit form is
`./unify build --base-url https://thistleknap.pages.dev/forge/ --pretty-urls --clean --audit`.
Exit 0 means `dist/` is the complete publishable site; `--audit` in the config gates
publishing, and I verified that a failing check leaves `dist/` byte-identical.

## 2. The estimator's build command

Nothing to run separately: `unify.yaml` has `generate: scripts/gen.mjs`, and unify runs it
before every build. `scripts/gen.mjs` compiles `components/FeeCalculator.svelte` (Svelte 4
client generator) and bundles it with esbuild into a single self-contained IIFE written into
the generated overlay as `assets/fee-calculator.js` — Svelte's runtime is inlined, so the
page loads nothing off-site. **When the next `.svelte` revision arrives, the one command is
again `./unify build`.** The compile can also be run by hand:

```
node scripts/build-fee.mjs .fee-build/fee-calculator.js
```

## 3. What was built

- `site/_layout.html` — shared header (the anvil mark + nav) and footer; every page,
  including the generated notes index, is wrapped by it.
- `site/index.html`, `site/courses.html` (course table + estimator mount +
  `<script src="/assets/fee-calculator.js" defer>` with a `<noscript>` fallback),
  `site/visit.html` (address, open-days table, numbered safety rules).
- `site/notes/` — three dated Markdown notes (frontmatter `date`, `author`,
  `description`, `class`; body is plain Markdown — the instructors never touch HTML).
- `scripts/gen.mjs` — reads the source inventory unify hands it and writes `notes.html`
  into the generated overlay: every note under `notes/`, sorted newest-first. Forgetting to
  update an index by hand is now impossible.
- `site/assets/anvil.svg` (placeholder mark, used in header, footer and favicon) and
  hand-written `site/assets/site.css`. No remote fonts, no CDN, no images to fetch.
- `drafts/`, `components/`, `scripts/`, `node_modules/` and `unify.yaml` all live outside
  the `site/` source root, so none of them can ship.

## 4. What `rules.md` did not answer

- **What happens to the directory the generator writes into.** The one sentence I wanted and
  could not find: *"the generated directory is composed as if it were source files under the
  source root."* Rules only say the script "writes into the directory unify hands it, never
  into `site/`" — not that those files get wrapped by the site's `_layout.html`, rewritten
  under `--pretty-urls`, prefixed by `--base-url`, or that assets placed there are copied
  like source assets. All of that was true, and all of it I had to discover with probe
  builds.
- **How the generator is handed anything.** Nothing in `rules.md` says the script receives
  the generated directory and a `generator-context.json` (with `inputs.sourcePages` pointing
  at the inventory) as `process.argv[3]`/`argv[4]`. `--help` hints "give that file
  source-pages.json" but not where or how.
- **Where a `generate:` path resolves from.** The CLI says "a relative path is from the
  source root" and `rules.md` shows `generate: scripts/gen.mjs` in `unify.yaml` with scripts
  kept "beside the site" — the yaml resolves against the project, the CLI flag against
  `site/`. The two spellings of the same setting take different bases; the docs never say
  so. My first CLI probe died on exactly this.

## 5. What I re-read, and why it did not land the first time

- **The `generate` paragraph in line 6** — I read it three times. The first pass I mapped
  "a script you write … derives files" onto the familiar pattern of a generator writing into
  the source tree, because every static-site tool I have used works that way; "writes into
  the directory unify hands it, **never into `site/`**" slid past as boilerplate until the
  contradiction forced a second, slower read.
- **The Files section, on directory links** — re-read after `--audit` reported
  "`/notes/` does not resolve". It says the build succeeds *only when the output has*
  `notes/index.html` — I had written the link before deciding how the index page itself
  would exist, and the sentence assumes that decision was already made.
- **The Head-merging paragraph** — I initially missed "Write the separator into the layout's
  title — `<title>— My Site</title>`, no leading space" on first pass because it is phrased
  as an instruction to the author, not as a rule about composition; I re-read it after
  seeing the joined title in probe output.

## 6. What I guessed or inferred rather than read

- **Svelte version and tooling**: the docs say nothing about Svelte (outside unify entirely).
  From the component's syntax (`export let` props, `$:` reactivity, `bind:value`) I inferred
  legacy-instance Svelte and pinned `svelte@4.2.20` + `esbuild@0.28.2`. Compiling to an
  IIFE bundle with the `svelte/internal` runtime inlined was my inference of what
  "load nothing from another website" requires.
- **Instantiating the component with no props**, so a future revision's own
  `hourlyRate`/`materialsFee` defaults survive; the brief's prices match those defaults today.
- That esbuild would resolve `svelte/internal` from a scratch dir under the project root —
  standard Node resolution, untested until it worked.
- The feed idea: `rules.md` says a `date:` with no time is "left out" of `feed.xml`, so I
  inferred my date-only notes would render a useless feed and skipped declaring `schema:`
  entirely rather than invent timestamps.
- That Cloudflare Pages serves `dist/` such that `/forge/` addresses work the way
  `--base-url` rewrites them; verified by emulating that layout with a local server, not by
  reading anything about Cloudflare.
- The exact inventory JSON shape (`pages[].source/href/title/date/meta`) — read out of the
  file unify hands over, not documented in prose.

## 7. How I verified

No browser was available, so verification is static + HTTP:

1. `./unify audit --strict` → "nothing to report"; `./unify build` (with `audit: true`
   config) → exit 0. `dist/` is 11 files.
2. `node scripts/serve-dist.mjs` serves `dist/` under `/forge/` only (any path outside the
   prefix 404s, like the real subdirectory deployment); I fetched every visitor URL —
   `/forge/`, `/forge/courses/`, `/forge/visit/`, `/forge/notes/`, all three
   `/forge/notes/<date>-<slug>/`, the CSS, the SVG, `fee-calculator.js` — **all 200**, and
   `/forge/courses.html` is **404**: no published page even has a `.html` address except
   index files that no link points to.
3. `node scripts/verify-dist.mjs` (passing, exit 0) walks `dist/` and asserts: every
   `href`/`src` is `/forge/`-prefixed or a same-address absolute under
   `https://thistleknap.pages.dev/forge/` (canonical/og are absolute for crawlers); every
   page carries the shared header/footer chrome; the sitemap lists exactly the site's
   addresses; no `drafts/` string ("DRAFT", "flux quantities") appears anywhere in output.
4. **The estimator's code reaches the browser at that address**: `/forge/courses/` contains
   `<script src="/forge/assets/fee-calculator.js" defer>` and `id="fee-calculator"`; the
   fetched bundle (24,227 B) is a single IIFE that contains the compiled component's
   template strings (`fee-calc`, `People`, `Hours`, `Estimated cost`), the original reactive
   expression (`people * hours * hourlyRate`), the two-way-bind `"input"` listeners, and the
   mount call `document.getElementById("fee-calculator")` — with no unresolved imports and
   no off-origin URL (the only `http` string anywhere is the SVG XML namespace, which is not
   fetched). The live-update-on-typing itself is Svelte's compiled `bind:value` reactivity;
   I could not click a real input without a browser, so that part is verified by the
   presence of that compiled wiring, not observed behaviour.
5. **Repeatability, demonstrated end to end**: I added a fourth dated note and edited
   `FeeCalculator.svelte`, ran the single `./unify build` — the index listed 4 notes newest
   first and the bundle changed; I reverted and rebuilt to the identical tree. I also
   injected a broken link to confirm a failing build exits 1 and leaves `dist/` untouched.
