# Thistleknap Forge — build report

## The command line that publishes the site

After a one-time `npm install` (pulls `svelte`, `esbuild`, `jsdom`), the single command is:

```
./unify build
```

It compiles the estimator, regenerates the notes index, and publishes `dist/` for
`https://thistleknap.pages.dev/forge/`. The options live in `unify.yaml`, which is equivalent
to typing them every time:

```
./unify build --pretty-urls --base-url https://thistleknap.pages.dev/forge/ --generate scripts/gen.mjs
```

## The estimator's build command

```
node scripts/build-estimator.mjs <output-dir>
```

`scripts/gen.mjs` (unify's `generate:` hook) imports that function and calls it with the
overlay directory unify hands it, so during `./unify build` it runs automatically. When the
next revision of `components/FeeCalculator.svelte` arrives, dropping the file in place and
running `./unify build` is the whole procedure — I proved repeatability by editing the
component (`hourlyRate` 18→20), rebuilding once, and seeing 20 in
`dist/assets/fee-calculator.js`; then I reverted and rebuilt. The component stays Svelte and
is never rewritten: svelte/compiler + esbuild turn it into one self-contained IIFE
(`/forge/assets/fee-calculator.js`) with an entry that mounts it into `#fee-calculator`; the
Svelte runtime is bundled in, so nothing is fetched from any other site.

## What is where

- `site/_layout.html` — one layout with the inline anvil-mark SVG header, nav (active link via
  `body.home`/`body.courses`/… CSS), and footer fallback; every page merges into it
  (the build report lists each page with `_layout.html`, including generated ones).
- `site/index.html`, `site/courses.html`, `site/visit.html` — hand-written HTML.
- `site/courses/notes/*.md` — four dated Markdown notes (frontmatter `title`/`date`/`author`/
  `description`; instructors write no HTML).
- `scripts/gen.mjs` — reads the source inventory (`source-pages.json`) unify writes for it,
  filters `courses/notes/*.md`, sorts newest-first, and writes a complete page to
  `<overlay>/courses/notes/index.html` with `data-layout="/_layout.html"`. A new note appears
  in the index on the next build with no hand-editing: I added `tilt-hammer.md` dated after
  all the others and one `./unify build` put it first in the index.
- `site/assets/site.css`, `site/assets/anvil.svg` (favicon), plus an inline placeholder SVG
  "photo" on the home page and a placeholder "map" SVG on Visit.
- `drafts/` stays outside `site/` (the source root is `site/`, so it can never ship);
  nothing under the default `_*` exclude either.

## How I verified

- `./unify build --dry-run --strict` and `./unify audit --strict`: both exit 0, "nothing to
  report" — that's the broken-link check over every page, including the generated index's
  links to the notes.
- Grepped `dist/`: every `href`/`src` is under `/forge/`; zero links end in `.html`
  (pretty-urls rewrote them to `/forge/courses/notes/<slug>/`); `sitemap.xml` and every
  `canonical`/`og:url` are absolute `https://thistleknap.pages.dev/forge/…`; titles join
  ("Visit — Thistleknap Forge"); no file contains the drafts' text ("flux quantities").
- **Estimator reaches the browser at that address:** `scripts/test-estimator.mjs` loads the
  published `dist/courses/index.html` into jsdom with `url = https://thistleknap.pages.dev/forge/courses/`
  and a request interceptor that serves `/forge/…` straight from `dist/` (anything else is
  refused). The page fetched `/forge/assets/fee-calculator.js`, the component mounted, and
  firing `input` events updated the estimate without any reload: £132 → £198 (people 2→3)
  → £306 (hours 3→5). Zero off-origin requests. Run it with `npm run test:estimator`.

## What `rules.md` did not answer

The sentences I looked for and could not find:

1. **The generate-script calling convention.** The rules say only "it writes into the
   directory unify hands it, never into `site/`" — nowhere is it stated that unify invokes
   the script with `<sourceRoot> <overlayDir> <context.json>` as argv (or as `unify
   <script> …` in argv[0]), or that `generator-context.json` has an `inputs.sourcePages`
   key pointing at the inventory, or that overlay files may be non-page assets. I discovered
   all of it by running a probe script that dumped its argv and the context file. Related:
   whether the script runs under node or the binary's embedded runtime (Bun, from the
   error-message hint `BUN_BE_BUN=1`) is not stated — I wrote the scripts to avoid
   node-only APIs for that reason.
2. **Whether a generated overlay page gets treated like a normal page.** Nothing says the
   script's HTML can carry `data-layout` or that its `/…` links get the `--base-url` prefix.
   It does — confirmed in `dist/courses/notes/index.html` — but I inferred it.
3. **The base of `generate:` in `unify.yaml` vs `--generate` on the CLI.** The rules show
   `generate: scripts/gen.mjs` "kept in `scripts/` beside the site" (project root); the help
   says "a relative path is from the source root". One sentence saying which base applies
   where would have saved me the first probe (my initial `--generate scripts/probe.mjs`
   failed as `site/scripts/probe.mjs not found`). `--save-config` writing a project-root path
   suggested the yaml is cwd-relative; confirmed by building with `generate: scripts/gen.mjs`.
4. **What `date` looks like inside the inventory** (line 6 promises `source-pages.json`
   gives each page's date, but the format is never shown). I found `2026-11-07` strings by
   printing the file, and sorted on them directly.
5. **Whether a directory link is satisfied by a generated index.** Line 12 says `/guides/`
   builds only when the output has "a `guides/index.html` — one you wrote, or one
   `--pretty-urls` made from `guides.html`". A generate-script overlay index is neither, so
   strictly read, my `/courses/notes/` links looked broken; they build and audit cleanly, so
   the doc's enumeration is incomplete.

## What I re-read, and why it did not land

- **Line 39's footer sentence** — "only `slot=` fills, and it fills the *contents*: where
  the layout wraps its slot in its own `<footer>`, write `<p slot="footer">`". It first
  collided with line 35's "that element replaces the slot, tag and all": replace the slot, or
  fill its contents? Re-read twice; the two describe different cases (named `slot=` element
  fills vs bare `<header>`/`<footer>` elements, which do nothing). My layout wraps its
  `slot="footer"` in a `<footer>`, and no page fills it, so the fallback ships — consistent
  either way, and `dist` confirms exactly one footer per page.
- **Line 6/54 dates** — line 6 says a feed "left out [dates with] no time rather than
  guessed at", while line 54 says schema reads `2026-01-02` fine. I initially thought my
  `date: 2026-11-02` notes were half-invalid; they're only excluded from a feed, and I built
  no feed. The inventory carries the bare date regardless.
- **Line 38's "The first default-content page main unwraps, even for a bare slot outside a
  layout main"** — the densest sentence in the file; took three reads to parse as "your page's
  `<main>` won't end up nested inside the layout's `<main>`". Verified in output rather than
  trusting the parse.
- The top-of-file tension: "without a template language, variables, or loops" then, inside a
  parenthetical, "derived files come from a script you write". The answer to my whole
  auto-index problem was hiding in a side clause of line 6.

## What I guessed or inferred rather than read

- That `--source-inventory` is "on by default with `--generate`" (the help's parenthetical)
  means the file path appears at `ctx.inputs.sourcePages` — inferred from the context dump.
- That the inventory `href` for a `.md` page can be turned into a real link by swapping the
  extension to `.html`; the rules say "always link the real filename" without discussing
  source-extension vs output-extension for Markdown. Audit's broken-link check is my
  evidence, and the jsdom test proves the generated index's own URLs resolve at `/forge/`.
- That esbuild's and svelte's JS APIs work fine under whatever runtime unify uses for
  `generate` (they do — the build never spawns node itself; `npm run build:estimator` on real
  node works identically).
- Svelte version: I chose svelte@4 so the provided component's `export let`/`$:` compiles
  unchanged; the rules obviously say nothing about this, and the component's own syntax made
  the choice.
- That the brief's "one command" tolerates a documented one-time `npm install`.
