import fs from 'node:fs';
import path from 'node:path';
import { buildEstimator } from './build-estimator.mjs';

// unify runs: unify <this-file> <sourceRoot> <overlayDir> <contextJson>
const [, , , overlayDir, ctxPath] = process.argv;
const ctx = JSON.parse(fs.readFileSync(ctxPath, 'utf8'));

const esc = (s) => String(s ?? '')
  .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;');

// ---------- 1. the fee estimator: compile the developer's Svelte, bundle for the browser ----------
await buildEstimator(path.join(overlayDir, 'assets'));

// ---------- 2. the course-notes index: every note, newest first, never hand-edited ----------
function buildNotesIndex() {
  const inv = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, 'utf8'));
  const notes = inv.pages
    .filter((p) => /^courses\/notes\/.+\.md$/.test(p.source))
    .sort((a, b) => String(b.date ?? '').localeCompare(String(a.date ?? '')));

  const metaVal = (p, name) => (p.meta ?? []).find((m) => m.name === name)?.content ?? null;
  const fmt = new Intl.DateTimeFormat('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });

  const items = notes.map((p) => {
    const href = p.href.replace(/\.md$/, '.html');
    const author = metaVal(p, 'author');
    const dateCell = p.date
      ? `<time datetime="${esc(p.date)}">${esc(fmt.format(new Date(p.date + 'T12:00:00Z')))}</time>`
      : '<time>undated</time>';
    return `      <li>
        <h2><a href="${esc(href)}">${esc(p.title)}</a></h2>
        <p>${dateCell}${author ? ` · <span class="by">${esc(author)}</span>` : ''}</p>
        ${p.description ? `<p>${esc(p.description)}</p>` : ''}
      </li>`;
  }).join('\n');

  const html = `<!doctype html>
<html lang="en" data-layout="/_layout.html">
<head>
<meta charset="utf-8">
<title>Course notes</title>
<meta name="description" content="Every note the instructors have posted after a session, newest first.">
</head>
<body class="notes">
<main>
  <h1>Course notes</h1>
  <p>What actually happened at the fire, written up after most sessions by the instructor on
  the night. This index is generated at build time from the notes themselves — it lists every
  one, newest first, so nobody has to remember to update it.</p>
  <ul class="note-list">
${items}
  </ul>
</main>
</body>
</html>
`;

  const out = path.join(overlayDir, 'courses', 'notes', 'index.html');
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, html);
}

buildNotesIndex();
