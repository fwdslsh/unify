import fs from 'node:fs';
import path from 'node:path';
import pkg from 'jsdom';
const { JSDOM, requestInterceptor } = pkg;

const dist = path.resolve(import.meta.dirname, '..', 'dist');
const BASE = 'https://thistleknap.pages.dev/forge/';
const offsite = [];

// Serve /forge/... requests straight out of dist/ — the exact address the site is published at.
const fromDist = requestInterceptor((request) => {
  const url = request.url;
  if (url.startsWith(BASE)) {
    const p = decodeURIComponent(new URL(url).pathname);
    let rel = p.slice('/forge/'.length) || 'index.html';
    if (rel.endsWith('/')) rel += 'index.html';
    const file = path.join(dist, rel);
    if (!fs.existsSync(file)) return new Response('404', { status: 404 });
    return new Response(fs.readFileSync(file), {
      headers: { 'Content-Type': file.endsWith('.js') ? 'text/javascript' : 'text/html' },
    });
  }
  offsite.push(url);
  return new Response('off-origin', { status: 403 });
});

const html = fs.readFileSync(path.join(dist, 'courses', 'index.html'), 'utf8');
const dom = new JSDOM(html, {
  url: BASE + 'courses/',
  resources: { interceptors: [fromDist] },
  runScripts: 'dangerously',
});

await new Promise((res) => {
  if (dom.window.document.readyState === 'complete') res();
  else dom.window.addEventListener('load', res);
});

const { document } = dom.window;
const assert = (cond, msg) => {
  if (!cond) { console.error('FAIL:', msg); process.exit(1); }
  console.log('ok:', msg);
};

const calc = document.querySelector('#fee-calculator .fee-calc');
assert(calc, 'estimator bundle fetched from /forge/assets/ and mounted into the page');

const [people, hours] = [...document.querySelectorAll('#fee-calculator input[type=number]')];
const total = () => document.querySelector('#fee-calculator p:last-of-type').textContent;
const settle = () => new Promise((res) => setTimeout(res, 50));
const type = (input, v) => {
  input.value = v;
  input.dispatchEvent(new dom.window.Event('input'));
  return settle();
};

assert(total().includes('£132'), `initial total renders (default 2 people x 3h @18 + materials): ${total()}`);

await type(people, '3');
assert(total().includes('£198'), `updates on people edit without reload: ${total()}`);

await type(hours, '5');
assert(total().includes('£306'), `updates on hours edit without reload: ${total()}`);

assert(offsite.length === 0, `nothing was fetched off the forge origin (requests: ${JSON.stringify(offsite)})`);
assert([...document.querySelectorAll('script[src]')].every((s) => s.src.startsWith(BASE)),
  'every script src is under the published /forge/ address');
console.log('ALL PASS');
