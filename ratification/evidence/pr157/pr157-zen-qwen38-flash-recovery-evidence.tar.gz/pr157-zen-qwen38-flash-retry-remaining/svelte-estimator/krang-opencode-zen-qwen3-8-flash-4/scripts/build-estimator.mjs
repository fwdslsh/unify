import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { compile } from 'svelte/compiler';
import esbuild from 'esbuild';

const projectRoot = path.dirname(path.dirname(fileURLToPath(import.meta.url)));

// Compile the developer's Svelte component and bundle it into one browser file in outDir.
export async function buildEstimator(outDir) {
  const source = fs.readFileSync(path.join(projectRoot, 'components', 'FeeCalculator.svelte'), 'utf8');
  const { js } = compile(source, { generate: 'dom', dev: false });
  const work = path.join(projectRoot, 'scripts', '.build');
  fs.mkdirSync(work, { recursive: true });
  fs.writeFileSync(path.join(work, 'FeeCalculator.js'), js.code);
  fs.writeFileSync(path.join(work, 'entry.js'), `
import FeeCalculator from './FeeCalculator.js';
function mount() {
  const target = document.getElementById('fee-calculator');
  if (target) new FeeCalculator({ target });
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', mount);
} else {
  mount();
}
`);
  fs.mkdirSync(outDir, { recursive: true });
  const outfile = path.join(outDir, 'fee-calculator.js');
  await esbuild.build({
    entryPoints: [path.join(work, 'entry.js')],
    bundle: true,
    format: 'iife',
    platform: 'browser',
    target: ['es2018'],
    legalComments: 'none',
    outfile,
  });
  fs.rmSync(work, { recursive: true, force: true });
  return outfile;
}

const invokedDirectly = process.argv[1] && fileURLToPath(import.meta.url) === pathToFileURL(path.resolve(process.argv[1])).href;
if (invokedDirectly) {
  const outArg = process.argv[2];
  if (!outArg) {
    console.error('usage: node scripts/build-estimator.mjs <output-dir>');
    process.exit(1);
  }
  const file = await buildEstimator(outArg);
  console.log('built', file);
}
