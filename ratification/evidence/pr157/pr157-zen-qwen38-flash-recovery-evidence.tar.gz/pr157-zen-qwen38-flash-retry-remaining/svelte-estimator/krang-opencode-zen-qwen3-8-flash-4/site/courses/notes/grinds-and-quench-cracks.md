---
title: "Bladesmithing block: grinds, quench cracks, and one beautiful blade"
date: 2026-11-02
author: Marta Ilves
description: Week seven of the bladesmithing course — platen choice for the bevel, spotting the hairline quench crack before the temper, and handle scales in ash off the saw.
---

# Bladesmithing block: grinds, quench cracks, and one beautiful blade

We are at the grind phase of the eight-week block, which is where the stakes get real.

- Platen: soft touch for the shoulder, hard for the final bevel. Two groups started with
  the wrong one and spent the night chasing a flat they had ground away.
- Quench was out at 81 °C — the shed is doing its job, but check the thermometer battery
  before *every* session, not the night of. Two blades cracked and it was not the steel's
  fault: they went in with a hairline from an over-thin grind. Slow the last twenty
  thousandths.
- Temper colour reading in the evening light is useless at the door. Use the shade of the
  coal shed wall for reference or wait for the daylight demo.

The one beautiful blade belongs to A., who has been coming since the spring basics block.
Etched it at the last session; the hamon line came up like smoke. Photo is on the
notice board.

Handling for next week: ash scales off the offcut bin, not the rack — the rack is for
the demo only, the students cut their own or learn nothing.
