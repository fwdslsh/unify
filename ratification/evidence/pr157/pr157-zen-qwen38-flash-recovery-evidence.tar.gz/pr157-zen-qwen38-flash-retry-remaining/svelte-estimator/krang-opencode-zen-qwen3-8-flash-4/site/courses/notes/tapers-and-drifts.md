---
title: "Tapers, drifts and the thing with the fuller"
date: 2026-10-19
author: Tomás Breck
description: Session four of Hedge Row Basics — clean tapers with the fuller, punching drift holes on the swing, and why nobody should heat a whole bar tonight.
---

# Tapers, drifts and the thing with the fuller

Half the group got a genuinely clean taper tonight, so it *is* teachable. What worked:

- Draw the taper in three heats, not one. One heat means hammering cold steel and
  the "sparkly scale" sound, and it wrecks the face line.
- **Fuller before hammer**, all the way along. Everyone wants to skip it and beat the
  shape out. The fuller marks the line; the hammer just follows it.

Drifting holes: the swing drill is fine but people pull *up* on the handle instead of
punching *down*. Put a mark on the floor where the elbow goes. This is embarrassing
to write down and essential to set up.

One bar came out of the coal pitted — it was in too long at white heat, not too hot.
Watch the timer on the forge door; nobody's phone clock is accurate for this.

Next session we bend. Soak the tongs in the water bucket *before* bending anything,
every time, no exceptions.
