---
title: "The tilt hammer, up close"
date: 2026-11-07
author: Tomás Breck
description: An unplanned Saturday session on the old tilt hammer — grip, rhythm, and why we stopped after an hour.
---

# The tilt hammer, up close

We finally oiled the bearings and ran the old tilt hammer on an open Saturday.

- Grip light, the hammer does the work; three people tried to muscle it and made the bar
  worse than by hand.
- Rhythm before weight. Set it to the slowest stroke and match, then open the valve.
- We stopped after an hour by choice; the noise upsets the chapel next door, so it goes
  back on the notice board: hammer hours are Saturday mornings only.
