---
title: "First fire: getting the heat in, not on"
date: 2026-09-28
author: Marta Ilves
description: Notes from the first Hedge Row Basics session of the autumn — coal bed depth, drawing out, and the two things everyone forgets.
---

# First fire: getting the heat in, not on

Six beginners tonight, six usable hooks, one minor singed eyebrow (mine, from leaning on
a cold rail that was not cold). Notes for whoever takes the next group:

- Start the fire **an hour before**, not twenty minutes before. A shallow coal bed cooks
  the surface and leaves the core of the bar cold; we kept re-heating bars that looked
  ready. Twelve inches deep, blast for ten minutes, then let it settle.
- Everyone tries to draw out from the middle. Say it again at the start of every session:
  **work from one end, section by section**, or you get the wasp-waist.
- The tongs everyone grabs off the rack are sized for the *previous* class. Sort stock
  before the doors open.
- Heat colours: repeat "straw is not yellow, yellow is not orange" until they can see it.
  Two of the group had genuinely never noticed the change while watching, which is the
  whole lesson.

Homework on the board: bring any tool with a bent shank next week; we straighten them
on the Friday demo.
