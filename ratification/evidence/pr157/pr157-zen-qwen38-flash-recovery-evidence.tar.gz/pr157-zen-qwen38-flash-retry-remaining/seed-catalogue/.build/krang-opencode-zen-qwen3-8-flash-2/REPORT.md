# Fernhollow Seed Library — build report

## Publish command

```
./unify build --clean --base-url https://fernhollow.pages.dev/library/ --pretty-urls
```

`unify.yaml` carries `generate: scripts/gen.mjs`, so every build regenerates the
catalogue pages from `varieties.json` first. `--clean` matters on season
re-exports: a slug that disappears must not linger in `dist/`. Exit was 0 with
`dist/` written (244 `.html` files: 225 variety pages, home, browse, lending,
guides section ×4, 12 family fragments, plus css/js/svg/sitemap).

## What was checked, for that address specifically

Since there is no browser, `serve-check.mjs` serves `dist/` over HTTP **mounted
at `/library/` exactly like `fernhollow.pages.dev` will**, and `fetch-check.mjs`
(node) walks the site the way a browser resolves addresses:

- Fetched every chrome page, guide, and sample variety page under `/library/…`: all 200.
- The **browse page's initial payload is 3.5 KB and contains zero variety
  entries** (`grep -c variety-list dist/catalogue/index.html` → 0) — only 12
  family anchors. That is the "don't pull down all 225" requirement.
- For each of the 12 family anchors: fetched the rewritten `/library/families/<f>.fragment.html`
  address as written in the page (this is exactly what `site/js/browse.js`
  fetches after load), then fetched **every one of the 225 variety links found
  inside the fragments**, resolving them as a browser would. All 225 returned
  200. This is why fragment links are baked absolute from `--base-url` (see below).
- Asserted no page contains a root-relative address lacking the `/library` prefix.
- `drafts/`, `varieties.json`, and member PII (`seed_keeper`, `keeper_contact`,
  keeper names) appear in no shipped file (grep of `dist/` = 0 hits). All live
  outside `site/`, the source root, so they are never emitted.
- `./unify audit --base-url … --pretty-urls` → **0 broken, exit 0**.
- Header (leaf mark) and contact strip identical on every page via shared
  `_includes` fragments; the lending page's `<div slot="footer">` replaces the
  contact strip with membership terms (`grep` confirms 0 contact-strip hits in
  `lending/`, present on catalogue/guides/variety pages).

## What `rules.md` did not answer

- **How the generator is invoked.** The rules say the script "writes into the
  directory unify hands it" but never say what it is handed. The sentence I
  wanted: *what argv does a `--generate` script receive?* I discovered by
  printing: `[unify, script, sourceRoot, generatedRoot, generator-context.json]`
  — after a first attempt wrote straight into `site/` because I guessed argv[2].
- **Whether "shipped as written" for fragments also exempts them from
  rewriting and from link resolution.** Line 57 says unify "rewrites only
  HTML's own URL attributes" and line 10 says fragments ship "as written" — but
  nowhere states that the `href`s *inside a fragment* keep the exact bytes the
  generator wrote and are not rewritten by `--base-url`. I learned it by
  inspecting `dist/families/*.fragment.html`. Worse, relative links inside a
  fragment resolve against the page they are injected into (`/library/catalogue/`),
  which my checker caught 404ing; the fix — baking final absolute URLs from
  `generator-context.json`'s `site.baseUrl` — is an inference, not a rule.
- **Whether a generated (overlay) file can be an `<include>` target.** Nothing
  says includes can read the generated root. I tried it (`_frag/family-nav`
  carries the 12 anchors so the browse page needs no hand-editing each season)
  and it worked.
- **Whether files outside the source root are scanned at all.** "Everything in
  the source root ships" implies everything outside is invisible; I relied on
  that for `drafts/` and `varieties.json`.
- **Audit semantics behind `page-orphan`.** Default audit is clean, but
  `--strict` reports all 225 variety pages as orphans because the only pages
  linking them are fragments, and rules never say fragments don't count as
  linking pages. Inferred from the finding itself; documented rather than
  worked around, since linking all 225 pages from HTML would violate the brief.
- `.fragment.html` under `--pretty-urls` keeps its literal address (`…/families/brassica.fragment.html`) —
  observed, never stated.

## What I had to re-read

The "Merging a page into its layout" section (rules 33–39), especially line 39:
"A bare `<header>`/`<footer>` does **not** replace the layout's — only `slot=`
fills, and it fills the *contents*: where the layout wraps its slot in its own
`<footer>`, write `<p slot=\"footer\">`, or you ship a footer inside a footer."
It didn't land first time because line 34 says a slot fill "replaces the slot,
tag and all", which sounds like whole-element replacement, while line 39 says
fills "the contents" — the two only reconcile in my head as: the fill replaces
the `<slot>` element in place, so the layout's surrounding `<footer>` survives.
I built a scratch site and looked at composed output to be sure:
`<footer><div slot-target>terms</div></footer>`-style nesting, no footer-in-footer.

Also re-read "Styles, scripts, finishing" (57–58) twice: the short clause "or
read it back from an `href` unify rewrote" is the load-bearing hint for the
whole browse design — JS fetches `getAttribute('href')` on the family anchors,
which `--base-url` has already rewritten to `/library/…`.

## What I guessed or inferred

- Excluded `seed_keeper`/`keeper_contact` **names as well as emails** from all
  pages; the brief only forbids `varieties.json`, but "members' names and
  addresses" reads as personal data to keep off the public site.
- Put variety pages at `/varieties/<family-slug>/<slug>/` after noticing the
  export has **225 varieties but only 210 unique slugs** (the Apiaceae and
  Umbellifer entries are double-listed). The brief demands a page per variety,
  and family scoping is the one collision-free layout that stays stable on
  re-export.
- Cloudflare Pages (`*.pages.dev`) redirects extensionless directory URLs to a
  trailing slash; I made fragment links absolute so nothing depends on that.
- The `#family` hash links on variety pages auto-load via a `hashchange`/init
  handler in `browse.js` — not required by the brief, inferred as the natural
  behavior of an anchor to `/catalogue.html#brassica`.
- No feed/sitemap beyond what `--base-url` generates; no `--catalog`/`--search-corpus`.
- `unify.yaml`'s `generate:` resolves from the project root, not the source root
  (the CLI help says "relative path is from the source root" for `--generate`;
  the config value worked from cwd — I did not test the CLI flag's reading).
