---
title: When to sow what
description: A month-by-month sowing calendar for the Fernhollow valley, from the library's volunteers.
---

# When to sow what

The valley warms late. These windows are what we have settled on after eight seasons of library records; every catalogue page repeats the same dates, so the two agree.

![A seed tray of even sprouts](/img/field.svg)

## March to May

- Brassicas under cover from mid-March; straight into the bed by the end of April.
- Peas and beans once the soil takes a bare knee comfortably — usually the first week of May.
- Onion sets, late April, and thin them cruelly early.

## June to August

- Successional salads and beet every fortnight.
- Last broad beans by mid-July, or the mildew gets a vote.

## September onwards

- Garlic in October, winter brassicas as transplants while the beds still hold heat.

When in doubt, look at the catalogue page for the variety: the seed keeper who last grew it writes the window that worked *here*.
