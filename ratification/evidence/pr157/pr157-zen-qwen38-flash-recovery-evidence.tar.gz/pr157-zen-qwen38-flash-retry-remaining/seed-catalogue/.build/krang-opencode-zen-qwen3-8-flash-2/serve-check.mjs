import http from "node:http";
import { readFile } from "node:fs/promises";
import path from "node:path";

const dist = path.resolve("dist");
const types = { ".css": "text/css", ".js": "text/javascript", ".html": "text/html", ".svg": "image/svg+xml", ".xml": "application/xml" };
const server = http.createServer(async (req, res) => {
  const p = decodeURIComponent(new URL(req.url, "http://x").pathname);
  if (!p.startsWith("/library/")) { res.writeHead(404); res.end("outside mount"); return; }
  const base = path.join(dist, p.slice("/library/".length));
  for (const f of [base, path.join(base, "index.html")]) {
    try {
      const d = await readFile(f);
      res.writeHead(200, { "content-type": types[path.extname(f)] ?? "application/octet-stream" });
      res.end(d);
      return;
    } catch {}
  }
  res.writeHead(404);
  res.end("not found: " + p);
});
server.listen(8782, () => console.log("serving /library/ on 8782"));
