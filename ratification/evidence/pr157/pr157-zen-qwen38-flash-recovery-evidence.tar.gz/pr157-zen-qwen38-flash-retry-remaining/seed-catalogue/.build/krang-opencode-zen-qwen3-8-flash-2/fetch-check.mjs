const B = "http://127.0.0.1:8782";
let fails = 0;
async function get(u, label) {
  const r = await fetch(B + u);
  const body = await r.text();
  if (!(r.status === 200 && body.length > 0)) {
    fails++;
    console.log("FAIL", label ?? u, r.status, body.slice(0, 120));
  }
  return { status: r.status, body };
}

// every chrome, guide, and sample variety page
for (const u of ["/", "/catalogue/", "/lending/", "/guides/", "/guides/when-to-sow/", "/guides/saving-seed/", "/guides/bed-planning/", "/varieties/brassica/nine-star-pea-1/", "/varieties/umbellifer/late-squash-1/", "/varieties/apiaceae/late-squash-1/"]) {
  await get("/library" + u, "page " + u);
}

// the browse page exactly as a browser sees it: follow each family href,
// then resolve each link inside the returned fragment against the PAGE url.
const cat = await get("/library/catalogue/", "catalogue");
const nav = [...cat.body.matchAll(/<a id="([a-z-]+)" href="([^"]+)" data-family/g)];
console.log("family links on browse page:", nav.length);
let fetched = 0;
for (const [, slug, href] of nav) {
  const frag = await get(href, "fragment " + slug);
  for (const m of frag.body.matchAll(/<a href="([^"]+)"/g)) {
    const u = new URL(m[1]);
    if (u.origin !== "https://fernhollow.pages.dev" || !u.pathname.startsWith("/library/")) {
      fails++; console.log("FAIL fragment link not baked for the publish address:", m[1]);
    }
    await get(u.pathname, "variety " + m[1]);
    fetched++;
  }
}
console.log("variety links fetched as the browser resolves them:", fetched);

// assets and generated files
for (const u of ["/css/site.css", "/css/guides.css", "/js/browse.js", "/img/leaf.svg", "/img/field.svg", "/sitemap.xml"]) {
  await get("/library" + u, "asset " + u);
}

// every resource address in a page must carry the /library prefix
const scan = await get("/library/varieties/solanum/purple-squash-1/", "scan page");
const bad = [...scan.body.matchAll(/(?:href|src)="\/(?!library)[^"]*"/g)].map((m) => m[0]);
console.log("root-relative-without-prefix on a page:", bad.length ? bad : "none");

// nothing that must never appear
for (const needle of ["drafts", "frost-dates", "keeper_contact", "fernhollow-members", "seed_keeper", "J. Vance"]) {
  for (const page of ["/library/", "/library/lending/", "/library/catalogue/", "/library/families/allium.fragment.html"]) {
    const body = (await get(page, "leak base " + page)).body;
    if (body.includes(needle)) { fails++; console.log("FAIL leak", needle, "in", page); }
  }
}
console.log(fails === 0 ? "ALL CHECKS PASSED" : fails + " FAILURES");
process.exit(fails === 0 ? 0 : 1);
