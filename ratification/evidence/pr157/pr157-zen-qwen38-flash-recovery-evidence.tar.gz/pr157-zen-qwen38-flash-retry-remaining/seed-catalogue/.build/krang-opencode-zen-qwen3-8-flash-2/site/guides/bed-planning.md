---
title: Planning a small seed bed
description: A one-bed rotation for members who want to grow out borrowed seed without a garden to spare.
---

# Planning a small seed bed

You do not need an acre. A bed three metres by one carries a year of library seed if you plan it tight.

![A narrow planted bed between grass paths](/img/field.svg)

## The shape of the year

1. **Spring (March–May):** sow the borrowed brassicas and salads down the near half.
2. **Early summer:** pull them as they bolt and harvest seed, and move the beans and squash onto the ground with a week's gap.
3. **Late summer:** the far half takes the roots and onions you did not sow early.
4. **Autumn:** clear the last seed heads, mulch the whole bed with whatever the swap left over, and let the worms file it.

## Two rules that keep the bed honest

- Never grow the same family in the same foot of soil two years running — that is how the library loses varieties to disease.
- Give a seed-save bed its own corner near the house. You will forget the far plot at exactly the week the pods need cutting.

One bed, twelve families, and the rotation maths works out fine.
