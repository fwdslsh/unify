import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";

const [, , sourceRoot, generatedRoot, contextPath] = process.argv;
const context = JSON.parse(readFileSync(contextPath, "utf8"));
const data = JSON.parse(readFileSync(path.join(sourceRoot, "..", "varieties.json"), "utf8"));

const esc = (s) =>
  String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const famSlug = (f) => f.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

const families = new Map();
for (const v of data.varieties) {
  const fs = famSlug(v.family);
  if (!families.has(fs)) families.set(fs, { name: v.family, varieties: [] });
  families.get(fs).varieties.push(v);
}

mkdirSync(path.join(generatedRoot, "varieties"), { recursive: true });
mkdirSync(path.join(generatedRoot, "families"), { recursive: true });

for (const v of data.varieties) {
  const fs = famSlug(v.family);
  mkdirSync(path.join(generatedRoot, "varieties", fs), { recursive: true });
  writeFileSync(
    path.join(generatedRoot, "varieties", fs, `${v.slug}.html`),
    `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(v.name)} (${esc(v.family)})</title>
<meta name="description" content="${esc(v.name)} — ${esc(v.family)} seed, ready to lend. Sow ${esc(v.sow)}, matures in ${v.days_to_maturity} days.">
</head>
<body class="variety">
<main>
<p class="crumbs"><a href="/index.html">Home</a> &rsaquo; <a href="/catalogue.html">Browse the catalogue</a> &rsaquo; ${esc(v.family)}</p>
<h1>${esc(v.name)}</h1>
<dl class="specs">
<dt>Family</dt><dd><a href="/catalogue.html#${fs}">${esc(v.family)}</a></dd>
<dt>Season</dt><dd>${esc(v.season)}</dd>
<dt>Sow</dt><dd>${esc(v.sow)}</dd>
<dt>Days to maturity</dt><dd>${v.days_to_maturity}</dd>
<dt>Packets available this season</dt><dd>${v.packets_available}</dd>
</dl>
<p class="notes">${esc(v.notes)}</p>
<p><a href="/lending.html">How to borrow this seed</a></p>
</main>
</body>
</html>
`
  );
}

const navLinks = [...families.entries()]
  .map(([fs, fam]) => `  <a id="${fs}" href="/families/${fs}.fragment.html" data-family="${fs}">${esc(fam.name)} <span class="n">${fam.varieties.length}</span></a>`)
  .join("\n");
mkdirSync(path.join(generatedRoot, "_frag"), { recursive: true });
writeFileSync(
  path.join(generatedRoot, "_frag", "family-nav.fragment.html"),
  `<p id="season-label">This season the export lists <strong>${data.varieties.length}</strong> varieties across <strong>${families.size}</strong> families.</p>
<nav class="family-nav" aria-label="Plant families">
${navLinks}
</nav>
`
);

// Fragments ship byte-for-byte: unify rewrites nothing inside them, and a
// relative link would resolve against whatever page the fragment is injected
// into. With a --base-url, bake each variety address in absolute so it
// resolves for the published site from any page; without one, keep the
// address relative to the browse page (which unify serves with trailing slash).
const base = context.site?.baseUrl ? context.site.baseUrl.replace(/\/+$/, "/") : null;
const varietyHref = (fs, slug) =>
  base ? `${base}varieties/${fs}/${slug}/` : `../varieties/${fs}/${slug}/`;

for (const [fs, fam] of families) {
  const rows = fam.varieties
    .map(
      (v) =>
        `  <li><a href="${varietyHref(fs, v.slug)}">${esc(v.name)}</a><span class="meta">${esc(v.season)} · ${v.packets_available} packets</span></li>`
    )
    .join("\n");
  writeFileSync(
    path.join(generatedRoot, "families", `${fs}.fragment.html`),
    `<section class="family-list" aria-label="${esc(fam.name)} varieties">
<h2>${esc(fam.name)} <span class="count">(${fam.varieties.length} varieties)</span></h2>
<ul class="variety-list">
${rows}
</ul>
</section>
`
  );
}

console.log(
  `gen: ${data.varieties.length} variety pages, ${families.size} family fragments`
);
