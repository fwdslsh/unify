---
title: Growing guides
---

# Growing guides

Notes from Fernhollow volunteers, kept plain and tried out in real beds.

- [When to sow what](/guides/when-to-sow.md)
- [Saving seed from the big four](/guides/saving-seed.md)
- [Planning a small seed bed](/guides/bed-planning.md)
