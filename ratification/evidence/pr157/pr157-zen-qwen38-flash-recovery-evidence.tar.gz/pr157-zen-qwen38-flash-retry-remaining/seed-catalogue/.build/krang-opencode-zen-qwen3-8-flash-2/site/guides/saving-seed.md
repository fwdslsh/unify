---
title: Saving seed from the big four
description: How Fernhollow members save honest seed from beans, tomatoes, lettuce and squash.
---

# Saving seed from the big four

These four give the most seed to the library each autumn. They are also the easiest to get wrong, so here is what the keepers have agreed on.

## Beans

Leave a few pods on the plant until they rattle. Shell by hand, dry the seed a further week on a plate, and freeze it for a day before it goes in the tin — weevils hate that.

## Tomatoes

Scoop the seedy jelly into a jar with a little water. Ferment it three days until a skin forms, skim, rinse, dry on a coffee filter. Never boil or bake the gel — that is the commonest failure we get back.

## Lettuce

Lettuce bolts; that is the point. Keep the best early heart, let it throw a tall stem, and cut the seed heads when the fluff first shows. Winnow on a breezy day.

## Squash

Only save from one squash family per bed-year, or the next generation is nobody's. Wash the seeds free of pulp, dry hard for two weeks — squash seed is smug about being dry — and label with the parent, not just the variety.

Return one packet, keep the rest for your own beds, and bring the leftovers to the autumn swap.
