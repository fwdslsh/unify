(function () {
  var nav = document.querySelector(".family-nav");
  var out = document.getElementById("family-results");
  var status = document.getElementById("family-status");
  if (!nav || !out) return;

  function buttonFor(slug) {
    return nav.querySelector('a[data-family="' + slug + '"]');
  }

  function load(link) {
    nav.querySelectorAll("a").forEach(function (a) {
      a.setAttribute("aria-pressed", a === link ? "true" : "false");
    });
    status.textContent = "Loading " + link.firstChild.textContent.trim() + "…";
    out.innerHTML = "";
    // The href here is the address unify rewrote for this deployment,
    // so it resolves from any page at any depth.
    fetch(link.getAttribute("href"))
      .then(function (r) {
        if (!r.ok) throw new Error(r.status);
        return r.text();
      })
      .then(function (html) {
        out.innerHTML = html;
        status.textContent = "";
      })
      .catch(function () {
        status.textContent = "That family could not be loaded — check the connection and tap again.";
      });
  }

  nav.addEventListener("click", function (e) {
    var link = e.target.closest("a[data-family]");
    if (!link) return;
    e.preventDefault();
    if (history.replaceState) history.replaceState(null, "", "#" + link.getAttribute("data-family"));
    load(link);
  });

  window.addEventListener("hashchange", function () {
    var link = buttonFor(location.hash.slice(1));
    if (link) load(link);
  });

  var start = buttonFor(location.hash.slice(1));
  if (start) load(start);
})();
