# Fernhollow Seed Library — build report

## The publish command

    ./unify build --clean --pretty-urls --base-url https://fernhollow.pages.dev/library/ --audit

`unify.yaml` holds only `generate: scripts/gen.mjs`; everything address-specific stays on
the command line so the publish command is the whole truth. Exit 0 ⇒ `dist/` is the
published site. I developed against `./unify build --dry-run --strict` (every check in one
pass, plus the page→layout list); `--strict` alone reports the 225 `page-orphan` advisories
described below, so the publish command audits broken links only.

## What I checked, and how

- `--audit` publishes only if the audit passes: 0 broken links — every `href`/`src` unify
  can see resolves to an emitted file.
- `_verify/check.mjs` mounts `dist/` at `/library/` on a local HTTP server that mimics
  pages.dev (a directory request without its trailing slash gets a 301 to it) and fetches
  every page **as a visitor at `https://fernhollow.pages.dev/library/` would**, rewritten
  to localhost: home, browse, lending, the guides index and all three guides, a sample
  variety page, `site.css`, `guides.css`, `leaf.svg`, `sitemap.xml` — all 200.
- Every emitted `href`/`src` on every page is asserted to start with `/library/`
  (or be `mailto:`/`tel:`) — nothing can 404 by missing the subdirectory, and nothing is
  off-origin. No emitted URL ends in `.html`.
- **The after-load fetch, verified the way a browser resolves it:** the check parses the
  12 family chip hrefs out of `/library/browse/` (these are unify-rewritten absolute paths,
  exactly what the page JS reads back from `link.href`), fetches each — 12× 200 — then
  resolves **each of the 225 item hrefs inside the fetched fragments** with
  `new URL(href, 'https://fernhollow.pages.dev/library/browse/')` (the browse page's URL,
  since injected HTML resolves against the document) and fetches every one: 225× 200, each
  with the shared header and its `<h1>`.
- `dist/browse/index.html` is 4 KB and asserted to contain **no** `/varieties/` link —
  opening it ships only the 12 family chips; per-family checks confirm each fragment holds
  exactly that family's export count (22+34+26+19+17+15+21+14+12+18+16+11 = 225).
- Privacy greps over `dist/`: no `varieties.json`, no `drafts/` content, no
  `seed_keeper`/`keeper_contact` strings, no member name or email; `/library/varieties.json`,
  `/library/drafts/…` and `/library/_layout.html` all serve 404. The `_*` default keeps
  `_layout.html`/`_includes/` out; `drafts/` and `varieties.json` live outside `site/`,
  so the build never sees them as pages.

## What `rules.md` did not answer

**The sentence I wanted and could not find: how the `--generate` script is invoked.** The
docs say "unify runs it before every build and it writes into the directory unify hands
it" — but never *how the directory is handed over*: no documented argv order, working
directory, or context file. I found it by running a probe script that dumped
`process.argv`: it is `node <script> <sourceRoot> <generatedRoot> <context.json>`, cwd =
the source root, and the fourth argument is a JSON file containing `paths`, `site`
(including `baseUrl` and `prettyUrls`) and the source-pages inventory. Nothing in the
documentation mentions that context file except the `--source-inventory` flag line.

Related unanswered questions I resolved only by building a probe site:

- **Do `--generate`-written files go through the same pipeline as hand-written source?**
  "it writes into the directory unify hands it, never into `site/`" doesn't say whether
  those files are layouts-wrapped, link-rewritten, canonical-added pages or inert
  fixtures. They are full source-equivalent pages — verified, not read.
- **Where does a `.fragment.html` land in the output, and are its links rewritten?**
  The one phrase bearing on it ("a bare snippet shipped as written") is the whole answer
  to neither question. It ships at the same path, still named `*.fragment.html`, byte for
  byte, links unrewritten — which is why the fragment item hrefs are written as
  page-relative `../varieties/<family>/<slug>/` instead of `/varieties/<slug>.html`.

## What I re-read, and why it didn't land the first time

- *"A bare `<header>`/`<footer>` does not replace the layout's — only `slot=` fills, and
  it fills the contents: where the layout wraps its slot in its own `<footer>`, write
  `<p slot="footer">`, or you ship a footer inside a footer."* I re-read this three times.
  It sits in direct tension with the earlier rule that a fill "replaces the slot, tag and
  all" — "fills the *contents*" suggests the fill is spliced inside something, "replaces
  … tag and all" suggests it is not. The probe settled it: a named slot inside the layout's
  own `<footer>` is replaced wholesale by the fill element, so the fill must not itself be
  a `<footer>`. The lending page fills `<div slot="footer">` (terms); every other page
  ships the layout's contact-strip fallback.
- *"keep every `url()` in a stylesheet file and every fetched address relative to the page
  — or read it back from an `href` unify rewrote."* The first two options are prohibitions;
  the third was a *technique*, and I only saw that on re-reading it as the answer to the
  fetch problem. The browse JS therefore reads `link.href` from the chips (unify has
  already baked in `/library/`), and `fetch()` never appears as a written-down address.
- *"`tags`/`categories` are allowed but build nothing"* — fine — but the whole
  derived-index sentence ("a post index … `generate: scripts/gen.mjs` … runs it before
  every build") reads like a feature note until you realise it is also the *only* answer
  to "225 pages from a re-export". I re-read it after realising no template language
  exists to loop over the JSON with.

## What I guessed or inferred rather than read

- **Addressing the slug collisions.** `varieties.json` has 225 rows but 210 unique slugs —
  the export lists Apiaceae and Umbelliferae as separate families and repeats 15
  name+slug pairs between them. Nothing says how to address that; I inferred the export
  intends a page per *(family, slug)* and chose `/varieties/<family>/<slug>/` rather than
  de-duplicating with suffixes, because the file is re-exported by someone who will never
  hand-edit a page — the generator re-derives addresses each season and fails loudly if
  they ever collide.
- **Privacy.** The brief bans `varieties.json` from the output; it does not say whether
  `seed_keeper` and `keeper_contact` may appear *on variety pages*. I inferred a member's
  email address is not public content and omitted both fields from every page.
- **htmx vs hand-rolled JS.** `rules.md` names `hx-get` next to `fetch` as if htmx is the
  idiom, but "nothing may be loaded from another website" rules out a CDN runtime, and
  "no client runtime" is unify's own tagline. I guessed at ~35 lines of plain
  `addEventListener` + `fetch` + `innerHTML` in `/assets/browse.js` (also handles the
  `#family` deep-link from variety-page breadcrumbs).
- **"without the page reloading"** = prevent the chip's default and swap a region's
  content; the chip is still a real `<a href>`, so with JS off a visitor gets the bare
  fragment document — degraded, not broken.
- **Pages-style serving.** I assumed `*.pages.dev` redirects `/library/browse` →
  `/library/browse/`; the fragment links' `../` resolution only works with that. The
  local verifier emulates the redirect (it observed the 301), but I cannot confirm
  Cloudflare's behaviour from here.
- The audit flags all 225 generated pages as `page-orphan` ("no other page links to this
  one") because their only inbound links live *inside* the fragments, which ship as written
  and are never crawled. That is a true statement about unify's view and a false statement
  about the site, so I publish with `--audit` (broken-only, exit 0) and deliberately did
  not `--strict` the publish command to hide it.

## File map (source of truth after this build)

    site/_layout.html, site/_includes/{header,footer}.fragment.html   shared chrome
    site/index.html  site/lending.html                                hand-written pages
    site/guides/  _layout.html, index.md + 3 volunteer .md guides, guides.css
    site/assets/  site.css, leaf.svg, browse.js
    scripts/gen.mjs  ← runs before every build; writes varieties/, browse/families/*.fragment.html, browse.html
    _verify/check.mjs  served-address checks (underscore dir; never published)
