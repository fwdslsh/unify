import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';

const DIST = path.resolve('dist');
const BASE = '/library';
let redirects = 0;

const server = http.createServer((req, res) => {
  const url = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (!url.startsWith(BASE + '/') && url !== BASE) { res.writeHead(404); res.end('outside mount'); return; }
  let rel = url.slice(BASE.length);
  const fp = path.join(DIST, rel);
  if (!fp.startsWith(DIST)) { res.writeHead(400); res.end(); return; }
  if (fs.existsSync(fp) && fs.statSync(fp).isFile()) {
    res.writeHead(200, { 'content-type': fp.endsWith('.css') ? 'text/css' : fp.endsWith('.js') ? 'text/javascript' : fp.endsWith('.svg') ? 'image/svg+xml' : fp.endsWith('.xml') ? 'application/xml' : 'text/html' });
    res.end(fs.readFileSync(fp));
    return;
  }
  const idx = path.join(fp, 'index.html');
  if (fs.existsSync(idx)) {
    if (!url.endsWith('/')) { redirects++; res.writeHead(301, { location: url + '/' }); res.end(); return; }
    res.writeHead(200, { 'content-type': 'text/html' });
    res.end(fs.readFileSync(idx));
    return;
  }
  res.writeHead(404); res.end('404 ' + url);
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const origin = 'http://127.0.0.1:' + server.address().port;
const ORIGIN_URL = 'https://fernhollow.pages.dev';

const fails = [];
const ok = (cond, msg) => { if (!cond) fails.push(msg); };

const get = async (href) => {
  let res = await fetch(new URL(href, ORIGIN_URL).href.replace(ORIGIN_URL, origin), { redirect: 'manual' });
  let url = new URL(href, ORIGIN_URL).href.replace(ORIGIN_URL, origin);
  let hops = 0;
  while (res.status >= 301 && res.status <= 308 && hops < 4) {
    url = new URL(res.headers.get('location'), url).href;
    res = await fetch(url, { redirect: 'manual' });
    hops++;
  }
  return { res, url, text: res.status === 200 ? await res.text() : '' };
};

const attrs = (html, name) => [...html.matchAll(new RegExp(name + '="([^"]+)"', 'g'))].map((m) => m[1]);

// 1. entry pages
for (const p of ['/library/', '/library/browse/', '/library/lending/', '/library/guides/', '/library/guides/sowing/', '/library/guides/seed-saving/', '/library/guides/compost/']) {
  const { res, text } = await get(p);
  ok(res.status === 200, p + ' status ' + res.status);
  if (p !== '/library/guides/' && p !== '/library/browse/') ok(text.includes('leaf.svg') || true, '');
  ok(/class="site-header"/.test(text), p + ' missing shared header');
  ok(/src="\/library\/assets\/leaf\.svg"/.test(text), p + ' header leaf mark not at served address');
  // every page URL: no .html
  ok(!p.endsWith('.html'), p + ' ends in .html');
  // every emitted href/src resolves under /library/
  for (const a of [...attrs(text, 'href'), ...attrs(text, 'src')]) {
    if (a.startsWith('mailto:') || a.startsWith('tel:') || a.startsWith('#')) continue;
    ok(a.startsWith(ORIGIN_URL) || a.startsWith(BASE), p + ' has non-base address: ' + a);
  }
}

// 2. lending: terms instead of contact strip
{
  const { text } = await get('/library/lending/');
  ok(text.includes('Membership terms'), 'lending missing terms');
  ok(!text.includes('contact-strip'), 'lending still ships contact strip');
}

// 3. guides: own look + identical chrome
{
  const { text } = await get('/library/guides/sowing/');
  ok(text.includes('/library/guides/guides.css'), 'guides.css not loaded');
  ok(text.includes('/library/assets/site.css'), 'shared css not loaded on guides');
  ok(text.includes('Fernhollow contact strip') || text.includes('seeds@fernhollow.example'), 'guides missing shared footer');
}

// 4. browse page: no varieties shipped inline
{
  const { res, text, url } = await get('/library/browse');
  ok(res.status === 200, 'browse redirect status ' + res.status);
  ok(url.endsWith('/library/browse/'), 'browse final url ' + url);
  ok(!text.includes('/varieties/'), 'browse page embeds variety links');
  const chips = attrs(text, 'data-family');
  const chipHrefs = [...text.matchAll(/<li class="family-chip"><a href="([^"]+)"/g)].map((m) => m[1]);
  ok(chipHrefs.length === 12, 'expected 12 chips, got ' + chipHrefs.length);
  ok(chipHrefs.every((h) => h.startsWith(BASE)), 'chip href not under /library/: ' + chipHrefs.find((h) => !h.startsWith(BASE)));

  // 5. what the browser fetches AFTER load: each chip link.href, then each item href resolved
  //    the way the browser would resolve it inside the page document
  const data = JSON.parse(fs.readFileSync('varieties.json', 'utf8'));
  const counts = {};
  for (const v of data.varieties) counts[v.family] = (counts[v.family] || 0) + 1;
  let totalLinks = 0;
  for (const href of chipHrefs) {
    const r = await get(href);
    ok(r.res.status === 200, 'fragment 404: ' + href);
    const items = attrs(r.text, 'href');
    ok(items.length > 0, 'empty fragment ' + href);
    totalLinks += items.length;
    const famName = r.text.match(/<h2>([^<]+)/)[1].trim();
    ok(items.length === counts[famName], 'fragment ' + famName + ' has ' + items.length + ' of ' + counts[famName]);
    for (const item of items) {
      const resolved = new URL(item, 'https://fernhollow.pages.dev' + '/library/browse/');
      const page = await get(resolved.pathname);
      ok(page.res.status === 200, 'fragment item 404: ' + item + ' -> ' + resolved.pathname);
      ok(/class="site-header"/.test(page.text) && /<h1>/.test(page.text), 'variety page lacks chrome/h1: ' + item);
    }
  }
  ok(totalLinks === 225, 'variety links across fragments = ' + totalLinks);
}

// 6. variety pages reachable by address + chrome + asset fetches
{
  const { text } = await get('/library/varieties/brassica/nine-star-pea-1/');
  ok(text.includes('Nine Star Pea 1'), 'variety page content missing');
  const css = await get('/library/assets/site.css');
  ok(css.res.status === 200 && css.text.includes('--green'), 'site.css');
  const js = await get('/library/assets/browse.js');
  ok(js.res.status === 200 && js.text.includes('fetch('), 'browse.js');
  const svg = await get('/library/assets/leaf.svg');
  ok(svg.res.status === 200 && svg.text.includes('<svg'), 'leaf.svg');
}

// 7. sitemap + no stray files
{
  const { text } = await get('/library/sitemap.xml');
  ok(text.includes('https://fernhollow.pages.dev/library/'), 'sitemap urls');
  ok(!text.includes('.html'), 'sitemap has .html urls');
}

// 8. 404 sanity: drafts and json must NOT exist at served paths
for (const p of ['/library/drafts/frost-dates.md', '/library/drafts/frost-dates/', '/library/varieties.json', '/library/browse/families/brassica/', '/library/_layout.html', '/library/unify.yaml', '/library/scripts/gen.mjs']) {
  const { res } = await get(p);
  ok(res.status === 404, 'served but should not exist: ' + p);
}

console.log('redirects:', redirects, '| problems:', fails.length);
fails.forEach((f) => console.log(' -', f));
server.close();
process.exit(fails.length ? 1 : 0);
