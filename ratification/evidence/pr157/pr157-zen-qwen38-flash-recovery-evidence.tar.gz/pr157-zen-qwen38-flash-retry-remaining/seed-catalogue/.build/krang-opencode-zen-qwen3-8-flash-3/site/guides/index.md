---
title: Growing guides
description: Practical growing notes for seed lent by Fernhollow Seed Library, written by volunteers.
---
# Growing guides

Short, practical notes from Fernhollow volunteers, written for our cool valley climate and short working season.

- [Sowing in the Fernhollow climate](/guides/sowing.md) — a volunteer's calendar for our four sowing windows.
- [Saving seed from your harvest](/guides/seed-saving.md) — what the library asks you to bring back.
- [Compost before you sow](/guides/compost.md) — preparing a bed the season you borrow for.
