import fs from 'node:fs';
import path from 'node:path';

const [, , sourceRoot, generatedRoot, contextPath] = process.argv;
const context = JSON.parse(fs.readFileSync(contextPath, 'utf8'));
const pretty = Boolean(context.site && context.site.prettyUrls);

const data = JSON.parse(fs.readFileSync(path.resolve(sourceRoot, '..', 'varieties.json'), 'utf8'));
const varieties = data.varieties;
if (!Array.isArray(varieties) || varieties.length === 0) {
  throw new Error('varieties.json has no varieties array');
}

const esc = (s) => String(s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const famKey = (f) => String(f).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

const families = new Map();
for (const v of varieties) {
  const k = famKey(v.family);
  if (!k) throw new Error('variety ' + v.slug + ' has an unusable family name');
  if (!families.has(k)) families.set(k, { label: v.family, list: [] });
  families.get(k).list.push(v);
}
const keys = [...families.keys()].sort();
const pagePath = (v) => 'varieties/' + famKey(v.family) + '/' + v.slug;
const seen = new Set();
for (const v of varieties) {
  const p = pagePath(v);
  if (seen.has(p)) throw new Error('duplicate page address in export: ' + p);
  seen.add(p);
}

const write = (rel, content) => {
  const abs = path.join(generatedRoot, rel);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, content);
};

const itemHref = (v) => '../' + pagePath(v) + (pretty ? '/' : '.html');

for (const v of varieties) {
  const description = esc(v.name) + ' (' + esc(v.family) + ') — sow ' + esc(v.sow)
    + ', about ' + esc(v.days_to_maturity) + ' days to maturity; '
    + esc(v.packets_available) + ' packets available in the ' + esc(v.season) + ' list.';
  write(pagePath(v) + '.html', [
    '<!doctype html>',
    '<html lang="en">',
    '<head>',
    '<meta charset="utf-8">',
    '<meta name="viewport" content="width=device-width, initial-scale=1">',
    '<title>' + esc(v.name) + ' (' + esc(v.family) + ')</title>',
    '<meta name="description" content="' + description + '">',
    '</head>',
    '<body class="variety nav-browse-active">',
    '<main>',
    '<article class="variety-card">',
    '<h1>' + esc(v.name) + '</h1>',
    '<p class="crumbs"><a href="/browse.html">Browse the catalogue</a> &middot; <span>' + esc(v.family) + '</span></p>',
    '<dl class="facts">',
    '<dt>Plant family</dt><dd>' + esc(v.family) + '</dd>',
    '<dt>Lending season</dt><dd>' + esc(v.season) + '</dd>',
    '<dt>Sow</dt><dd>' + esc(v.sow) + '</dd>',
    '<dt>Days to maturity</dt><dd>' + esc(v.days_to_maturity) + '</dd>',
    '<dt>Packets available</dt><dd>' + esc(v.packets_available) + '</dd>',
    '</dl>',
    '<h2>Variety notes</h2>',
    '<p>' + esc(v.notes) + '</p>',
    '</article>',
    '</main>',
    '</body>',
    '</html>',
    '',
  ].join('\n'));
}

for (const k of keys) {
  const fam = families.get(k);
  const items = fam.list.map((v) =>
    '<li><a href="' + itemHref(v) + '">' + esc(v.name) + '</a> &mdash; '
    + esc(v.season) + ', sow ' + esc(v.sow) + '</li>');
  write('browse/families/' + k + '.fragment.html', [
    '<h2>' + esc(fam.label) + ' <span class="count">(' + items.length + ' varieties)</span></h2>',
    '<ul class="variety-list">',
    ...items,
    '</ul>',
    '',
  ].join('\n'));
}

const chips = keys.map((k) => {
  const fam = families.get(k);
  return '<li class="family-chip"><a href="/browse/families/' + k + '.fragment.html" data-family="' + esc(fam.label) + '">'
    + esc(fam.label) + ' <span class="count">(' + fam.list.length + ')</span></a></li>';
});
write('browse.html', [
  '<!doctype html>',
  '<html lang="en">',
  '<head>',
  '<meta charset="utf-8">',
  '<meta name="viewport" content="width=device-width, initial-scale=1">',
  '<title>Browse the catalogue</title>',
  '<meta name="description" content="Browse ' + varieties.length + ' vegetable seed varieties in ' + keys.length + ' plant families, lent by Fernhollow Seed Library.">',
  '</head>',
  '<body class="browse-page nav-browse-active">',
  '<main>',
  '<h1>Browse the catalogue</h1>',
  '<p class="browse-intro">' + esc(data.season) + ' collection: ' + varieties.length
    + ' varieties across ' + keys.length + ' plant families. Choose a family and only that family\u2019s list is downloaded \u2014 nothing else arrives.',
  '</p>',
  '<ul class="family-chips">',
  ...chips,
  '</ul>',
  '<div id="family-results" aria-live="polite"></div>',
  '</main>',
  '<script src="/assets/browse.js" defer></script>',
  '</body>',
  '</html>',
  '',
].join('\n'));
