---
title: Sowing in the Fernhollow climate
description: How Fernhollow's four sowing windows work, and what to sow in each, from a volunteer's logbook.
---
# Sowing in the Fernhollow climate

The catalogue gives every variety a sowing window — *Spring*, *Early summer*, *Late summer* or *Autumn* — but the windows mean something specific here. We sit in a frost-pocket, and our soil is late to warm.

## Spring (late March to May)

Wait for the soil to crumble in the hand, not the calendar. Brassicas and beet can go in first; beans and squash wait until the last frost risk passes. The packet's own date range is written for our valley, so trust it over general advice.

## Early summer (May to June)

Our real busy weeks. Succession-sow salad and peas every fortnight, and get the long-season crops — pumpkins, sweetcorn, winter storage roots — into the ground by the end of June at the latest.

## Late summer (July to August)

The second spring. Sow hardy leaves, turnips and spring cabbage for next year. A cold frame earns its keep from here on.

## Autumn (September to October)

Broad beans and overwintering peas, if the beds are not already under green manure. Everything else waits.
