---
title: Saving seed from your harvest
description: How to save and return seed to Fernhollow Seed Library so a variety keeps its character year on year.
---
# Saving seed from your harvest

The library runs on returned seed. A packet you borrow is expected to come back as more packets than you took — that is the whole of the lending bargain.

## Pick the right plant

Let three or four plants grow on to full maturity and choose the one that looks healthiest and most like the description on the packet. Seed from your earliest-flowering plant quietly turns a variety soft over the years.

## Dry, clean, label

- Ferment wet seed (tomato, cucumber) for two or three days, then rinse and dry on a plate, not in the sun.
- Thresh dry seed (beans, peas, lettuce) and winnow the chaff with a screensieve.
- Label with **variety name, family and year** on the envelope itself — inside slips get lost.

Dried seed goes into the tin by the lending desk any open day; a volunteer will weigh it and record the return against your name.
