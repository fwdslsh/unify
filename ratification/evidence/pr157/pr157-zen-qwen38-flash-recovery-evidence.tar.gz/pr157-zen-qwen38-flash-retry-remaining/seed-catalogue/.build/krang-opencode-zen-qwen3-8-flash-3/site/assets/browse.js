(function () {
  'use strict';
  var results = document.getElementById('family-results');
  var chips = Array.prototype.slice.call(document.querySelectorAll('.family-chip a'));
  if (!results || !chips.length) return;

  function markActive(link) {
    chips.forEach(function (chip) {
      if (chip === link) { chip.setAttribute('aria-current', 'true'); }
      else { chip.removeAttribute('aria-current'); }
    });
  }

  function load(link) {
    markActive(link);
    results.innerHTML = '<p class="loading">Loading ' + link.dataset.family + '…</p>';
    fetch(link.href).then(function (response) {
      if (!response.ok) { throw new Error(response.status); }
      return response.text();
    }).then(function (html) {
      results.innerHTML = html;
      history.replaceState(null, '', '#' + link.dataset.family);
    }).catch(function () {
      results.innerHTML = '<p class="error">That family list could not be downloaded — check the connection and choose the family again.</p>';
    });
  }

  chips.forEach(function (chip) {
    chip.addEventListener('click', function (event) {
      event.preventDefault();
      load(chip);
    });
  });

  var wanted = decodeURIComponent((location.hash || '').replace('#', ''));
  if (/^[a-z0-9-]+$/.test(wanted)) {
    var initial = chips.filter(function (chip) { return chip.dataset.family === wanted; })[0];
    if (initial) { load(initial); }
  }
})();
