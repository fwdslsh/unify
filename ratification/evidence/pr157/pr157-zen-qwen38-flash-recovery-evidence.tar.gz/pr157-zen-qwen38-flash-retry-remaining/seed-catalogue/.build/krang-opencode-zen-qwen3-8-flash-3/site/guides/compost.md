---
title: Compost before you sow
description: Preparing a bed with compost the season before you borrow seed, so lent varieties reach their days to maturity.
---
# Compost before you sow

Most "difficult" seasons at Fernhollow are not the seed's fault — they are beds that were never fed.

## The year before

Croppy ground here is thin and cold. Spread a barrow-load of compost or well-rotted manure over each square metre in autumn and let worms drag it in over the winter. Do not dig it under; on our clay subsoil digging just smears a hard pan.

## The spring you sow

Fork in a top-dressing of an inch of compost and rake level before the packets arrive from the library. Beans, peas and squash resent fresh manure — compost only.

## Keep a bin going

The library keeps a shared compost bin behind the Old Post Room. If you return saved seed, you can take compost out — that is how the valley's seed keeps coming round.
