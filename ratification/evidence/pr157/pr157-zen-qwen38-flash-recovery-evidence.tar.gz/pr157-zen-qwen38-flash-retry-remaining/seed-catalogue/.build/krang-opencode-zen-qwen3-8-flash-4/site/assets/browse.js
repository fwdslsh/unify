/* Browse the catalogue: fetch one family's list when it is picked.
   Every address comes back from the href attributes of this page's own
   links, which the build has already rewritten for the site's mount —
   nothing here is hardcoded and nothing is loaded from another site. */
(function () {
  if (!window.fetch || !window.DOMParser) return;
  var nav = document.querySelector('.browse-families');
  var out = document.getElementById('family-results');
  if (!nav || !out) return;
  var links = nav.querySelectorAll('a.family-link');
  var cache = {};

  nav.addEventListener('click', function (ev) {
    var link = ev.target.closest ? ev.target.closest('a.family-link') : null;
    if (!link || !nav.contains(link)) return;
    ev.preventDefault();
    show(link);
  });

  function show(link) {
    for (var i = 0; i < links.length; i++) links[i].removeAttribute('aria-current');
    link.setAttribute('aria-current', 'true');
    var url = link.href;
    var name = link.textContent.replace(/\(.*?\)/, '').trim();

    function render(familyHtml) {
      var tpl = document.createElement('template');
      tpl.innerHTML = familyHtml;
      var panel = tpl.content.querySelector('.family-panel');
      out.innerHTML = '';
      if (panel) {
        out.appendChild(panel);
      } else {
        out.textContent = 'The ' + name + ' list arrived empty — please reload.';
      }
    }

    if (cache[url]) { render(cache[url]); return; }
    out.setAttribute('aria-busy', 'true');
    out.textContent = 'Loading ' + name + ' varieties…';
    fetch(url).then(function (resp) {
      if (!resp.ok) throw new Error('HTTP ' + resp.status);
      return resp.text();
    }).then(function (text) {
      var doc = new DOMParser().parseFromString(text, 'text/html');
      var panel = doc.querySelector('.family-panel');
      if (!panel) throw new Error('panel not found');
      cache[url] = panel.outerHTML;
      out.removeAttribute('aria-busy');
      render(cache[url]);
    }).catch(function () {
      out.removeAttribute('aria-busy');
      out.textContent = 'Could not load ' + name + ' just now. Reuse the link above to open its plain list instead.';
    });
  }
})();
