import fs from 'node:fs';
import path from 'node:path';

const overlay = process.argv[3];
const contextPath = process.argv[4];
if (!overlay || !fs.existsSync(overlay)) {
  throw new Error('unify generator: expected the generated directory as argv[3] (see generator contract: argv = [unify, script, sourceRoot, generatedRoot, contextJson])');
}

const ctx = JSON.parse(fs.readFileSync(contextPath, 'utf8'));
const dataPath = path.join(path.dirname(ctx.paths.sourceRoot), 'varieties.json');
const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
const varieties = data.varieties;

const esc = (s) => String(s)
  .replaceAll('&', '&amp;')
  .replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;');

const famSlug = (f) => f.toLowerCase();

const families = new Map();
const pageKeys = new Set();
for (const v of varieties) {
  const fs_ = famSlug(v.family);
  if (!/^[a-z0-9-]+$/.test(fs_) || !/^[a-z0-9-]+$/.test(v.slug)) {
    throw new Error(`unusable slug: family=${v.family} slug=${v.slug}`);
  }
  const key = `${fs_}/${v.slug}`;
  if (pageKeys.has(key)) throw new Error(`duplicate page for family+slug: ${key}`);
  pageKeys.add(key);
  if (!families.has(v.family)) families.set(v.family, []);
  families.get(v.family).push(v);
}

// seed_keeper and keeper_contact are members' private data: never written out.
// Some display names repeat across families; when they do, titles say which family.
const nameCounts = new Map();
for (const v of varieties) nameCounts.set(v.name, (nameCounts.get(v.name) || 0) + 1);
const pageTitle = (v) => nameCounts.get(v.name) > 1 ? `${v.name} (${v.family})` : v.name;

const fields = (v) => [
  ['Plant family', `<a href="/browse/families/${esc(famSlug(v.family))}.html">${esc(v.family)}</a>`],
  ['Season', esc(v.season)],
  ['Sow', esc(v.sow)],
  ['Days to maturity', esc(v.days_to_maturity)],
  ['Packets available', v.packets_available > 0 ? esc(v.packets_available) : 'none left this season'],
];

function page({ title, desc, body, extraHead = '' }) {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
${extraHead}</head>
<body>
${body}
</body>
</html>
`;
}

function write(rel, text) {
  const p = path.join(overlay, rel);
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, text);
}

const crumbHome = `<nav class="crumb"><a href="/index.html">Home</a> · <a href="/browse.html">Browse the catalogue</a>`;

for (const v of varieties) {
  const fs_ = famSlug(v.family);
  const body = `${crumbHome} · <a href="/browse/families/${fs_}.html">${esc(v.family)}</a></nav>
<article>
<h1>${esc(v.name)}</h1>
<dl class="spec">
${fields(v).map(([k, val]) => `<dt>${k}</dt><dd>${val}</dd>`).join('\n')}
</dl>
<p>${esc(v.notes)}</p>
<p class="member-only">The seed keeper and their contact details are held privately by the library and shared with members at the lending desk.</p>
</article>`;
  const desc = `${v.name} — ${v.family}. Sow ${v.sow}; ${v.days_to_maturity} days to maturity; ${v.packets_available > 0 ? v.packets_available + ' packets available' : 'none left'} this season.`;
  write(`varieties/${fs_}/${v.slug}.html`, page({ title: pageTitle(v), desc, body }));
}

for (const [family, list] of [...families.entries()].sort((a, b) => a[0].localeCompare(b[0]))) {
  const fs_ = famSlug(family);
  const items = list
    .slice()
    .sort((a, b) => a.name.localeCompare(b.name))
    .map((v) => `  <li><a href="/varieties/${fs_}/${v.slug}.html">${esc(v.name)}</a><span class="variety-meta">${esc(v.days_to_maturity)} days · ${v.packets_available > 0 ? esc(v.packets_available) + ' packets' : 'none left'}</span></li>`)
    .join('\n');
  const body = `${crumbHome}</nav>
<div class="family-panel" id="family-panel">
<h1 class="family-title">${esc(family)} <span class="family-count">(${list.length} varieties)</span></h1>
<ul class="variety-list">
${items}
</ul>
</div>`;
  write(`browse/families/${fs_}.html`, page({ title: family, desc: `${family} varieties in the ${data.season} Fernhollow Seed Library catalogue (${list.length}).`, body }));
}

const famLinks = [...families.entries()]
  .sort((a, b) => a[0].localeCompare(b[0]))
  .map(([family, list]) => `  <li><a class="family-link" href="/browse/families/${famSlug(family)}.html">${esc(family)} <span class="family-count">(${list.length})</span></a></li>`)
  .join('\n');

const browseBody = `<h1>Browse the catalogue</h1>
<p class="lede">${data.season} season: ${varieties.length} varieties in ${families.size} plant families. Pick a family to load just that family&rsquo;s list &mdash; nothing else arrives with this page.</p>
<nav class="browse-families" aria-label="Plant families">
<ul>
${famLinks}
</ul>
</nav>
<div id="family-results" aria-live="polite"></div>
<noscript><p>With JavaScript off, each family link above still opens that family&rsquo;s own page.</p></noscript>`;

write('browse.html', page({
  title: 'Browse the catalogue',
  desc: `Browse the ${data.season} catalogue by plant family — ${varieties.length} varieties across ${families.size} families.`,
  body: browseBody,
  extraHead: '<script src="/assets/browse.js" defer></script>\n',
}));

console.log(`generated ${varieties.length} variety pages, ${families.size} family pages and the browse page in ${overlay}`);
