---
description: "A small plot, four beds, and a plan that rests itself: leaf, root, fruit, beans."
author: "Sybil Okafor, volunteer"
---

# A three-year rotation

A rotation is just a promise to next year's gardener, and you are also that gardener. Four beds and three years is the smallest plan worth keeping.

## The four groups

Walk the beds in a ring each year: **leaf** (cabbage, lettuce), then **root** (beets, onions, carrots), then **fruit** (tomatoes, squash, potatoes), then **beans** — which feed the bed for the leaf group behind them.

The fourth bed is the pause: while a bed rests under clover or weeds, it still feeds something.

## Keeping it honest

Write the plan on the inside of the gate and move a peg along a string each spring — one marker per bed is enough to remember. Keep beans at the end of the ring, never the start: their nitrogen is only worth what the next crop can take.

Do not fight the calendar. If a crop lingers two weeks past its slot, let it — the ring is a habit, not a law.
