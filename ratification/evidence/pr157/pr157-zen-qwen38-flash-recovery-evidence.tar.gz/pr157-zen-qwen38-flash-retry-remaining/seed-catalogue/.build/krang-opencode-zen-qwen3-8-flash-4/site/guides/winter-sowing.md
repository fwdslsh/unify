---
description: "Getting hardy crops off to a slow, sure start with milk jugs on a cold frame."
author: "Tom Renwick, volunteer"
---

# Winter sowing

Winter sowing is simply a greenhouse that costs nothing: a clear plastic jug, a fork of soil, and cold weather doing the timing.

## Making a jug

Cut a one-litre jug in half. Poke four drain holes in the base with a nail, fill with sifted soil, and sow the seed at the depth on the packet. Fold the top back down and tape one seam. Label it with crop and date.

Set the jugs on a bench or cold frame outdoors, out of reach of pigeons. Do not bring them inside — the seeds want the cold.

## What to sow this way

Onions, leeks, chard, beets, and most brassicas work well, and hardy lettuces too. Peas and beans rot more often than they sprout; start those in the open ground in spring instead.

## After the seeds wake

Check after the first mild days of late winter. When leaves press the sides, open the top and let the seedlings harden off for a week before potting on or planting out. Water on mild afternoons only — the point is a slow start, not a forced one.

Bring any spare seedlings to the Tuesday lending desk; other members will take them gladly.
