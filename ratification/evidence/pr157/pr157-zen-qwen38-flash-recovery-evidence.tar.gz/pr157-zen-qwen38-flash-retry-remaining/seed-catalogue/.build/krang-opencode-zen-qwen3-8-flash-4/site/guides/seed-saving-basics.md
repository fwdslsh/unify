---
description: "What you need to save seed from beans, peas, lettuce and tomatoes, and the five rules that stop most mistakes."
author: "Mira Hallam, volunteer"
---

# Seed saving basics

Seed saving needs almost no kit: a paper bag, a label, a freezer-cold night or two, and a plant you like. Here is how our keepers start.

## The five rules

1. **Pick one plant, not the best three.** Save from the single plant that impressed you, and the seed carries that story.
2. **Let it ripen past what feels ready.** Beans and peas dry on the vine until the pods rattle. Later than you think.
3. **Dry the seed, then dry it again.** One week on a plate in an airy room, then a sealed jar. Damp seed is dead seed.
4. **Label it the day you fill the envelope.** Variety, plant family, year. You will not remember by February.
5. **Freeze overnight in the envelope.** It kills weevils and helps beans keep another two years.

## What is easiest first

Beans, peas, lettuce and tomatoes are self-pollinating or nearly so — what you save comes true. Squashes and chard cross by insect, so grow one of each at a time in a small plot.

For tomatoes, scoop the seeds with their jelly into a jar, let them ferment three days, rinse, and dry on a paper plate — never on kitchen towel, they glue themselves to it.

Write to us at the lending desk if a batch fails; half of keeping is learning which years are just unlucky.
