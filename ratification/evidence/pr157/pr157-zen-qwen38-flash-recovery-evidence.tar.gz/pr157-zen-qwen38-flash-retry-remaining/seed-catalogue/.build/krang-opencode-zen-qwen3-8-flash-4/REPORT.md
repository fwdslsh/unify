# Fernhollow Seed Library — build report

## Publish command

```
./unify build --clean --base-url https://fernhollow.pages.dev/library/ --pretty-urls
```

Exit 0 means `dist/` is the complete site; non-zero publishes nothing. The catalogue is
derived at build time by `generate: scripts/gen.mjs` in `unify.yaml` — the same command line
rebuilds everything when `varieties.json` is re-exported next season. `./unify build --strict`
and `./unify audit --strict` (with the same flags) both exit 0: **"audit: nothing to report"**.

## What was built

- 244 pages: home, **How lending works**, **Browse the catalogue**, a **Growing guides**
  section (`guides.html` → `/guides/`, plus 3 volunteer Markdown guides), 12 family list
  pages and 225 variety pages — all generated from `varieties.json` by `scripts/gen.mjs`.
- **Browse never ships the catalogue.** The page is 3.9 KB (9.6 KB with CSS/JS/favicon on a
  first visit) and contains zero variety links. Picking a family fetches only that family's
  page (~4–7 KB) with `fetch()`, extracts its `.family-panel`, and injects it — no reload.
  Family addresses are not hardcoded anywhere in JS: the script reads the `href` attributes
  **that `--base-url` rewrote**, so it resolves at the mount from any depth. With JS off the
  same links simply open each family's own page.
- Shared chrome from `_includes/site-header.fragment.html` (inline leaf-mark SVG) and
  `_includes/contact-strip.fragment.html`. The layout's footer is a named slot whose
  fallback is the contact strip; *How lending works* fills that slot with the membership
  terms instead (`grep contact-strip` = 0 on its page). `guides/_layout.html` is the
  redesigned section shell: its own stylesheet, but it `<include>`s the same header and
  contact fragments, so the chrome is byte-identical everywhere.
- The export holds 225 rows but only **210 unique slugs** (15 name/slug pairs appear twice,
  under Apiaceae and Umbellifer with different days-to-maturity — real distinct varieties).
  Pages are therefore addressed `varieties/<family>/<slug>/`, which is unique for all 225,
  and duplicated display names get their family in `<title>`. `seed_keeper` /
  `keeper_contact` are never written into any page. `varieties.json` and `drafts/` sit
  outside the source root (`site/`), so they are not published; `/library/varieties.json`
  and `/library/drafts/…` 404. `assets/leaf.svg` is the only image, hand-written.

## How I checked a visitor at `https://fernhollow.pages.dev/library/` gets a working page

No browser, so `_verify/check.mjs` (kept outside the source root, never published) starts a
node HTTP server that serves `dist/` **under the exact `/library/` path** with directory
`index.html` semantics, and walks the site as that visitor, resolving every URL against the
same address. It asserts, all passing:

1. home is 200 and carries the leaf mark;
2. `/library/browse/` is 200, has exactly 12 family links, `/library/assets/browse.js`
   rewritten, and **no `/varieties/` link in its own body**;
3. it then does exactly what `browse.js` does: for each family link, take the rewritten
   `href`, `fetch` it (all 12 → 200, each with the shared header), extract `.family-panel`,
   and follow the links inside — the union is **exactly 225 unique variety pages**, and each
   panel contains only links into its own family;
4. sampled 25 variety pages (plus both pages of every duplicate-slug pair): 200, header +
   contact strip present, no member names or emails;
5. full crawl: 244 pages, 3124 in-page `href`/`src` — every one resolves 200 on the mount;
   no page emits a `.html` link;
6. `/library/varieties.json`, `/library/drafts/…`, `/library/_layout.html`,
   `/library/_includes/…` all 404;
7. no URL points at any other origin; `site.css` / `guides.css` / `browse.js` contain no
   root-relative `url()` or `fetch('/…')` strings — the two failure modes rules.md warns
   about;
8. `sitemap.xml` and every canonical/og:url are absolute under the address.

I deliberately did not run `audit --external`: its whole job is fetching off-origin URLs,
and this site emits none (the on-mount ones do not exist publicly until this publishes).
Re-run the whole proof: `./unify build --clean --base-url https://fernhollow.pages.dev/library/ --pretty-urls && node _verify/check.mjs`.

## What `rules.md` did not answer

The sentence I wanted and could not find: **what happens to files the generate script writes
into the directory it is handed.** The docs say a script exists, runs before every build, and
"writes into the directory unify hands it" — but never say that those files are composed like
normal source pages. I had to test it: overlay pages pick up the root `_layout.html` (two
levels deep), get `--pretty-urls` and `--base-url` rewriting, canonicals and sitemap entries.
Related gaps: *which* argument is that directory (I guessed argv[2] — the source root — and
the script wrote into `site/`, the one place the docs forbid; the contract turns out to be
`[unify, script, sourceRoot, generatedRoot, generatorContext.json]`); and the
generator-context.json inventory, which the docs only hint at via `--source-inventory`
("on by default with `--generate`") without saying where that file is — argv[4], with
`paths` and the effective `site.baseUrl/prettyUrls`.

## What I re-read, and why it did not land the first time

- The `--base-url` sentence in *Files* ("prefixes every link…") read like a blanket promise.
  It took the *Styles, scripts, finishing* paragraph — which I read as a CSS footnote — to
  learn it covers only HTML `href`/`src`: `fetch()` strings, `hx-get` and CSS `url()` ship as
  written and miss the prefix. The site's central requirement hangs off the least
  conspicuous clause in the document, 45 lines after the flag is described.
- The slot-filling rules (§ *Merging a page into its layout*). I first wrote `<slot>` tags in
  a page and the build correctly rejected them, which sent me back: the docs distinguish a
  named slot fill that "replaces the slot, tag and all" from filling a wrapped footer, where
  the fill "fills the *contents*" — and the same phrase "fills" earlier means including into
  a fragment's slots. My first design (hand-rolled `footer` markup per page, raw
  `.fragment.html` family lists with hand-joined links) died against these two sentences.
- The opening paragraph, because its first sentence reads like marketing ("no template
  language…") while its last sentence carries the generator contract, the feed, and the
  date-without-time rule. I re-read it three times for the generate half alone.

## What I guessed or inferred rather than read

- That the 15 repeated slugs are genuinely distinct varieties (different days-to-maturity per
  family), deserve two pages each, and that `family/slug` is the honest address — nothing in
  the docs or the brief mentions duplicate slugs.
- That `seed_keeper`/`keeper_contact` must be stripped from *generated pages* too, not just
  from the JSON file; the brief only forbids publishing the JSON, but the fields are the
  members' names and addresses it warns about.
- The fetch pattern itself — fetch the family page, `DOMParser`-extract `.family-panel`,
  inject — is my composition of the docs' "read it back from an `href` unify rewrote" hint;
  the docs never describe this loop.
- That a deploy host maps `/browse/` to `browse/index.html` (standard for Cloudflare Pages;
  rules.md implies it by generating `--pretty-urls` that way, but serving is out of its scope).
  My simulation implements that mapping, so it is an assumption I tested with, not proof of
  the host.
- That HTML pages should carry `<meta name="description">` (markdown has a `description`
  key; HTML pages get it from the sentence about what `schema` reads — "from what the page
  already declares") — and that `unify audit`'s "incomplete" findings (missing `<h1>`,
  duplicate titles) are worth fixing to zero even though plain `build` passes without them.
