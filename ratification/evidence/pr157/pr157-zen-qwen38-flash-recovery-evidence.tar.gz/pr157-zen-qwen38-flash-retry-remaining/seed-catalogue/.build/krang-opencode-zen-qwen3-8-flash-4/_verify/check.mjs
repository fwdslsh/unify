import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.resolve('dist');
const BASE = 'https://fernhollow.pages.dev/library/';

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (!p.startsWith('/library/')) { res.writeHead(404).end('off-mount'); return; }
  let rel = p.slice('/library/'.length);
  if (rel === '') rel = 'index.html';
  let f = path.join(ROOT, rel);
  if (fs.existsSync(f) && fs.statSync(f).isDirectory()) f = path.join(f, 'index.html');
  if (!f.startsWith(ROOT) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404).end('404'); return; }
  const type = f.endsWith('.html') ? 'text/html; charset=utf-8' : f.endsWith('.css') ? 'text/css' : f.endsWith('.js') ? 'text/javascript' : f.endsWith('.svg') ? 'image/svg+xml' : f.endsWith('.xml') ? 'application/xml' : 'application/octet-stream';
  res.writeHead(200, { 'content-type': type }).end(fs.readFileSync(f));
});

await new Promise((r) => server.listen(8787, r));

// Visitor-visible address stays https://fernhollow.pages.dev/library/...; the server answers it on localhost.
const visit = (u) => u.replace('https://fernhollow.pages.dev', 'http://127.0.0.1:8787');

let problems = 0;
const fail = (m) => { problems++; console.log('PROBLEM:', m); };
const get = async (u) => { const r = await fetch(visit(u)); return { status: r.status, text: await r.text() }; };
const urlsIn = (html, pageUrl) =>
  [...html.matchAll(/(?:href|src)="([^"]+)"/g)]
    .map((m) => m[1])
    .filter((u) => !u.startsWith('mailto:') && !u.startsWith('#'))
    .map((u) => new URL(u, pageUrl).href)
    .filter((u) => new URL(u).origin === 'https://fernhollow.pages.dev');

console.log('--- 1. home page as a visitor sees it');
let r = await get(BASE);
if (r.status !== 200) fail('home not 200');
if (!r.text.includes('leaf-mark')) fail('home has no leaf mark');

console.log('--- 2. browse page initial payload');
const bUrl = BASE + 'browse/';
r = await get(bUrl);
if (r.status !== 200) fail('browse not 200');
const famLinks = [...r.text.matchAll(/class="family-link" href="([^"]+)"/g)].map((m) => new URL(m[1], bUrl).href);
if (famLinks.length !== 12) fail('expected 12 family links, got ' + famLinks.length);
if ((r.text.match(/\/varieties\//g) || []).length !== 0) fail('browse page itself contains variety links');
if (!r.text.includes('/library/assets/browse.js')) fail('browse.js link not rewritten');

console.log('--- 3. exactly what browse.js does: fetch each family href, extract .family-panel, follow its links');
const seenVarieties = new Set();
for (const link of famLinks) {
  const fr = await get(link);
  if (fr.status !== 200) fail('family page 404: ' + link);
  const m = fr.text.match(/<div class="family-panel"[\s\S]*?<\/div>/);
  if (!m) fail('no family panel in ' + link);
  if (!fr.text.includes('site-header') || !fr.text.includes('leaf-mark')) fail('family page missing shared header: ' + link);
  const panel = m[0];
  const vLinks = urlsIn(panel, link);
  const famOf = link.match(/families\/([^/]+)\//)[1];
  for (const v of vLinks) {
    if (!v.includes('/varieties/' + famOf + '/')) fail('family page ' + famOf + ' leaks other-family link ' + v);
    seenVarieties.add(v);
  }
}
console.log('families fetched:', famLinks.length, '| variety links total:', seenVarieties.size);
if (seenVarieties.size !== 225) fail('expected 225 unique variety links across families, got ' + seenVarieties.size);

console.log('--- 4. every variety page reachable and self-consistent (sample 25 + all dup-slug pairs)');
const sample = [...seenVarieties].filter((_, i) => i % 9 === 0);
for (const v of sample) {
  const vr = await get(v);
  if (vr.status !== 200) fail('variety 404: ' + v);
  if (!vr.text.includes('leaf-mark')) fail('variety missing header: ' + v);
  if (!vr.text.includes('contact-strip')) fail('variety missing contact strip: ' + v);
  if (/fernhollow-members|seed_keeper|keeper_contact/.test(vr.text)) fail('PII on variety page: ' + v);
}

console.log('--- 5. crawl every published page: all rewritten links/assets resolve on this mount');
const pages = [];
const walk = (d) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) e.isDirectory() ? walk(path.join(d, e.name)) : e.name.endsWith('.html') && pages.push(path.join(d, e.name)); };
walk(ROOT);
let checked = 0;
for (const f of pages) {
  const url = BASE + path.relative(ROOT, f).replace(/\\/g, '/').replace(/index\.html$/, '');
  const pr = await get(url);
  if (pr.status !== 200) { fail('page 404 at its visitor address: ' + url); continue; }
  if (/<a[^>]+href="[^"]*\.html"/.test(pr.text)) fail('page still ships a .html link: ' + url);
  for (const u of urlsIn(pr.text, url)) {
    if (/\/$|\.html$/.test(u) === false && !/\.(css|js|svg|xml)$/.test(u)) continue;
    const h = await get(u);
    if (h.status !== 200) fail('link did not resolve: ' + u + ' (from ' + url + ')');
    checked++;
  }
}
console.log('pages crawled:', pages.length, '| in-page URLs verified:', checked);

console.log('--- 6. off-limits addresses');
for (const u of [BASE + 'varieties.json', BASE + 'drafts/', BASE + 'drafts/frost-dates.html', BASE + '_layout.html', BASE + '_includes/site-header.fragment.html', BASE + 'scripts/gen.mjs']) {
  const h = await fetch(visit(u));
  if (h.status !== 404) fail('should not exist on the mount: ' + u + ' returned ' + h.status);
}

console.log('--- 7. nothing loads from another origin');
for (const f of pages) {
  const t = fs.readFileSync(f, 'utf8');
  for (const m of t.matchAll(/(?:href|src)="(https?:\/\/[^"]+)"/g)) {
    if (!m[1].startsWith('https://fernhollow.pages.dev')) fail('external origin ' + m[1] + ' in ' + f);
  }
  for (const m of t.matchAll(/(?:href|src)="\/(?!library\/)[^"]*"/g)) fail('root-relative path missing the mount in ' + f + ': ' + m[0]);
}
for (const ext of ['assets/site.css', 'assets/guides.css', 'assets/browse.js']) {
  const t = fs.readFileSync(path.join(ROOT, ext), 'utf8');
  if (/url\s*\(\s*['"]?\//.test(t) || /fetch\s*\(\s*['"]\//.test(t)) fail('root-relative url()/fetch in ' + ext);
}

console.log('--- 8. sitemap absolute');
const sm = await get(BASE + 'sitemap.xml');
if (sm.status !== 200 || !sm.text.includes('https://fernhollow.pages.dev/library/browse/')) fail('sitemap missing absolute site urls');

server.close();
console.log(problems === 0 ? 'ALL CHECKS PASSED' : problems + ' PROBLEMS');
process.exit(problems === 0 ? 0 : 1);
