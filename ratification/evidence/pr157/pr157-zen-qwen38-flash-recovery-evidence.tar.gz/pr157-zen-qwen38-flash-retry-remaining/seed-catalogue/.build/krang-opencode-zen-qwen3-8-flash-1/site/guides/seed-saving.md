---
title: "Seed saving basics"
description: "The three rules of saving lending seed: start clean, dry well, label now."
author: "M. Okonjo"
---

# Seed saving basics

Seed saving is mostly patience. Three rules carry a beginner a long way.

## Start clean

Save from plants that look healthy and true to type, not from the first
fruit you happen to pick. Ferment tomato and cucumber seed in a jar for two
or three days, rinse the pulp away, and skim off anything that floats.

## Dry well

Drying is where saved seed is won or lost. Spread seed on a plate or screen,
a thumb's depth at most, out of the sun, and give it a week even when it
seems dry. A pea that snaps instead of bends is ready; one that squashes is
not.

## Label now

Write the variety name and the year on the jar before the seed goes in.
Untitled seed is only ever a rumour by spring.
