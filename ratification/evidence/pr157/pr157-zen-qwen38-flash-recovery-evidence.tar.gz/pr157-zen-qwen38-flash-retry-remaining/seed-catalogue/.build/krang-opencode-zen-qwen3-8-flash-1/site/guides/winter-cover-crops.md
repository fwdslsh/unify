---
title: "Winter cover crops"
description: "Sow a living blanket over bare beds in autumn and mulch it in spring."
author: "R. Bekele"
---

# Winter cover crops

Bare soil in winter is soil we are borrowing from next year. Cover it.

## What to sow

A handful of field beans or winter tares scattered over the bed after harvest
is enough; they sprout slowly and hold the soil with roots all the way down.
On thin, dry beds, add a bushy oat for bulk.

## When to sow

Sow while the leaves are still coming off the trees — early autumn at the
latest. Seed in cold, dry ground simply waits, and waits well.

## What to do in spring

Cut the cover at the ankles two or three weeks before you mean to sow the
real crop, and lay the cuttings where they fall as a mulch. Dig only the
paths; the beds will take care of the rest.
