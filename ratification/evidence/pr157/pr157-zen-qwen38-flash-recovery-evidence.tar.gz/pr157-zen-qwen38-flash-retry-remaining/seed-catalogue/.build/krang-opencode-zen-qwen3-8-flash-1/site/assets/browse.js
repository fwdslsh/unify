(function () {
  var picker = document.getElementById('family-picker');
  var results = document.getElementById('family-results');
  if (!picker || !results || !window.fetch || !window.DOMParser) return;
  var pending = null;
  picker.addEventListener('click', function (ev) {
    var link = ev.target.closest ? ev.target.closest('a.fam') : null;
    if (!link || !picker.contains(link)) return;
    ev.preventDefault();
    // Read the address back from the href the build rewrote, so it is correct
    // under /library/ and at any depth — fetch() addresses ship as written.
    var url = link.getAttribute('href');
    if (!url || url === pending) return;
    pending = url;
    var links = picker.querySelectorAll('a.fam');
    for (var i = 0; i < links.length; i++) links[i].classList.toggle('is-active', links[i] === link);
    results.innerHTML = '<p class="loading">Loading ' + link.firstChild.textContent.trim() + '…</p>';
    fetch(url, { headers: { accept: 'text/html' } })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.text(); })
      .then(function (html) {
        if (pending !== url) return;
        var page = new DOMParser().parseFromString(html, 'text/html').querySelector('main');
        results.innerHTML = page ? page.innerHTML : html;
        var top = document.getElementById('family-results');
        if (top.scrollIntoView) top.scrollIntoView();
      })
      .catch(function () {
        if (pending === url) { pending = null; results.innerHTML = '<p class="load-error">Sorry — that family did not load. Please try again.</p>'; }
      });
  });
})();
