// Fernhollow Seed Library — catalogue generator.
// Reads varieties.json (which sits OUTSIDE the source root and is therefore never
// published) and writes generated pages into the overlay directory unify hands to
// this script: argv[2]=source root, argv[3]=generated overlay, argv[4]=generator-context.json.
// Pages are authored with real filenames and root-relative links; the build itself
// rewrites them for --pretty-urls and --base-url, so nothing here hard-codes the mount.
import fs from 'node:fs';
import path from 'node:path';

const [, , sourceRoot, overlay] = process.argv;
const data = JSON.parse(fs.readFileSync(path.join(sourceRoot, '..', 'varieties.json'), 'utf8'));

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const slugify = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
const put = (rel, text) => {
  const p = path.join(overlay, rel);
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, text);
};

const byFamily = new Map();
for (const v of data.varieties) {
  if (!byFamily.has(v.family)) byFamily.set(v.family, []);
  byFamily.get(v.family).push(v);
}
const families = [...byFamily.keys()].sort();

// One page per family — the unit the browse page fetches, one family at a time.
for (const fam of families) {
  const rows = byFamily.get(fam).map((v) => {
    const meta = `${esc(v.season)} · sow ${esc(v.sow)} · ${v.days_to_maturity} days · ${v.packets_available} packets`;
    return `<li><a href="/variety/${slugify(fam)}/${esc(v.slug)}.html">${esc(v.name)}</a> <span class="vmeta">${meta}</span></li>`;
  });
  put(`catalogue/families/${slugify(fam)}.html`, `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>${esc(fam)}</title>
<meta name="description" content="${esc(fam)} varieties on loan at the Fernhollow Seed Library: ${rows.length} for season ${esc(data.season)}.">
</head>
<body class="family">
<main>
<h1>${esc(fam)}</h1>
<p class="crumb"><a href="/catalogue.html">Browse the catalogue</a> · ${rows.length} varieties</p>
<ul class="variety-list">
${rows.join('\n')}
</ul>
</main>
</body>
</html>
`);
}

// One page per variety. Keeper names and contacts are PII and never rendered.
for (const v of data.varieties) {
  const desc = `${v.name} — ${v.family} variety in the Fernhollow Seed Library lending catalogue. Sow ${v.sow}; ${v.days_to_maturity} days to maturity.`;
  put(`variety/${slugify(v.family)}/${v.slug}.html`, `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>${esc(v.name)} (${esc(v.family)})</title>
<meta name="description" content="${esc(desc)}">
</head>
<body class="variety">
<main>
<h1>${esc(v.name)}</h1>
<p class="crumb"><a href="/catalogue.html">Catalogue</a> · <a href="/catalogue/families/${slugify(v.family)}.html">${esc(v.family)}</a></p>
<dl class="specs">
<dt>Season</dt><dd>${esc(v.season)}</dd>
<dt>Sow</dt><dd>${esc(v.sow)}</dd>
<dt>Days to maturity</dt><dd>${v.days_to_maturity}</dd>
<dt>Packets available</dt><dd>${v.packets_available}</dd>
</dl>
<p class="notes">${esc(v.notes)}</p>
</main>
</body>
</html>
`);
}

// The single browse page: 12 picker links, no variety names on it at all.
const picker = families.map((fam) => {
  const n = byFamily.get(fam).length;
  return `<li><a class="fam" href="/catalogue/families/${slugify(fam)}.html">${esc(fam)} <span class="fam-count">${n} varieties</span></a></li>`;
}).join('\n');
put('catalogue.html', `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Browse the catalogue</title>
<meta name="description" content="Lending catalogue, season ${esc(data.season)}: ${data.varieties.length} varieties in ${families.length} families. Pick a family to see its varieties.">
</head>
<body class="catalogue">
<main>
<h1>Browse the catalogue</h1>
<p class="lede">Season ${esc(data.season)} — ${data.varieties.length} varieties across ${families.length} families. Pick a family: only that family&rsquo;s varieties load, and the page never reloads. Nothing above has fetched them.</p>
<ul id="family-picker" class="family-picker">
${picker}
</ul>
<noscript><p class="noscript-note">The links above each open one family&rsquo;s page.</p></noscript>
<div id="family-results" class="family-results" aria-live="polite"></div>
</main>
<script src="/assets/browse.js"></script>
</body>
</html>
`);
