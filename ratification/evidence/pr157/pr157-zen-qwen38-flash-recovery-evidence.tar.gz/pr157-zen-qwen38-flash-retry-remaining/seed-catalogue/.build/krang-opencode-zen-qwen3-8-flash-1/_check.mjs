import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const DIST = path.resolve('dist');
const BASE_PATH = '/library/';
const MIME = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml', '.xml': 'application/xml' };

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (!p.startsWith(BASE_PATH)) { res.writeHead(404); return res.end('outside mount'); }
  let f = path.join(DIST, p.slice(BASE_PATH.length));
  if (fs.existsSync(f) && fs.statSync(f).isDirectory()) f = path.join(f, 'index.html');
  if (!f.startsWith(DIST) || !fs.existsSync(f)) { res.writeHead(404); return res.end('not found: ' + p); }
  res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
});
await new Promise(r => server.listen(0, '127.0.0.1', r));
const origin = 'http://127.0.0.1:' + server.address().port;
const siteBase = origin + BASE_PATH;

// ---- tiny DOM: collect (tag, attr, value) URL refs + text checks ----
function refs(html) {
  const out = [];
  const re = /<(a|link|script|img)\b[^>]*?>/gi;
  let m;
  while ((m = re.exec(html))) {
    const tag = m[1].toLowerCase();
    const attrs = m[0];
    for (const a of (tag === 'script' || tag === 'img' ? ['src'] : ['href'])) {
      const am = new RegExp(a + '="([^"]*)"', 'i').exec(attrs);
      if (am) out.push({ attr: a, url: am[1].replace(/&amp;/g, '&') });
    }
  }
  return out;
}
const queue = [BASE_PATH, BASE_PATH + 'index.html'];
for (const extra of ['index.html', 'catalogue/', 'lending/', 'guides/',
  'guides/seed-saving/', 'guides/rotation-planning/', 'guides/winter-cover-crops/',
  'catalogue/families/brassica/', 'catalogue/families/umbellifer/',
  'variety/brassica/nine-star-pea-1/', 'variety/apiaceae/late-squash-1/', 'variety/umbellifer/late-squash-1/'])
  queue.push(BASE_PATH + extra);
queue.push(BASE_PATH);

const seen = new Set();
const problems = [];
let pages = 0, fetches = 0;

async function get(url) {
  const r = await fetch(url);
  return { status: r.status, type: r.headers.get('content-type') || '', body: r.headers.get('content-type')?.includes('html') ? await r.text() : await r.text() };
}

while (queue.length) {
  const u = queue.pop();
  if (seen.has(u)) continue;
  seen.add(u);
  const res = await get(origin + u);
  if (res.status !== 200) { problems.push('HTTP ' + res.status + ' ' + u); continue; }
  if (u.endsWith('/') || u.endsWith('.html')) {
    pages++;
    for (const { url } of refs(res.body)) {
      if (/^(mailto:|tel:|#|data:)/.test(url)) continue;
      let next;
      try { next = new URL(url, origin); } catch { problems.push('unparseable ' + url + ' on ' + u); continue; }
      if (next.origin === 'https://fernhollow.pages.dev') {
        if (!next.pathname.startsWith(BASE_PATH)) { problems.push('canonical misses mount: ' + url + ' on ' + u); continue; }
        queue.push(next.pathname);
        continue;
      }
      if (next.origin !== origin) { problems.push('off-origin ' + url + ' on ' + u); continue; }
      if (!next.pathname.startsWith(BASE_PATH)) { problems.push('misses mount: ' + url + ' on ' + u); continue; }
      queue.push(next.pathname);
      if (next.pathname.endsWith('.html') && !next.pathname.endsWith('/index.html')) problems.push('visitor URL ends in .html: ' + next.pathname + ' on ' + u);
    }
    if (!/— Fernhollow Seed Library<\/title>/.test(res.body)) problems.push('no shared title on ' + u);
    if (!/class="site-header"/.test(res.body)) problems.push('no header on ' + u);
    if (u !== BASE_PATH + 'lending/') {
      if (!/contact-strip/.test(res.body)) problems.push('no contact strip on ' + u);
    } else {
      if (/contact-strip/.test(res.body)) problems.push('contact strip on lending');
      if (!/Membership terms/.test(res.body)) problems.push('no terms on lending');
    }
    if (res.body.includes('fernhollow-members') || /keeper_contact/i.test(res.body)) problems.push('PII on ' + u);
  }
}

// ---- simulate browse.js post-load fetches from the catalogue page ----
const cat = await get(siteBase + 'catalogue/');
const picker = [...cat.body.matchAll(/<a class="fam" href="([^"]+)"/g)].map(m => m[1].replace(/&amp;/g, '&'));
if (picker.length !== 12) problems.push('picker count=' + picker.length);
for (const href of picker) {
  const fam = new URL(href, siteBase);
  if (!fam.pathname.startsWith(BASE_PATH)) { problems.push('picker fetch misses mount: ' + href); continue; }
  const r = await fetch(origin + fam.pathname); fetches++;
  const body = await r.text();
  if (r.status !== 200) { problems.push('fetch ' + r.status + ' ' + fam.pathname); continue; }
  const main = /<main>([\s\S]*?)<\/main>/.exec(body)?.[1];
  if (!main) { problems.push('no main in fetched ' + fam.pathname); continue; }
  for (const { url } of refs(main)) {
    const v = new URL(url, siteBase);
    const vr = await fetch(origin + v.pathname); fetches++;
    if (vr.status !== 200) problems.push('variety link ' + vr.status + ' ' + v.pathname);
    else if (!(await vr.text()).includes('— Fernhollow Seed Library')) problems.push('variety page unwrapped ' + v.pathname);
  }
}

// ---- the actual browse.js file must be reachable as linked ----
const js = await fetch(siteBase + 'assets/browse.js');
if (js.status !== 200) problems.push('browse.js ' + js.status);

// ---- nothing sensitive emitted ----
for (const bad of ['varieties.json', 'drafts', 'frost-dates', 'generator-context', 'source-pages', 'scripts']) {
  const hits = [...seen].filter(p => p.includes(bad));
  if (hits.length) problems.push('leaked path ' + bad + ': ' + hits.join(','));
}
const inDist = [];
(function walk(d) { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const f = path.join(d, e.name); if (e.isDirectory()) walk(f); else if (/varieties\.json|frost|draft|\.fragment\.html$/.test(f)) inDist.push(f); } })(DIST);
if (inDist.length) problems.push('dist contains ' + inDist.join(','));

// ---- no page embeds all 225 varieties ----
const onCat = (cat.body.match(/\/library\/variety\//g) || []).length;
if (onCat > 0) problems.push('catalogue page embeds variety links: ' + onCat);
const catBytes = Buffer.byteLength(cat.body);

const nVariety = [...seen].filter((p) => p.startsWith(BASE_PATH + 'variety/')).length;
if (nVariety !== 225) problems.push('visited variety pages: ' + nVariety);
const nFam = [...seen].filter((p) => p.startsWith(BASE_PATH + 'catalogue/families/')).length;
if (nFam !== 12) problems.push('visited family pages: ' + nFam);

console.log(JSON.stringify({ pagesVisited: pages, subFetches: fetches, cataloguePageBytes: catBytes, problems: problems.slice(0, 25), problemCount: problems.length }, null, 2));
server.close();
