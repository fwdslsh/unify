---
title: "Planning a four-year rotation"
description: "Move each plant family around the beds on a four-year circle to keep soil and pests honest."
author: "T. Halloran"
---

# Planning a four-year rotation

A rotation is just a promise you make to the bed: this family was here, so
next year something else comes.

## The circle

1. **Legumes** — beans and peas of the Fabaceae family feed nitrogen back
   into the soil. Start the circle here.
2. **Leaves** — brassicas and salad greens spend that nitrogen on growth.
3. **Fruits** — squash, tomatoes, and sunflowers take the richest year.
4. **Roots and alliums** — onions, carrots, and beetroot are the clean-up
   crew, and they leave the bed quiet and open for legumes again.

## Why four years

Most family-specific pests and rots cannot survive four years without their
host. Keep the plan on paper — the bed forgets, the notebook does not — and
if a bed rests empty for a season, count it as the roots year.
