# Fernhollow Seed Library — build report

## Publishing the site

```
./unify build --clean
```

The site address and URL style are part of the project: `unify.yaml` holds
`generate: scripts/gen.mjs`, `pretty-urls: true`, and
`base-url: https://fernhollow.pages.dev/library/` (captured once with
`--save-config`). Plain `./unify build` produces identical output; `--clean`
empties `dist/` first so a re-exported catalogue never leaves last season's
pages behind. Exit 0 means `dist/` is the complete site.

What the build publishes: 225 variety pages at `/library/variety/<family>/<slug>/`
(15 slugs repeat across Apiaceae/Umbellifer in the export, so pages are keyed by
family; titles carry the family for the same reason), 12 family pages the browse
page fetches one at a time, `/library/catalogue/`, home, lending, and the four
guides pages. `varieties.json` and `drafts/` live outside `site/` and ship
nothing; keeper names and contacts are never rendered.

## How I checked it works at *that* address

1. `./unify build --dry-run --strict` and `./unify audit --strict`: no problems.
2. Served `dist/` under exactly `/library/` with a throwaway Node server and
   crawled it with `_check.mjs` — 245 pages visited, every `href`/`src` on every
   page requested from the mount: all resolve, none leaves `/library/`, none of
   the on-origin URLs ends in `.html`, guide pages' header/footer are identical
   to the rest, lending has the membership terms and no contact strip, no
   member emails appear anywhere, and `dist/` contains no `varieties.json`,
   drafts, scripts, or generator files.
3. Post-load fetches, the way the browser does it: I parsed the shipped
   `/library/catalogue/` (3.5 KB, containing **zero** `/library/variety/`
   links — nothing is sent-and-hidden), read the 12 picker `href` attributes
   exactly as `browse.js` does (the values unify rewrote to `/library/…`),
   fetched each with plain `fetch` (all 200), extracted `<main>` as the script
   does, and followed all 225 variety links out of those fetched mains —
   every one returns 200 with the shared layout wrapped around it.

## What `rules.md` did not answer

- **Whether a `.fragment.html` file's links get rewritten.** The file rules say a
  fragment is "shipped as written"; the finishing section says the build "rewrites
  only HTML's own URL attributes (`href`, `src`)" — and also that "`fetch()`/`hx-get`
  address[es] ship as written". The sentence I wanted and could not find is the
  tie-breaker: *do `--base-url`/`--pretty-urls` rewrite `<a href>` inside a fragment,
  or does "as written" win?* I tested it: as written wins — a fragment in `dist/`
  still carried `/variety/nine-star-pea-1.html`, no prefix, no pretty form. That
  decided the architecture: the family lists ship as real generated pages
  (rewritten by the build like everything else), and `browse.js` fetches the page
  and injects its `<main>` — so only that family's varieties arrive, at URLs that
  are correct under `/library/`, and a JS-off visitor still lands on a real page
  rather than a `.html` ending.
- **The generator script's interface.** "It writes into the directory unify hands
  it" never says *how it is handed*. Not one line on argv, cwd, or the context
  file. I probed by making the script dump `process.argv`:
  `[unify, script, source-root, generated-overlay, generator-context.json]`, cwd =
  source root. What `generator-context.json` contains (paths, `site.baseUrl`,
  `site.prettyUrls`, the `source-pages.json` inventory location) is also absent
  from rules.md — I read it out in the probe.
- **Whether overlay files resolve layouts from the site.** "Nearest `_layout.html`,
  its own folder, then each parent" is written about `site/`; generated pages live
  in a different directory. I inferred the overlay participates in the search,
  verified with a probe page, and built on it — all 245 built pages come out
  wrapped correctly.

## What I re-read, and why it didn't land the first time

- **"Merging a page into its layout"**, three times. "A bare `<header>`/`<footer>`
  does not replace the layout's — only `slot=` fills, and it fills the *contents*:
  where the layout wraps its slot in its own `<footer>`, write `<p slot="footer">`"
  first reads as a ban on `<footer slot="footer">`. It isn't — it's conditional on
  the layout wrapping the slot in its own footer. So I wrote the root layout's
  footer slot unwrapped, and the lending page replaces the whole contact strip with
  `<footer slot="footer" class="terms">`.
- **The Styles/scripts/finishing paragraph**, twice. The warning that fetched
  addresses "ship as written" and the hint "or read it back from an `href` unify
  rewrote" are one compressed sentence; it took the second pass to see the second
  half as the prescribed pattern. `browse.js` does exactly that — it fetches
  `link.getAttribute('href')` from a rewritten anchor, so nothing hard-codes the mount.
- **The Files/underscore bullet.** "Everything in the source root ships" plus the
  `_`-prefix escape: the corollary — that files outside the source root simply
  aren't part of the build at all — was never stated; re-reading it next to the
  default `-o dist` behavior is what made me confident leaving `drafts/`,
  `varieties.json`, and `scripts/` beside `site/` (and `_check.mjs` with an
  underscore prefix) is safe.

## What I guessed at or inferred rather than read

- From "shipped as written", I *predicted* fragment links wouldn't be rewritten —
  then verified rather than trusting the guess.
- The `unify.yaml` key spellings for saved options (`pretty-urls:`, `base-url:`)
  — not documented; I let `--save-config` write them and read the result.
- That `--base-url` also emits `sitemap.xml` and canonical/og:url came from
  `--help`, not rules.md; likewise that `--canonical auto` is the default with
  `--base-url`.
- That `--dry-run --strict`'s "would publish …" report and audit's exit code are
  the pass/fail gate; the docs describe the pieces, the combination is inferred.
- `drafts/frost-dates.md` — I never opened it. Nothing in the brief asked me to
  use it, only to keep it out of the output; it sits outside `site/`, unshipped.
- Design choices the docs deliberately leave open: inline SVG in the shared header
  include (plus an `assets/leaf.svg` for the favicon), the `body.guides` class
  prefix scoping the redesigned guide look over the identical chrome, and the
  guide pages' copy.
