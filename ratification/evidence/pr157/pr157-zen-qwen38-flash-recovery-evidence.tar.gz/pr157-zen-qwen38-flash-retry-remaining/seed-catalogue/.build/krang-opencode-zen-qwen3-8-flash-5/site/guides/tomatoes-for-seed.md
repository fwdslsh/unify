---
title: Growing tomatoes for seed
description: Fermenting tomato seed and keeping varieties true in one small garden.
class: guide
---
# Growing tomatoes for seed

Tomato seed hides inside wet gel that stops it germinating until you wash it off. The
washing is called fermenting, and done well it is the most satisfying half-hour in the
seed room.

## Pick the fruit that proves the variety

Save from the first ripe fruit off the sturdiest plant, and only if the fruit actually
looks like the catalogue picture — a beefsteak that is setting coins of fruit is telling
you it crossed. Squash the pulp and seeds into a jar with a little of its own juice.

## Ferment, then rinse

1. Leave the jar loose-lidded for two to four days. A mould skin is fine; skim it.
2. Good seed sinks. Pour off the floaters — they are pulp and dud seed.
3. Rinse the sinkers twice, and dry them on a paper plate, never kitchen roll they will stick to.

Label the envelope: variety, year, and the member who lent you the original packet.

## Two varieties, one balcony

Tomatoes mostly self-pollinate, so two nearby varieties stay honest if you keep the
flowers distant and pinch off any truss you are not sure about. A fan open on a still,
hot day is when a bumblebee does the damage; a light breeze is your friend.
