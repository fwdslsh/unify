// Derives the catalogue pages from varieties.json before every build.
// unify runs this script and hands it: the source root, a generated-root
// (overlay) directory to write into, and a JSON context describing the
// build options. Nothing here is ever hand-edited; the output is a pure
// projection of varieties.json minus the member-identifying fields.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const [sourceRoot, generatedRoot, contextPath] = process.argv.slice(2);
if (!sourceRoot || !generatedRoot || !contextPath) {
  console.error('gen.mjs: expected to be run by unify build');
  process.exit(1);
}
const ctx = JSON.parse(fs.readFileSync(contextPath, 'utf8'));

// Fields that must never leave the membership export.
const PRIVATE = new Set(['seed_keeper', 'keeper_contact']);

const data = JSON.parse(fs.readFileSync(path.join(here, '..', 'varieties.json'), 'utf8'));
const varieties = data.varieties;

const esc = (s) => String(s)
  .replaceAll('&', '&amp;')
  .replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;');

const key = (family) => family.toLowerCase();

// Unique page ids: slugs collide across families in the export, so
// disambiguate duplicates with the family key, then with the index.
const slugCount = new Map();
for (const v of varieties) slugCount.set(v.slug, (slugCount.get(v.slug) || 0) + 1);
const ids = new Set();
varieties.forEach((v, i) => {
  let id = slugCount.get(v.slug) > 1 ? `${v.slug}-${key(v.family)}` : v.slug;
  if (ids.has(id)) id = `${id}-${i}`;
  ids.add(id);
  v.pageId = id;
  // Colliding names are different varieties; say which on the page itself.
  v.displayName = slugCount.get(v.slug) > 1 ? `${v.name} (${v.family})` : v.name;
});
if (ids.size !== varieties.length) throw new Error('gen.mjs: page id collision');

// Fetched fragments ship byte-for-byte, so links inside them must already
// carry the deployed base path. Read it back from the build context.
const basePath = ctx.site.baseUrl ? new URL(ctx.site.baseUrl).pathname : '/';
const varietyUrl = (id) => `${basePath}varieties/${id}${ctx.site.prettyUrls ? '/' : '.html'}`;

const byFamily = new Map();
for (const v of varieties) {
  if (!byFamily.has(v.family)) byFamily.set(v.family, []);
  byFamily.get(v.family).push(v);
}
for (const list of byFamily.values()) list.sort((a, b) => a.name.localeCompare(b.name));
const families = [...byFamily.keys()].sort((a, b) => a.localeCompare(b));

fs.mkdirSync(path.join(generatedRoot, 'varieties'), { recursive: true });
fs.mkdirSync(path.join(generatedRoot, 'browse'), { recursive: true });

for (const v of varieties) {
  const publicFacts = Object.entries(v).filter(([k]) => !PRIVATE.has(k) && k !== 'pageId');
  const row = (label, value) => `    <div class="fact"><dt>${esc(label)}</dt><dd>${esc(value)}</dd></div>`;
  const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>${esc(v.displayName)}</title>
<meta name="description" content="${esc(v.displayName)} — ${esc(v.family)}. ${esc(v.days_to_maturity)} days to maturity.">
</head>
<body class="variety">
<main>
  <nav class="breadcrumbs" aria-label="Breadcrumb"><a href="/">Home</a> · <a href="/browse.html">${esc(v.family)}</a></nav>
  <h1>${esc(v.displayName)}</h1>
  <p class="variety-notes">${esc(v.notes)}</p>
  <dl class="variety-facts">
${[
    row('Plant family', v.family),
    row('Season', v.season),
    row('Sow', v.sow),
    row('Days to maturity', v.days_to_maturity),
    row('Packets available', v.packets_available),
  ].join('\n')}
  </dl>
  <p class="variety-cta">Want some? <a href="/lending.html">How lending works</a> — or <a href="/browse.html#${esc(key(v.family))}">browse ${esc(v.family)} again</a>.</p>
</main>
</body>
</html>
`;
  fs.writeFileSync(path.join(generatedRoot, 'varieties', `${v.pageId}.html`), html);
}

// One small HTML fragment per family: fetched on demand, never all at once.
for (const family of families) {
  const list = byFamily.get(family);
  const items = list.map((v) =>
  `    <li><a href="${varietyUrl(v.pageId)}">${esc(v.name)}</a><span class="row-meta">Sow ${esc(v.sow)} · ${esc(v.days_to_maturity)} days · ${esc(v.packets_available)} packets</span></li>`
  ).join('\n');
  const html = `<h2>${esc(family)} <span class="family-count">${list.length} varieties</span></h2>
<ul class="family-list">
${items}
</ul>
`;
  fs.writeFileSync(path.join(generatedRoot, 'browse', `${key(family)}.fragment.html`), html);
}

// The Browse page itself is also a projection of the export: family list
// and counts must survive the next re-export with no hand-editing.
const buttons = families.map((family) => {
  const k = esc(key(family));
  return `      <li><a id="${k}" href="/browse/${k}.fragment.html" data-family="${k}">${esc(family)} <span class="count">${byFamily.get(family).length}</span></a></li>`;
}).join('\n');
fs.writeFileSync(path.join(generatedRoot, 'browse.html'), `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Browse the catalogue</title>
<meta name="description" content="Browse the Fernhollow seed catalogue by plant family — 225 varieties, one family at a time.">
</head>
<body class="browse">
<main>
  <h1>Browse the catalogue</h1>
  <p>${varieties.length} varieties in ${families.length} families, for the ${esc(data.season)} season. Pick a family and only its varieties load.</p>
  <nav class="families" aria-label="Plant families">
    <ul id="family-buttons">
${buttons}
    </ul>
  </nav>
  <section id="family-results" aria-live="polite" tabindex="-1">
    <p class="hint">Choose a family above.</p>
  </section>
  <noscript><p>JavaScript is off: the family links above open plain list pages — each one still only that family's varieties.</p></noscript>
</main>
<script src="/js/browse.js"></script>
</body>
</html>
`);

console.error(`gen: ${varieties.length} variety pages, ${families.length} family fragments, browse page (base "${basePath}", pretty ${ctx.site.prettyUrls})`);
