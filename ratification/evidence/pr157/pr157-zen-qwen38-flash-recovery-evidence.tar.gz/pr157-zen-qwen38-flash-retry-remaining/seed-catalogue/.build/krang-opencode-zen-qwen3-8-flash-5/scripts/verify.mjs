// Serves dist/ under the /library/ prefix exactly as the deploy does,
// then verifies the site the way a browser at that address uses it.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const DIST = path.join(process.cwd(), 'dist');
const BASE = '/library';

const types = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml',
  '.json': 'application/json', '.xml': 'application/xml',
};

function resolve(urlPath) {
  let p = urlPath.split('?')[0].split('#')[0];
  if (!p.startsWith(BASE)) return { status: 404 };
  p = p.slice(BASE.length) || '/';
  let file = path.normalize(path.join(DIST, p));
  if (!file.startsWith(DIST)) return { status: 404 };
  if (fs.existsSync(file) && fs.statSync(file).isDirectory()) {
    if (!urlPath.endsWith('/')) return { status: 301, location: urlPath + '/' };
    file = path.join(file, 'index.html');
  }
  if (fs.existsSync(file) && fs.statSync(file).isFile()) return { status: 200, file };
  if (fs.existsSync(file + '.html')) return { status: 200, file: file + '.html' };
  return { status: 404 };
}

const server = http.createServer((req, res) => {
  const r = resolve(req.url);
  if (r.status === 301) { res.writeHead(301, { Location: r.location }); return res.end(); }
  if (r.status === 404) { res.writeHead(404); return res.end('not found'); }
  res.writeHead(200, { 'Content-Type': types[path.extname(r.file)] || 'application/octet-stream' });
  fs.createReadStream(r.file).pipe(res);
});

await new Promise((ok) => server.listen(0, '127.0.0.1', ok));
const origin = `http://127.0.0.1:${server.address().port}`;

const data = JSON.parse(fs.readFileSync('varieties.json', 'utf8'));
const byFamily = {};
for (const v of data.varieties) (byFamily[v.family] ??= []).push(v);
const key = (f) => f.toLowerCase();

let pass = 0, fail = 0;
const check = (name, cond, extra = '') => {
  if (cond) { pass++; } else { fail++; console.log('FAIL:', name, extra); }
};

async function get(urlPath) {
  const res = await fetch(origin + encodeURI(urlPath));
  const body = res.status === 200 ? await res.text() : '';
  return { status: res.status, body, location: res.headers.get('location') };
}

// 1. Home page at the address.
const home = await get(BASE + '/');
check('home 200', home.status === 200);
check('home has header leaf mark under base', home.body.includes('/library/img/leaf.svg'));

// 2. Every page must load chrome+assets under /library/ from its own depth.
const pages = [
  BASE + '/',
  BASE + '/browse/',
  BASE + '/lending/',
  BASE + '/guides/',
  BASE + '/varieties/nine-star-pea-1/',
  BASE + '/guides/saving-bean-seed/',
];
for (const p of pages) {
  const r = await get(p);
  check(`page 200 ${p}`, r.status === 200, String(r.status));
  check(`header on ${p}`, r.body.includes('/library/img/leaf.svg'));
  check(`nav links absolute under base on ${p}`, r.body.includes('href="/library/browse/"'));
  const assets = [...r.body.matchAll(/(?:href|src)="(\/library\/[^"#]*?)"/g)].map((m) => m[1]);
  for (const a of assets) {
    const ar = await get(a);
    check(`asset ${a} from ${p}`, ar.status === 200, String(ar.status));
  }
  if (p !== BASE + '/lending/') check(`contact strip on ${p}`, r.body.includes('contact-strip'));
  if (p === BASE + '/lending/') {
    check('lending ends with terms', r.body.includes('Membership terms'));
    check('lending has NO contact strip', !r.body.includes('contact-strip'));
  }
}

// 3. Browse page must NOT ship the 225 varieties.
const browse = await get(BASE + '/browse/');
for (const v of data.varieties) {
  if (browse.body.includes(`>${v.name}</`)) { check('browse does not embed variety rows', false, v.name); break; }
}
check('browse has JS hook', browse.body.includes('/library/js/browse.js'));

// 4. Simulate the browser: family buttons -> fetch each fragment href.
const fragHrefs = [...browse.body.matchAll(/<a id="[^"]+" href="([^"]+\.fragment\.html)" data-family="([^"]+)"/g)];
check('12 family buttons', fragHrefs.length === 12, String(fragHrefs.length));
const seenVarietyLinks = new Set();
for (const [, href, fam] of fragHrefs) {
  const fr = await get(href);
  check(`fragment fetch 200 ${fam}`, fr.status === 200, String(fr.status));
  const rows = [...fr.body.matchAll(/<a href="([^"]+)">([^<]+)<\/a>/g)];
  const expected = byFamily[Object.keys(byFamily).find((f) => key(f) === fam)];
  check(`fragment ${fam} has exactly its ${expected.length} varieties`, rows.length === expected.length, String(rows.length));
  const names = expected.map((v) => v.name).sort();
  for (const row of rows) {
    check(`fragment ${fam}: name is a member`, names.includes(row[2]), row[2]);
    seenVarietyLinks.add(row[1]);
  }
  for (const other of data.varieties.filter((v) => v.family !== expected[0].family)) {
    if (fr.body.includes(`>${other.name}</a>`) && !names.includes(other.name)) {
      check(`fragment ${fam}: excludes other families`, false, other.name);
    }
  }
}
check('all 225 varieties reachable via fragments', seenVarietyLinks.size === 225, String(seenVarietyLinks.size));

// 5. Every link the fragments carry must resolve under the address.
let vfail = 0;
for (const href of seenVarietyLinks) {
  const r = await get(href);
  if (r.status !== 200) { vfail++; if (vfail < 4) console.log('FAIL variety link', href, r.status); }
  else if (!r.body.includes('<h1>')) vfail++;
}
check('all 225 variety pages resolve', vfail === 0, `${vfail} failed`);

// 6. Nothing sensitive is reachable.
for (const p of [BASE + '/varieties.json', BASE + '/drafts/frost-dates.md', BASE + '/unify.yaml', BASE + '/scripts/gen.mjs', '/varieties.json']) {
  const r = await get(p);
  check(`refuses ${p}`, r.status === 404, String(r.status));
}

server.close();
console.log(`\npassed ${pass}, failed ${fail}`);
process.exit(fail ? 1 : 0);
