// Loads one family at a time on the Browse page. The hrefs on the family
// links were rewritten by the build to sit under the deployed base path,
// so read them back from the DOM — never hardcode a fetch address here.
(function () {
  var buttons = Array.prototype.slice.call(document.querySelectorAll('#family-buttons a'));
  var results = document.getElementById('family-results');
  if (!buttons.length || !results) return;
  var current = null;

  function activate(link) {
    buttons.forEach(function (b) {
      b.classList.toggle('active', b === link);
    });
    results.innerHTML = '<p class="loading">Loading ' + link.textContent.trim() + '…</p>';
    fetch(link.href)
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.text();
      })
      .then(function (html) {
        results.innerHTML = html;
        try { history.replaceState(null, '', '#' + link.getAttribute('data-family')); } catch (e) {}
      })
      .catch(function () {
        results.innerHTML = '<p class="error">Could not load that family on this connection. Try again, or use the link directly.</p>';
      });
    current = link;
  }

  buttons.forEach(function (link) {
    link.addEventListener('click', function (ev) {
      ev.preventDefault();
      activate(link);
    });
  });

  var wanted = decodeURIComponent((window.location.hash || '').replace('#', ''));
  var initial = buttons.filter(function (b) { return b.getAttribute('data-family') === wanted; })[0];
  if (initial) activate(initial);
})();
