# Fernhollow Seed Library — build report

## Publish command

```
./unify build --base-url https://fernhollow.pages.dev/library/ --pretty-urls --clean --audit
```

`--base-url` is the whole deployed address (subdirectory included), `--pretty-urls` keeps
visitor URLs free of `.html`, `--clean` prevents stale files surviving between re-exports,
and `--audit` publishes only if `unify audit` would exit 0 (it does: **0 broken**).
Exit 0; 249 files land in `dist/`.

## What was built

- `site/` is the source root, so `varieties.json`, `drafts/`, `unify.yaml`, and `scripts/`
  are outside it and cannot ship (`--exclude` untouched: the default `_*` covers `site/_layout.html`,
  `site/_includes/`).
- `scripts/gen.mjs` (run by unify before every build via `generate:` in `unify.yaml`) reads
  `varieties.json` and writes into the generated directory unify hands it: 225 variety
  pages (`/varieties/<id>/`), one 12-family browse page with its counts, and **one
  `.fragment.html` per family** — nothing else. `seed_keeper` and `keeper_contact` are
  dropped at generation; a grep of `dist/` for `keeper_contact|seed_keeper|fernhollow-members`
  returns nothing.
- The export contains 15 duplicated slugs (same name in two families). The generator
  disambiguates ids as `<slug>-<family>` and titles as `Name (Family)` so every variety
  gets a unique page — this is inferred, not documented.
- Shared chrome: `site/_layout.html` (root) and `site/guides/_layout.html` (the redesigned
  guides look) both `<include>` the same `/_includes/header.html` (leaf mark `img/leaf.svg`
  placeholder + nav) and put `/_includes/footer.html` (contact strip) as the **fallback of
  a named `<slot name="footer">`** inside the layout's own `<footer>`. `lending.html` fills
  that slot with `<section slot="footer">` membership terms — the one page without the
  contact strip.
- No page ships all 225 varieties: `/library/browse/` carries only 12 family links;
  `js/browse.js` fetches the clicked family's fragment and reads the fetch address back
  from the rewritten `href` (per `rules.md`, fetched URLs are not rewritten by the build —
  nor are the variety links *inside* a copied fragment, so the generator bakes the correct
  base path into them from the build context it is handed).

## How I checked a visitor at that address gets a working page

`scripts/verify.mjs` (run with `node scripts/verify.mjs`) starts a node http server that
serves `dist/` exactly as the deploy does — a request for `/library/<x>` maps to `dist/<x>`,
directories redirect, and no origin fallback — then behaves like a browser at
`https://fernhollow.pages.dev/library/` (it uses only the URLs the emitted pages contain):

- every page kind (home, browse, lending, guides index, a guide at depth `/library/guides/<name>/`,
  a variety at `/library/varieties/<slug>/`) returns 200 with the leaf-mark header, and
  **every `href`/`src` it emits starting `/library/` is fetched and 200s** — css, js, svg, nav.
- the browse page body is asserted not to contain any variety row; its 12 family links are
  fetched one by one, each returning exactly its family's count of rows (17, 11, 15, 21,
  22, 14, 19, 26, 18, 12, 34, 16 = 225), no other family's varieties, and every one of the
  225 links inside those fetched fragments resolves 200 under the same address.
- the contact strip is asserted present on every page and absent on lending (terms instead).
- negatives asserted: `/library/varieties.json`, `/library/drafts/frost-dates.md`,
  `/library/unify.yaml`, `/library/scripts/gen.mjs` are 404, and the only absolute URLs in
  the output are the site's own canonicals on `fernhollow.pages.dev` (nothing cross-origin).

359 assertions pass, 0 fail. (No browser exists here; this server+fetch loop is the closest
honest simulation of the visitor's requests.)

## What `rules.md` did not answer

The sentence I wanted and could not find, in order of how much it cost me:

- **How the `generate:` script is actually invoked.** `rules.md` says it "writes into the
  directory unify hands it" — but never says *what it is handed*: the working directory,
  the argument order (source root, generated root, context path), or that
  `generator-context.json` contains `baseUrl`/`prettyUrls`/`sourcePages`. I learned all of
  that by running a probe script that printed `process.argv` and dumped the context file.
  A sentence like "unify runs `node <script> <source-root> <generated-root> <context.json>`
  from the source root" would have saved the whole first experiment.
- **Whether the contents of the generated directory get the same treatment as source files.**
  Do they see layouts? Are their `href`s rewritten? Are broken links inside them checked?
  Nothing said. (Probing showed: yes layout, yes rewriting, yes checking for built pages;
  `.fragment.html` in it is still copied byte-for-byte, and its links are *not* rewritten.)
- **What `--pretty-urls` does to `x.fragment.html`.** The rules give the `about.html →
  about/index.html` rule but never mention fragments; I had to test to learn they ship with
  their `.fragment.html` name intact (my fetched-URL design depends on knowing this).
- **Whether pages written in Markdown are linked as `.html` or `.md`.** "Always link the
  real filename — `/about.html`" only covers HTML pages. I guessed `saving-bean-seed.html`
  for a `.md` source; the link checker accepted it, which is evidence but not documentation.
- **Where `generate:` in `unify.yaml` resolves from.** The CLI help says `--generate` paths
  are relative to the *source root*; the rules show `generate: scripts/gen.mjs` "beside the
  site". Both readings fit the example. Empirically the yaml value resolved from the project
  root (the yaml's directory) — I inferred that and only trusted it after the probe ran.
- **That `audit` builds its link graph from rewritten pages only.** Nothing in the rules
  says copied files (fragments) are invisible to `page-orphan`, so `audit --strict` fails on
  225 advisories for exactly the pages the on-demand design must not statically link. I
  decided those are false positives by construction: the HTTP verification above proves every
  variety page is reachable by clicking through the browse page as a real visitor would, and
  the alternative — linking all 225 from a processed page — is precisely what the library
  forbade. So the publish gate is `build`/non-strict `audit` (0 broken), not `--strict`.

## What I re-read, and why it did not land the first time

- The Merge section's footer sentence: "**A bare `<header>`/`<footer>` does not replace the
  layout's — only `slot=` fills, and it fills the *contents*: where the layout wraps its slot
  in its own `<footer>`, write `<p slot="footer">`, or you ship a footer inside a footer.**"
  It contradicts itself on first read (a `slot=` element "replaces the slot, tag and all",
  yet a fill "fills the contents"), and the "footer inside a footer" warning names the wrong
  failure. I initially planned a whole second layout for lending's terms; the reread landed
  once I framed it as: the *layout* owns the `<footer>` wrapper and the named slot's contents,
  and the page's `slot="footer"` element replaces only those contents. I then proved the
  reading with a probe page before writing `lending.html` — twice in one sentence ("direct
  children of your default-content main" is where the terms fill lives) because the first
  reading left me unsure whether a *named* slot could be filled from a child of `<main>` at
  all.
- The Styles/scripts paragraph about fetched URLs. My first pass read it as "hx-get is a
  tool unify supports"; the sentence "unify … rewrites only HTML's own URL attributes" plus
  "read it back from an `href` unify rewrote" only landed on the third read, when it became
  the actual implementation note for `browse.js`. That single compressed paragraph carries
  three distinct behaviours (href/src rewritten; fetch/hx-get not; fragment hrefs not either)
  and gives each one clause.
- "Everything in the source root ships." It reads like background colour; it is a landmine —
  `varieties.json` sitting in the project root of a tool whose source root *defaults to the
  current directory* would have published members' addresses. It landed when I hit the
  "Neither may `varieties.json` itself" line in the brief, and I went back to find the
  sentence that made `site/` the right move.

## What I guessed at, or inferred rather than read

- Duplicate-slug handling (`<slug>-<family>` ids, `Name (Family)` titles) — the rules never
  address slugs colliding; I chose a deterministic scheme and asserted uniqueness in the
  script (it throws if ids still collide).
- Family keys for the fetched fragments (`brassica`, `allium`, …) and the `#family` hash
  deep-link behaviour on the browse page — not asked for, designed.
- That the deploy maps the `dist/` root onto the `/library/` path (that is what `--base-url`
  implies, but the rules document the tool's side only; my verification server mirrors that
  assumption, so the report's correctness claim is "correct *given* that standard mapping").
- `--canonical` default: the help says auto is "the default with --base-url"; I relied on it
  for 232 canonical links rather than authoring them (the rules forbid a layout from setting
  one anyway, and I confirmed the generated pages each got their own absolute URL).
- The guides look (colours, serif index cards in `guides.css`) — "its own look, while
  carrying the identical header and footer" is a taste call; the mechanism is documented,
  the design isn't.
- That a `<section slot="footer">` (a block element, not the `<p>` the rules use in their
  example) is an acceptable fill — the rule says "a real element", I read `<p>` as example,
  not a whitelist; the probe confirmed it composes.

## State of the checks

- `./unify build --base-url https://fernhollow.pages.dev/library/ --pretty-urls --clean --audit` → exit 0,
  publishes `dist/`.
- `./unify build --dry-run --strict --base-url … --pretty-urls` → exit 0.
- `./unify audit --base-url … --pretty-urls` → exit 0 (0 broken, 225 incomplete advisories,
  all `page-orphan`, all explained above).
- `node scripts/verify.mjs` → 359 passed / 0 failed against a server that reproduces the
  published address, including the twelve post-load family fetches and all 225 links they
  hand the browser.
