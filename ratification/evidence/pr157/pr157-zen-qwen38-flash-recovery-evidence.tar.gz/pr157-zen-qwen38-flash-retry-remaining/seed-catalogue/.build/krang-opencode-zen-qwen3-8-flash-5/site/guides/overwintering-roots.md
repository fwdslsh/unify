---
title: Overwintering roots for seed
description: Keeping carrots, parsnips and chard alive through winter so they flower in year two.
class: guide
---
# Overwintering roots for seed

Carrots, parsnips, chard and most of the Brassica roots are biennial: the plant spends a
year growing a root, a winter sitting still, and the next spring running up a tall flower
spike. If you have never grown a carrot flower, you have never grown a carrot — the umbel
is one of the best insects' gardens on the allotment.

## Lift and clamp, or leave and mulch

In a mild corner of the valley, leave the roots in the ground under a deep straw mulch.
Elsewhere, lift before hard frost and clamp them in a box of damp sand in a cool shed or
unheated porch. The roots must stay cool and slightly damp: a warm kitchen makes them
shrivel, and a dry one makes them woody.

## Check monthly, replant in March

A monthly look for rot, and a dampen if the sand has gone dry. In March, replant the
surviving roots as they lay, tops just at the soil line, and water. Expect a spike in
four to six weeks. Carrots flower the first summer; their seed takes another month to
harden in the umbel — cut the whole head when the outer umbrels turn beige, and dry it
on a sheet.

> "I keep three carrot roots every winter in a sand box by the coal chute and I have not
> bought a seed packet since 2019."
> — Walter, bed 14
