---
title: Saving bean seed
description: How to dry and store seed from runner and French beans, by a Fernhollow volunteer.
class: guide
---
# Saving bean seed

Beans are the easiest crop in the catalogue to keep, and the one most often ruined by
impatience. All you need is a pod that finishes on the plant.

## Leave it longer than feels right

Pick your seed pod from a healthy plant early — mark it with a twist of yarn so nobody
picks and eats it. Then leave it. The pod should go from green, to bulging, to papery
and rattly. If you can dent the pod with a thumbnail, it is not ready.

> "I shelled mine too early for three years and every packet sinned."
> — Marta, who now labels her seed row "NOT DINNER"

## Dry, then freeze briefly

- Shell the beans onto a plate and pick out any with holes (weevil work).
- Air the plates for a fortnight in a warm, dry room.
- A week in a freezer kills any late-hatching weevils. Then store in a labelled envelope.

Label with variety, year, and the name of the member whose seed you borrowed. That line
of credit is the whole library.

## How many plants

Save seed from at least six plants of one variety, mixed together, so the population
stays broad. A single plant's seed is inbreeding, not lending.
