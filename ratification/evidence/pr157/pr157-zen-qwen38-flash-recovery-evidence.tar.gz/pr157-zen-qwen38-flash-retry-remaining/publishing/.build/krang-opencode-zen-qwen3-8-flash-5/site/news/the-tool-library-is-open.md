---
title: "The tool library is open: borrow, don't buy"
description: "Ines explains how to take a drill, a sewing machine or a tile cutter home for a weekend — no money, just a name and a promise."
date: "2026-07-12T14:00:00Z"
author: "Ines Duarte"
schema: BlogPosting
og:image: /assets/news-card.svg
og:image:width: 1200
og:image:height: 630
class: news
---

# The tool library is open

The shelf is on the wall to the left as you come in, and it is finally doing its job:
twenty-two hand tools, four cordless drills with charged batteries, a sewing machine,
a tile cutter that belongs to Frank and which he watches like a hawk, and a ladder
that lives by the door because nobody wants to carry it home.

The rule is simple. You are over sixteen, you write your name and what you took in the
green book, you bring it back by the next Saturday session, and if anything breaks you
tell us instead of hiding it. No money, no deposit, no judgement. A borrowed tile cutter
comes back cleaner than it left, because the person who used it was here last Saturday
anyway, so of course they helped.

Borrowing a tool for one afternoon is how a repair stops being an event someone else
performs on your life and becomes something you do yourself. That is the whole point.
The book is open every Wednesday and Saturday; the first few rows are already full
for August.

*— Ines*
