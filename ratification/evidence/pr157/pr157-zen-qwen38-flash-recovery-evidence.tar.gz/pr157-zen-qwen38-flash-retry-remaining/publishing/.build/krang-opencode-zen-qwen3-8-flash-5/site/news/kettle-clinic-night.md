---
title: "Kettle clinic night: twenty of twenty-three kettles went home working"
description: "Marta reports on our biggest kettle night yet — limescale, one lucky thermal fuse, and two kettles that were never broken at all."
date: "2026-10-18T17:30:00Z"
author: "Marta Byrne"
schema: BlogPosting
og:image: /assets/news-card.svg
og:image:width: 1200
og:image:height: 630
class: news
---

# Kettle clinic night

Twenty-three kettles came through the green door on Wednesday, and twenty of them went
home working. That is the best ratio we have managed all year, and I think it is because
almost every failure was the same one: limescale.

If your kettle clicks on but never boils, or boils and cuts out after a few seconds,
check the base first. Nine of ours had a scorched connection strip that a ten-minute
clean and a re-seat brought back to life. One had a genuinely dead thermal fuse —
Osei had a spare in the parts drawer for a 2014 model nobody else would touch.

Two kettles were never broken at all: the switch was just packed in calcified slop
from years of never being descaled. The fix was warm water and a toothbrush.

Next month we are trying the same evening for toasters. Bring yours, bring a towel,
bring your patience — and if your kettle is plastic and riveted shut, come anyway,
we will show you how to tell it when it is time to let go.

*— Marta*
