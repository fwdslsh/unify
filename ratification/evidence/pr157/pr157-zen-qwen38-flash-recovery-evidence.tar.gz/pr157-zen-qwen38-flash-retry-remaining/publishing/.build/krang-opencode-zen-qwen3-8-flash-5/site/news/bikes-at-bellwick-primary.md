---
title: "Rolling repair: a bike clinic at Bellwick Primary"
description: "Osei and two volunteers overhauled thirty-one school bikes in one grey Saturday, and taught a class of ten-year-olds how to patch a tube."
date: "2026-09-06T10:00:00Z"
author: "Osei Mensah"
schema: BlogPosting
og:image: /assets/news-card.svg
og:image:width: 1200
og:image:height: 630
class: news
---

# Rolling repair

The head teacher at Bellwick Primary asked if we could look at the bike shed, and when we
got there the shed told its own story: thirty-one bikes, maybe four that a child could
safely ride. Brakes rubbed, chains complained, saddles gave up at the smallest nudge.

We spent the Saturday there — me, Ines, and Frank, who turned up with an unmarked van
of spare tubes he refuses to explain the provenance of. By two o'clock thirty-one bikes
were rolling, and a class of ten-year-olds had each patched a tube themselves, badly,
happily, on the wall by the bike racks.

The lesson I keep re-learning: most "dead" bikes are a seized brake cable and a wheel
out of true. Children notice everything, so we talked them through every step rather
than working around them, and half the class stayed after to hold the other half's
inner tubes steady.

The school has asked us back in the spring. We said yes before they finished asking.

*— Osei*
