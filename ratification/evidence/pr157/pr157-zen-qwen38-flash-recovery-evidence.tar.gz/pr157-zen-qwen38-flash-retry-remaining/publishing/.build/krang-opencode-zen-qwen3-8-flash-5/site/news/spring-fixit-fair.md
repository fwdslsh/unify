---
title: "Fix-it fair results: 1.2 tonnes diverted from landfill"
description: "Frank totals up the spring fair — 388 items brought in, 341 repaired on the spot, and the strange economics of a good lamp."
date: "2026-03-21T09:30:00Z"
author: "Frank Okafor"
schema: BlogPosting
og:image: /assets/news-card.svg
og:image:width: 1200
og:image:height: 630
class: news
---

# Fix-it fair results

Numbers, finally, from the March fair on the green. People brought us 388 items between
ten and four. Our thirty-odd volunteers got 341 of them working again in front of their
owners — a 88 percent success rate, and I intend to be smug about it until the kettle
night figures beat it.

The forty-seven that went into the parts crate break down like this: nineteen were
"smart" anything, with chips nobody will document or sell; eleven had motors with
no spare brushes anywhere; and the rest were simply chewed, meaning chewed by a dog,
and we will not pretend otherwise to their owners.

By weight we diverted 1.2 tonnes. Lamps were the surprise: thirty-one came in,
twenty-nine left working, mostly for the price of a new socket and a cloth. A good lamp
outlives four bad ones and costs nothing to keep.

Thank you to the café on Kiln Lane for the free urn of tea, and to whoever donated
the box of brown envelopes — they vanished fast, and I assume into a junk drawer
that will one day be the most useful drawer in Bellwick.

*— Frank*
