import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join, dirname } from "node:path";

const context = JSON.parse(readFileSync(process.argv[4], "utf8"));
const inventory = JSON.parse(readFileSync(context.inputs.sourcePages, "utf8"));
const overlay = context.paths.generatedRoot;

function esc(s) {
  return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function niceDate(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  if (!m) return "";
  return `${Number(m[3])} ${months[Number(m[2]) - 1]} ${m[1]}`;
}

const posts = inventory.pages
  .filter((p) => /^news\/.+\.md$/.test(p.source))
  .filter((p) => p.meta.some((m) => m.name === "schema" && /Article|BlogPosting/.test(m.content || "")))
  .sort((a, b) => String(b.date).localeCompare(String(a.date)));

const items = posts
  .map((p) => {
    const author = p.meta.find((m) => m.name === "author")?.content || "";
    return [
      "      <li>",
      `        <h2><a href="${esc(p.href)}">${esc(p.title)}</a></h2>`,
      `        <p class="post-meta"><time datetime="${esc(p.date)}">${esc(niceDate(p.date))}</time> — ${esc(author)}</p>`,
      `        <p>${esc(p.description)}</p>`,
      "      </li>",
    ].join("\n");
  })
  .join("\n");

const page = `<!doctype html>
<html lang="en" data-layout="/_layout.html">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>News</title>
  <meta name="description" content="News from the Bellwick Repair Collective workshop — newest first.">
</head>
<body class="news-index">
  <main>
    <h1>News</h1>
    <p>What the volunteers have been fixing, written by the people who did it. Newest first.
      Subscribe with any feed reader: <a href="/feed.xml">/feed.xml</a>.</p>
    <ul class="post-list">
${items}
    </ul>
  </main>
</body>
</html>
`;

const target = join(overlay, "news", "index.html");
mkdirSync(dirname(target), { recursive: true });
writeFileSync(target, page);
