import fs from "node:fs";
import path from "node:path";

const ctx = JSON.parse(fs.readFileSync(process.argv[4], "utf8"));
const { generatedRoot } = ctx.paths;
const inventory = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, "utf8"));

const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );

const metaValue = (page, key) =>
  (page.meta.find((m) => m.name === key) || {}).content ?? null;

const posts = inventory.pages
  .filter((p) => p.source.startsWith("news/") && p.source.endsWith(".md"))
  .filter((p) => metaValue(p, "schema") === "BlogPosting")
  .sort((a, b) => String(b.date).localeCompare(String(a.date)));

if (posts.length === 0) throw new Error("no BlogPosting pages found under news/");

const MONTHS = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"];

const shown = (iso) => {
  const d = new Date(iso);
  return `${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]} ${d.getUTCFullYear()}`;
};

const items = posts
  .map((p) => {
    const author = metaValue(p, "author");
    return [
      "      <li>",
      `        <h2><a href="${esc(p.href)}">${esc(p.title)}</a></h2>`,
      `        <time datetime="${esc(p.date)}">${esc(shown(p.date))}</time>${author ? ` · ${esc(author)}` : ""}`,
      p.description ? `        <p>${esc(p.description)}</p>` : null,
      "      </li>",
    ].filter(Boolean).join("\n");
  })
  .join("\n");

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>News</title>
<meta name="description" content="News from the Bellwick Repair Collective: what volunteers have been mending, and when you can come and watch.">
</head>
<body class="news">
<main>
  <h1>News from the workshop</h1>
  <p class="lede">Written by the volunteers who did the fixing. Newest first —
  <a href="/feed.xml">subscribe in a feed reader</a> to never miss one.</p>
  <ul class="post-list">
${items}
  </ul>
</main>
</body>
</html>
`;

const out = path.join(generatedRoot, "news", "index.html");
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, html);
console.log(`gen: wrote news/index.html listing ${posts.length} posts (newest first)`);
