---
title: "The library wants your torn coats"
description: "Bellwick Library is hosting our mending circle on Thursdays, with a donated fabric wall and a rule that nobody leaves with a hole."
author: "Tomas Lindqvist"
date: "2026-09-14T09:30:00Z"
schema: BlogPosting
---

# The library wants your torn coats

The library has lent us a corner of the reading room every Thursday from six,
and the first mending circle was packed. Twenty-two people, one fabric wall
donated by the Mill family's old dressmaker's shop, and a house rule we stick
to: *nobody leaves with a hole*.

Jeans took the afternoon — blown-out knees mostly — but a wedding-dress-era
cardigan got a proper darning, and a child's school coat came back patched
with waxed canvas.

Come with a needle or without one. The library is quiet, so we talk in
workshop voices, which everyone quickly learns.
