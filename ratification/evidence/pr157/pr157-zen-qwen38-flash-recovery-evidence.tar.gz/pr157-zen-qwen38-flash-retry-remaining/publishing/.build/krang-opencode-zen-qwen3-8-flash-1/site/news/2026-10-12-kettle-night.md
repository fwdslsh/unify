---
title: "Kettle night: eleven saved from the bin"
description: "Our Fix-it Friday kettle clinic mended eleven of the twelve kettles brought in — a heating element, two switches, and a lot of limescale."
author: "Rosa Meireles"
date: "2026-10-12T17:00:00Z"
schema: BlogPosting
---

# Kettle night: eleven saved from the bin

Eleven of the twelve kettles that came to Friday's kettle clinic went home
working. The twelfth was a sealed model with a welded base; we parted it out
for spares and wrote to the manufacturer, as is our custom.

The usual culprits, in order: dry-boiled thermostats, snapped switch clips,
and limescale so thick the element was cooking rock instead of water. Vinegar
and patience beat a new kettle every single time.

Next clinic is *Fix-it Friday, last Friday of November* — lamps this time.
Bring yours, bring a friend, leave with both hands busy.
