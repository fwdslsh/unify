import fs from "node:fs";
import path from "node:path";
import http from "node:http";

const DIST = "/tmp/sandbox/dist";
const BASE = "https://bellwick.example/workshop/";

const toFile = (pathname) => {
  let p = pathname.replace(/^\/workshop\/?/, "");
  const f = path.join(DIST, p);
  if (fs.existsSync(f) && fs.statSync(f).isDirectory()) return path.join(f, "index.html");
  return f;
};

const server = http.createServer((req, res) => {
  const file = toFile(decodeURIComponent(req.url));
  if (!file.startsWith(DIST) || !fs.existsSync(file)) { res.writeHead(404); return res.end(); }
  const type = file.endsWith(".html") ? "text/html" : file.endsWith(".css") ? "text/css"
    : file.endsWith(".svg") ? "image/svg+xml" : file.endsWith(".xml") ? "application/xml" : "text/plain";
  res.writeHead(200, { "content-type": type });
  res.end(fs.readFileSync(file));
});
await new Promise((r) => server.listen(8123, r));

const pages = [
  "", "visit/", "news/", "news/2026-11-02-van-mot/", "news/2026-10-12-kettle-night/",
  "news/2026-09-14-library-mending/", "news/2026-08-17-hundred-toasters/",
  "feed.xml", "sitemap.xml", "assets/gear-card.svg", "assets/gear.svg",
  "assets/placeholder-map.svg", "assets/style.css",
];
let fail = 0;
const htmls = {};
for (const p of pages) {
  const r = await fetch("http://127.0.0.1:8123/workshop/" + p);
  const body = await r.text();
  if (r.status !== 200) { fail++; console.log("FAIL", r.status, "/workshop/" + p); }
  else console.log(r.status, "/workshop/" + p, body.length, "bytes");
  if (p.endsWith("/")) htmls["/workshop/" + p] = body;
}

for (const [url, body] of Object.entries(htmls)) {
  const addrs = [...body.matchAll(/(?:href|src)="([^"]+)"/g)].map((m) => m[1]);
  for (const a of addrs) {
    if (/^(#|mailto:|data:)/.test(a)) continue;
    if (!a.startsWith(BASE) && !a.startsWith("/workshop/")) { fail++; console.log("OFF-SITE", url, "→", a); continue; }
    if (/\.html(["?]|$)/.test(a)) { fail++; console.log("HTML-EXT", url, "→", a); }
    const target = a.startsWith(BASE) ? a.slice(BASE.length - 1) : a;
    const r = await fetch("http://127.0.0.1:8123" + target);
    if (r.status !== 200) { fail++; console.log("BROKEN", url, "→", a); }
  }
  const og = ["og:title", "og:description", "og:url", "og:image"].filter((k) => body.includes(`property="${k}"`));
  const titles = [...body.matchAll(/<title>([^<]*)<\/title>/g)].length;
  const h1 = (body.match(/<h1/g) || []).length;
  console.log("page", url, "| title:", titles, "| h1:", h1, "| og:", og.join(","));
}

for (const slug of ["2026-11-02-van-mot", "2026-10-12-kettle-night", "2026-09-14-library-mending", "2026-08-17-hundred-toasters"]) {
  const body = htmls[`/workshop/news/${slug}/`];
  const ld = JSON.parse(body.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);
  const abs = (s) => s.startsWith(BASE);
  console.log(`article ${slug}: @type=${ld["@type"]} headline=${!!ld.headline} desc=${!!ld.description} datePublished=${ld.datePublished} author=${ld.author} url-abs=${abs(ld.url)} image-abs=${abs(ld.image)}`);
  const ogimg = body.match(/property="og:image" content="([^"]+)"/)[1];
  const r = await fetch(ogimg.replace(BASE, "http://127.0.0.1:8123/workshop/"));
  if (r.status !== 200) { fail++; console.log("OG-IMAGE 404", ogimg); }
}

const feed = fs.readFileSync(path.join(DIST, "feed.xml"), "utf8");
const entries = [...feed.matchAll(/<entry>([\s\S]*?)<\/entry>/g)].map((m) => m[1]);
console.log("feed entries:", entries.length);
const dates = [];
for (const e of entries) {
  const title = /<title>([^<]*)<\/title>/.exec(e)[1];
  const link = /<link rel="alternate" href="([^"]+)"/.exec(e)[1];
  const updated = /<updated>([^<]*)<\/updated>/.exec(e)[1];
  const published = /<published>([^<]*)<\/published>/.exec(e)[1];
  if (!link.startsWith(BASE)) { fail++; console.log("ENTRY-LINK not absolute", link); }
  if (!/T\d\d:\d\d/.test(updated)) { fail++; console.log("ENTRY-DATE no time", updated); }
  const lr = await fetch(link.replace(BASE, "http://127.0.0.1:8123/workshop/"));
  if (lr.status !== 200) { fail++; console.log("ENTRY-LINK 404", link); }
  console.log("  entry:", published, "|", title.slice(0, 46), "|", link);
  dates.push(published);
}
console.log("feed newest-first:", dates.join(",") === [...dates].sort().reverse().join(","));

const sm = fs.readFileSync(path.join(DIST, "sitemap.xml"), "utf8");
console.log("sitemap locs:", (sm.match(/<loc>/g) || []).length);

server.close();
console.log(fail === 0 ? "ALL CHECKS PASSED" : `${fail} FAILURES`);
process.exit(fail === 0 ? 0 : 1);
