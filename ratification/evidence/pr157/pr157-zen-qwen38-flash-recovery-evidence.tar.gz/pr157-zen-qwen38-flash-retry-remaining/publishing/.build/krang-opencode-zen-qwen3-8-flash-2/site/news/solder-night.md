---
title: "Solder night: twelve lamps revived"
description: "Twelve table lamps came to Tuesday bench night; only one needed a whole new cable. Rosa writes up the evening's wins."
date: "2026-01-12T18:30:00Z"
author: "Rosa Iglesias"
schema: BlogPosting
class: news
og:type: article
og:image: /news/images/solder-night.svg
---

# Solder night: twelve lamps revived

The room smelled of rosin and tea by half-six. Twelve lamps arrived on our trestle
table — inherited standards, a lava lamp from 1974, a bedside light with a chewed
flex — and one by one they came back.

The usual culprits, in order of appearance:

- **Broken flex near the strain relief.** The cable snaps where it enters the base.
  We cut, re-strip, and fit a new grommet. Five lamps, twenty minutes each.
- **Tarnished sockets.** A pencil eraser does what no replacement part can.
- **One melted switch** on a halogen desk lamp. Out went the switch, in came a
  spare we desoldered off a dead kettle last November. Nothing is finished until
  it is finished.

## The lava lamp

She was not "broken", exactly: the wax had gone to a single grey lump after years
in a cold attic. New cap, new coil, a patient two-hour warm-up — and she floated
again to a small cheer from the whole bench.

If you have a lamp that gave up on you, bring it to the next Tuesday. Advice is
free, and the kettle is on.
