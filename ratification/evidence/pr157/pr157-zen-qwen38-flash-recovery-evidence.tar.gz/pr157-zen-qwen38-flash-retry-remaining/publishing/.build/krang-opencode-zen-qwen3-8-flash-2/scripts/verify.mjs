import fs from "node:fs";
import path from "node:path";

const dist = "dist";
const read = (f) => fs.readFileSync(path.join(dist, f), "utf8");
const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) =>
  e.isDirectory() ? walk(path.join(d, e.name)) : [path.relative(dist, path.join(d, e.name))]);
const files = walk(dist);
const htmls = files.filter((f) => f.endsWith(".html"));
let fails = 0;
const check = (cond, label) => { console.log(`${cond ? "ok  " : "FAIL"} ${label}`); if (!cond) fails++; };

const posts = [
  "news/solder-night/index.html", "news/kettles-vs-limescale/index.html",
  "news/the-lamp-rescue/index.html", "news/spring-saturday-recap/index.html"];

// 1. pages exist, shared chrome, pretty URLs
for (const f of ["index.html", "visit/index.html", "news/index.html", ...posts])
  check(files.includes(f), `page emitted: /${f}`);
for (const f of htmls) {
  const s = read(f);
  check(s.includes("class=\"site-header\"") && s.includes("gear-mark") && s.includes("</svg>"), `${f}: shared header with gear mark`);
  check(s.includes("class=\"site-footer\"") && s.includes("14 Fulmar Lane"), `${f}: shared footer`);
}
const noHtmlLinks = htmls.every((f) =>
  [...read(f).matchAll(/(?:href|src)="([^"]+)"/g)]
    .map((m) => m[1])
    .every((u) => u.startsWith("mailto:") || !u.includes(".html")));
check(noHtmlLinks, "no visitor-visible link ends in .html");

// 2. every internal link resolves to an emitted file
const resolve = (u) => {
  if (!u.startsWith("/workshop/")) return null;
  const rel = u.slice("/workshop/".length).replace(/\/$/, "") || "index.html";
  return rel.endsWith(".html") || rel.includes(".") ? rel : rel + "/index.html";
};
for (const f of htmls) {
  for (const m of read(f).matchAll(/(?:href|src)="(\/workshop\/[^"]*)"/g)) {
    const t = resolve(m[1]);
    check(fs.existsSync(path.join(dist, t)), `${f}: ${m[1]} resolves to ${t}`);
  }
}

// 3. preview cards: og:image/title/description/url absolute + canonical on every post
for (const f of posts) {
  const s = read(f);
  const og = (p) => s.match(new RegExp(`property="${p}" content="([^"]+)"`))?.[1];
  const url = new URL(s.match(/property="og:url" content="([^"]+)"/)[1]);
  check(url.origin === "https://bellwick.example" && url.pathname === "/workshop/" + path.dirname(f).replace(/^news/, "news") + "/", `${f}: og:url absolute at published address`);
  check(!!og("og:image") && og("og:image").startsWith("https://bellwick.example/workshop/"), `${f}: og:image absolute (${og("og:image")})`);
  check(fs.existsSync(path.join(dist, new URL(og("og:image")).pathname.slice("/workshop/".length))), `${f}: og:image file exists`);
  check(!!og("og:title") && !!og("og:description"), `${f}: og:title + og:description present`);
  check(s.includes(`rel="canonical" href="https://bellwick.example/workshop/${path.dirname(f)}/"`), `${f}: canonical matches published address`);
}

// 4. article JSON-LD, generated not handwritten
for (const f of posts) {
  const m = read(f).match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/);
  check(!!m, `${f}: JSON-LD block present`);
  const j = JSON.parse(m[1]);
  check(j["@type"] === "BlogPosting" && j.headline && j.description && j.datePublished && j.author && j.url && j.image, `${f}: BlogPosting has title/description/date/author (url=${j.url})`);
}
check(htmls.every((f) => !read(f).includes("ld+json") || posts.includes(f)), "no hand-written JSON-LD on other pages");

// 5. feed: valid XML Atom, every post, title/link/updated
const feed = read("feed.xml");
const entries = [...feed.matchAll(/<entry>([\s\S]*?)<\/entry>/g)].map((m) => m[1]);
check(feed.includes("xmlns=\"http://www.w3.org/2005/Atom\""), "feed.xml is Atom");
check(entries.length === 4, `feed has 4 entries (got ${entries.length})`);
for (const e of entries) {
  const link = e.match(/<link rel="alternate" href="([^"]+)"/)?.[1];
  check(/<title>/.test(e) && !!link && /<updated>[^<]+<\/updated>/.test(e), `entry: title+address+date (${link})`);
}
const dates = entries.map((e) => Date.parse(e.match(/<updated>([^<]+)/)[1]));
check(dates.every((d, i) => i === 0 || d <= dates[i - 1]), "feed newest-first");
check(htmls.every((f) => read(f).includes("rel=\"alternate\" type=\"application/atom+xml\"")), "every page advertises the feed");

// 6. sitemap sanity + nothing local loads externally
check(files.includes("sitemap.xml"), "sitemap.xml emitted");
check(htmls.every((f) => ![...read(f).matchAll(/(?:href|src)="(https?:\/\/[^"]+)"/g)].some((m) => !m[1].startsWith("https://bellwick.example"))), "no page loads anything off-origin");

console.log(fails ? `\n${fails} FAILURES` : "\nALL CHECKS PASSED");
process.exit(fails ? 1 : 0);
