---
title: "Kettles vs. limescale: the quiet war"
description: "Three of every four kettles that reach our bench are fine apart from the scale. Theo's field guide to the win that takes ten minutes."
date: "2026-02-03T17:00:00Z"
author: "Theo Brandt"
schema: BlogPosting
class: news
og:type: article
og:image: /news/images/kettles.svg
---

# Kettles vs. limescale: the quiet war

We see a lot of kettles. Most arrive declared dead by their owners, and most are
not dead — they are thirsty for citric acid.

## Our standing procedure

1. Unplug, always, before anything else.
2. Half a litre of water, two spoons of citric acid (white vinegar works; it
   seasons the house for a day).
3. Boil, wait, boil again. The scale comes off the element like it never signed a
   contract.
4. Only then open the base to look at the switch and the thermostat, because
   sometimes the real fault is a burnt connector — twice last month.

## What we threw away

The honest list is short: one cracked jug, one element with a hole in it, one
kettle that had clearly been used to boil something other than water. We do not
ask what.

A de-scaled kettle boils faster and uses less electricity over its life than the
new one it replaced. Bring yours to the first Saturday of March with a Saturday
coffee and watch ten minutes turn into a decade.
