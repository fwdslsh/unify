import fs from "node:fs";
import path from "node:path";

const ctxPath = process.argv[4];
const ctx = JSON.parse(fs.readFileSync(ctxPath, "utf8"));
const inv = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, "utf8"));

const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );

const posts = inv.pages
  .filter((p) => /^news\/[^/]+\.md$/.test(p.source))
  .filter((p) => p.date)
  .sort((a, b) => Date.parse(b.date) - Date.parse(a.date));

const metaOf = (p, name) => p.meta.find((m) => m.name === name)?.content ?? null;

const items = posts
  .map((p) => {
    const author = metaOf(p, "author");
    const day = new Date(p.date).toLocaleDateString("en-GB", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
    const desc = p.description ? `<p>${esc(p.description)}</p>` : "";
    return `    <li>
      <a href="/news/${path.basename(p.source, ".md")}.html">${esc(p.title)}</a>
      <span class="post-meta"><time datetime="${esc(p.date)}">${esc(day)}</time>${author ? ` · ${esc(author)}` : ""}</span>
${desc}
    </li>`;
  })
  .join("\n");

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>News</title>
<meta name="description" content="Notes from the bench: what Bellwick Repair Collective fixed, taught, and rescued this month.">
</head>
<body class="news">
<main>
<h1>News from the bench</h1>
<p>Written by the volunteers who were there, newest first. Subscribe with any
feed reader using the link at the end of every page, or the
<a href="/feed.xml">news feed</a>.</p>
<ol class="post-list">
${items}
</ol>
</main>
</body>
</html>
`;

const out = path.join(ctx.paths.generatedRoot, "news", "index.html");
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, html);
