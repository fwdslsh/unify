---
title: "Spring Saturday recap: 34 items, 29 saved"
description: "Our biggest bench day yet: a wind-up clock, six cycles, a sandwich toaster with a personal name, and five honest farewell repairs."
date: "2026-03-21T12:00:00Z"
author: "Grace Nyambe"
schema: BlogPosting
class: news
og:type: article
og:image: /news/images/spring-saturday.svg
---

# Spring Saturday recap: 34 items, 29 saved

The queue started before ten and the hall filled with the particular noise of a
sewing machine celebrating. Final tally: **34 items in, 29 saved.**

## The favourites

- **Bartholomew**, a sandwich toaster who has had a name since 1998 (owner: "he
  burns the edges, I love him"). One bent latch plate, some foil tape honesty,
  and he seals again.
- A wind-up kitchen clock whose mainspring had wound itself into a knot. Our
  horology volunteer, Ivo, said "ah" in a worried way, then fixed it anyway.
- Six bicycles, mostly cables and brakes. Two kids learned what a spanner is for.
- A record player belt from 1981, replaced from the drawer of things-too-good-to-
  bin, exact match. That drawer earns its keep.

## The five we could not save

A tumble dryer heating element (parts discontinued), two power bricks potted in
epoxy — the ones we cannot open are the ones we cannot fix — a plastic gearbox
with a melted tooth, and a "repairable" lamp whose entire body was one moulding.
We said so honestly, sorted them for scrap metals, and wrote the owners a card
about what to look for next time.

Next bench night is Tuesday as ever. Bring the thing you have already grieved
over.
