---
title: "The church hall lamp that outlived its paperwork"
description: "A 1960s brass pendant came in with no diagram and left with a new lease of life — and a lesson in tracing circuits by torchlight."
date: "2026-02-21T15:00:00Z"
author: "Ama Okafor"
schema: BlogPosting
class: news
og:type: article
og:image: /news/images/lamp-rescue.svg
---

# The church hall lamp that outlived its paperwork

Margaret from St. Cadfa's back room carried it in wrapped in a bedsheet: a brass
pendant light, older than the hall's roof, no idea what year, certainly no wiring
diagram.

## Tracing it with a torch and a multimeter

The old flex was fused to the frame and the bakelite holder had cracked clean
through. Nothing unfixable — just patient:

- Photograph everything before you touch it. We do this now on every old lamp.
- The terminals were brass on copper with a century of grime. Cleaning them made
  more difference than any new part.
- New cotton-braided flex in the same oxblood, a porcelain holder from the parts
  drawer, and a knot in the cable so the pendant hangs on the knot and never on
  the terminals.

It now sways over the tombola table, lit, and Margaret tells everyone it was
"broke for eight years and fixed in one evening". Both halves are true, and that
is the best outcome a bench can offer.
