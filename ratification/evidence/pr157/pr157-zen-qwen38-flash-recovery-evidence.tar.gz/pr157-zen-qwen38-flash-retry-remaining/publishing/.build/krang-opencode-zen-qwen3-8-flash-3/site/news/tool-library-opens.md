---
layout: /_layout.html
class: news
schema: Article
description: "Borrow a pressure washer, a tailor's dummy or a soldering iron from the new tool library — free, on a promise and a signature."
author: "Ana Petrescu"
date: "2026-03-28T18:00:00Z"
og:image: /assets/card.svg
og:image:width: 1200
og:image:height: 630
og:type: article
twitter:card: summary_large_image
---
# The tool library is open

*Written by Ana Petrescu, Saturday 28 March 2026*

The west wall of the kiln building has shelves again. The tool library is now open every Saturday,
and borrowing is free — as with everything here, it runs on neighbours signing a clipboard and
bringing things back with the fuel tank full or the blade clean.

## What's on the shelves

- A pressure washer that has already adopted three driveways
- Two tailors' dummies and a steam iron for curtain people
- Soldering irons, with a strict no-grabbing rule: they live at the bench
- Cycle stands, chain whips and a truing stand for the bikes of the estate
- A mitre box, clamps, and the good spirit level that everyone pretends not to fight over

## The promise

Sign out, sign in, tell us if it broke *while you had it* — that's the whole system. A tool that
comes back broken with an honest note gets repaired by Frank; a tool that comes back missing gets
a conversation and then a replacement, because the library belongs to the street, not the shelf.

Borrowing hours are on the [visit page](/visit.html). If you have a tool in a garage that sits
idle and could earn its keep on our wall, bring it to a Tuesday and we'll make a shelf.
