---
layout: /_layout.html
class: news
schema: Article
description: "Three clinics, thirty-one kettles, one lesson: nine out of ten are the switch, the flex or the scale."
author: "Priya Raman"
date: "2026-03-14T17:00:00Z"
og:image: /assets/card.svg
og:image:width: 1200
og:image:height: 630
og:type: article
twitter:card: summary_large_image
---
# Kettle clinic number three: nine out of ten

*Written by Priya Raman, Saturday 14 March 2026*

We ran a kettle-focused clinic for three Saturday mornings and kept a tally, because Frank insists
that anything worth fixing twice is worth counting. Thirty-one kettles came in. Twenty-eight went
home working.

## The tally board

| Fault | Kettles | The fix |
| --- | --- | --- |
| Split or chewed flex | 9 | New flex, sometimes a new plug |
| Dead on/off switch | 8 | A switch for ninety pence |
| Scale blindness | 6 | Citric acid and patience |
| Burnt element | 3 | This is the end, friend |
| Lid clip | 2 | Spare from the shelf |

Nine out of ten, said the board, were the switch, the flex or the scale. People kept apologising for
bringing "just a kettle". There is no such thing as just a kettle: it is the most-used appliance in
most of these houses.

## Safe way to fail

Every kettle that opened was unplugged first, and every element test was on the bench with the
resistances written down. If your kettle smells burnt or its base is brown, unplug it and bring it
to the Saturday bench — we have a rule that a volunteer, not the owner, gets the privilege of
looking inside those.

The next clinic is in April. Until then, the doors are open on the usual evenings, listed on the
[visit page](/visit.html).
