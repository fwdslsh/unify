# Bellwick Repair Collective — build report

## Publish command

```
./unify build --base-url https://bellwick.example/workshop/ --pretty-urls --clean --audit
```

Exit 0; `dist/` is the complete published site (13 files). The feed, sitemap,
canonical links and JSON-LD come from that command's `--base-url`; `.html`
addresses are rewritten to directory URLs by `--pretty-urls`. Config is minimal
(`unify.yaml`: `generate: scripts/gen.mjs`).

## What was built

- `site/index.html` (Home), `site/visit.html` (Visit: place, hours, what to bring),
  `site/news/*.md` — four dated Markdown posts by named volunteers, and
  `site/news/index.html` **generated** by `scripts/gen.mjs` from the source
  inventory, newest first.
- Shared chrome in `site/_layout.html`: header with inline SVG gear mark and nav,
  footer, applied to every page including the generated index (the build report
  shows each page resolved to `_layout.html`).
- `site/styles.css` self-hosted; placeholder SVGs (`assets/card.svg` share card,
  `workshop.svg`, `map.svg`). Nothing references another website (no `url()` in
  CSS; every `href`/`src` is under `https://bellwick.example/workshop/`).

## How each requirement was verified (no browser; inspection of `dist/`)

- **Pages.** `./unify build --dry-run --strict` listed every page with the
  layout it resolved to, 0 problems; `--audit` on the final build: "audit:
  nothing to report"; exit 0. `grep` showed all 7 output HTML files contain the
  gear mark and the shared footer; no output `href` ends in `.html`; no leaked
  `_*` files or scripts.
- **Preview cards.** Each post's `dist/news/<slug>/index.html` head contains
  `og:title`, `og:description`, `og:type=article`, and an **absolute**
  `og:image=https://bellwick.example/workshop/assets/card.svg` with
  `og:image:width/height` (added after the audit flagged missing dimensions),
  plus `twitter:card=summary_large_image` and `og:url` equal to the real
  published address `https://bellwick.example/workshop/news/<slug>/`. Verified
  by grep counts (1 each in all four posts).
- **Article data.** Each post has exactly one generated
  `<script type="application/ld+json">` block, `@type: Article` with headline,
  description, url (the published address), image, author and `datePublished`
  — produced by `schema: Article` frontmatter, not hand-written JSON.
- **Feed.** `dist/feed.xml` is Atom with 4 `<entry>` elements, newest first,
  each with title, absolute `<link rel="alternate">` matching the post's
  canonical, `<published>`/`<updated>`, summary and author. Verified well-formed
  with a tag-balance parser in Node (`well-formed tags: true`), and that every
  entry carries title/link/dates; `--base-url` also generated `sitemap.xml`.
  Every page ships `<link rel="alternate" type="application/atom+xml"
  href="/workshop/feed.xml">`, so readers can discover it.

## 1. What `rules.md` did not answer

The sentence I wanted and could not find was, in effect: **"unify runs the
generator with the source directory, the generated directory and a context JSON
file as its arguments."** Line 6 says only that the script "writes into the
directory unify hands it" — it never says *how* it is handed. `rules.md` also
never documents `source-pages.json`'s shape (the CLI help calls it "authored
title" but no schema), and never says whether files written into that directory
are treated as pages (layout-applied, links rewritten). I discovered
`argv = [script, srcDir, overlayDir, context.json]` and
`generator-context.json`'s `paths.generatedRoot` / `inputs.sourcePages` by
running a probe script. Related gap: the inventory's `title` is null for a post
whose title comes from its first `# Heading`, so my index shipped empty link
text until the script read the headings from the sources itself; no rule warned
that "authored title" excludes derived titles.

## 2. What I had to re-read, and why it didn't land the first time

- The opening paragraph (line 6). It packs generation, the feed, and the
  date rule into three long sentences; "a `date:` with no time is reported and
  left out rather than guessed at" only read as important once I treated the
  feed as a requirement — it pushed me to quote full ISO datetimes
  (`date: "2026-03-14T17:00:00Z"`) on every post.
- The "real filename" rule: "Always link the real filename — `/about.html`,
  not `/about/`. This stays true under `--pretty-urls`." It didn't land because
  it reads like a prohibition on pretty URLs rather than an authoring
  convention; I wrote links twice in my head before accepting that I write
  `/news/index.html` and the build turns it into `/news/`.
- The Head bullet — the title-separator rule (`<title>— My Site</title>` in the
  layout, pages write only their name) initially looked like styling advice;
  it is the mechanism that also fixes `og:title` and the JSON-LD headline.

## 3. What I guessed or inferred rather than read

- That overlay pages participate in normal page resolution (layout, link
  rewriting) — inferred from the dry-run line `news/index.html ← generated +
  _layout.html`, not stated.
- That `--base-url` making "`og:` … absolute" includes `og:image` content, and
  that an SVG (not PNG/JPG) is an acceptable share image here — the docs never
  name supported image formats; the brief's "write a placeholder SVG wherever
  one is needed" is what I relied on.
- That `twitter:card: summary_large_image` as a frontmatter key becomes
  `<meta name="twitter:card">` — inferred from "every other becomes
  `<meta name=…>`" plus "no Twitter tag is invented."
- That `generate:` in `unify.yaml` resolves relative to the config file ("beside
  the site") while the CLI `--generate` resolves from the source root — learned
  from an error message, not the documentation.
- The exact moment/date format unify "reads" for feeds — inferred it must be
  one of the two formats the schema section names; quoted-ISO-with-Z passed the
  audit, so nothing else was tested.
