---
layout: /_layout.html
class: news
schema: Article
description: "Two donated sewing machines, one long evening of belt replacements, and why the zig-zag dial always sticks."
author: "Tom Whitfield"
date: "2026-02-21T17:30:00Z"
og:image: /assets/card.svg
og:image:width: 1200
og:image:height: 630
og:type: article
twitter:card: summary_large_image
---
# Two sewing machines came back from the dead

*Written by Tom Whitfield, Saturday 21 February 2026*

A member of the public donated two domestic sewing machines when she moved out of the county:
a 1970s Singer with a stuck zig-zag dial, and a lighter plastic-bodied machine whose belt had
gone stretchy as liquorice. Both now run, and both have names.

## The Singer

Stuck dials on these machines are almost always hardened grease, not damage. Hot water, a
hair dryer from the outside, and gentle wiggling over about twenty minutes freed it. The hook
race wanted a drop of sewing oil and a very small prayer.

## The plastic one

Belts like this are cheap and rubber, and they melt into sticky loops as they age. Note to
volunteers and the public alike: the old belt will break your heart trying to get it off, and
a new one costs less than the tea you drink while fitting it. We keep three sizes on the
spares shelf now.

## Come sew

Machines are on the Thursday bench. Bring your own if you have one that hesitates, or use ours
to fix something that has been waiting in a cupboard for years. Hours and directions are on the
[visit page](/visit.html).
