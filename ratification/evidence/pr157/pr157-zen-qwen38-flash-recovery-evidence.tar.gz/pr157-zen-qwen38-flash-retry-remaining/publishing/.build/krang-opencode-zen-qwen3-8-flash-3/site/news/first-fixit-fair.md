---
layout: /_layout.html
class: news
schema: Article
description: "We opened the doors for the first time on a rainy Saturday — 41 visitors, 26 repairs, one very lucky kettle."
author: "Marisol Vega"
date: "2026-01-31T18:00:00Z"
og:image: /assets/card.svg
og:image:width: 1200
og:image:height: 630
og:type: article
twitter:card: summary_large_image
---
# Our first Fix-It Fair was a wet and successful disaster

*Written by Marisol Vega, Saturday 31 January 2026*

The turnout for the first Fix-It Fair at the old kiln building exceeded every plan we had made while
drinking tea. Forty-one people came through the gate; twenty-six broken things left working.

The hall smelled of solder and damp wool within minutes. Dev mended twelve zip pullers in a row,
while Priya explained to three different people that yes, the toaster *can* be opened, and no,
we will not be doing that to the one that is still plugged in.

## The kettle of honour

One kettle had been to two shops and a "repair man" who charged forty pounds to look at it and
say nothing. Our Frank, who retired from boiler-making in 1991, found a £1.50 thermostat in four
minutes. Its owner cried a little. We all pretended not to notice, and handed her a biscuit.

## What we learned

- People want to *watch* the repair, not just receive it back. The bench facing the room was the
  best mistake we made all month.
- We need more multimeters and a sign saying where the breaker box is.
- Sums of money are not part of this. A cake tin came round for the electricity bill; it paid it twice.

If you missed it, the workshop is open every Tuesday, Thursday and Saturday — see
[when to visit](/visit.html). More news as it happens in the [news index](/news/index.html).
