import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';

const [, , srcDir, generatedRoot, contextPath] = process.argv;
const context = JSON.parse(readFileSync(contextPath, 'utf8'));
const outDir = context.paths?.generatedRoot ?? generatedRoot;
const srcRoot = context.paths?.sourceRoot ?? srcDir;

const inventory = JSON.parse(readFileSync(context.inputs.sourcePages, 'utf8'));

const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
  'August', 'September', 'October', 'November', 'December'];

function esc(s) {
  return String(s ?? '')
    .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

function posted(date) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(date);
  if (!m) return esc(date);
  return `${Number(m[3])} ${months[Number(m[2]) - 1]} ${m[1]}`;
}

function titled(p) {
  if (p.title) return p.title;
  const m = /^#\s+(.+?)\s*$/m.exec(readFileSync(join(srcRoot, p.source), 'utf8'));
  return m ? m[1] : p.href;
}

const posts = inventory.pages
  .filter((p) => p.source.startsWith('news/') && p.date
    && (p.meta || []).some((m) => m.name === 'schema'))
  .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));

const items = posts.map((p) => `        <li>
          <a class="post-link" href="${esc(p.href)}">${esc(titled(p))}</a>
          <time datetime="${esc(p.date)}">${posted(p.date)}</time>
          ${p.description ? `<p>${esc(p.description)}</p>` : ''}
        </li>`).join('\n');

const html = `<!doctype html>
<html lang="en" data-layout="/_layout.html">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>News</title>
<meta name="description" content="Everything that has been happening at the Bellwick Repair Collective workshop, newest first.">
</head>
<body class="news">
<main>
      <h1>News</h1>
      <p>Written by the volunteers between repairs, newest first. Subscribe with any feed reader:
      <a href="/feed.xml">the Atom feed</a>.</p>
      <ul class="post-list">
${items}
      </ul>
</main>
</body>
</html>
`;

mkdirSync(join(outDir, 'news'), { recursive: true });
writeFileSync(join(outDir, 'news', 'index.html'), html);
