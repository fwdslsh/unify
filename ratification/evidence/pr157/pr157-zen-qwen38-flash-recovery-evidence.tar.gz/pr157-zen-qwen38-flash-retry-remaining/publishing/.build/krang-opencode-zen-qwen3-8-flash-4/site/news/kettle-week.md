---
title: "Kettle week: 90 kettles, 61 saved"
date: 2026-11-08T10:00:00Z
author: Bess Whitlock
description: "Our biggest week so far — and the quiet hero of it all is the two-pound thermostat disc."
schema: BlogPosting
og:image: /assets/card.svg
og:image:width: 1200
og:image:height: 630
class: post
---
# Kettle week: 90 kettles, 61 saved

Kettle week came and went: ninety kettles on the bench, sixty-one boiling
again, nine adopted as parts donors, and the rest — honest numbers — beyond
a volunteer's reach.

## What saved most of them

Nearly every survivor came down to one of two parts: a limescale-fouled
thermostat disc, or a boiled split in the handle mount that epoxy and a
self-tapping screw fixed for good. We replaced exactly zero heating elements,
continuing the tradition begun by the toasters.

## What we learned

- Bring your descaling solution, or we will make you use vinegar and watch
  you wince.
- Cordless kettles are not cord-free; the base has a cord, and it fails.
- Six people came to watch and left having reassembled a kettle themselves.
  That is the whole point.

Many thanks to the eleven volunteers who ran the bench. Next mini-event:
zip pulls and toggles, first Saturday of December.
