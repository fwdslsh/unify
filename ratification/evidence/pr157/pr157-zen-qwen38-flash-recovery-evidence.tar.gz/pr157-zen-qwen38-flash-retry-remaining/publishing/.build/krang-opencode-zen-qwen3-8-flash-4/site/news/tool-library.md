---
title: "The tool library needs lenders"
date: 2026-11-03T17:00:00Z
author: Priya Nandakumar
description: "Our loan shelf is nearly empty. If a tool sits in your shed collecting dust, it could be fixing a chair across town instead."
schema: BlogPosting
og:image: /assets/card.svg
og:image:width: 1200
og:image:height: 630
class: post
---
# The tool library needs lenders

The collective runs a small tool library: you hand over a membership card,
borrow a tool for a week, and bring it back oiled. It only works if the shelf
stays full, and this month the shelf is nearly bare.

## Tools we are short of right now

- orbital sanders and a bench belt sander
- a plumbing snake long enough for outdoor drains
- a sewing machine that can handle denim
- an oil can, any oil can, donated with love

## How lending works

Bring the tool to a Wednesday or Saturday session. We label it, log it, and
insure it under the collective — and if your precious sander dies of old age
in somebody else's hands, we will find its wake, not your bill. Lenders get
first call on everything else on the shelf.
