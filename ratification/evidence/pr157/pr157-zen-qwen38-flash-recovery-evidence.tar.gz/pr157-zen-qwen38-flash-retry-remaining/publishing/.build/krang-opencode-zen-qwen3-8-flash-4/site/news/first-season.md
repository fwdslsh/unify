---
title: "Our first mending season is open"
date: 2026-10-07T09:00:00Z
author: Miriam Osei
description: "Forty of us signed up, we found a hall, and Bellwick Repair Collective now has a home at 12 Foundry Lane."
schema: BlogPosting
og:image: /assets/card.svg
og:image:width: 1200
og:image:height: 630
class: post
---
# Our first mending season is open

Six months ago eleven neighbours met in a kitchen to fix a single bread machine.
Last Saturday that crowd had a name — the Bellwick Repair Collective — and a
hall of our own at 12 Foundry Lane.

## What we fixed on opening day

- a bread machine with a seized dough spindle, now baking again
- nine lamps (two were never broken; the plug was wired backwards)
- a child's bicycle, a cardigan with a moth-eaten elbow, and one stubborn kettle

## Come and help

We are always looking for volunteers — not just people who can solder. Kettle
week needs a kettle person; everything else needs people willing to sit at a
bench and look at a thing closely. Sign up at the desk on a Wednesday or
Saturday, or bring a biscuit and offer to make tea. That counts too.
