---
title: "The toaster autopsy: what actually kills them"
date: 2026-10-18T18:30:00Z
author: Tomas Reinholt
description: "We opened eleven dead toasters to find the same three faults over and over. None of them are the heating element."
schema: BlogPosting
og:image: /assets/card.svg
og:image:width: 1200
og:image:height: 630
class: post
---
# The toaster autopsy: what actually kills them

We now keep a shelf of dead toasters until someone adopts them back. Last
week, instead of letting them wait, we opened eleven of them on camera-free
Saturday and took notes.

## The three recurring faults

1. **Crumbs fused under the elements.** Unplug, turn upside down, shake, repeat
   until what comes out stops looking like soil.
2. **The high-limit thermal fuse.** A five-cent part; test it with continuity,
   and if it is open, that is your whole repair.
3. **Levers that slip because a plastic latch has warped,** not because the
   magnet has failed. Sometimes a new latch; sometimes the old one turned
   around.

If your toaster pops early or never pops at all, bring it on Saturday. Bring
the cord too — three of the eleven were guilty power cords, not guilty toasters.
