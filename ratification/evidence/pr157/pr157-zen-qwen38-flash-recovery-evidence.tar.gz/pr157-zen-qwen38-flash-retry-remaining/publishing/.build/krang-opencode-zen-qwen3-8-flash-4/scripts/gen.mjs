import fs from 'node:fs';
import path from 'node:path';

const [,, srcRoot, overlay, ctxPath] = process.argv;
const ctx = JSON.parse(fs.readFileSync(ctxPath, 'utf8'));
const inv = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, 'utf8'));

const getMeta = (page, name) =>
  (page.meta || []).find(m => m.name === name)?.content ?? null;

const posts = inv.pages
  .filter(p => /^news\/.+\.md$/.test(p.source))
  .map(p => ({
    slug: p.source.replace(/^news\//, '').replace(/\.md$/, ''),
    title: p.title || p.source,
    description: p.description || getMeta(p, 'description'),
    date: p.date || getMeta(p, 'date'),
    author: getMeta(p, 'author'),
  }))
  .filter(p => p.date && !Number.isNaN(Date.parse(p.date)))
  .sort((a, b) => Date.parse(b.date) - Date.parse(a.date));

if (!posts.length) throw new Error('no dated news posts found in source inventory');

const esc = s => String(s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const fmt = iso => {
  const d = new Date(iso);
  return `${d.getUTCDate()} ${d.toLocaleString('en-GB', { month: 'long', timeZone: 'UTC' })} ${d.getUTCFullYear()}`;
};

const items = posts.map(p => `      <li>
        <h2><a href="/news/${p.slug}.html">${esc(p.title)}</a></h2>
        <time datetime="${esc(p.date)}">${esc(fmt(p.date))}</time>${p.author ? ` — ${esc(p.author)}` : ''}
        ${p.description ? `<p>${esc(p.description)}</p>` : ''}
      </li>`).join('\n');

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>News</title>
<meta name="description" content="News from the Bellwick Repair Collective: mends, events and calls for volunteer help.">
</head>
<body class="news">
<main>
  <h1>News</h1>
  <p>What came off the bench, and what we need next. Newest first.
  Subscribe with any feed reader: <a href="/feed.xml">Atom feed</a>.</p>
  <ol class="post-list">
${items}
  </ol>
</main>
</body>
</html>
`;

fs.mkdirSync(path.join(overlay, 'news'), { recursive: true });
fs.writeFileSync(path.join(overlay, 'news', 'index.html'), html);
console.log(`gen.mjs: wrote news/index.html with ${posts.length} posts (newest first)`);
