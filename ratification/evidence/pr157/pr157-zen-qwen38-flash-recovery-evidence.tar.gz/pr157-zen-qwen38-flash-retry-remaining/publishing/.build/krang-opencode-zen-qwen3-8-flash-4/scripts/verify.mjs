import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';

const DIST = path.resolve('dist');
const BASE = '/workshop';

const server = http.createServer((req, res) => {
  let rel = decodeURIComponent(req.url.split('?')[0]);
  if (!rel.startsWith(BASE + '/') && rel !== BASE) { res.writeHead(404); res.end('outside mount'); return; }
  rel = rel.slice(BASE.length) || '/';
  let p = path.join(DIST, rel);
  if (p.endsWith('/')) p = path.join(p, 'index.html');
  if (!fs.existsSync(p) && fs.existsSync(p + '.html')) p += '.html';
  if (!fs.existsSync(p) || !fs.statSync(p).isFile()) { res.writeHead(404); res.end('not found'); return; }
  const type = { '.html': 'text/html', '.css': 'text/css', '.svg': 'image/svg+xml', '.xml': 'application/atom+xml' }[path.extname(p)] || 'application/octet-stream';
  res.writeHead(200, { 'content-type': type });
  res.end(fs.readFileSync(p));
});
await new Promise(r => server.listen(0, '127.0.0.1', r));
const origin = `http://127.0.0.1:${server.address().port}`;

const problems = [];
const ok = [];
const check = (cond, msg) => { (cond ? ok : problems).push(msg); };

const seen = new Set();
const queue = [BASE + '/'];
while (queue.length) {
  const url = queue.shift();
  if (seen.has(url)) continue;
  seen.add(url);
  const res = await fetch(origin + url);
  check(res.status === 200, `GET ${url} -> ${res.status}`);
  if (res.status !== 200) continue;
  const body = await res.text();
  if (res.headers.get('content-type')?.includes('html')) {
    check(!/href="\/(?!workshop\/)/.test(body) && !/src="\/(?!workshop\/)/.test(body),
      `${url}: every root-relative href/src carries the /workshop/ prefix`);
    for (const m of body.matchAll(/(?:href|src)="(\/workshop\/[^"#?]*)"/g)) queue.push(m[1]);
    for (const m of body.matchAll(/(?:href|src)="https:\/\/bellwick\.example(\/[^"]*)"/g)) queue.push(m[1].startsWith(BASE) ? m[1] : '/OUT-OF-PREFIX' + m[1]);
  }
  if (/\/news\/(first-season|toaster-autopsy|tool-library|kettle-week)\/$/.test(url)) {
    const $ = re => body.match(re)?.[1];
    check(!!$('property="og:title" content="([^"]+)"'), `${url}: og:title present`);
    check(!!/property="og:image" content="https:\/\/bellwick\.example\/workshop\/[^"]+\.svg"/.test(body), `${url}: og:image absolute at published host`);
    check(!!/property="og:description" content="[^"]+"/.test(body), `${url}: og:description present`);
    check(!!/property="og:url" content="https:\/\/bellwick\.example\/workshop\/news\/[a-z-]+\/"/.test(body), `${url}: og:url = published address`);
    const ld = body.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/);
    let j = null;
    try { j = JSON.parse(ld[1]); } catch {}
    check(j?.['@type'] === 'BlogPosting', `${url}: JSON-LD parses, @type BlogPosting`);
    check(!!j?.headline && !!j?.description && !!j?.author && !!j?.datePublished && !!j?.url && !!j?.image, `${url}: article data has headline/description/author/datePublished/url/image`);
    check(j?.url === `https://bellwick.example${url}`, `${url}: JSON-LD url is the published address`);
  }
}

const feed = await (await fetch(origin + BASE + '/feed.xml')).text();
const entries = feed.match(/<entry>[\s\S]*?<\/entry>/g) || [];
check(entries.length === 4, `feed: 4 entries (got ${entries.length})`);
for (const [i, e] of entries.entries()) {
  const t = e.match(/<title>([^<]+)<\/title>/)?.[1];
  const l = e.match(/<link rel="alternate" href="([^"]+)"/)?.[1];
  const d = e.match(/<published>([^<]+)<\/published>/)?.[1];
  check(t && l && d, `feed entry ${i + 1}: title + address + published (${t?.slice(0, 40)}… @ ${l} on ${d})`);
  check(/^https:\/\/bellwick\.example\/workshop\/news\/.+\/$/.test(l), `feed entry ${i + 1}: absolute address at published host`);
}
const sm = await (await fetch(origin + BASE + '/sitemap.xml')).text();
check(/https:\/\/bellwick\.example\/workshop\/news\/kettle-week\//.test(sm), 'sitemap lists posts at published address');

server.close();
console.log(`PASS ${ok.length}`);
for (const p of problems) console.log('FAIL ' + p);
process.exit(problems.length ? 1 : 0);
