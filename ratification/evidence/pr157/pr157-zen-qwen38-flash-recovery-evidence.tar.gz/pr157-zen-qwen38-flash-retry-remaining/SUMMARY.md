# Ratification round pr157-zen-qwen38-flash-retry-remaining

- **unify** 0.11.18 at `83bc115168cb` (working tree)
- **rules** `fb07d931bd36` · **prompt** `456131468750` · **agent** opencode 1.18.25 · **models** krang/opencode-zen/qwen3.8-flash · **isolation** mount namespace, probe clean
- 2026-11-09T00:41:33.339Z; scored 2026-11-09T00:56:17.984Z

## Score

**11 of 15 samples completed their brief: every scored check passed (73%).**

The protocol's bar, at least 4 of 5 samples of a model on each brief: **not met**.

| Brief | Model | Passed | Checks that failed |
|---|---|---|---|
| publishing | krang/opencode-zen/qwen3.8-flash | 4/5 | agent-finished (1) |
| seed-catalogue | krang/opencode-zen/qwen3.8-flash | 3/5 | strict-build (2) |
| svelte-estimator | krang/opencode-zen/qwen3.8-flash | 4/5 | strict-build (1), fresh-build (1), addresses (1), drafts-unpublished (1) |

## publishing — Publishing surface: schema:, og: share cards, dated posts, a feed, a subpath

*round 27, re-run unchanged in round 29; checks follow round 27's pre-registered V1-V5.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | feed | article-data | share-cards | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 6m30s | 47 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | 7m33s | 42 | $0.00 | ✗ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | fail |
| krang-opencode-zen-qwen3-8-flash-3 | 6m07s | 41 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-4 | 5m35s | 34 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-5 | 5m32s | 31 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |

- krang-opencode-zen-qwen3-8-flash-2 · **agent-finished**: exit 1, agent error: The user has specified a rule which prevents you from using this specific tool call. Here are some of the relevant rules [{"permission":"*","action":"allow","pattern":"*"},{"permission":"doom_loop","action":"ask","pattern":"*"},{"permission":"doom_loop","action":"deny","pattern":"*"}], wrote REPORT.md

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> ## 1. What `rules.md` did not answer
> 
> The sentence I wanted and could not find: **"unify runs the generate script as
> `node <script> <sourceRoot> <overlayDir> <contextFile>`, the context file names
> `source-pages.json`, and files written into the overlay are composed like source pages."**
> rules.md says the script "writes into the directory unify hands it" and never says *how* it
> is handed, in which argument, that a context JSON exists at all, what `source-pages.json`
> contains, or whether a generated file gets the layout applied. I discovered all of that by
> running throwaway probes that printed `process.argv`, the context file, and the inventory.
> Two smaller gaps: `--source-inventory`/`source-pages.json` and `sitemap.xml` exist only in
> `./unify --help`, not in the rules; and nothing says a Markdown post must write its own
> `# heading` — a page's `title:` does **not** emit an `<h1>` (the audit's `h1-missing`

**krang-opencode-zen-qwen3-8-flash-2**

> **1. What rules.md did not answer — the sentence I wanted and could not find.**
> rules.md says the generator script "writes into the directory unify hands it" but never
> says *how* the directory is handed over, nor how the script learns what the posts are.
> The sentence I wanted — "the script is invoked as
> `process.argv = [source root, generated directory, context JSON path]`" — does not
> exist. I found it by writing a throwaway probe that dumped `process.argv` and reading
> the `generator-context.json` it names. The context file's `inputs.sourcePages` pointer
> to `source-pages.json` (the per-page title/date/meta inventory I built the index from)
> is not mentioned in rules.md at all — only `--help` says it is "on by default with
> --generate". rules.md also never states whether files the generator writes get the
> layout wrapped around them; I had to believe the dry-run report line
> `dist/news/index.html ← generated + _layout.html`.

**krang-opencode-zen-qwen3-8-flash-3**

> ## 1. What `rules.md` did not answer
> 
> The sentence I wanted and could not find was, in effect: **"unify runs the
> generator with the source directory, the generated directory and a context JSON
> file as its arguments."** Line 6 says only that the script "writes into the
> directory unify hands it" — it never says *how* it is handed. `rules.md` also
> never documents `source-pages.json`'s shape (the CLI help calls it "authored
> title" but no schema), and never says whether files written into that directory
> are treated as pages (layout-applied, links rewritten). I discovered
> `argv = [script, srcDir, overlayDir, context.json]` and
> `generator-context.json`'s `paths.generatedRoot` / `inputs.sourcePages` by
> running a probe script. Related gap: the inventory's `title` is null for a post

**krang-opencode-zen-qwen3-8-flash-4**

> ### 1. What `rules.md` did not answer
> 
> The sentence I wanted and could not find: **how the generator script is invoked — what
> arguments, what working directory, and how it is handed "the directory unify hands it" —
> and where `source-pages.json` lives.** Line 6 says a derived index comes from "a script
> you write… and it writes into the directory unify hands it", full stop. I only learned the
> answer by writing a probe generator that dumped `process.argv`/`process.cwd`: it is called
> with (source root, overlay dir, context JSON), the context JSON points at
> `source-pages.json`, and files written into the overlay ship as if authored (the layout
> wraps them). `source-pages.json` itself appears nowhere in `rules.md` — only in
> `--help`. Other gaps: `rules.md` never mentions `sitemap.xml` (the help does), never says
> `--canonical` defaults to `auto` under `--base-url` (I needed that for canonical/og:url),

**krang-opencode-zen-qwen3-8-flash-5**

> ## 1. What `rules.md` did not answer
> 
> The sentence I wanted and could not find: **how the generator is "handed" its directory, and
> whether files the script writes are treated as source pages.** The rules say "it writes into
> the directory unify hands it, never into `site/`" — but never say it is handed as `argv[3]`
> (next to `argv[2]` = source root and `argv[4]` = `generator-context.json`), never mention
> that a `generator-context.json` or `source-pages.json` exists at all (that is `--help` and
> `--source-inventory` territory), and never state whether an `index.html` written into the
> overlay gets layout wrapping and link rewriting or ships verbatim. A probe script that dumped
> `process.argv` plus a line in the dry-run report (`← generated + _layout.html`) settled both.
> Related gaps: the rules' example `generate: scripts/gen.mjs` reads as project-root-relative
> while the CLI says `--generate` paths are "from the source root" — in practice the YAML


## seed-catalogue — A 225-variety catalogue generated from a JSON export, fetched one family at a time

*round 20; the judge's default marker and privacy fields are this brief's.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-and-export-unpublished | private-data | variety-pages | fetch-targets | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 8m03s | 40 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | — | 59 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-3 | — | 41 | $0.00 | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | fail |
| krang-opencode-zen-qwen3-8-flash-4 | — | 46 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-5 | — | 44 | $0.00 | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | fail |

- krang-opencode-zen-qwen3-8-flash-1 · **fetch-targets** (not scored): 0 of 0 resolved, 0 built at runtime (no base URL (none in config, none in the command) — skipped)
- krang-opencode-zen-qwen3-8-flash-2 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-opencode-zen-qwen3-8-flash-3 · **strict-build**: exit 1: 0 problems, 0 advisories
- krang-opencode-zen-qwen3-8-flash-3 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-opencode-zen-qwen3-8-flash-4 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-opencode-zen-qwen3-8-flash-5 · **strict-build**: exit 1: 0 problems, 0 advisories — gen: 225 variety pages, 12 family fragments, browse page (base "/library/", pretty true)
- krang-opencode-zen-qwen3-8-flash-5 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> ## What `rules.md` did not answer
> 
> - **Whether a `.fragment.html` file's links get rewritten.** The file rules say a
>   fragment is "shipped as written"; the finishing section says the build "rewrites
>   only HTML's own URL attributes (`href`, `src`)" — and also that "`fetch()`/`hx-get`
>   address[es] ship as written". The sentence I wanted and could not find is the
>   tie-breaker: *do `--base-url`/`--pretty-urls` rewrite `<a href>` inside a fragment,
>   or does "as written" win?* I tested it: as written wins — a fragment in `dist/`
>   still carried `/variety/nine-star-pea-1.html`, no prefix, no pretty form. That
>   decided the architecture: the family lists ship as real generated pages
>   (rewritten by the build like everything else), and `browse.js` fetches the page
>   and injects its `<main>` — so only that family's varieties arrive, at URLs that

**krang-opencode-zen-qwen3-8-flash-2**

> ## What `rules.md` did not answer
> 
> - **How the generator is invoked.** The rules say the script "writes into the
>   directory unify hands it" but never say what it is handed. The sentence I
>   wanted: *what argv does a `--generate` script receive?* I discovered by
>   printing: `[unify, script, sourceRoot, generatedRoot, generator-context.json]`
>   — after a first attempt wrote straight into `site/` because I guessed argv[2].
> - **Whether "shipped as written" for fragments also exempts them from
>   rewriting and from link resolution.** Line 57 says unify "rewrites only
>   HTML's own URL attributes" and line 10 says fragments ship "as written" — but
>   nowhere states that the `href`s *inside a fragment* keep the exact bytes the
>   generator wrote and are not rewritten by `--base-url`. I learned it by

**krang-opencode-zen-qwen3-8-flash-3**

> ## What `rules.md` did not answer
> 
> **The sentence I wanted and could not find: how the `--generate` script is invoked.** The
> docs say "unify runs it before every build and it writes into the directory unify hands
> it" — but never *how the directory is handed over*: no documented argv order, working
> directory, or context file. I found it by running a probe script that dumped
> `process.argv`: it is `node <script> <sourceRoot> <generatedRoot> <context.json>`, cwd =
> the source root, and the fourth argument is a JSON file containing `paths`, `site`
> (including `baseUrl` and `prettyUrls`) and the source-pages inventory. Nothing in the
> documentation mentions that context file except the `--source-inventory` flag line.
> 
> Related unanswered questions I resolved only by building a probe site:

**krang-opencode-zen-qwen3-8-flash-4**

> ## What `rules.md` did not answer
> 
> The sentence I wanted and could not find: **what happens to files the generate script writes
> into the directory it is handed.** The docs say a script exists, runs before every build, and
> "writes into the directory unify hands it" — but never say that those files are composed like
> normal source pages. I had to test it: overlay pages pick up the root `_layout.html` (two
> levels deep), get `--pretty-urls` and `--base-url` rewriting, canonicals and sitemap entries.
> Related gaps: *which* argument is that directory (I guessed argv[2] — the source root — and
> the script wrote into `site/`, the one place the docs forbid; the contract turns out to be
> `[unify, script, sourceRoot, generatedRoot, generatorContext.json]`); and the
> generator-context.json inventory, which the docs only hint at via `--source-inventory`
> ("on by default with `--generate`") without saying where that file is — argv[4], with

**krang-opencode-zen-qwen3-8-flash-5**

> ## What `rules.md` did not answer
> 
> The sentence I wanted and could not find, in order of how much it cost me:
> 
> - **How the `generate:` script is actually invoked.** `rules.md` says it "writes into the
>   directory unify hands it" — but never says *what it is handed*: the working directory,
>   the argument order (source root, generated root, context path), or that
>   `generator-context.json` contains `baseUrl`/`prettyUrls`/`sourcePages`. I learned all of
>   that by running a probe script that printed `process.argv` and dumped the context file.
>   A sentence like "unify runs `node <script> <source-root> <generated-root> <context.json>`
>   from the source root" would have saved the whole first experiment.
> - **Whether the contents of the generated directory get the same treatment as source files.**


## svelte-estimator — A Svelte component compiled to a browser asset by one repeatable command

*round 24 (round 25 re-ran it with docs/integrations.md seeded); needs the npm registry.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-unpublished | Result |
|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | — | 50 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | — | 74 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-3 | — | 50 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-opencode-zen-qwen3-8-flash-4 | — | 53 | $0.00 | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-opencode-zen-qwen3-8-flash-5 | — | 53 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |

- krang-opencode-zen-qwen3-8-flash-4 · **strict-build**: exit 1: 1 problems, 0 advisories — site/scripts/gen.mjs: problem: --generate scripts/gen.mjs failed (exit 1): error: Module not found "/tmp/sandbox/site/scripts/gen.mjs"
- krang-opencode-zen-qwen3-8-flash-4 · **fresh-build**: publish command could not be rebuilt
- krang-opencode-zen-qwen3-8-flash-4 · **addresses**: no build output
- krang-opencode-zen-qwen3-8-flash-4 · **drafts-unpublished**: no build output

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> ## What `rules.md` did not answer
> 
> The generator-script contract. rules.md says the script "writes into the directory unify hands
> it" — the sentence I wanted and could not find is **how it is handed over**. Nothing in
> rules.md; the CLI help doesn't say either. I found it only by making a script dump
> `process.argv`: `[unify, script, sourceRoot, generatedRoot, generator-context.json]`, and the
> context JSON reveals `paths`, `site` options and `inputs.sourcePages`. The second clue was
> unify's error message, which prints `BUN_BE_BUN=1 unify scripts/gen.mjs` — so generators run
> under Bun, which is nowhere stated; that's why `gen.mjs` stays runtime-agnostic and spawns
> `node` explicitly for the esbuild/svelte step.
> 
> Also unanswered:

**krang-opencode-zen-qwen3-8-flash-2**

> ## What `rules.md` did not answer
> 
> **The generator's invocation contract.** The docs say "unify runs it before every build and it
> writes into the directory unify hands it" — but never *how the hand is given*. There is no
> documented argv order, no documented context file, and no documented cwd. I had to write a
> probe generator that printed `process.argv` and the file unify passes it
> (`<generator-context.json>`, which names `generatedRoot`, the source inventory path, and the
> effective `baseUrl`/`prettyUrls`) to learn: `unify <script.mjs> <sourceRoot> <generatedOverlay>
> <context.json>`, cwd = source root, run by unify's own runtime (so the generator itself must
> stay plain Node — I shell out to `node` for the Svelte/esbuild step rather than import them
> under whatever runtime unify uses).

**krang-opencode-zen-qwen3-8-flash-3**

> ## 4. What `rules.md` did not answer
> 
> - **What happens to the directory the generator writes into.** The one sentence I wanted and
>   could not find: *"the generated directory is composed as if it were source files under the
>   source root."* Rules only say the script "writes into the directory unify hands it, never
>   into `site/`" — not that those files get wrapped by the site's `_layout.html`, rewritten
>   under `--pretty-urls`, prefixed by `--base-url`, or that assets placed there are copied
>   like source assets. All of that was true, and all of it I had to discover with probe
>   builds.
> - **How the generator is handed anything.** Nothing in `rules.md` says the script receives
>   the generated directory and a `generator-context.json` (with `inputs.sourcePages` pointing
>   at the inventory) as `process.argv[3]`/`argv[4]`. `--help` hints "give that file

**krang-opencode-zen-qwen3-8-flash-4**

> ## What `rules.md` did not answer
> 
> The sentences I looked for and could not find:

**krang-opencode-zen-qwen3-8-flash-5**

> ## What `rules.md` did not answer
> 
> - It never says **how the generate script receives the "directory unify hands it"** —
>   not as argv, not as env, just "it writes into the directory". I discovered by running
>   one: `argv[2]` = source root, `argv[3]` = a generated *overlay* directory, `argv[4]` =
>   a context JSON whose `inputs.sourcePages` points at the inventory. The sentence I
>   wanted and could not find: *"The generate script is called with the source root, the
>   generated overlay directory and a context file as its arguments."*
> - It does not say that **files written into the overlay get the full treatment** — layout,
>   `--base-url` prefixing, `--pretty-urls` — though everything works that way. I inferred
>   it from "Derived files (a post index)", then tested it before relying on it.
> - The **shape of `source-pages.json`** is undocumented (keys `source/href/title/date/…`),


---

`✓` passed, `✗` failed, `(i)` reported but not scored. Each sample's directory is `<brief>/<sample>/`, its OpenCode event stream and session data are in `<brief>/.harness/<sample>/`, and the build the checks read is `<brief>/.build/<sample>/`. Triage every failure with ratification/ratification-protocol.md before changing anything.
