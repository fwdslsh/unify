# Ratification round pr157-zen-qwen38-flash-retry-council

- **unify** 0.11.18 at `83bc115168cb` (working tree)
- **rules** `fb07d931bd36` · **prompt** `456131468750` · **agent** opencode 1.18.25 · **models** krang/opencode-zen/qwen3.8-flash · **isolation** mount namespace, probe clean
- 2026-11-09T00:39:52.649Z to 2026-11-09T00:51:01.320Z; scored 2026-11-09T00:51:01.321Z

## Score

**3 of 3 samples completed their brief: every scored check passed (100%).**

The protocol's bar, at least 4 of 5 samples of a model on each brief: not measured: the bar needs at least 5 samples per brief and model, so this score is indicative.

| Brief | Model | Passed | Checks that failed |
|---|---|---|---|
| council-panel | krang/opencode-zen/qwen3.8-flash | 3/3 | — |

## council-panel — A bare opening-hours panel another site fetches, kept in one place, and month lists fetched on demand

*round 23, the first exposure of *.fragment.html.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-unpublished | bare-fragment | fetch-targets | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-opencode-zen-qwen3-8-flash-1 | 6m27s | 35 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-2 | 10m48s | 50 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-opencode-zen-qwen3-8-flash-3 | 8m40s | 51 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |

- krang-opencode-zen-qwen3-8-flash-1 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-opencode-zen-qwen3-8-flash-2 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-opencode-zen-qwen3-8-flash-3 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime

What the agents said the rules did not answer:

**krang-opencode-zen-qwen3-8-flash-1**

> ## 3. What `rules.md` did not answer
> 
> The **URL a `.fragment.html` ends up at under `--pretty-urls`**. The doc says
> fragments are "shipped as written" and separately that pretty-urls rewrites
> `about.html` → `about/` — it never says whether the pretty treatment is *exempt*
> for fragments, and the "no `.html` addresses" rule then becomes a judgement call.
> The sentence I wanted and could not find, in words close to: *"fragments are not
> pretty-ised; their served address keeps the `.fragment.html` suffix."* I learned
> it only by building: the report line is `copy dist/hours.fragment.html
> (/mill/hours.fragment.html) ← generated`. I read the brief's "addresses visitors
> see" as scoping the no-`.html` rule to human navigation, which leaves the two
> machine addresses (the council's fetch, the JS month lists) legally `.html`.

**krang-opencode-zen-qwen3-8-flash-2**

> ## What `rules.md` did not answer
> 
> - **The generate script's whole interface.** The docs say only "it writes into the directory unify
>   hands it". They never say how the script learns which directory that is or where the inventory is.
>   The sentence I wanted, and could not find: *"the script is invoked as
>   `… gen.mjs <sourceRoot> <generatedDir> <generator-context.json>` and the context names
>   `inputs.sourcePages`."* I probed with a throwaway script that printed `process.argv` and the
>   context file.
> - **Whether the generated overlay is composed or merely copied.** "Writes into the directory unify
>   hands it" is silent on what happens to those files next. They are composed as sources — layout,
>   base-url rewriting, pretty-urls — which is what makes a script-generated *index page* sane. I
>   found this by experiment, and it changed my design (the index is a plain page with authored links,

**krang-opencode-zen-qwen3-8-flash-3**

> ## What rules.md did not answer
> 
> - **The generator's calling contract.** The sentence I wanted — and there is none — is one that
>   says *how* `generate:` runs the script. I only learned by probing: unify runs it as
>   `node scripts/gen.mjs <sourceRoot> <generatedOverlayDir> <generator-context.json>` with cwd
>   = source root, hands paths absolutely, runs it before every build (including `--dry-run` and
>   `audit`), and files written into the overlay participate in the build *as if they were sources*
>   (layout applied, links rewritten). Rules says only "it writes into the directory unify hands
>   it" — which directory that is, and what a file written there becomes, you must discover.
> - **Whether `--pretty-urls` touches fragment paths.** "Every file … copies byte-for-byte to the
>   same path" plus the fragment definition implies `/mill/hours.fragment.html` stays exactly that,
>   but I wanted the explicit "a `.fragment.html` name keeps its `.html` suffix under


---

`✓` passed, `✗` failed, `(i)` reported but not scored. Each sample's directory is `<brief>/<sample>/`, its OpenCode event stream and session data are in `<brief>/.harness/<sample>/`, and the build the checks read is `<brief>/.build/<sample>/`. Triage every failure with ratification/ratification-protocol.md before changing anything.
