const base = 'http://127.0.0.1:8787';
const get = async (p) => {
  const r = await fetch(base + p, { redirect: 'manual' });
  return { status: r.status, body: r.status < 500 ? await r.text() : '' };
};
const checks = [];
const ok = (name, pass, detail = '') => checks.push([pass ? 'PASS' : 'FAIL', name, detail]);

const home = await get('/mill/');
ok('home 200 at /mill/', home.status === 200);
const visit = await get('/mill/visit/');
ok('visit 200 at /mill/visit/', visit.status === 200);
ok('visit.html is not a page URL', (await get('/mill/visit.html')).status === 404);
const idx = await get('/mill/milling/');
ok('milling index 200 at /mill/milling/', idx.status === 200);

const notes = [
  'first-grind-of-winter-wheat', 'sails-down-for-the-stock-inspection',
  'a-wet-saturday-and-a-dry-kiln', 'harvest-thanksgiving-under-the-sails',
];
for (const n of notes) ok(`note /mill/milling/${n}/ 200`, (await get(`/mill/milling/${n}/`)).status === 200);

// index: newest first
const order = [...idx.body.matchAll(/datetime="([^"]+)"/g)].map((m) => m[1]);
ok('index lists 4 notes', order.length === 4, order.join(' '));
ok('index newest first', order.join() === [...order].sort().reverse().join());

// chrome shared on every page
for (const [name, page] of Object.entries({ home, visit, idx, note: await get('/mill/milling/' + notes[0] + '/') }))
  ok(`header+footer on ${name}`, /class="site-header"/.test(page.body) && /class="site-footer"/.test(page.body) && page.body.includes('sails.svg'));

// council endpoint: bare markup, stable address
const council = await get('/mill/fragments/opening-hours.fragment.html');
ok('council 200', council.status === 200);
ok('council bare: no html/head/body', !/<html|<head|<body/i.test(council.body));
ok('council has hours', council.body.includes('Wednesday to Sunday'));

// one panel, one edit: fragment text is byte-identical inside the Visit page
ok('same panel inlined on Visit page', visit.body.includes(council.body.trim()),
  council.body.trim().slice(0, 60) + '...');

// month flip: the two addresses the home page fetches
const fetchHrefs = [...home.body.matchAll(/class="month-link[^"]*" href="([^"]+)"/g)].map((m) => m[1]);
ok('home fetches /mill/-prefixed fragment URLs', fetchHrefs.length === 2
  && fetchHrefs.every((h) => h.startsWith('/mill/milling/')), fetchHrefs.join(' '));
for (const h of fetchHrefs) {
  const f = await get(h);
  ok(`fetched ${h} 200 bare markup`, f.status === 200 && !/<html|<head|<body/i.test(f.body) && /milling-days|No milling/.test(f.body));
}
ok('this-month shows November 2026', (await get(fetchHrefs[0])).body.includes('November 2026'));
ok('next-month shows December 2026', (await get(fetchHrefs[1])).body.includes('December 2026'));
ok('no fetch on load: JS fetches only inside click handler',
  home.body.includes("addEventListener('click'") && !/onload|DOMContentLoaded/.test(home.body));

// assets
ok('styles.css 200', (await get('/mill/styles.css')).status === 200);
ok('sails.svg 200', (await get('/mill/sails.svg')).status === 200);
ok('feed.xml 200', (await get('/mill/feed.xml')).status === 200);

// drafts must never appear
ok('drafts absent', (await get('/mill/drafts/winter-hours.html')).status === 404
  && (await get('/mill/winter-hours/')).status === 404);

// every href/src the browser will request is absolute under /mill/ or a same-dir relative fragment
for (const p of ['/', '/visit/', '/milling/', '/milling/' + notes[0] + '/']) {
  const page = await get('/mill' + p);
  const urls = [...page.body.matchAll(/(?:href|src)="([^"]+)"/g)].map((m) => m[1]);
  const bad = urls.filter((u) => u.startsWith('/') && !u.startsWith('/mill/'));
  ok(`all root-relative URLs in ${p} are under /mill/`, bad.length === 0, bad.join(' '));
}

let fails = 0;
for (const [s, name, detail] of checks) { if (s === 'FAIL') fails++; console.log(`${s}  ${name}${detail ? '   [' + detail + ']' : ''}`); }
console.log(`\n${checks.length - fails}/${checks.length} passed`);
process.exit(fails ? 1 : 0);
