# Holt Fen Windmill — build report

## Publish command

```
./unify build --base-url https://holtfen.pages.dev/mill/ --pretty-urls --clean --audit --strict
```

(Exit 0 = `dist/` is the complete site for `https://holtfen.pages.dev/mill/`; non-zero = nothing
published. I also run `./unify build --dry-run --strict --base-url https://holtfen.pages.dev/mill/ --pretty-urls`
first to see every problem and the page→layout list in one pass.)

What it builds: `site/_layout.html` carries the header (sails mark `site/sails.svg`), nav and
footer for every page, authored or generated. `site/fragments/opening-hours.fragment.html` is the
single opening-hours panel: it is included into the Visit page at build time and also ships
byte-for-byte at `https://holtfen.pages.dev/mill/fragments/opening-hours.fragment.html` — the
council's fixed address (a `.fragment.html` is the documented bare-markup form for embeds/fetches;
it is a machine endpoint, not a URL visitors see). `unify.yaml` declares `generate: scripts/gen.mjs`,
which before every build writes into the generated overlay: the notes index (`milling/index.html`,
every note newest-first, taken from the source inventory) and the two month lists the home page
fetches (`milling/this-month.fragment.html`, `milling/next-month.fragment.html`). Overlay files are
composed like sources, so the generated index gets the layout, the `/mill/` prefix and pretty URLs.
Volunteers add a note as a Markdown file with three frontmatter keys; the index updates itself.
`drafts/` and `scripts/` are outside the source root and appear nowhere in `dist/`.

## How I verified it (no browser)

`node scripts/verify-server.mjs` serves `dist/` **mounted at `/mill/` exactly** — every other path
404s, so a wrong prefix fails. `node scripts/verify.mjs` runs 32 fetch checks, all passing:

- **Pages**: `/mill/`, `/mill/visit/`, `/mill/milling/` and the four notes return 200 with the
  shared header, footer and sails mark; `/mill/visit.html` returns 404 (no `.html` visitor
  addresses); the index lists 4 notes, sorted newest-first; every root-relative `href`/`src` on
  every page starts with `/mill/`; `styles.css`, `sails.svg`, `feed.xml` 200.
- **Council address**: `GET /mill/fragments/opening-hours.fragment.html` → 200, and the body
  contains no `<html`, `<head` or `<body` — bare `<section>` + table. The Visit page contains the
  panel byte-identically (string-match check), and I proved the one-edit rule: added `TESTMARK` to
  the fragment, rebuilt, saw it in both the Visit page and the council copy, removed it, rebuilt
  (`grep TESTMARK dist` → empty).
- **Month flip**: the home page's fetch targets are read from its own markup — the only two
  `month-link` hrefs, `/mill/milling/this-month.fragment.html` and `/mill/milling/next-month.fragment.html`
  (unify rewrote them; the JS reads them back from the anchors and fetches only inside the click
  handler — there is no load-time fetch). Both return 200 bare fragments naming November 2026 and
  December 2026; nothing references another origin.
- `unify audit --strict` and the publishing build itself: "audit: nothing to report", exit 0.

## What `rules.md` did not answer

- **The generate script's whole interface.** The docs say only "it writes into the directory unify
  hands it". They never say how the script learns which directory that is or where the inventory is.
  The sentence I wanted, and could not find: *"the script is invoked as
  `… gen.mjs <sourceRoot> <generatedDir> <generator-context.json>` and the context names
  `inputs.sourcePages`."* I probed with a throwaway script that printed `process.argv` and the
  context file.
- **Whether the generated overlay is composed or merely copied.** "Writes into the directory unify
  hands it" is silent on what happens to those files next. They are composed as sources — layout,
  base-url rewriting, pretty-urls — which is what makes a script-generated *index page* sane. I
  found this by experiment, and it changed my design (the index is a plain page with authored links,
  not hand-prefixed markup).
- **Inventory title derivation.** It promises "every source page's authored title" but does not say
  that a Markdown title derived from a leading `# Heading` (no `title:` key) is `null` in the
  inventory even though the built page uses it. My index fell back to the filename; I had the script
  re-read the note's first heading from the source root.
- **Links inside fragments under `--base-url`.** The docs warn for `fetch()`/`hx-get` addresses and
  say fragments ship "as written" — but not that links written into a *generated* fragment are
  therefore un-prefixed. My first month fragments contained `href="/visit.html"`; injected into a
  page at `/mill/`, that escapes the mount. Audit did not flag it (fragments aren't link-checked).
  Fix: the fragments now contain no links at all; linkable prose lives in the surrounding page.
- **`--audit` gate semantics.** Whether a build with `--audit` publishes past `incomplete` findings:
  it exited 0 while reporting four `h1-missing` incompletes. The `--strict` bullet hints at this;
  I confirmed by experiment and now publish with `--audit --strict`, and fixed the content instead
  of loosening the bar.
- Not answered at all, outside the tool: what Content-Type the host returns for
  `.fragment.html` (assumed `text/html`, fine for an HTML-inserter), and that `/mill/visit/` maps to
  `visit/index.html` on the host — standard static-host behaviour, simulated by my server.

## What I re-read, and why it did not land

- **Line 6 of the rules (the generate/feed paragraph)** three times. It packs the script contract,
  the feed rule and the date rule into one unbroken paragraph; the first two reads gave me "a script
  writes derived files somewhere" and missed `never into site/`, the `scripts/` location, and that
  context. It didn't land because there is no heading or list — the most load-bearing mechanics of
  the tool are a footnote inside a prose wall.
- **The `_*` exclusion bullet vs "a script you write, kept in `scripts/` beside the site"** — they
  read as a contradiction (scripts must be underscored? scripts live in `scripts/`?). Rereading
  showed the underscore rule applies *inside the source root*, while `scripts/` beside `site/` is
  outside it and ships by never being looked at. My first attempt at the layout had to be corrected
  once I understood this.
- **`A date:` with no time is reported and left out`** vs the schema section's *"`date` unify cannot
  read as `2026-01-02` or `2026-01-02T09:30:00Z`"* — they look contradictory (date-only is
  readable-format vs date-only is dropped). Best reading: JSON-LD accepts date-only, the feed entry
  wants a time. I sidestepped by giving every note a full timestamp.

## What I guessed at or inferred rather than read

- That the council GETs the address and inserts the response, so the panel must also survive an
  unstyled context: bare semantic `<section>`/`<table>`, classes only, no `<style>`, no links, no
  script inside it.
- The source of "milling days" for the month flip is not specified; I invented `SCHEDULE` (keyed
  `YYYY-MM`) inside `scripts/gen.mjs`, computed relative to build-time "today", so the two addresses
  are fixed forever and their contents roll each build. Empty months get an explicit "nothing
  booked" fragment rather than a 404.
- Notes need dates *with times*, `schema: BlogPosting` on each note (to get JSON-LD and the feed),
  and a leading `# Heading` as the h1 (the missing-`<h1>` advisory, not a rule, taught me layout
  can't supply one — there is no template language).
- Placing the home page's `<script>` inside `<main>` rather than beside it: I inferred a body-level
  sibling of `main` might merge unpredictably and never tested the alternative.
- Graceful no-JS behaviour: the month links are real anchors, so without JS a click navigates to
  the bare fragment. I judged that acceptable and did not verify a browser's rendering (there is
  none here).
- The charity number, email and directions copy are invented filler; the *winter weekend hours* in
  the panel are mine too — `drafts/winter-hours.md` explicitly says the trust has not agreed them,
  so I used none of its content.
- `--clean` ordering vs the generator: the overlay lives under `/tmp/unify-generated-*`, so cleaning
  `dist/` cannot wipe generated files. Inferred from the probe paths, consistent with every build.
