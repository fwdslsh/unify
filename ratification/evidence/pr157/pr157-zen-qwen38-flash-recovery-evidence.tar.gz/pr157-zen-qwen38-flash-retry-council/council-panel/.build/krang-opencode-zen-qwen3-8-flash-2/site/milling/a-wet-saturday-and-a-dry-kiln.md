---
date: 2026-10-03T18:05:00Z
author: Priya Nair
description: Milling between showers; the school group got the floor to themselves.
schema: BlogPosting
---

# A wet Saturday and a dry kiln

Rain off and on all day. We ran the stones between the showers — you get about forty
minutes of dry flour at a time and then everybody shelters under the gantry with the
sacks.

The Yatterbury school group arrived bone dry on the bus and left with ten kilos of
oatmeal between them and one very enthusiastic drawing of the fantail which is pinned
up in the office.

Wind died by five. We hosed the floor down and called it.
