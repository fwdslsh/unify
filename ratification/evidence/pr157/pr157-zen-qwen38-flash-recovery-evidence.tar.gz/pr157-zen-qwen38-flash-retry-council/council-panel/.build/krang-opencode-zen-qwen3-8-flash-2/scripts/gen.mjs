import fs from 'node:fs';
import path from 'node:path';

// Runs before every build (declared in unify.yaml). Writes derived files into
// the generated overlay directory unify passes it — never into site/.
// argv: [runtime, script, sourceRoot, overlayDir, generatorContextJson]
const [, , sourceRoot, overlay, ctxPath] = process.argv;
const ctx = JSON.parse(fs.readFileSync(ctxPath, 'utf8'));
const inventory = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, 'utf8'));

const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'];
const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function esc(value) {
  return String(value ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

function metaValue(page, name) {
  for (const m of page.meta || []) {
    if (m && m.name === name && m.content != null) return m.content;
  }
  return null;
}

function longDate(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${DAY_NAMES[d.getUTCDay()]} ${d.getUTCDate()} ${MONTH_NAMES[d.getUTCMonth()]} ${d.getUTCFullYear()}`;
}

// --- The notes index: every milling note, newest first. Volunteers never edit this by hand.
// The inventory carries a frontmatter title but not one derived from a leading
// "# Heading", so fall back to reading the first heading out of the note itself.
function noteTitle(p) {
  if (p.title) return p.title;
  try {
    const text = fs.readFileSync(path.join(sourceRoot, p.source), 'utf8');
    const m = text.match(/^# (.+)$/m);
    if (m) return m[1].trim();
  } catch { /* leave the filename as last resort */ }
  return p.source;
}

const notes = (inventory.pages || [])
  .filter((p) => p.source.startsWith('milling/') && p.source.endsWith('.md') && !path.basename(p.source).startsWith('_'))
  .sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));

const items = notes.map((p) => {
  const when = p.date ? `<time datetime="${esc(p.date)}">${esc(longDate(p.date))}</time>` : '<time>(undated)</time>';
  const author = metaValue(p, 'author');
  const who = author ? ` &middot; ${esc(author)}` : '';
  const desc = p.description ? `<p class="note-desc">${esc(p.description)}</p>` : '';
  return `      <li>${when} <a href="${esc(p.href)}">${esc(noteTitle(p))}</a>${who}\n${desc}</li>`;
}).join('\n');

fs.mkdirSync(path.join(overlay, 'milling'), { recursive: true });
fs.writeFileSync(path.join(overlay, 'milling', 'index.html'),
`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Milling days</title>
<meta name="description" content="Volunteers' notes from the days Holt Fen Windmill was working, newest first.">
</head>
<body class="milling">
<main>
  <h1>Milling days</h1>
  <p>Notes from the volunteers who spent the day at the mill, newest first. This index is
  rewritten from the notes themselves on every build &mdash; nobody has to remember to update it.</p>
  <ol class="note-list">
${items}
  </ol>
</main>
</body>
</html>
`);

// --- The month lists the home page fetches on demand. Fixed addresses; the
// --- contents roll forward with the calendar because this script recomputes
// --- them from the schedule below on every build.
const SCHEDULE = {
  '2026-11': [
    { day: '2026-11-07', label: 'Winter wheat grind; flour shop all day' },
    { day: '2026-11-11', label: 'Millers\' practice morning, 10:00' },
    { day: '2026-11-14', label: 'Open milling day; tours 11:00, 14:00, 15:00' },
    { day: '2026-11-22', label: 'Oats for the school bake; sail check after' },
    { day: '2026-11-28', label: 'Last weekend run before winter hours' },
  ],
  '2026-12': [
    { day: '2026-12-05', label: 'Winter opening begins; weekends only' },
    { day: '2026-12-13', label: 'Maslin rye grind; mince-pie flour in the shop' },
    { day: '2026-12-19', label: 'Miller\'s Christmas — carols under the sails, 18:00' },
    { day: '2026-12-23', label: 'Final run of the year' },
  ],
  '2027-01': [
    { day: '2027-01-09', label: 'New year opening; cap greasing, sails half-caff' },
    { day: '2027-01-23', label: 'Open milling day' },
  ],
};

function monthFragment(key, heading) {
  const days = (SCHEDULE[key] || [])
    .map((d) => {
      const dt = new Date(d.day + 'T12:00:00Z');
      return `      <li><time datetime="${esc(d.day)}">${DAY_NAMES[dt.getUTCDay()]} ${dt.getUTCDate()}</time> &mdash; ${esc(d.label)}</li>`;
    }).join('\n');
  const body = days
    ? `    <ul class="milling-days">\n${days}\n    </ul>\n    <p class="days-foot">Usual opening hours apply on these days; the miller&apos;s word on the day is final.</p>`
    : '    <p class="milling-days-empty">No milling days have been booked for this month yet. Check back soon.</p>';
  return `<div class="month-list">
    <h3>${esc(heading)}</h3>
${body}
  </div>
`;
}

const now = new Date();
const thisKey = `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, '0')}`;
const nextDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));
const nextKey = `${nextDate.getUTCFullYear()}-${String(nextDate.getUTCMonth() + 1).padStart(2, '0')}`;

fs.writeFileSync(path.join(overlay, 'milling', 'this-month.fragment.html'),
  monthFragment(thisKey, `Milling days in ${MONTH_NAMES[now.getUTCMonth()]} ${now.getUTCFullYear()}`));
fs.writeFileSync(path.join(overlay, 'milling', 'next-month.fragment.html'),
  monthFragment(nextKey, `Milling days in ${MONTH_NAMES[nextDate.getUTCMonth()]} ${nextDate.getUTCFullYear()}`));

console.log(`gen: index of ${notes.length} notes; month lists for ${thisKey} and ${nextKey}`);
