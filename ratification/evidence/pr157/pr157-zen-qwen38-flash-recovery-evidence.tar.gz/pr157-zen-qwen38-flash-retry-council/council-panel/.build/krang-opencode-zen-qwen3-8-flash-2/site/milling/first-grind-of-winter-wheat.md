---
date: 2026-11-07T16:45:00Z
author: Ida Ward
description: Saturday milling with the new dressing stones and a queue for the flour shop.
schema: BlogPosting
---

# First grind of winter wheat

Winds came round north-east about nine, steady enough by ten to put the sails to work.
We dressed the runner stone on Friday, so the first barrow of winter wheat came through
clean — best grido this year, no grey in it at all.

Four tours went round before one. The last one, a family from Norwichtown, stayed till
five watching the sails come round. We sold out of wholemeal by three o'clock.

*Next time:* bring a spare bolt cloth; the south one is going.
