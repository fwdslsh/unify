---
date: 2026-09-19T19:00:00Z
author: Ida Ward
description: The sails were turned for the service and the mill glowed like a lantern.
schema: BlogPosting
---

# Harvest thanksgiving service under the sails

Revd. Coates held the harvest service in the field against the mill, two hundred
souls on the bank. We had the sails up half-caff for the sunset and lit the vestibule
lantern, and I do not think any of us had seen the mill look so much like what it is
for.

We ground a bushel of Maslin's rye after dark for the communion bread. The stone
temper was perfect — I have never known her go so sweet.

Flour shop takings were the best since the cap went back on. Everyone gets a share of
the credit, but the weather gets most of it.
