---
date: 2026-10-24T14:30:00Z
author: Ben Thatcher
description: Half a day checking the elm stocks; no milling, but good progress.
schema: BlogPosting
---

# Sails down for the stock inspection

Calm all morning, so instead of milling we put the sails down and had a long look at
the elm stocks. Two of the bolts we renewed in August are sweet, no movement at all.
The windshaft bearings took a grease and they run quiet now.

Got the cap turned a quarter by hand — three of us and a bar of soap on the fantail rail.

Nobody got hurt, which is the way I like these notes to end.
