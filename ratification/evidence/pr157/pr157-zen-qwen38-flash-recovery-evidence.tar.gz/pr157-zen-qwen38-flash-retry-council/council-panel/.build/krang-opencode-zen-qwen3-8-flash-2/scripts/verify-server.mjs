import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

// Serve ./dist mounted at /mill/ only — anything else must 404, the way the
// real address would behave. Proves the site is correct for that address.
const dist = path.resolve('dist');
const types = { '.html': 'text/html', '.css': 'text/css', '.svg': 'image/svg+xml', '.xml': 'application/xml' };
http.createServer((req, res) => {
  const url = decodeURIComponent(req.url.split('?')[0]);
  if (!url.startsWith('/mill')) { res.end('NOT OUR PATH'); return; }
  let rel = url.slice('/mill'.length);
  if (rel.endsWith('/')) rel += 'index.html';
  const file = path.join(dist, rel);
  if (!file.startsWith(dist) || !fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404); res.end('404'); return; }
  res.writeHead(200, { 'content-type': types[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
}).listen(8787, () => console.log('mounted dist at /mill/ on :8787'));
