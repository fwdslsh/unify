---
title: Stumpage day at the mill
date: 2026-10-12T10:00:00Z
author: Dan Millward
schema: BlogPosting
description: "The last milling of the crop: rye by the sackful, mustard seed, and a spur wheel running dry."
---

# Stumpage day at the mill

Stumpage — the last milling of the year's crop for the fen farms, when everyone brings
their ends and odds. The yard was full of trailers by nine.

We ground three sacks of rye, a bin of mixed feed, and what felt like every bushel of
mustard seed on the fen. Mustard is cruel on the stones: we had to stop twice to draw and
dress the right-hand runner, and the whole dust chamber smells of it till Tuesday.

New thing to note down before I forget: the oil on the great spur wheel ran thin in the
afternoon heat even in October. Meg thinks the feed cup is cracked again. Check it before
the winter runs.
