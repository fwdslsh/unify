import fs from 'node:fs';
import path from 'node:path';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'];

const sourceRoot = process.argv[2];
const overlay = process.argv[3];
const ctxPath = process.argv[4];

const ctx = JSON.parse(fs.readFileSync(ctxPath, 'utf8'));
const inventory = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, 'utf8'));

function esc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// Fragments are shipped as written: links inside them never get rewritten,
// so they must already carry the address the published site will serve.
// (Pages, including the index below, keep the real filename and let the build
// rewrite them.)
const base = ctx.site.baseUrl ? new URL(ctx.site.baseUrl).pathname : '/';
function publishedUrl(href) {
  let out = href;
  if (ctx.site.prettyUrls) out = out.replace(/\.html$/, '/');
  return base === '/' ? out : base.replace(/\/+$/, '') + out;
}

const notes = inventory.pages
  .filter(function (p) { return p.source.startsWith('milling/') && p.source.endsWith('.md'); })
  .filter(function (p) { return p.date; })
  .map(function (p) {
    const meta = {};
    (p.meta || []).forEach(function (m) { if (m.name) meta[m.name] = m.content; });
    return {
      href: p.href,
      title: p.title || meta.title || 'Untitled',
      date: p.date,
      author: meta.author || 'a volunteer',
    };
  })
  .sort(function (a, b) { return a.date < b.date ? 1 : a.date > b.date ? -1 : 0; });

function dayOfMonth(iso) { return Number(iso.slice(8, 10)); }
function monthName(iso) { return MONTHS[Number(iso.slice(5, 7)) - 1]; }

function item(n, href) {
  const when = dayOfMonth(n.date) + ' ' + monthName(n.date) + ' ' + n.date.slice(0, 4);
  return '<li><a href="' + esc(href) + '">' + esc(n.title) + '</a> '
    + '<time datetime="' + esc(n.date) + '">' + esc(when) + '</time>'
    + ' &mdash; ' + esc(n.author) + '</li>';
}

// The index: every note, newest first. Volunteers never touch it.
const index = [
  '<!doctype html>',
  '<html lang="en">',
  '<head>',
  '<meta charset="utf-8">',
  '<title>Milling days</title>',
  '<meta name="description" content="Dated notes from the volunteers who grind at Holt Fen Windmill, newest first.">',
  '</head>',
  '<body class="milling">',
  '<h1>Milling days</h1>',
  '<p>Notes from the volunteers, newest first. A note appears whenever the mill runs;</p>',
  '<p>this index is written by a script at build time, so it is never out of date.</p>',
  '<ul class="note-list">',
  notes.map(function (n) { return item(n, n.href); }).join('\n'),
  '</ul>',
  '</body>',
  '</html>',
  '',
].join('\n');

// Month lists for the home page's no-reload flip, keyed off the build date.
function monthKey(offset) {
  const d = new Date();
  d.setMonth(d.getMonth() + offset);
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
}

function monthFragment(offset) {
  const key = monthKey(offset);
  const label = MONTHS[Number(key.slice(5, 7)) - 1] + ' ' + key.slice(0, 4);
  const days = notes
    .filter(function (n) { return n.date.slice(0, 7) === key; })
    .sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : 0; });
  const list = days.length
    ? '<ul>\n' + days.map(function (n) { return item(n, publishedUrl(n.href)); }).join('\n') + '\n</ul>'
    : '<p>Nothing listed yet for ' + esc(label) + ' &mdash; the list grows as the mill runs.</p>';
  return '<div class="month-list">\n<h3>' + esc(label) + ' milling days</h3>\n' + list + '\n</div>\n';
}

fs.mkdirSync(path.join(overlay, 'milling'), { recursive: true });
fs.writeFileSync(path.join(overlay, 'milling', 'index.html'), index);
fs.writeFileSync(path.join(overlay, 'milling', 'this-month.fragment.html'), monthFragment(0));
fs.writeFileSync(path.join(overlay, 'milling', 'next-month.fragment.html'), monthFragment(1));

console.log('generated milling index (' + notes.length + ' notes) + this/next month fragments');
