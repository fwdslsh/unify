# Holt Fen Windmill — build report

## Publish command

```
./unify build --clean --strict --pretty-urls --base-url https://holtfen.pages.dev/mill/
```

Exit 0 writes the complete site to `dist/`; deploy `dist/` so that its root is served at
`/mill/` (that is what the URL in `--base-url` declares, and everything in `dist/` was
resolved against it). The same options are what `unify.yaml` + this command expect; `generate`
is already saved in `unify.yaml`, so only the four flags above matter at publish time.

Site layout: `site/` is the source root (home, `visit.html`, `milling/*.md`, `styles.css`,
`assets/sails.svg`, `_layout.html`, `hours.fragment.html`); `scripts/gen.mjs` is the generator
(`generate: scripts/gen.mjs` in `unify.yaml`); `drafts/` sits outside the source root, so it
can never ship.

## How I verified it

`unify build --dry-run --strict` first, then `unify audit --strict --pretty-urls --base-url …`
(exits 0, "nothing to report"), then the publish command above (exit 0), then `node verify.mjs`
(43 assertions, all PASS, kept in `verify-out.txt`). verify.mjs runs a node server that maps
`/mill/…` onto `dist/…` — the exact shape of the deployed address, since I have no browser and
holtfen.pages.dev isn't mine to hit:

- **Pages**: `/mill/`, `/mill/visit/`, `/mill/milling/`, two note pages return 200 and carry the
  shared header (the sails-mark inline SVG) and footer; sitemap holds only `.html`-free page URLs.
  All 62 root-relative `/mill/` hrefs and srcs in every emitted HTML file (stylesheet, favicon,
  nav, note links, flip anchors) resolve to 200 through that server.
- **Council address**: `GET /mill/hours.fragment.html` → 200 with bare markup — starts
  `<section`, and contains no `<html`, `<head` or `<body` (checked case-insensitively by grep and
  by verify.mjs). The Visit page was asserted to contain that file's bytes unchanged: both come
  from the one `site/hours.fragment.html` (Visit via `<include>`), so editing that file updates
  both. The fragment path is immune to `--pretty-urls` (fragments copy byte-for-byte to the same
  path), so the address survives seasons and renames of everything else.
- **Month flip**: the home page's JS fetches from an anchor's `href` that the build rewrote; the
  emitted markup reads `id="flip-src-this" href="/mill/milling/this-month.fragment.html"` and
  `flip-src-next` → `/mill/milling/next-month.fragment.html`. verify.mjs re-fetches exactly those
  addresses (200, bare list markup, correct November/December entries under today's build date),
  and every note link inside them resolves at `/mill/…`. The `fetch()` call is inside the click
  handler only — lists are loaded on demand, nothing is requested at page load.
- **Drafts**: no `winter-hours`/`DRAFT` string or path anywhere in `dist/` (asserted), because
  `drafts/` lives outside the source root, and underscore-prefixed sources never emit.

## What rules.md did not answer

- **The generator's calling contract.** The sentence I wanted — and there is none — is one that
  says *how* `generate:` runs the script. I only learned by probing: unify runs it as
  `node scripts/gen.mjs <sourceRoot> <generatedOverlayDir> <generator-context.json>` with cwd
  = source root, hands paths absolutely, runs it before every build (including `--dry-run` and
  `audit`), and files written into the overlay participate in the build *as if they were sources*
  (layout applied, links rewritten). Rules says only "it writes into the directory unify hands
  it" — which directory that is, and what a file written there becomes, you must discover.
- **Whether `--pretty-urls` touches fragment paths.** "Every file … copies byte-for-byte to the
  same path" plus the fragment definition implies `/mill/hours.fragment.html` stays exactly that,
  but I wanted the explicit "a `.fragment.html` name keeps its `.html` suffix under
  `--pretty-urls`". Verified by build.
- **Whether links inside fragments are checked or rewritten.** They are neither: the
  `… does not resolve to any emitted file` error fires for page links only. My first version of
  the month fragments linked `/milling/x.html` and passed the whole strict pipeline while being
  broken in production (no `/mill` prefix, not prettified). The fix — computing the final
  published URL inside `gen.mjs` from `generator-context.json` (`baseUrl`, `prettyUrls`) — came
  from reading `dist/`, not from rules.md.
- **`unify audit` flag set** (does it take `--pretty-urls/--base-url/--strict` like build?). Help
  text says "audit" only; it does accept them.

## What I re-read, and why it did not land

- **The include paragraph**, twice. The first read made me think fragments needed `<slot>`s to be
  includable; it actually says the opposite — empty tags splice verbatim, and fills are only
  possible when the target declares slots. Once read that way, `<include src="/hours.fragment.html"></include>`
  for the Visit page became obvious.
- **"or read it back from an `href` unify rewrote"** (Styles, scripts, finishing). This clause
  looks like a throwaway and took me a re-read before it registered as *the* instruction for the
  month flip: since `fetch()` addresses ship as written and root-relative ones miss the
  `--base-url` prefix, the home page keeps its two lists in plain `<a href>`s — the build rewrites
  those — and its JS calls `fetch(getAttribute('href'))`. That is what makes the flip resolve at
  `/mill/` from every page.
- **"a bare `<header>`/`<footer>` does not replace the layout's"** — I read it once while still
  thinking in component terms (every page would need a `slot=` fill), re-read it as "pages put
  content where the `<slot>` is and the layout's chrome ships untouched", and then the layout
  could be written in one pass.

## What I guessed or inferred rather than read

- **"this month's / next month's milling days" = days that have notes.** The brief never defines
  what a month's list contains; I derived it from the note dates (a milling day is a day the mill
  ran and someone wrote a note), so the generator groups notes by build-time month and the
  fragments' names (`this-month` / `next-month`) stay fixed while their content tracks the build
  date. A future-dated note (`christmas-flour.md`) is what makes "next month" non-empty; if a
  month has nothing, the fragment says so rather than failing.
- **The council's address.** rules.md gives the mechanism (fragments ship as written); "the fixed
  address" being `https://holtfen.pages.dev/mill/hours.fragment.html` is my choice, made stable
  because a fragment's path is content-independent and prettify-exempt. The suffix isn't pretty,
  but it is not a visitor-facing page address, so it can't collide with "no `.html` for visitors".
- **Full ISO timestamps (`2026-11-08T14:00:00Z`) in frontmatter `date:`.** Inferred from
  "a `date:` with no time is reported and left out" of the feed: date-only would silence feed
  entries. The `description:`/`author:` keys filling JSON-LD and killing the audit's
  `description-duplicate` (which the notes failed on my first strict audit — shared layout
  description, no `<h1>`) were likewise inferred from "every other key becomes `<meta name=…>`"
  plus what audit then complained about.
- **That `schema: BlogPosting` + `--base-url` also emitting `feed.xml` is welcome.** Not asked
  for; left in.
- **Pages.dev subpath deployment** (`dist/` root served at `/mill/`) as the deployment shape the
  brief's address means — the brief says "served from …/mill/", and `--base-url` takes "the
  site's whole address", so I took those two as the same fact.
