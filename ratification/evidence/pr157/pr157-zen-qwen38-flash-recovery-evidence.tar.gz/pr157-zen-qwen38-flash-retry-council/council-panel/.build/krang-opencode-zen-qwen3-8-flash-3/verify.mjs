import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

// Serve dist/ exactly as https://holtfen.pages.dev/mill/ would: everything the
// build published sits under the /mill/ path.
const server = http.createServer((req, res) => {
  const url = decodeURIComponent(req.url.split('?')[0]);
  const root = path.resolve('dist');
  let p = path.resolve(root, '.' + (url.replace(/^\/mill/, '') || '/'));
  if (!p.startsWith(root)) { res.writeHead(403); return res.end(); }
  if (fs.existsSync(p) && fs.statSync(p).isDirectory()) p = path.join(p, 'index.html');
  if (!fs.existsSync(p)) { res.writeHead(404); return res.end('404 ' + url); }
  const type = p.endsWith('.html') ? 'text/html' : p.endsWith('.css') ? 'text/css' :
    p.endsWith('.svg') ? 'image/svg+xml' : p.endsWith('.xml') ? 'application/xml' : 'text/plain';
  res.writeHead(200, { 'content-type': type });
  res.end(fs.readFileSync(p));
});
await new Promise(r => server.listen(8711, r));

const BASE = 'http://localhost:8711/mill';
const failures = [];
const ok = cond => { if (cond) console.log('PASS: ' + cond); else { console.log('FAIL: ' + false); failures.push(String(cond)); } };
const assert = (label, cond) => { if (cond) { console.log('PASS: ' + label); } else { console.log('FAIL: ' + label); failures.push(label); } };
const get = async u => { const r = await fetch(u); return { status: r.status, body: await r.text() }; };

const pages = ['/', '/visit/', '/milling/', '/milling/schools-morning/', '/milling/first-light/'];
for (const p of pages) {
  const r = await get(BASE + p);
  assert('GET ' + p + ' -> 200', r.status === 200);
  assert(p + ' has header sails mark', r.body.includes('sails-mark'));
  assert(p + ' has shared footer', r.body.includes('site-footer'));
}

// council panel: fixed address, bare markup
const panel = await get(BASE + '/hours.fragment.html');
assert('council address /mill/hours.fragment.html -> 200', panel.status === 200);
assert('council panel has no <html>/<head>/<body>',
  !/<html|<head|<body/i.test(panel.body) && panel.body.trimStart().startsWith('<section'));
assert('council panel has the hours', panel.body.includes('Opening hours') && panel.body.includes('16:00'));

// one panel in two places: same bytes on the Visit page
const visit = await get(BASE + '/visit/');
assert('Visit page contains the identical panel', visit.body.includes(panel.body.trim()));

// home month flip: what a click fetches
const home = await get(BASE + '/');
const srcThis = home.body.match(/id="flip-src-this" href="([^"]+)"/)[1];
const srcNext = home.body.match(/id="flip-src-next" href="([^"]+)"/)[1];
assert('flip fetches /mill/milling/this-month.fragment.html', srcThis === '/mill/milling/this-month.fragment.html');
assert('flip fetches /mill/milling/next-month.fragment.html', srcNext === '/mill/milling/next-month.fragment.html');
const f1 = await get('http://localhost:8711' + srcThis);
const f2 = await get('http://localhost:8711' + srcNext);
assert('this-month fragment -> 200 bare markup', f1.status === 200 && !/<html|<head|<body/i.test(f1.body));
assert('this-month lists the two November days', f1.body.includes('November 2026') && f1.body.includes('Schools morning') && f1.body.includes('wind finally comes'));
assert('next-month fragment -> 200', f2.status === 200 && f2.body.includes('December 2026') && f2.body.includes('Christmas flour'));
assert('fragment note links resolve (fetch happens at /mill/, links are /mill/milling/.../)',
  (f1.body.match(/href="\/mill\/milling\//g) || []).length === 2);
for (const m of (f1.body + f2.body).matchAll(/href="([^"]+)"/g)) {
  const r = await get('http://localhost:8711' + m[1]);
  assert('fragment link ' + m[1] + ' -> 200', r.status === 200);
}

// index: every note, newest first
const idx = await get(BASE + '/milling/');
const dates = [...idx.body.matchAll(/datetime="([^"]+)"/g)].map(m => m[1]);
assert('index lists all 5 notes', dates.length === 5);
assert('index is newest first', dates.join() === [...dates].sort().reverse().join());
assert('one edit -> index and notes stay in step (script, not hand list)', idx.body.includes('written by a script'));

// every internal /mill/ href and src in every page resolves
const files = fs.readdirSync('dist', { recursive: true }).filter(f => String(f).endsWith('.html'));
let links = 0;
for (const f of files) {
  const html = fs.readFileSync(path.join('dist', f), 'utf8');
  for (const m of html.matchAll(/(?:href|src)="(\/mill\/[^"]*)"/g)) {
    links++;
    const r = await get('http://localhost:8711' + m[1]);
    if (r.status !== 200) failures.push('broken: ' + f + ' -> ' + m[1]);
  }
}
assert('all ' + links + ' internal /mill/ links + assets resolve', failures.length === 0);

// no visitor page address ends in .html; fragments are machine/fetch targets, not pages
for (const m of fs.readFileSync('dist/sitemap.xml', 'utf8').matchAll(/<loc>([^<]+)<\/loc>/g)) {
  assert('sitemap URL is .html-free: ' + m[1], !m[1].endsWith('.html'));
}

// drafts never ship
const everything = files.map(f => fs.readFileSync(path.join('dist', f), 'utf8')).join('')
  + fs.readdirSync('dist', { recursive: true }).map(String).join('');
assert('drafts content absent from dist', !everything.includes('Winter hours') && !everything.includes('DRAFT'));
assert('drafts paths absent from dist', !fs.readdirSync('dist', { recursive: true }).map(String).some(s => s.includes('winter-hours')));

server.close();
if (failures.length) { console.log('\nFAILURES:\n' + failures.join('\n')); process.exit(1); }
console.log('\nALL CHECKS PASSED');
