---
title: The wind finally comes in from the wash
date: 2026-11-22T10:30:00Z
author: Meg Treader
schema: BlogPosting
description: "North-west eight, fantail steady, eight sacks for the Felmingland bakehouse."
---

# The wind finally comes in from the wash

Forecast said north-west eight, and it meant it. Reeled the sails round at nine, capped to
the wind by ten, and never had to help a single time — the fantail held her head all
afternoon on a fen wind like that.

Ran both stones on wheat for the bakery at Felmingland: eight sacks of flour out by four.
The bakehouse took the whole bin and left us the bran, which is exactly how these days
should end.

One note for whoever opens on Saturday: the tail-pole gear is slipping a tooth under full
canvas. I have wedged it for now. It wants a proper look before we carry it into winter.
