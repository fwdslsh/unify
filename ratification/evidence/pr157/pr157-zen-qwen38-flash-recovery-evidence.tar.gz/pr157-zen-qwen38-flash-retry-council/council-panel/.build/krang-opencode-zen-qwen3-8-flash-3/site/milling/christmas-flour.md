---
title: "Save the date: Christmas flour grinding"
date: 2026-12-13T09:30:00Z
author: Dan Millward
schema: BlogPosting
description: "An advance note for the Christmas-market grinding on the thirteenth of December."
---

# Save the date: Christmas flour grinding

Written in advance, before I forget to write anything at all.

We have the big order from the Christmas market again, so the sails will be turned on the
Thirteenth for the special winter grinding — spelt for the bakers and a long run of
wholemeal for the box shops. Bring the second dressing cloth; last year we only had one and
it was in the wash.

If the wind fails, the mill will not turn and the note stays as proof we meant to. Check
the front board on the day.
