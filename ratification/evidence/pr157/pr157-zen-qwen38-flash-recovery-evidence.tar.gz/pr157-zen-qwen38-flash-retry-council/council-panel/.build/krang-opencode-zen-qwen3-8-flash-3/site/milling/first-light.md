---
title: First light on the sails
date: 2026-08-16T06:40:00Z
author: Meg Treader
schema: BlogPosting
description: "Midsummer grinding for the fen farms: first flour by seven, thirty sacks hoisted by hand."
---

# First light on the sails

Wind from the north-east, just enough to fill the sails and no more. We set stones at ten
past six, before the visitors came, and the first flour of the morning went into the bin by
seven. A good day for fen wheat: heavy grain, dry straw.

The hoisting winch is still stiff on the third turn — Dan says the ratchet needs a new pad,
and until then we hoist by hand. Thirty-odd sacks up the stairs between the rounds.

At two we opened the hatch and sold out by four. Two lads from the Wavenham mill club
walked round with us after closing and could not believe the wallower is original. It is.
