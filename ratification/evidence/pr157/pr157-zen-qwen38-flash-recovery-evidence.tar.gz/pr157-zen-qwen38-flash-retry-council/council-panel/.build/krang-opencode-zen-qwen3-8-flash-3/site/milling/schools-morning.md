---
title: "Schools morning: twenty pairs of hands"
date: 2026-11-08T14:00:00Z
author: Priya Nair
schema: BlogPosting
description: "Twenty Year 4s feed the hopper one cup at a time on a Sunday morning in November."
---

# Schools morning: twenty pairs of hands

Holt C of E primary came up the flood bank path at ten and were on the stairs by ten past.
Twenty Year 4s, two teachers, one very serious camera boy.

We set stones with Meg and let them feed the hopper a cup at a time. The moment the shoes
start ticking is the moment they all go quiet, every single time. Someone always asks why
the flour is grey, and today the answer is the rye from last week still in the bin — we
swept it out before the wheat.

They left with a sample sack for the classroom and a trail worksheet. Half had done it by
the time they reached the sluice bridge, which I thought was a compliment to us and a
criticism of their school.
