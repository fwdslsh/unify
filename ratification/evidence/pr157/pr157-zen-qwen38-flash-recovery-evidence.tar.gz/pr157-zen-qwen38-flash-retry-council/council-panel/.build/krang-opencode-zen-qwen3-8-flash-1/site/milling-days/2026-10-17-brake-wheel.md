---
title: "The brake wheel creaks again"
date: 2026-10-17
description: "First grinding of autumn: one axle of sails, a very stiff brake wheel, forty loaves."
---

# The brake wheel creaks again — Saturday 17 October

We ground for three hours with the west pair of sails only; the east stocks are
still swelling after the summer and Peggy says leave them be.

The brake wheel has gone stiff again — a sponge of linseed oil on the rim and it
sang by eleven. Forty loaves out of the ovens by two o'clock, and the queue never
went below six people, which is the correct number for a Saturday.

— Doris, volunteer baker
