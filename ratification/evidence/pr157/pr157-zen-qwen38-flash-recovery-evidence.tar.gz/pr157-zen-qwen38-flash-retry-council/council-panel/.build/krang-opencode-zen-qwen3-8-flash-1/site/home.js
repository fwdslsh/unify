/* Holt Fen Windmill — home page month flip.
   Fetch addresses are never written here: each tab is an <a> whose href
   unify has already rewritten for the published address, so the browser's
   resolved `tab.href` is the correct URL. Lists load only on click. */
(() => {
  const tabs = document.querySelectorAll('a.days-tab');
  const panel = document.getElementById('days-panel');
  if (!tabs.length || !panel) return;

  const cache = new Map();

  const markActive = (tab) => {
    tabs.forEach((t) => {
      t.classList.toggle('is-active', t === tab);
      t.setAttribute('aria-selected', t === tab ? 'true' : 'false');
    });
  };

  const render = (html) => {
    panel.innerHTML = html;
  };

  const load = (tab) => {
    markActive(tab);
    const url = tab.href;
    if (cache.has(url)) {
      render(cache.get(url));
      return;
    }
    render('<p>Loading\u2026</p>');
    fetch(url)
      .then((r) => {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.text();
      })
      .then((html) => {
        cache.set(url, html);
        render(html);
      })
      .catch(() => {
        render('<p>That month\u2019s list could not be loaded. '
          + 'You can <a href="' + url + '">open it directly</a>.</p>');
      });
  };

  tabs.forEach((tab) => {
    tab.addEventListener('click', (event) => {
      event.preventDefault();
      load(tab);
    });
  });
})();
