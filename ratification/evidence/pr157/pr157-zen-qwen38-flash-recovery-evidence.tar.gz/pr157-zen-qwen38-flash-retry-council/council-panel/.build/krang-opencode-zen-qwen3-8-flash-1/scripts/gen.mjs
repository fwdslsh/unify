// Derives everything a volunteer would otherwise have to update by hand:
//   milling-days/index.html      — the archive, newest note first
//   days/this-month.fragment.html
//   days/next-month.fragment.html — month lists the home page fetches on demand
// unify runs this before every build and hands it (argv[3]) a directory that
// ships like the site; it never writes into site/.

import fs from 'node:fs';

const ctx = JSON.parse(fs.readFileSync(process.argv[4], 'utf8'));
const inv = JSON.parse(fs.readFileSync(ctx.inputs.sourcePages, 'utf8'));
const OUT = ctx.paths.generatedRoot;

const base = ctx.site.baseUrl ?? '/';
const pretty = !!ctx.site.prettyUrls;

// Authored hrefs (e.g. /milling-days/x.html) -> the URL visitors are given.
function toUrl(href) {
  let path = href;
  if (pretty) {
    if (path === '/index.html') path = '/';
    else if (/\/index\.html$/.test(path)) path = path.replace(/index\.html$/, '');
    else if (path.endsWith('.html')) path = path.slice(0, -'.html'.length) + '/';
  }
  return base === '/' ? path : base.replace(/\/$/, '') + path;
}

function esc(s) {
  return String(s ?? '')
    .replaceAll('&', '&amp;').replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;').replaceAll('"', '&quot;');
}

const DAY = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTH = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'];

const notes = inv.pages
  .filter((p) => p.source.startsWith('milling-days/') && p.source.endsWith('.md'))
  .map((p) => ({ ...p, day: (p.date ?? '').slice(0, 10), month: (p.date ?? '').slice(0, 7) }))
  .sort((a, b) => (b.day || '').localeCompare(a.day || '')); // newest first; undated last

function longDate(iso) {
  const d = new Date(iso + 'T12:00:00');
  return `${DAY[d.getDay()]} ${d.getDate()} ${MONTH[d.getMonth()]} ${d.getFullYear()}`;
}

// ---- the archive index, rewritten from the notes themselves ----
{
  const items = notes.map((n) => `      <li>
        ${n.day ? `<time class="note-date" datetime="${n.day}">${longDate(n.day)}</time>` : '<span class="note-date">date to be confirmed</span>'}
        &ndash; <a href="${toUrl(n.href)}">${esc(n.title)}</a>
${n.description ? `        <p class="note-desc">${esc(n.description)}</p>` : ''}
      </li>`).join('\n');

  const page = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Milling days</title>
<meta name="description" content="Every working day of Holt Fen Windmill, as noted by the volunteers, newest first.">
</head>
<body class="milling-days">
<main>
<h1>Milling days</h1>
<p>Volunteers write a note whenever the mill runs, and this index rebuilds itself
from their notes, newest first &mdash; no one has to remember to add a line here.</p>
<ol class="note-list">
${items}
</ol>
</main>
</body>
</html>
`;
  fs.mkdirSync(`${OUT}/milling-days`, { recursive: true });
  fs.writeFileSync(`${OUT}/milling-days/index.html`, page);
}

// ---- the two month lists the home page flips between ----
function monthFragment(dirName, year, monthIdx, label) {
  const key = `${year}-${String(monthIdx + 1).padStart(2, '0')}`;
  const inMonth = notes.filter((n) => n.month === key);
  const list = inMonth.length
    ? `    <ul>\n${inMonth.map((n) => `      <li><time datetime="${n.day}">${DAY[new Date(n.day + 'T12:00:00').getDay()]} ${Number(n.day.slice(8))} ${MONTH[Number(n.day.slice(5, 7)) - 1].slice(0, 3)}</time> &mdash; <a href="${toUrl(n.href)}">${esc(n.title)}</a></li>`).join('\n')}\n    </ul>\n`
    : '    <p>No milling days announced for this month yet.</p>\n';
  const frag = `<section class="milling-days-list">
    <h2>Milling days &mdash; ${MONTH[monthIdx]} ${year} (${label})</h2>
${list}    <p>Older and future dates: <a href="${toUrl('/milling-days/index.html')}">full milling days archive</a>.</p>
  </section>
`;
  fs.writeFileSync(`${OUT}/days/${dirName}.fragment.html`, frag);
}

fs.mkdirSync(`${OUT}/days`, { recursive: true });
const now = new Date();
monthFragment('this-month', now.getFullYear(), now.getMonth(), 'this month');
const next = new Date(now.getFullYear(), now.getMonth() + 1, 1);
monthFragment('next-month', next.getFullYear(), next.getMonth(), 'next month');

console.log(`gen: ${notes.length} notes -> index + this/next month lists (base ${base}, pretty ${pretty})`);
