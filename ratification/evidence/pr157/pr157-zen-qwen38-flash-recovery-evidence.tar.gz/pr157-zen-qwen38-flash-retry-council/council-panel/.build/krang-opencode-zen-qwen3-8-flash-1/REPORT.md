# Holt Fen Windmill — build report

## 1. The exact publish command line

```
./unify build --pretty-urls --base-url https://holtfen.pages.dev/mill/
```

(`generate: scripts/gen.mjs` is saved in `unify.yaml`, so the build runs the
index/month generator automatically. Exit 0 means `dist/` is the complete site;
every non-zero exit left `dist/` untouched during development, so this line
alone is the publish step.)

Site layout: sources live in `site/` (the default source root), which keeps
`drafts/`, `scripts/`, `unify.yaml` and the docs outside the published tree —
"everything in the source root ships", so nothing that is not the site goes in it.

## 2. What I verified

Checks were run against the *published shape for that address*: `node` served
`dist/` under the `/mill/` path prefix (`_verify/server.mjs`) and a crawler
(`_verify/check.mjs`) walked every page exactly as a browser at
`https://holtfen.pages.dev/mill/` would. Final gate: `unify audit --strict
--pretty-urls --base-url https://holtfen.pages.dev/mill/` → "nothing to report",
exit 0; then the plain build above, exit 0, 14 files.

- **Pages.** `GET` 200 for `/mill/`, `/mill/visit/`, `/mill/milling-days/` and all
  four dated notes. Every page carries the shared header (the sails-mark inline
  SVG) and footer, merged from `site/_layout.html`. Every `href`/`src` emitted on
  every page was fetched: all resolve under `/mill/` (`/mill/style.css`,
  `/mill/home.js`, `/mill/sails.svg`, all internal links). No page address ends
  in `.html`.
- **The council's address.** `GET /mill/opening-hours.fragment.html` → 200; body
  starts `<section class="hf-hours">`; regex-checked to contain no `<html`,
  `<head` or `<body`; `cmp` shows it is byte-for-byte the source file (fragments
  ship "as written", so the URL keeps `.fragment.html` — see §3). The same file
  is `<include>`d into `/mill/visit/` at build time, so it is one panel in one
  place. Proof of "one edit updates both": changing `16:00 → 16:30` in
  `site/opening-hours.fragment.html` and rebuilding updated *both* the council
  copy and the Visit-page splice (2 lines each); the source was then reverted and
  rebuilt, and the final `dist/` matches the checked output.
- **What the home page fetches on a month flip.** No browser was available, so
  I verified the mechanism statically and then simulated it: the two tabs are
  `<a class="days-tab">` whose built hrefs are
  `/mill/days/this-month.fragment.html` and `/mill/days/next-month.fragment.html`
  (root-relative in source, rewritten by `--base-url` — the "read it back from an
  `href` unify rewrote" rule). `home.js` contains no fetch URL at all (crawler
  asserted no `fetch('/…` literal); it reads `tab.href`, which the browser
  resolves for the current page. `GET`ing those two addresses returned 200 with
  bare `<section class="milling-days-list">` lists (Nov: 14 & 28; Dec: 12).
  Nothing is fetched at load: `fetch` is only reached from a click handler, and
  the initial panel is static text.
- **Drafts.** `/mill/drafts/winter-hours.md` → 404; no draft file exists anywhere
  in `dist/`; `sitemap.xml` mentions none of them. `drafts/` stays exactly where
  the volunteers keep it, outside the source root.
- **Index.** `scripts/gen.mjs` reads the `source-pages.json` inventory unify
  hands it and rewrites `/mill/milling-days/` newest-first on every build
  (2026-12-12, 11-28, 11-14, 10-17) — volunteers add a note; nobody edits the
  index.

## 3. What `rules.md` did not answer

The **URL a `.fragment.html` ends up at under `--pretty-urls`**. The doc says
fragments are "shipped as written" and separately that pretty-urls rewrites
`about.html` → `about/` — it never says whether the pretty treatment is *exempt*
for fragments, and the "no `.html` addresses" rule then becomes a judgement call.
The sentence I wanted and could not find, in words close to: *"fragments are not
pretty-ised; their served address keeps the `.fragment.html` suffix."* I learned
it only by building: the report line is `copy dist/hours.fragment.html
(/mill/hours.fragment.html) ← generated`. I read the brief's "addresses visitors
see" as scoping the no-`.html` rule to human navigation, which leaves the two
machine addresses (the council's fetch, the JS month lists) legally `.html`.

Also unanswered: **what the generator is actually handed**. rules.md says the
script "writes into the directory unify hands it" but never how; `-s`/`--generate`
help only adds that a relative path is from the source root. The contract
(`argv = [unify, script, sourceRoot, overlayDir, contextJson]`, cwd = source root,
context JSON with `paths`/`site`/`inputs.sourcePages`) came entirely from probing.
And: **whether generated overlay pages get composed at all** — wrapped by
`_layout.html`, link-checked, sitemap'd — is nowhere stated; they are (a probe
printed `← generated + _layout.html`, and a broken link inside a generated page
does fail the build). Relatedly, whether links in *generated* pages get the
base prefix: they do, but generated *fragments* are copies, and copies are not
rewritten — so the generator emits absolute note URLs computed from
`ctx.site.baseUrl` and the `prettyUrls` flag.

## 4. What I re-read, and why it did not land the first time

The finishing bullet: *"unify … rewrites only HTML's own URL attributes (`href`,
`src`) — a `url()` in CSS and a `fetch()`/`hx-get` address ship as written, so a
root-relative one misses the `--base-url` prefix and 404s: keep every `url()` in a
stylesheet file and every fetched address relative to the page — or read it back
from an `href` unify rewrote."* It took three reads. It packs a constraint, a
failure mode and two remedies into one sentence, and "read it back from an `href`"
did not land until I read it as an instruction about **DOM properties**: JS should
take the URL from an anchor's resolved `.href`, not from any string — which is why
`home.js` contains no URL whatsoever. My first read missed that a string literal
inside `.js` is invisible to the build: unify rewrites *HTML*, not JavaScript.

The first paragraph ("…except a name ending `.fragment.html`, a bare snippet
shipped as written, for `<include>`, embeds, or `fetch`/`hx-get`…") also needed a
second pass once I was designing the council panel: I had read fragments only as
*include targets*, and it was on re-read that "for … `fetch`" means a fragment in
the source root is itself a **served public file** — that is the whole mechanism
for "bare markup at a fixed address".

The Merging section, "Head" bullet: I re-read it as a checklist when writing
`_layout.html`, because the first pass reads as prose — the parts that matter in
practice are "write the separator into the layout's title", "a page has its own
complete `<head>`", and canonical must *not* live in the layout (auto-canonical
with `--base-url` handles it; the build reported 7 pages gaining one).

## 5. What I guessed or inferred rather than read

- That a Markdown note is linked by its emitted name, `/milling-days/x.html` —
  "link the real filename" is written with `.html` examples; I inferred `.md`
  counts as the wrong spelling. The inventory probe later *confirmed* it (`href:
  "/milling-days/…html"` for `.md` sources), so this became a checked fact.
- Anchors (`<a class="days-tab">`) rather than `<button>` for the month tabs, and
  that leaving them clickable without JS (navigating to the raw fragment) is the
  better trade than hiding the lists behind script-only buttons — pure judgement;
  nothing in the doc discusses no-JS fallback.
- That `this month`/`next month` are decided by the build clock (the generator
  uses `new Date()`; the site is rebuilt whenever a volunteer adds a note) —
  the brief never says who decides which month "this" is.
- The ARIA on the tab group (`role="button"`, `aria-selected`, `aria-live`) is my
  accessibility judgement; unify is silent on it.
- Skipping `schema:`/feeds and `--catalog`/`--search-corpus`: nothing in the brief
  asked; rules.md documents them but they are not required to make the pages,
  panel and flip correct.
- `unify dev` exists (help mentions watch/serve/reload) but rules.md never
  describes it; I stayed on `--dry-run --strict` + `audit`, which the doc does
  describe, and my own node server for verification.
