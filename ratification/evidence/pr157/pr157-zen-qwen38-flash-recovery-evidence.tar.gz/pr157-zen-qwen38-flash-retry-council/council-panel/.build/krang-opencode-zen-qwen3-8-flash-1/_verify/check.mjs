import { spawn } from 'node:child_process';
const srv = spawn('node', ['_verify/server.mjs'], { stdio: 'pipe' });
srv.stdout.on('data', () => run());
let fails = 0;
const ok = (cond, msg) => { console.log((cond ? 'PASS' : 'FAIL') + '  ' + msg); if (!cond) fails++; };
const get = async (u) => { const r = await fetch('http://127.0.0.1:8123' + u); return { status: r.status, body: await r.text() }; };

async function run() {
  const pages = ['/', '/visit/', '/milling-days/',
    '/milling-days/2026-12-12-st-lucia/', '/milling-days/2026-11-28-winter-grain/',
    '/milling-days/2026-11-14-sails-by-hand/', '/milling-days/2026-10-17-brake-wheel/'];
  const seen = new Set();
  for (const p of pages) {
    const r = await get('/mill' + (p === '/' ? '/' : p));
    ok(r.status === 200, 'page ' + p + ' -> ' + r.status);
    ok(r.body.includes('<header class="site-head">') && r.body.includes('<footer class="site-foot">'), '  shared header+footer on ' + p);
    ok(r.body.includes('sails-mark'), '  sails mark on ' + p);
    // every href/src on the page must resolve for this address
    for (const m of r.body.matchAll(/(?:href|src)="([^"]+)"/g)) {
      let u = m[1];
      if (u.startsWith('#') || u.startsWith('mailto')) continue;
      if (u.startsWith('http://') || u.startsWith('https://')) {
        ok(u.startsWith('https://holtfen.pages.dev/'), 'absolute URL is on-site: ' + u);
        u = u.slice('https://holtfen.pages.dev'.length);
      } else if (u.startsWith('/')) {
        ok(u.startsWith('/mill/'), 'root-relative stays under /mill/: ' + u + ' (from ' + p + ')');
      } else continue; // relative resolves against page; spot-check below
      const url = u.startsWith('/') ? u : '/mill/' + p.slice(1).replace(/[^/]*$/, '') + u;
      const key = url;
      if (seen.has(key)) continue; seen.add(key);
      const s = await get(url);
      ok(s.status === 200, 'link ' + url + ' -> ' + s.status);
    }
  }
  // visitor-facing page URLs must not end in .html
  for (const p of pages) ok(!p.endsWith('.html'), 'no .html page address: ' + p);
  // no fetch happens at load: home.js contains no literal root-relative fetch address
  const js = await get('/mill/home.js');
  ok(js.status === 200, 'home.js loads');
  ok(!/fetch\(\s*["'`]\//.test(js.body), 'home.js fetches no hardcoded root-relative URL (reads tab.href)');
  // what the home page fetches when a visitor flips the month
  const home = await get('/mill/');
  const tabs = [...home.body.matchAll(/class="days-tab[^"]*"[^>]*href="([^"]+)"/g)].map(m => m[1]);
  ok(tabs.length === 2, 'two month tabs, hrefs: ' + JSON.stringify(tabs));
  for (const t of tabs) {
    const r = await get(t);
    ok(r.status === 200, 'flip fetch ' + t + ' -> ' + r.status);
    ok(/^<section class="milling-days-list">/.test(r.body.trim()), '  fetched list is a bare section');
  }
  // the council's fixed address
  const c = await get('/mill/opening-hours.fragment.html');
  ok(c.status === 200, 'council address /mill/opening-hours.fragment.html -> ' + c.status);
  ok(!/<html|<head|<body/i.test(c.body), 'council payload is bare markup (no html/head/body)');
  ok(c.body.includes('10:00'), 'council payload carries the hours');
  // the same panel is spliced into the Visit page (one source)
  const visit = await get('/mill/visit/');
  ok(visit.body.includes('<section class="hf-hours">'), 'Visit page shows the same panel (built from the same file)');
  // drafts must never appear
  ok((await get('/mill/drafts/winter-hours.md')).status === 404, '/mill/drafts/... -> 404');
  ok(!(await get('/mill/sitemap.xml')).body.includes('draft'), 'sitemap mentions no drafts');
  console.log(fails === 0 ? '\nALL CHECKS PASSED' : '\n' + fails + ' FAILURES');
  srv.kill(); process.exit(fails === 0 ? 0 : 1);
}
setTimeout(() => { console.log('server did not start'); srv.kill(); process.exit(2); }, 5000);
