---
title: "Winter grain day"
date: 2026-11-28
description: "The co-operative's winter barley arrives; two tonnes ground before dark."
---

# Winter grain day — Saturday 28 November

The co-operative brought down two tonnes of winter barley in the morning,
and the wind behaved for once: full sail from noon, and the long glass on
the tail pole steadied the cap without trouble.

Mind the sack stacks in the yard if you visit late November — the floor
by the elevator house is ours to sweep, and we will.

Flour tins sold out at quarter past three, the earliest we have ever
finished. More barley in December if the weather holds.

— Peggy, volunteer steward
