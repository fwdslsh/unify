---
title: "Sails by hand"
date: 2026-11-14
description: "Calm morning, sails wound and set by hand at half wind; a quiet grinding day."
---

# Sails by hand — Saturday 14 November

Hardly a breath of wind all morning, so eight of us put shoulders to the
tarping and wound the sails out by hand. We ground at half wind from ten until
one — slow, but the millstone never complains.

A school from Aylsham came at eleven and sat cross-legged in the flour room
while Sam explained dresser bolts to twenty-nine children. Two of them came
back after lunch to ask what wheat tastes like before it is flour. Honest
answer: not much.

— Sam, volunteer miller
