---
title: "How to prepare a broken item for repair"
author: Priya Mehta
date: 2025-06-01T09:00:00Z
description: "A friendly guide from our volunteers on cleaning, unpacking, and bringing the right items."
og:image: /card-placeholder.svg
schema: BlogPosting
---

## Tips for first-time visitors

Several people ask us what to bring and how to pack it. Here's a quick checklist we keep by the door now:

- Unplug anything electrical and shake out crumbs. A dusty toaster is always the hardest job on Saturday morning.
- Bring loose screws, caps, and batteries in a small bag. We'll test them and return what you brought.
- If it uses gas or contains refrigerant, leave it at home. Those need certified technicians.
- Tell us as much as you know about what happened — the moment it stopped working usually tells us where to start.

We've added these signs near the entrance and people seem to find them useful. First time coming? Just bring your item and don't worry about being tidy — we've seen worse.
