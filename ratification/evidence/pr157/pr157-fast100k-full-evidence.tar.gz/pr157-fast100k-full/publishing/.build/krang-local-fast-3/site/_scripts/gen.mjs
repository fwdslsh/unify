import { readFileSync, writeFileSync, readdirSync, statSync } from "fs";
import { join, basename } from "path";

const siteDir = ".";
const newsDir  = `${siteDir}/news`;

// Gather every Markdown post in /news/
function walk(dir, re, out) {
  for (const n of readdirSync(dir)) {
    const p = dir + "/" + n;
    if (statSync(p).isDirectory()) walk(p, re, out);
    else if (n.match(re)) out.push(p);
  }
}

function matchFiles(dir, re) {
  const result = [];
  walk(dir, re, result);
  return result;
}

const files = [...matchFiles(newsDir, /\.md$/)]
  .map((f) => {
    const src = readFileSync(f, "utf-8");
    let fm = {};
    const lines = src.split("\n");
    // Skip past opening --- then parse until closing ---
    let i = 0;
    while (i < lines.length && /^---/.test(lines[i].trim())) { i++; }
    while (i < lines.length) {
      const line = lines[i];
      if (/^---/.test(line.trim())) break;
      const m = line.match(/^(\w+):\s*(.*)/);
      if (m) fm[m[1]] = m[2].replace(/^"(.*)"$/, "$1");
      i++;
    }
    return { file: f, frontmatter: fm };
  })
  .filter((p) => p.frontmatter.date && !p.frontmatter.draft);

files.sort((a, b) => b.frontmatter.date.localeCompare(a.frontmatter.date));

let html = `<!doctype html>\n<html lang="en" data-layout="/_includes/layout.html">\n<head>\n  <title>News — Bellwick Repair Collective</title>\n  <link rel="alternate" type="application/rss+xml" href="/feed.xml">\n</head>\n<body class="">\n  <h1>News</h1>\n`;

for (const p of files) {
  const slug   = basename(p.file, ".md");
  const dateStr = p.frontmatter.date;
  html += `      <article class="post-preview">\n        <h2><a href="/news/${slug}/">${p.frontmatter.title}</a></h2>\n        <time datetime="${dateStr}">${dateStr}</time>\n        <p>${(p.frontmatter.description || "").replace(/\|/g, "")}</p>\n      </article>\n`;
}

html += `</body>\n</html>\n`;

writeFileSync(join(siteDir, "news.html"), html);

console.log("Generated news index with", files.length, "posts.");
