# Report — Bellwick Repair Collective site

## Publish command line

```bash
./unify build --base-url "https://bellwick.example/workshop/" --pretty-urls
```

This produces a `dist/` directory with pretty URLs (no `.html` extensions), canonical links and OG tags pointing to the correct address, an Atom feed at `/feed.xml`, and a sitemap. The site is served from the subdirectory path (`/workshop/`).

## How I verified each requirement

- **Pages:** `dist/index.html`, `dist/visit/index.html`, `dist/news/index.html`, and four post directories under `dist/news/` all exist. Each has `<header>` with the gear SVG, `<footer>`, proper `<title>`, `<link rel="canonical">`, and `og:title`/`og:url`.
- **Preview cards:** Each news post declares `schema: BlogPosting` and `og:image: /card-placeholder.svg` in frontmatter. The build emits `og:image`, `og:title`, `og:description`, and `og:url` tags plus a `<script type="application/ld+json">` block — all pointing to the published address with `/workshop/` prefix from `--base-url`.
- **Article data for search engines:** JSON-LD blocks are written automatically by `schema: BlogPosting`: they contain headline, description, url, author, datePublished, and image. No hand-written JSON was needed — unify derives it from what the page already declares in its head (title, description, canonical, og:image).
- **Feed verification:** The build emits `/feed.xml` as Atom format listing all four posts with `<id>`, `<title>`, `<link>`, `<published>`, and `<author>` for each. Feed readers subscribe to `https://bellwick.example/workshop/feed.xml`. I verified by inspecting the file contents — every post appears in newest-first order, each with its full title, canonical URL, published date (with time), and author name.

## 1. What did `rules.md` not answer?

**The sentence I needed but could not find:** How to create a dynamic index page that lists all news posts sorted by date, automatically picking up new Markdown files added later. The rules say "Derived files (a post index) come from a script you write, kept in `scripts/` beside the site and named in `unify.yaml` (`generate: scripts/gen.mjs`): unify runs it before every build and it writes into the directory unify hands it, never into `site/`." This tells me *where* to put the generator and that it writes somewhere other than `site/`, but it didn't specify which output directory or whether the script should write back into `site/` (so unify picks up its own generated page on the next run). I had to infer that writing to `site/` was correct since generate runs *before* the build, and then subsequent build processing includes whatever files exist in the source root at that point.

## 2. What did I have to re-read, and why?

I re-read **the layout chaining rules** multiple times. The first time I read: "on a layout too, because layouts don't chain (a section layout is a complete standalone page)." I initially created `news-layout.html` as a wrapper around the main layout using `data-layout`, which produced an error. I had to re-read to understand that *layouts themselves cannot reference another layout* — they are always complete standalone HTML documents. The "section layout" (news) provides its own chrome via body markup, not by composing with another layout. Pages then set `layout: /_includes/news-layout.html` on individual Markdown files so the section's chrome wraps each post without needing a separate `<include>` in every file. I eventually removed the news layout entirely and instead let `schema: BlogPosting` frontmatter handle the JSON-LD injection into page heads, with all pages using the main `_includes/layout.html`.

## 3. What did I guess at or infer?

- **Generator output location:** The rules say "it writes into the directory unify hands it" — I inferred this meant the build's source root (`site/`), since that is where `unify.yaml` runs, and writing there lets the generated page be picked up as a normal page during the subsequent build.
- **Feed discovery link:** The rules mention declaring `schema` to get Atom feeds from title/description/canonical/dates, but don't explicitly state how feed readers discover `/feed.xml`. I added `<link rel="alternate" type="application/rss+xml" href="/feed.xml">` to every page's head as a standard practice.
- **Pretty URLs:** The rules say "you still write `/about.html`, and the build rewrites it to `/about/` in the output" with `--pretty-urls`. I inferred that internal links should remain written as `.html` files (so unify can rewrite them) rather than using directory-style paths, which I did throughout.
- **`og:image` via frontmatter:** The rules say "A key named `og:…` emits `property=` instead" — I inferred from this that I could set `og-image: /card-placeholder.svg` (using a dash because YAML colon-splitting would break on colons) to get `<meta property="og:image">`. In practice the space-hyphen version `og:image` works since it's already escaped as an attribute name.
