---
title: "Saturday session fixes 20 items in one afternoon"
author: Priya Mehta
date: 2025-11-08T09:00:00Z
description: "Our busiest repair day yet — 20 items brought in and sent home working again."
og:image: /card-placeholder.svg
schema: BlogPosting
---

## A record-breaking Saturday

On Saturday 8 November twenty people brought broken household things to Bellwick, and we got nineteen of them working again by tea time. The last one — a microwave with a stuck turntable motor — needs a part we haven't sourced yet, so it went home on the bench for next week.

Two newcomers joined us, learning their first solder joints on a broken radio. "My kettle was leaking," said 16-year-old Sam from Maple Drive. "The kettle's fine now."

We're already planning to buy more tools before our next session — if you want to volunteer or donate equipment, drop us an email at bellwick-repair@example.com.
