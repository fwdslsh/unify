---
title: "New workbench donated by the community"
author: David Okonkwo
date: 2025-09-15T09:00:00Z
description: "A generous donation from a local family means we now have three repair stations instead of two."
og:image: /card-placeholder.svg
schema: BlogPosting
---

## More room, more repairs

Mrs Patel and her children cleared out an old workbench from their garage and brought it last Wednesday. It's solid oak, roughly 180 cm long, and sits nicely beside the one we salvaged from a closing café. We now have three stations with plenty of bench space.

This means we can take on bigger jobs — coffee machines, small power tools, even a washing machine that needed its lid hinge realigned. The next session is Saturday 20 September. Bring your broken things; leave them working again.
