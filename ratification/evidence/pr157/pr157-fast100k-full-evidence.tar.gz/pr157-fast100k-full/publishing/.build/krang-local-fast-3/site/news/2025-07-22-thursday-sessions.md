---
title: "Repair café brings neighbours together"
author: Amara Diallo
date: 2025-07-22T09:00:00Z
description: "A new regular evening session on Thursdays has turned the workshop into a weekly neighbourhood gathering."
og:image: /card-placeholder.svg
schema: BlogPosting
---

## Evening sessions are working well

We started Thursday evenings in July as a trial, and they've stayed. People drop off items during the day and pick them up after work — often with a neighbour who lives two streets over having dropped theirs at the same time.

The Thursday crowd tends toward smaller jobs: phones, chargers, lamps. Saturday is for appliances and anything that plugs into the wall. If you can't make Saturday but want to volunteer, Thursdays are easier on equipment because there's always room to spread out.
