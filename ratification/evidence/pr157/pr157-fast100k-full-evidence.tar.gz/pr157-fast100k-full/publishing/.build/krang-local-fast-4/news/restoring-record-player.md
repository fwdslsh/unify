---
title: Restoring a 1970s record player
layout: /_includes/layout.html
date: 2025-10-28T09:00:00Z
author: Tomáš Vele
schema: BlogPosting
description: A neighbour brought in a Sony GXP-310 that hadn't played since '84. We replaced the belt, cleaned the contacts, and heard Bowie through it again.
og:image: /news/cards/record.svg
---

# Restoring a 1970s record player

A neighbour brought in her late husband's Sony GXP-310 — untouched since 1984. The belt had disintegrated, the tonearm was sticky, and every contact was corroded with age. We spent two sessions: one on mechanical cleanup and a second to test everything live.

The reward came at 2 PM Saturday when we lowered the needle and David Bowie's *Let's Dance* filled the workshop. Three cheers followed by a request for the next track.

<!-- Placeholder SVG -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 150" width="100%" style="max-width:400px;margin-top:2rem">
  <rect width="400" height="150" rx="8" fill="#e07b39" opacity="0.1"/>
  <text x="200" y="80" text-anchor="middle" font-size="48">&#127911;</text>
</svg>

If you've got vintage tech gathering dust, bring it along. We love a challenge.
