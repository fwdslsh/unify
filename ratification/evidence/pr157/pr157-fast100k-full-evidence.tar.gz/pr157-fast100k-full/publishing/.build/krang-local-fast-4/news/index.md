---
title: News — Bellwick Repair Collective
layout: /_includes/layout.html
---

<main>
  <h1>News</h1>
  <p>Stories from the workshop, written by volunteers.</p>

  <ul class="news-index">
    <li>
      <span class="post-date">3 Nov 2025</span>
      <a href="/news/first-kettle-day.html">First repair day of 2025 — a flood of broken kettles</a>
    </li>
    <li>
      <span class="post-date">28 Oct 2025</span>
      <a href="/news/restoring-record-player.html">Restoring a 1970s record player</a>
    </li>
    <li>
      <span class="post-date">14 Oct 2025</span>
      <a href="/news/toy-clinic.html">Toy clinic — drones, ducks and a very patient soldering iron</a>
    </li>
    <li>
      <span class="post-date">7 Oct 2025</span>
      <a href="/news/new-parts-bin.html">New parts bin — how the community built our supply cabinet</a>
    </li>
  </ul>
</main>
