---
title: First repair day of 2025 — a flood of broken kettles
layout: /_includes/layout.html
date: 2025-11-03T09:00:00Z
author: Mara Jenkins
schema: BlogPosting
description: Over twenty residents brought in kettle after kettle. We stripped descale, rewired switches, and kept every unit out of the skip.
og:image: /news/cards/kettle.svg
---

# First repair day of 2025 — a flood of broken kettles

It was the busiest Tuesday we've seen since we opened last January. **Twenty-three** people turned up with dead or dying electric kettles — limescale build-up, faulty thermocouples, cracked bases. We had three technicians on soldering and two on descaling duty, plus a tea station that worked overtime.

By 9 PM, twelve were back in working order. The others got tagged for parts-harvesting: good switches from dead bodies, working elements salvaged into new builds. Not a single plastic shell hit the bin.

We learned something unexpected — most kettle failures are electrical, not mechanical. A blown fuse or cracked solder joint on the power board is cheaper to fix than a replacement unit costs. That's one less reason to buy new.

<!-- Placeholder SVG -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 150" width="100%" style="max-width:400px;margin-top:2rem">
  <rect width="400" height="150" rx="8" fill="#e07b39" opacity="0.1"/>
  <text x="200" y="80" text-anchor="middle" font-size="48">&#9881;</text>
</svg>

We'll be back next month — same time, same place. Bring your own kettle; we provide the tools and the stubbornness.
