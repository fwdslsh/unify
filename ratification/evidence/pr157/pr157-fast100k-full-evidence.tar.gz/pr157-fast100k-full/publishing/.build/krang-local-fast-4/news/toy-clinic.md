---
title: Toy clinic — drones, ducks and a very patient soldering iron
layout: /_includes/layout.html
date: 2025-10-14T09:00:00Z
author: Priya Nair
schema: BlogPosting
description: Thursday saw twelve toys under the bench. Drones, talking bears, LED trains — we sorted them all and the parents were thrilled.
og:image: /news/cards/toy.svg
---

# Toy clinic — drones, ducks and a very patient soldering iron

Thursday was toy day in the workshop. Twelve items arrived over two hours: a cracked DJI Mini, a talking bear that wouldn't wake up, an LED train set with a dead controller board, and four more besides.

The biggest win was the drone. A loose servo connector had been killing the gimbal signal; a ten-minute re-solder job brought it back to full flight capability. The kid who owned it couldn't stop smiling.

<!-- Placeholder SVG -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 150" width="100%" style="max-width:400px;margin-top:2rem">
  <rect width="400" height="150" rx="8" fill="#e07b39" opacity="0.1"/>
  <text x="200" y="80" text-anchor="middle" font-size="48">&#127968;</text>
</svg>

Toy clinic returns every fourth Thursday — watch this space for dates. Bring the toy, the charger, and the spare batteries if you have them.
