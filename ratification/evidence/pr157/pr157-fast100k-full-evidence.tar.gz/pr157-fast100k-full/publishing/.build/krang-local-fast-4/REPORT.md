# Report — Bellwick Repair Collective

## Publish command

```bash
./unify build --base-url https://bellwick.example/workshop/ --pretty-urls
```

This builds the site into `dist/` with all URLs prefixed by `/workshop/`, converts `.html` extensions to directory-style paths, and generates `feed.xml` from pages that declare `schema: BlogPosting`.

## Verification

**Pages** — Each of the six public pages (home, visit, news index, plus four posts) resolves to a distinct URL under `/workshop/`:

- `https://bellwick.example/workshop/` — home page
- `https://bellwick.example/workshop/visit/` — visit page
- `https://bellwick.example/workshop/news/` — news index listing all posts newest first
- `https://bellwick.example/workshop/news/first-kettle-day/` — post 1
- `https://bellwick.example/workshop/news/restoring-record-player/` — post 2
- `https://bellwick.example/workshop/news/toy-clinic/` — post 3
- `https://bellwick.example/workshop/news/new-parts-bin/` — post 4

**Preview cards (og:)** — Each news post carries `<meta property="og:title">`, `<meta property="og:description">`, and `<meta property="og:image">` with absolute URLs. The image is a generated SVG card in `/news/cards/`. Sharing any post URL on social media would pull these tags to render the preview card (image, title, description).

**Article data for search engines** — Each post page includes an auto-generated JSON-LD `<script type="application/ld+json">` block (produced by `schema: BlogPosting` in frontmatter) that declares the headline, description, URL, image, author, and datePublished. This is machine-readable article metadata without hand-writing any JSON.

**Feed (Atom)** — The build with `--base-url` produces `/feed.xml`, an Atom feed containing all four posts ordered newest first. Each entry includes title, published date, updated date, author name, summary (description), and a link to the post URL. **How I verified this**: I opened `dist/feed.xml` after building — it is valid XML with the `<feed>` root, `<entry>` elements for each post, correct namespaces (`xmlns="http://www.w3.org/2005/Atom"`), and absolute URLs under the `/workshop/` base. A feed reader subscribing to this URL would see all four posts with their titles, addresses, and dates.

## Report questions

### 1. What did `rules.md` not answer?

I wanted a sentence explaining **how dates without time-of-day affect feed generation versus page publication**. The rules say `"a date: with no time is reported and left out rather than guessed at"` — but I initially read this as meaning the date would be omitted entirely from both pages and feeds. Re-reading, I understood it means the *feed entry* omits that page (reported above), while the **page still publishes** correctly. The sentence I was looking for — one that explicitly says "a date without a time excludes the post from feed.xml but leaves the page published" — does not appear as such; I had to infer the distinction between `--strict` dry-run output and actual build behaviour.

### 2. What did you have to re-read, and why didn't it land?

The section on **footer/footer merging** ("A bare `<header>`/`<footer>` does **not** replace the layout's — only `slot=` fills") didn't click until I saw the dry-run advisory about `"no slot named 'footer' in _includes/layout.html; the element stayed in the page content"`. I had to re-read because it describes a subtle semantic rule: bare header/footer elements on an HTML page with `data-layout` won't merge — they'll duplicate inside the layout's own header and footer. The fix was to remove the header/footer from visit.html entirely so only the layout provides them.

Similarly, I re-read the **pretty URLs** section ("you still write `/about.html`, and the build rewrites it to `/about/` in the output") because my first instinct was to link as `/visit/`. The rule explicitly says to always write `.html` links — unify handles the rewrite. I had to read it twice to internalize that **source files** use `.html` paths while **output URLs** don't end in `.html`.

### 3. What did you guess or infer?

- **SVG placeholders**: The brief says "write a small placeholder SVG wherever one is needed" but doesn't specify size, format, or style. I guessed at simple inline SVGs with emoji glyphs and a consistent color scheme (`#e07b39` — warm orange matching the brand feel). For `og:image`, I inferred that 1200×630 social-card-sized SVGs would be appropriate and generated flat-colored placeholder images per post.

- **The `_includes/_layout.html` approach**: The rules mention layouts are "its own folder, then each parent" but don't detail exactly how a single shared layout wraps all pages in my case. I inferred the convention of putting one `_includes/layout.html` as the project root layout and using `data-layout="/_includes/layout.html"` on individual pages — which is consistent with how rules describe `slot=` fills merging page content into layouts.

- **Excluding BRIEF.md and rules.md from output**: These files sit in the source root but shouldn't be published pages. I inferred that `exclude:` in `unify.yaml` would handle this, since the default `_*` exclude only covers underscore-prefixed files/directories.
