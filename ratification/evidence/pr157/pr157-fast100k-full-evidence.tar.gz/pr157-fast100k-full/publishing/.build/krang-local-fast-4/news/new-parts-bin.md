---
title: New parts bin — how the community built our supply cabinet
layout: /_includes/layout.html
date: 2025-10-07T09:00:00Z
author: Elena Vasquez
schema: BlogPosting
description: Volunteers donated capacitors, resistors, motors and screws. Our new parts cabinet has every repairer covered for months.
og:image: /news/cards/parts.svg
---

# New parts bin — how the community built our supply cabinet

Last Saturday evening turned into a full volunteer effort: six people cleared out the corner of the workshop that had become a graveyard of loose components. What started as a clean-up became something much bigger.

We built a three-tier parts cabinet from pallet wood donated by the hardware store next door. Every shelf is labelled — capacitors, resistors, small motors, screws by thread pitch, relays, LEDs, connectors. A neighbour who works at a recycling centre also donated a full box of tested components from e-waste they'd processed.

<!-- Placeholder SVG -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 150" width="100%" style="max-width:400px;margin-top:2rem">
  <rect width="400" height="150" rx="8" fill="#e07b39" opacity="0.1"/>
  <text x="200" y="80" text-anchor="middle" font-size="48">&#128230;</text>
</svg>

If you have spare components, bring them in and label what they are. Every capacitor we don't have to buy is a win for the landfill tally.
