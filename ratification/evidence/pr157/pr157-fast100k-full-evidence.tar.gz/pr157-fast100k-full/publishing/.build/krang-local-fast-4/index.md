---
title: Bellwick Repair Collective
layout: /_includes/layout.html
---

<main class="hero">
  <h1>Repair. Reuse. Share.</h1>
  <p>Bellwick Repair Collective is a volunteer-run workshop where you bring the broken things
     and together we make them work again. We fix toasters, radios, lamps, bikes, toys —
     anything with a plug or a screw. Nothing goes to landfill if we can help it.</p>

  <h2>What we do</h2>
  <ul>
    <li><strong>Come and try:</strong> bring your own broken device or watch us work on yours.</li>
    <li><strong>Skill-sharing:</strong> learn basic repair techniques from experienced volunteers.</li>
    <li><strong>No-waste pledge:</strong> every fix is one less thing in the dump.</li>
  </ul>

  <h2>New to repairing?</h2>
  <p>We love beginners. Bring curiosity, patience, and a willingness to get your hands dirty.
     We'll provide the tools; you bring the items.</p>

  <!-- Placeholder SVG for illustration -->
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 150" width="100%" style="max-width:400px;margin-top:2rem">
    <rect width="400" height="150" rx="8" fill="#e07b39" opacity="0.1"/>
    <text x="200" y="80" text-anchor="middle" font-size="48">&#9881;</text>
  </svg>
</main>
