---
title: Tool Library — Now Open for Members
description: We've set up a proper tool library and any regular volunteer can borrow from it. Over 80 tools registered so far, from drill-sockets to multimeters. No more losing your own screwdriver to the bench drawer.
author: Clara (tools & space)
date: 2025-10-04T16:00:00Z
schema: Article
og:image: /news-icon.svg
---

## Borrowing Tools Now Easier

When you've six benches and three rooms worth of tools, losing your screwdriver to the bench drawer happens every week. So we set up a proper tool library — numbered hooks on a pegboard, with a notebook for signing items out.

There are currently **82 tools registered**, including:
- Power drills (3) and an angle grinder
- Multimeters (5), soldering stations (4)
- Socket sets from 6 mm to 19 mm
- Oscilloscope, clamp meter, component tester

Every regular volunteer gets a membership card. Sign one of our Tuesday sessions to pick yours up. If you have tools you'd like to contribute to the library, drop them off at reception and we'll log them.
