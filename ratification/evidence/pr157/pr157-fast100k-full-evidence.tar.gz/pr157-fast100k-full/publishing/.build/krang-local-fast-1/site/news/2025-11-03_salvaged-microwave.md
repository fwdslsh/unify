---
title: Salvaged a Working Microwave from the Dump
description: Last Thursday's tip-in day brought in an old LG microwave that was headed for landfill — turns out just the capacitor board needed replacing. We had the parts, and now it heats perfectly again.
author: Priya (electronics)
date: 2025-11-03T14:00:00Z
schema: Article
og:image: /news-icon.svg
---

## A Microwave That Saved Itself

Last Thursday night a neighbour brought in an LG microwave that had been sitting in their shed for two years. The turntable didn't spin and the display was dead — classic symptom of a fried capacitor on the high-voltage board.

We swapped the 1 µF / 2 kV capacitor, cleaned up the corroded board with brush and isopropyl alcohol, and fired it up. Five seconds later the display lit up and the turntable spun for the first time in two years.

**Lesson:** most "broken" microwaves are just one £0.15 component away from working again.
