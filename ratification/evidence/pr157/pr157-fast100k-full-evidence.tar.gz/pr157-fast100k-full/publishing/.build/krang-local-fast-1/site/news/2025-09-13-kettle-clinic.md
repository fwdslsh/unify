---
title: Kettle Clinic — Five Kettles Restored in One Session
description: Our Saturday kettle clinic on 13 September saved five kettles from landfill — a record for one session. All were power-switch failures, easily fixable with a £2 part.
author: Dan (repair)
date: 2025-09-13T11:00:00Z
schema: Article
og:image: /news-icon.svg
---

## Kettle Clinic Report

On Saturday afternoon we ran our first dedicated kettle clinic — bring in any dead kettle and we'll open it, diagnose the fault, and either fix it on the spot or set you up with a repair plan.

Five kettles came through the door. All five had failed power switches (the little button under the lever that trips when the kettle overheats). Each switch costs about £2 from Maplin. Five minutes per kettle and they were all back on the bench working.

**What we learned:** the most common kettle faults are:
1. **Power switch failure** (most frequent) — replace it yourself, or bring it to us.
2. **Lime scale buildup** on the element — descale with vinegar; takes ten minutes.
3. **Worn power cable** near the base — we have spares and can re-terminate in two minutes flat.

If you have a dead kettle at home, don't bin it. Bring it next Saturday — or any session — and we'll take a look for free.
