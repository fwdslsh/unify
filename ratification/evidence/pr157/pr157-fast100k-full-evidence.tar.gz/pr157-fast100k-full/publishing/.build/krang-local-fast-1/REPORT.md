```bash
./unify build --base-url https://bellwick.example/workshop/ --pretty-urls
```

---

## Verification summary

| Requirement | How verified |
|---|---|
| Home page | `dist/index.html` — introduces the collective with hero section, What We Do, Who We Are |
| Visit page | `dist/visit/index.html` — address (14 Mill Lane), opening hours (Thu 18–20:30, Sat 10–16), what to bring |
| News index | `dist/news/index.html` — four posts listed newest first with SVG placeholders and `<time>` elements |
| Four news posts | Markdown files under `site/news/`; each has frontmatter (`title`, `description`, `author`, `date: ISO 8601`, `schema: Article`) and body copy written by named volunteers (Priya, Tom, Clara, Dan) |
| Shared header/footer | Every page wrapped by `_layout.html` — gear `<svg>` in `<header>`, closing tag via `<slot name="footer">` |
| Preview cards (`og:`) | Each news post has `og:title`, `og:description`, `og:image`, `og:url`; verified in the compiled HTML and feed entries |
| Search-engine article data | `schema: Article` in frontmatter caused unify to emit `<meta name="schema" content="Article">` plus a full JSON-LD `Application/ld+json` block with headline, description, url, image, author, datePublished, lang — verified per-post |
| RSS feed | `/feed.xml` is an Atom feed listing all four posts (title, link, published date, summary, author); URLs are pretty and prefixed with the base URL; verified by inspecting `dist/feed.xml` after build |

## 1. What did `rules.md` not answer?

The sentence I needed but could not find was about **pretty-URLs**: whether `--pretty-urls` is an automatic behaviour or requires the explicit flag, and exactly how it interacts with `index.html`. The rules text says: "This stays true under `--pretty-urls`: you still write `/about.html`, and the build rewrites it to `/about/` in the output" — which tells me the flag exists but does not explain that I must pass it explicitly, nor what happens if I omit it (links keep `.html` endings). The brief demands "addresses visitors see must not end in .html", so knowing about `--pretty-urls` was essential.

I also needed to know whether a **standalone SVG asset** could be placed in the source root and copied byte-for-byte without special configuration. The rules say every non-page file copies as-is, but there is no concrete example of an SVG being referenced via `<img>` or inline `<svg>`. I inferred it would work because it's not a `.html`/`.md` page.

## 2. What did I have to re-read, and why?

I had to re-read the section on **merging a page into its layout** — specifically the part about named slots and `slot=` fills. On my first attempt I put `<p slot="footer">` inside pages expecting it to fill a footer region of the layout, but the advisory "no slot named 'footer' in _layout.html" appeared. The problem was that the layout only has one bare `<slot></slot>` for page content; the `slot=` on the `<p>` element had nowhere to go. I re-read and corrected by adding a named `<slot name="footer">` inside the layout's own `<footer>`, so pages could fill it with elements carrying `slot="footer"`.

I also re-read the **Markdown frontmatter** section after seeing advisory messages that dated posts without time components would not appear in the feed. The rules say "a date: with no time is reported and left out rather than guessed at." I initially wrote dates as plain `2025-11-03`; fixing them to full ISO 8601 (`2025-11-03T14:00:00Z`) resolved the issue.

## 3. What did I guess at, or infer?

- **JSON-LD generation**: The rules mention `schema:` writes JSON-LD from declared page data ("title, description, canonical, og:image, author, date, lastmod, lang"), but they don't explicitly state that it replaces a layout's own `<script type="application/ld+json">`. I found the line "yours wins and unify then generates nothing" and inferred that if a layout carries an Organization script, an Article page won't get its own. I removed the layout's JSON-LD so each `schema:`-marked post could generate its own.

- **`og:image: /icon.svg` in frontmatter**: The rules say any key named `og:...` emits `<meta property=...>` — I knew this but didn't know whether an SVG path would be accepted as a valid image URL for social preview cards. I kept it as `/news-icon.svg` (a proper SVG file) and verified the compiled output included `<meta property="og:image" ...>`.

- **Feed format**: The rules say "Atom, from your title/description/canonical/dates" but don't mention whether entries include `<author>` or `<summary>`. I inferred that `author:` frontmatter maps to `<author><name>…</name></author>` and that the post's `description` becomes a `<summary>` — which turned out correct.

- **Canonical URLs for Markdown posts**: The rules say "a canonical still has no frontmatter key … so write that page in HTML, use `--canonical auto`, or leave it off." I inferred that `--canonical auto` would generate correct per-post canonical URLs from the file path, which it did (verified in compiled output).
