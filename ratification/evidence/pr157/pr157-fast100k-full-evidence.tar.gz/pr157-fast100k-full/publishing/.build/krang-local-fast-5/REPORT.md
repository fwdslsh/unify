# Report — Bellwick Repair Collective Site

## Publish command line

```bash
./unify build --base-url https://bellwick.example/workshop/ --pretty-urls
```

## What did `rules.md` not answer?

The single sentence I needed but could not find is one about **how to handle `<footer>` elements in pages alongside a layout's footer slot**. Specifically: what happens when a page already has a bare `<footer>` (not using `slot=`) AND the layout also provides a `<slot name="footer">`? The rules say "a bare `<header>`/`<footer>` does not replace the layout's", which I read to mean it would be inert — but in practice, with the layout having `<slot name="footer">`, the page's bare `<footer>` became an additional element alongside the layout's slot-based footer. I had to re-read this three times because the distinction between "bare elements are ignored" and "the first default-content main unwraps" made me expect that a footer outside `<main>` would simply not affect the layout at all — but instead it appended after.

## What did you have to re-read, and why?

I had to re-read **rules.md §4 (Merging a page into its layout)** multiple times because the interaction between `slot=`, bare elements, and named slots in layouts was ambiguous. The first time I read "A bare `<header>`/`<footer>` does not replace the layout's" — I assumed it meant those elements would be silently ignored by the merge system. In reality (as observed after building), they do appear in the output but as siblings to whatever the layout produces. This forced me to remove explicit footers from pages and rely on the layout slot fallback instead.

## What did you guess at, or infer rather than read?

1. **Image path resolution**: The rules say files inside a leading-underscore directory are excluded from output ("Everything in the source root ships" vs "Anything that is not part of the site — notes, drafts, scratch … goes under a leading underscore"). I initially placed `card.svg` in `_img/`, assumed it would be copied byte-for-byte as an asset, and was surprised when dry-run reported it did not resolve to any emitted file. I inferred the build treats leading-underscore directories as fully excluded (both for inclusion AND for output), so I moved it to `/img/card.svg` and confirmed it worked.

2. **Feed link reference**: The rules say feed.xml is generated from pages with `schema: BlogPosting`. I inferred that a `<link rel="alternate" href="/feed.xml">` in the source would resolve at build time, but dry-run complained. I inferred (correctly) that the issue was the leading slash making it absolute to the source root rather than relative to the including file — switching to `../feed.xml` made it pass.

3. **Pretty URLs and link rewriting**: The rules say "`--pretty-urls`: you still write `/about.html`, and the build rewrites it". I inferred that this meant links like `/news/post.html` would automatically become `/news/post/` in output — which proved correct after building with both `--base-url` and `--pretty-urls`.

## Verification notes

- **Pages**: Each of the 7 pages was checked in `dist/` for correct header (gear SVG), footer, title format (`Page — Bellwick Repair Collective`), and canonical/og meta tags.
- **Preview cards**: Every post page has `<meta property="og:image">`, `<meta property="og:title">`, `<meta property="og:description">`, and `<meta property="og:url">` all pointing to `https://bellwick.example/workshop/...`.
- **Article data (search engines)**: Each post includes a `<script type="application/ld+json">` block with Schema.org `BlogPosting`, containing headline, description, url, image, author, and datePublished — auto-generated from frontmatter.
- **Feed**: The build produced `/workshop/feed.xml` listing all 4 posts with title, URL, date, author, and summary. Verified by reading the file directly; entries appear in newest-first order (Nov 15 → Nov 08 → Oct 28 → Sep 30). A feed reader subscribing to `https://bellwick.example/workshop/feed.xml` would see all post titles, addresses, and dates.
