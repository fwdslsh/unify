---
title: New soldering station donated
date: 2024-11-08T09:00:00Z
author: Tom Rhee
description: A local electronics shop has donated a fully equipped soldering station, letting us repair PCBs and small appliances we could only patch before.
schema: BlogPosting
og:image: /img/card.svg
---

# New soldering station donated

We were overjoyed to hear from Greenfield Electronics on Thornfield High Street. They've been clearing out old workshop gear and offered us everything we could use — including a proper temperature-controlled soldering station, multimeter, and oscilloscope.

This means we can now tackle circuit-board repairs that used to bounce off our bench. A radio brought in last week is already speaking again after its first test on the new kit.

The station sits by the front door. Pop it on if you've been meaning to learn soldering — there's a beginner's guide pinned above it.
