---
title: Open Night — November 15th
date: 2024-11-15T09:00:00Z
author: Maya Patel
description: Join us for an evening of fixing and learning — new tools, new faces. We're opening the workshop doors after a quiet October.
schema: BlogPosting
og:image: /img/card.svg
---

# Open Night — November 15th

October was quiet as some volunteers took leave, but we're back full force in November. Come meet the team, try your hand at soldering, and see what others have fixed this month.

We'll have a kettle on and plenty of screwdrivers to share. No experience needed — just bring whatever's broken and an open mind.

New volunteers are always welcome. If you can fix anything at all, you've got enough to teach someone else.
