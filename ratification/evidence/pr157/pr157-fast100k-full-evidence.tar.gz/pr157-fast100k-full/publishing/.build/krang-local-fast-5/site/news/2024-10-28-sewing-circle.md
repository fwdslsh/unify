---
title: Sewing circle returns this month
date: 2024-10-28T09:00:00Z
author: Priya Desai
description: The sewing volunteer has returned after summer hiatus. Bring your torn jackets, missing buttons, and curtains with shattered rod-pockets.
schema: BlogPosting
og:image: /img/card.svg
---

# Sewing circle returns this month

After a two-month break, Elena's back at the sewing table with a second machine — so we can take on twice as many garments. If you've got a jacket with a missing button, a tear in the seam, or curtains whose rod-pockets have shredded beyond repair, bring them along.

Elena will show anyone who wants to learn the basics: darning socks, replacing zips, taking in waistbands. The machines hum through Thursday afternoons like clockwork.

No sewing experience needed — Elena prefers teaching beginners over experienced sewers, she says "everyone starts with holes."
