---
title: Repair café weekend recap — 17 items saved from landfill
date: 2026-01-18T10:00:00Z
author: Anya Mwangi
description: Our first repair-café event in January saw volunteers fix 17 broken household devices.
schema: BlogPosting
og:image: /img/placeholder.svg
---

# Repair café weekend recap — 17 items saved from landfill

Last weekend was our first proper public repair café and it was a roaring success. We had **34 visitors**, worked through **17 items** that were headed for the tip, and served about eighty cups of tea along the way.

A particularly proud moment came when volunteer Raj Patel managed to resurrect a 1998 CRT television brought in by an elderly resident who refused to believe anything could have been wrong with it. After a thorough diagnosis — a dry joint on the mainboard board — it was back in business and showing pictures brighter than ever.

Other highlights include a repaired food mixer, two clocks restored to ticking perfection, and a hairdryer that someone thought was beyond saving but turned out to be a loose wire.
