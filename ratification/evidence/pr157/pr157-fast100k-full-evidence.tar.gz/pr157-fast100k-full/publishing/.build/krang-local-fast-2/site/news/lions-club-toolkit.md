---
title: New toolkit donated by the Lions Club
date: 2025-11-28T10:00:00Z
author: Tom Brennan
description: The local Lions Club has donated a complete set of hand tools and measuring equipment.
schema: BlogPosting
og:image: /img/placeholder.svg
---

# New toolkit donated by the Lions Club

We were absolutely chuffed when the Bellwick branch of the Lions Club turned up this morning with two large boxes full of tools — everything from multimeters to soldering irons, cable testers, and even a brand-new press for crimping connectors.

Tom from the Lions said, "We've been looking for a good home for these. These things are sitting in our warehouse gathering dust." Our founder Anya Mwangi wiped tears (or maybe tea steam) and accepted them with both hands.

We now have enough equipment to work on up to six items simultaneously. Huge thank-you to the Lions Club — you've made us a very happy workshop.
