---
title: Welcome to Bellwick Repair Collective
date: 2025-11-03T10:00:00Z
author: Priya Sharma
description: Our community repair workshop opens its doors for the first time this November.
schema: BlogPosting
og:image: /img/placeholder.svg
---

# Welcome to Bellwick Repair Collective

I'm over the moon to say that we're officially open. After months of planning, fundraising, and a lot of soldering practice, the Bellwick Repair Collective is ready to help you fix your broken things instead of binning them.

We'll be here every Tuesday and Wednesday evening and Saturday mornings through March. Drop in with anything from a cracked mug to a laptop that won't boot — if it's electrically or mechanically breakable, we'll take a look.

Come along on **Tuesday 4 November**, between 10:00 and 16:00, for our open day. Tea, coffee, and conversation provided. No repair needed — just come and meet us.
