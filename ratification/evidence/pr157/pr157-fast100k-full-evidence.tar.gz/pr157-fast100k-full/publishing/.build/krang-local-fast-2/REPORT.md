# REPORT.md — Bellwick Repair Collective Site Build Report

## Publish command line

```bash
./unify build --pretty-urls --base-url 'https://bellwick.example/workshop/'
```

This produces `dist/` with pretty URLs (no `.html` extensions), canonical links, Open Graph tags made absolute via `--base-url`, a generated Atom feed at `/feed.xml`, and a sitemap at `/sitemap.xml`. The command exits 0 on success.

## What the publish output includes

| Requirement | How satisfied |
|---|---|
| Pages: Home, Visit, News index, 4 news posts | Built from `site/` — HTML pages + Markdown posts |
| Shared header with gear SVG icon | In `_layout.html`, included on every page by the build |
| Shared footer | Fallback in layout's `<slot name="footer">`; each HTML page provides a fill via `slot="footer"` |
| Pretty URLs (no `.html`) | `--pretty-urls` rewrites links and creates `index.html` per directory |
| Subdirectory path `/workshop/` | `--base-url 'https://bellwick.example/workshop/'` prefixes all href/src links |
| Social preview cards | Each post has `og:image`, `og:title`, `og:description`, `og:url` in its `<head>` |
| Search engine article data | `schema: BlogPosting` frontmatter triggers automatic JSON-LD via unify (no hand-written JSON) |
| RSS/Atom feed | `--base-url` + `schema: BlogPosting` on posts → `/feed.xml` Atom with all 4 entries, ordered newest first |

### Feed verification

The generated `/feed.xml` contains four `<entry>` elements with correct `<title>`, `<link rel="alternate">`, `<published>`, and `<author>` fields. Each entry's `href` points to the published address (e.g., `https://bellwick.example/workshop/news/welcome/`). A feed reader subscribing would see each post title, its URL, and publish date — all present in the Atom output above.

## JSON-LD article data verification

Each Markdown post gains a `<script type="application/ld+json">` block automatically from unify:

- `@type: BlogPosting`
- Fields sourced from the page's own declarations: headline (from heading), description (`description:` frontmatter), url (`--base-url` + source path), image (`og:image:`), author, datePublished, inLanguage.

This requires no manual JSON writing — unify derives it from what the markdown frontmatter and head already declare.

---

## Answers to report questions

### 1. What did `rules.md` not answer? Name the sentence you wanted and could not find.

I needed a clear example of how **footer slotting** works in practice. The rules document mentions named slots (`<slot name="X">`) and page fills (`slot="X"`) but never shows a complete pattern where both layout and page collaborate on shared chrome (header + footer). I had to re-read the paragraph about "A bare `<header>`/`<footer>` does **not** replace the layout's — only `slot=` fills, and it fills the *contents*" multiple times. The first reading led me to put a plain `<footer>` tag inside `_layout.html`, which produced nested footers. Only after re-reading did I see that the slot declaration itself (`<slot name="footer">`) is what matters — not wrapping tags around it.

The sentence I wanted but couldn't find: **"Here's exactly how to put chrome (header + footer) in a layout so every page gets it."** Instead, the rules describe the mechanics of slots and merging abstractly. The concrete pattern for shared layout chrome was something I had to infer from the pieces described separately.

### 2. What did you have to re-read, and why did it not land the first time?

I re-read the **layout-slot-merging** section three times — specifically:
- "The first default-content page main unwraps" (rules line ~38)
- The footer rule about bare elements vs. slot fills

On my first read-through, I confused `<slot name="footer">` (the layout's declaration syntax) with `slot="footer"` on a fill element. HTML shadow DOM uses different attribute names (`name=` for the declared slot, `slot=` for the assigned content), and I mixed them up when writing `_layout.html`. The fix came after re-reading the rules line: "The layout writes `<slot name=\"footer\">fallback…</slot>`; the page fills it with `slot=` on a real element."

### 3. Was there anything you guessed at, or inferred rather than read?

Yes — I had to guess how **`og:image:`** frontmatter would behave under `--base-url`. The rules mention that root-relative links miss the `--base-url` prefix and go 404, but for `<meta property="og:…">` attributes (which aren't href/src HTML URL attributes), it was unclear whether unify's base-url rewrite applies. I guessed it does — based on the line "make og:/canonical absolute for share crawlers" in the CLI options help text — and verified by checking that `dist/news/welcome/index.html` shows `og:image: https://bellwick.example/workshop/img/placeholder.svg`.

I also inferred that **markdown posts get their title from the first `# Heading`** if no `title:` key is present (rules line 52 says "No `title:` → first `# Heading`"). This was a deduction, not something explicitly shown in an example. I verified it worked correctly in the output.

The news index page listing had to be **hand-written static HTML** because unify has no loop or template language (`{{ }}`, `{% %}`). The rules confirm this: "Most sites need no configuration file" and pages are plain HTML/MD — a script can derive files but I chose not to write one since there are only four posts. This was an inference from the absence of any indexing/generation feature in the documented vocabulary.
