## 1. Publish command line

```bash
./unify build --clean --base-url https://fernway.example/library/ --pretty-urls
```

## 2. Final check outputs

### Build (exit 0)

```bash
$ ./unify build --clean --base-url https://fernway.example/library/ --pretty-urls
(no output; exit code 0 — dist/ contains the complete site)
```

### `build --dry-run --strict`

```bash
$ ./unify build --dry-run --strict --base-url https://fernway.example/library/
serving from https://fernway.example/library/
canonical completion: 4 pages would gain a canonical link
structured data: 3 pages would gain a JSON-LD block
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
copy dist/images/flower-seeds.svg (/library/images/flower-seeds.svg) ← images/flower-seeds.svg
...
would publish 12 files to dist/

exit code 0 (no problems reported)
```

### `audit --strict`

```bash
$ ./unify audit --strict
audit: nothing to report

exit code 0
```

## 3. What rules.md did not answer — honest answers

**The sentence I wanted but couldn't find:** I needed a clear rule about how `<title>` merging works across the layout and page, specifically whether removing `<title>` from a page lets the layout's title survive intact or whether an empty head is always an error. The rules say "pages never contain `<head>`" for Markdown pages, but HTML pages must be complete documents — including `<head>`. I had to re-read the "Head" section in the layout merging rules twice: *"A page has its own complete `<head>`; the layout's is the base, and where both declare `<meta charset>` the layout's wins."* The second time I noticed that only same-`name`/same-`property` `<meta>` elements are replaced — `<title>` isn't mentioned as something that merges or replaces. When I removed `<title>` from index.html, the build simply used the layout's title unchanged. That was an inference rather than a read.

**What I guessed / inferred:** How `.html.md` vs plain `.md` extensions affect output paths under `--pretty-urls`. The rules say "Always link the real filename — `/about.html`, not `/about/`" and that pretty-urls rewrites links, but they don't explicitly state whether a file named `notes/post.md` (no `.html` in its source name) produces `/notes/post/` or `/notes/post.html/`. I had to try both conventions and inspect the actual output directory to resolve it. The fact that `dist/visit/index.html` appeared (pretty URLs creating a directory structure from a `.html`-named page, but not from a plain `.md` file) was discovered empirically, never read in documentation.

**What I had to re-read:** The section on Markdown frontmatter keys — specifically that `og:…` keys emit `property=` meta tags and that an indented block two levels deep is "an error." This was important because the brief required social preview cards (Open Graph images), which meant adding `og:image`, `og:image:width`, and `og:image:height` to frontmatter. The first time I read it, I missed the colon-in-name nuance — thinking `og:image:width` would be parsed as a nested key rather than a flat meta tag with literal property name. On re-reading I caught that these are three separate flat keys, each emitting its own `<meta>` line.
