---
title: Peering into soil — why some seeds need light
date: 2025-03-01T09:00:00Z
author: Elise Tremont
description: A primer on photoblastic germination and how a handful of common garden crops require surface sowing, explained with notes from three spring trials.
schema: BlogPosting
layout: /notes/_layout.html
og:image: /images/soil-seeds.svg
og:image:width: 1200
og:image:height: 630
---

# Peering into soil — why some seeds need light

Not every seed wants to be buried. Several species that appear in our lending collection are positively photoblastic, meaning they will not germinate unless exposed to daylight after sowing. Elise tested three of the most common examples over two spring months and found consistent results across both trials.

The first trial used 'Nokana' lettuce seeds. Elise sowed half the tray at a depth of one centimetre and left the other half on the soil surface, covered only with clear plastic to hold moisture. After ten days every seed on the surface had sprouted while none beneath the soil did — exactly backwards from what we might expect.

The second trial repeated the pattern with basil 'Genovese'. The pattern held again: germination was essentially zero under a thin covering and nearly total on the exposed surface. Elise recommends sowing photoblastic seeds in trays placed near the window rather than pressing them into the substrate at all.

A small number of seeds — carrots, cosmos, and most brassicas — are negatively photoblastic and prefer being covered. If you're unsure whether a variety needs light, Elise suggests starting from a surface sowing; anything that doesn't respond within the normal window will have died rather than wasted seed in the soil.
