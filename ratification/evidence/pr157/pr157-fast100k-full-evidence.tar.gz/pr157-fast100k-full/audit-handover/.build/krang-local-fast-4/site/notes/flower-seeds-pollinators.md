---
title: Flower seeds for pollinators — a September report
date: 2025-06-10T09:00:00Z
author: Sam Okonko
description: Sam shares what worked and what didn't with native flower seed mixes planted in late August, plus observations about which species drew the most bees.
schema: BlogPosting
layout: /notes/_layout.html
og:image: /images/flower-seeds.svg
og:image:width: 1200
og:image:height: 630
---

# Flower seeds for pollinators — a September report

The pollinator plot at Fernway went up in late August across three beds along the north fence. Sam mixed six native species: coneflower, goldenrod, milkweed, blazing star, bee balm, and wild bergamot. Each bed received roughly forty seeds of its designated variety, broadcast thin and lightly raked into the topsoil.

By mid-September every plot had germinated except the wild bergamot, which Sam replanted from a potted transplant in October. The goldenrod spread faster than expected — it now occupies two full beds and has already pushed against the fence line.

Bee activity was strongest on the bee balm and coneflower rows; Sam counted twelve species of native bees within the first week of bloom. A few members collected seed heads in late autumn, saving roughly three hundred seeds that will be available for spring borrowing under **Pollinator Mix B**.

Sam's notes are still coming together as conditions shift into frost season. Updates will appear here as she files them.
