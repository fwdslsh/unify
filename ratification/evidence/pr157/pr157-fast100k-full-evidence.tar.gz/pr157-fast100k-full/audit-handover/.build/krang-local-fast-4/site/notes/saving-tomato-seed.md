---
title: Saving tomato seed through the summer
date: 2025-08-15T09:00:00Z
author: Mara Chen
description: How our members fermented and dried heirloom cherry tomatoes for next spring's planting, including a tip about keeping jars in the root cellar.
schema: BlogPosting
layout: /notes/_layout.html
og:image: /images/tomato-seed.svg
og:image:width: 1200
og:image:height: 630
---

# Saving tomato seed through the summer

This year we had an unusually early germination window — our 'Sungold' seeds sprouted within five days of sowing, and several members noted how their seedlings responded to less light than usual. Mara tracked each tray under a windowsill lamp and found that the stems stretched 15 % taller when positioned more than thirty centimetres from the glass.

The fermentation step for cherry tomatoes is forgiving but worth doing properly. Leave the seeds sitting in their pulp for three full days at room temperature, then skim and rinse until the water runs clear. Spread them on a plate to dry; they're ready when they no longer clump together.

A few members stored their dried seed in the root cellar through September, wrapping each batch in paper envelopes inside small glass jars. One grower found that keeping the jars off the concrete floor saved a batch of 'Brandywine' from sprouting early. Mara's full method is posted under **Growing Notes**, and she's happy to demonstrate at the next library evening.
