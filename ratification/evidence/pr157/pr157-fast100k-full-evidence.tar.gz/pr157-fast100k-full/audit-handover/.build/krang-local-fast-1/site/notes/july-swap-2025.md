---
title: Seed Swap Success in July 2025
description: Our community seed swap brought together twelve growers and yielded over forty varieties of heirloom tomatoes alone. Here is what we learned from the season so far.
layout: /_layouts/layout.html
schema: BlogPosting
author: Mae Chen
date: 2025-07-14T09:00:00Z
og:image: /og-image.svg
og:image:width: 1200
og:image:height: 630
---

<h1>Seed Swap Success in July 2025</h1>

## A Bumper Crop of Ideas

Twelve growers showed up to the July swap — more than half the current lending pool — and we counted **over forty varieties** of heirloom tomato seed returned that day. Beans, peppers, squash, and a surprising number of rare sunflower lines filled every cabinet drawer.

### What We Learned

- **Saving at altitude matters.** Several growers reported thinner seed coats after two weeks in the dry shed. Next time we'll provide hygrometers.
- **Cross-pollination was lower than expected.** Isolation distances in suburban gardens are holding up — good news for varietal purity.
- **The bean line is a star.** Dry lima saved last year has been growing steadily vigorous. Two growers reported zero pod-borer damage all season.

We're already planning next swap date. If you'd like to join the mailing list, drop by on Tuesday or Thursday — we collect names at the door and send calendar reminders when the swap is due.
