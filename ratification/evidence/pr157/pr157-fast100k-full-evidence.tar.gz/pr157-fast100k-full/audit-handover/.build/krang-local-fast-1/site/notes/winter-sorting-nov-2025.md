---
title: Winter Seed Sorting Notes
description: As the garden sleeps, we spend November sorting, weighing, and storing the season's returned seed. Here is our checklist and what to expect next spring.
layout: /_layouts/layout.html
schema: BlogPosting
author: Sam Okonkwo
date: 2025-11-03T09:00:00Z
og:image: /og-image.svg
og:image:width: 1200
og:image:height: 630
---

<h1>Winter Seed Sorting Notes</h1>

## Clearing the Shelves

November means sorting season at Fernway. Every returned packet goes through the same three steps:

1. **Clean** — remove chaff, husks, and any remaining debris by hand or gentle winnowing.
2. **Weigh** — record seed weight against the original lent amount. This is how we track health of each variety.
3. **Store** — dry seeds go into paper envelopes labelled with variety, date saved, and grower name.

### Variety Highlights

| Variety | Growers | Avg Return % | Notes |
|---------|--------|--------------|-------|
| 'Grape' Tomato | 9 | 185% | Strong year; clean seed |
| 'Rattlesnake' Bean | 6 | 210% | Best dry bean we've saved yet |
| 'Carmen' Sunflower | 4 | 140% | First run — watch vigour next spring |

### What's Coming in Spring

We'll be opening the lending cabinets on **March 3**, with coffee and a quick growing overview. New this year: a trial plot for **indigo carrot** and **golden beet**. If you'd like to try either, come by in person — we keep a short list of who wanted what.
