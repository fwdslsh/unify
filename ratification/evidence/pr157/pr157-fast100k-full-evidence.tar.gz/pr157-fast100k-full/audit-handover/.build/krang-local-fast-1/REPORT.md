# Report — Fernway Seed Library

## Publish Command Line

```bash
./unify build --base-url https://fernway.example/library/ --pretty-urls --strict --audit
```

This builds `dist/` with pretty URLs, runs all checks (`--strict` treats advisories as problems, `--audit` audits before publishing), and exits 0 only when everything passes.

## Final Check Outputs

### Build output (`./unify build`)

```
Exit: 0
```

The build produced 12 files in `dist/`: the three page sets (home, visit, notes), the notes index, three note post pages, styles, SVG assets, feed.xml, and sitemap.xml.

### Audit output (`./unify audit`)

```bash
$ ./unify audit --base-url https://fernway.example/library/ --pretty-urls
audit: nothing to report
Exit: 0
```

Zero broken, zero incomplete, zero problems — the coordinator's acceptance criteria are met.

## What `rules.md` Did Not Answer

**1. The `<h1>` requirement.** I needed a sentence saying "Markdown pages with frontmatter titles do not automatically receive an `<h1>`; add one yourself" or "the audit will flag missing `<h1>` on every page." That sentence does not exist in `rules.md`. Rules.md describes layout merging, frontmatter keys, schema generation, and merge rules — but never mentions accessibility requirements like having exactly one `<h1>` per page. The first time I built, the notes posts had no visible `<h1>`, only an `<h2>` from the markdown parser. I re-read rules.md several times looking for where it discussed headings or accessible page structure, and the sentence about `og:image:width`/`og:image:height` was the closest thing to a requirement list — but nothing mentioned heading structure. I had to add an explicit `<h1>` element to each note's body content after seeing the audit complain.

**2. The "description-missing" check.** Rules.md describes how frontmatter `description:` becomes `<meta name="description">`, and that HTML pages never have frontmatter — but it never says anything about a build tool requiring `<meta name="description">` on every page for SEO or accessibility purposes, nor mentions a `[description-missing]` advisory. I re-read rules.md looking for how to add descriptions to pure-HTML pages; the only guidance was "use `<head>`" and that HTML pages never have frontmatter (which would render as visible text). I inferred from this that I should put `<meta name="description">` directly in the page's `<head>`, which is what I did.

**3. What I guessed at.** The rules say "`schema: BlogPosting` ... writes the page's JSON-LD for you, from what the page already declares" — I inferred that this means `author`, `date`, `description`, and `og:image` frontmatter keys would combine into valid schema.org BlogPosting JSON-LD. It turned out correct (I verified the output). I also guessed that adding `og:image:width` and `og:image:height` as separate frontmatter keys with a colon in their name would produce `<meta property="og:image:width" ...>` tags — which was exactly right per rules.md's description of how colons work. But I did not know the audit tool existed (it runs separately from `build`) or that it would complain about missing image dimensions; that information came from running `unify audit`, not from reading `rules.md`.
