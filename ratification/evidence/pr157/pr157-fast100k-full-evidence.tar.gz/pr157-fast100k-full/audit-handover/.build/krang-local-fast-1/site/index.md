---
title: Home
layout: /_layouts/layout.html
schema: WebPage
description: Borrow fresh seeds for your garden, return what grows at season's end.
---

<div class="hero">
  <h1>Fernway Seed Library</h1>
  <p>Borrow fresh seeds for your garden, return what grows at season's end. Every seed shared is a harvest returned — a living exchange that keeps seeds local, adaptable, and free.</p>
  <a href="/visit.html" class="cta">Plan Your Visit</a>
</div>

<section class="about">
  <h2>How It Works</h2>
  <p>Fernway Seed Library collects heirloom and open-pollinated seeds from the region's growing season. Local gardeners borrow seed packets in spring, plant them, and return freshly harvested seed at autumn's close — ready for next year's planting.</p>

  <p>This is more than lending; it's community seed sovereignty. Over time our collection becomes better suited to local soil, climate, and pest pressure. Growers gain access to rare varieties they might not otherwise find.</p>
</section>

<section class="featured">
  <h2>What We Grow</h2>
  <div class="card-grid">
    <div class="card">
      <img src="/seed-mark.svg" alt="" role="presentation">
      <h3>Vegetables</h3>
      <p>Tomatoes, beans, peppers, squash, and all the staples of a kitchen garden — adapted to our growing zone.</p>
    </div>
    <div class="card">
      <img src="/seed-mark.svg" alt="" role="presentation">
      <h3>Flowers</h3>
      <p>Pollinator-friendly blooms, cut flowers for the vase, and wildflowers that bring colour to every season.</p>
    </div>
    <div class="card">
      <img src="/seed-mark.svg" alt="" role="presentation">
      <h3>Herbs</h3>
      <p>Basil, mint, dill, chervil — herbs that seed easily and come back year after year.</p>
    </div>
  </div>
</section>
