---
title: Spring Lending Day Recap — March 2025
description: The first lending day of the season saw seventy visitors borrow seeds for over forty garden beds across the community. Here is a snapshot and tips from our veteran growers.
layout: /_layouts/layout.html
schema: BlogPosting
author: Mae Chen
date: 2025-03-10T09:00:00Z
og:image: /og-image.svg
og:image:width: 1200
og:image:height: 630
---

<h1>Spring Lending Day Recap — March 2025</h1>

## Doors Open Wide

Seventy visitors came through on Saturday morning — rain, cold wind, and everyone seemed thrilled. We handed out **seed packets for thirty-five raised beds** and another twenty-something in the community plot at the school.

### First-Time Growers

Three people told us it was their first time saving seed. Here is what they found most helpful:

- The **quick-reference card** we hand with each packet, showing spacing and thinning rules.
- A **text reminder system** (free) that fires one message before your area's last frost date.
- **Pairing up** — we matched two newcomers with returning growers who mentored them through April planting.

### Seed Count Snapshot

We started the season with **218 varieties** catalogued and ready. The fastest-selling lines were:

1. 'Sungold' tomato — 48 packets
2. 'Dragon's Tongue' bean — 37 packets
3. 'Aurora' lettuce — 34 packets

By mid-May we'll post a growth report with tips on thinning beans and training tomatoes up the trellis. If you have questions before then, come by — we're open every Tuesday and Thursday.
