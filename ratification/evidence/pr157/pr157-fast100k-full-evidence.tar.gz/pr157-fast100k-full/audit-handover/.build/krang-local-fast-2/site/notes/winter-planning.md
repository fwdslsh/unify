---
title: Winter Planning – Which Seeds to Borrow Next Season
date: 2025-12-01T09:00:00Z
author: Amara Osei-Bonsu
description: An end-of-season look at what we grew, what worked, and the seed varieties we recommend borrowers pick up for next spring.
schema: BlogPosting
og:image: /notes/winter-planning.svg
og:image:width: 800
og:image:height: 400
---

# Winter Planning – Which Seeds to Borrow Next Season

**By Amara Osei-Bonsu · December 1, 2025**

December is a quiet month at Fernway, but the shelves are still full of packets. The difference now is that we can recommend which ones based on what actually grew last season.

## What worked well

- **Carrots (Chantonnay variety)** — Our soil is sandy loam, and Chantonnay handled it beautifully. Two borrowers returned seed; both batches were viable.
- **Sunflower (American Giant)** — Easy from seed, tall enough to attract pollinators, and the seeds are popular with our bird guests. Every borrower managed full germination.
- **Radish (French Breakfast)** — Fastest crop in our shared garden. You can sow them under cloche all winter and they will be ready before lettuce.

## What struggled

Pepper seed is always risky indoors, especially when borrowers try it in November rather than waiting for February. The Fernway packets are high quality, but germination drops sharply below fifteen degrees Celsius. If you must start early, a heated propagator is non-negotiable.

## My recommendations for 2026 borrowings

| Crop             | Variety            | Difficulty |
|------------------|--------------------|------------|
| Beetroot         | Boltardy           | Easy       |
| Lettuce          | Winter Density     | Moderate   |
| Broad Bean       | Aquadulce Claudia  | Easy       |
| Sweet Pea        | Spencer Mixed      | Easy       |

<div class="post-image" aria-hidden="true">
  <svg xmlns="http://www.w3.org/2000/svg" width="800" height="400" viewBox="0 0 800 400">
    <rect fill="#e9f0df" width="800" height="400"/>
    <rect x="310" y="150" width="60" height="100" rx="4" fill="#c4a76a"/>
    <text x="340" y="205" text-anchor="middle" font-size="14">WINTER</text>
    <rect x="430" y="150" width="60" height="100" rx="4" fill="#c4a76a"/>
    <text x="460" y="205" text-anchor="middle" font-size="14">SPRING</text>
    <line x1="370" y1="250" x2="430" y2="250" stroke="#5a7c47" stroke-width="2"/>
    <path d="M428 246 L440 250 L428 254" fill="#5a7c47"/>
    <circle cx="395" cy="300" r="15" fill="#8fbf5a"/>
    <circle cx="395" cy="300" r="6" fill="#e9f0df"/>
  </svg>
</div>

## A note on sharing plans

If you are unsure what to grow, drop into the library any Tuesday evening and ask. The volunteers keep a notebook of past seasons' results — including which borrowers returned seed successfully. It is a great way to find out what your neighbours think works in this patch of soil.
