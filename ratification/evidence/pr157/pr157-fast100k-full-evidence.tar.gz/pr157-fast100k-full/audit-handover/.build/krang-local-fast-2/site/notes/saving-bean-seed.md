---
title: Saving Bean Seed Through a Humid Summer
date: 2026-05-14T09:00:00Z
author: Martha Penrose
description: A volunteer shares how to dry and store bean seeds when the summer humidity makes natural drying difficult.
schema: BlogPosting
og:image: /notes/saving-bean-seed.svg
og:image:width: 800
og:image:height: 400
---

# Saving Bean Seed Through a Humid Summer

**By Martha Penrose · May 14, 2026**

This year's summer was unusually damp, and beans can be tricky when the air won't cooperate. Here is what I learned after borrowing Broad Bean packets from Fernway last spring and returning decent seed in September.

## Why humidity is a problem

Bean pods look dry long before the seeds inside have lost enough moisture for safe storage. If you crack open a pod too soon, the seed feels soft — that is still plenty of water inside, and it will rot in your jar over winter.

## My method

1. **Harvest when pods rattle.** Even if the surrounding foliage looks green, listen. A dry shake means rattling seeds inside.
2. **Shuck immediately.** Crack open every pod and lay seeds on a tray.
3. **Use a fan.** In our small community hall I set up an old desktop fan pointed at the tray for three days. No heat — just air.
4. **Store in paper bags first**, then transfer to glass jars once you're sure they are dry. A coin tossed into the jar picks up condensation overnight if moisture is still present.

## What we returned

Our group saved roughly two hundred grams of Broad Bean and runner bean seed, cleaned and weighed at our June handover. That same amount feeds about forty borrowers next spring.

<div class="post-image" aria-hidden="true">
  <svg xmlns="http://www.w3.org/2000/svg" width="800" height="400" viewBox="0 0 800 400">
    <rect fill="#e9f0df" width="800" height="400"/>
    <ellipse cx="400" cy="210" rx="130" ry="75" fill="#d4e0c3"/>
    <circle cx="360" cy="190" r="18" fill="#f5eedd"/>
    <circle cx="410" cy="200" r="22" fill="#f5eedd"/>
    <circle cx="370" cy="220" r="16" fill="#f5eedd"/>
    <circle cx="430" cy="225" r="14" fill="#f5eedd"/>
    <path d="M400 90 Q420 130 400 170" stroke="#8fbf5a" stroke-width="6" fill="none"/>
  </svg>
</div>

## Final thought

Bean seed saved well was our biggest return ever. If you're new to saving, start with beans — they are forgiving and the learning curve is gentle.
