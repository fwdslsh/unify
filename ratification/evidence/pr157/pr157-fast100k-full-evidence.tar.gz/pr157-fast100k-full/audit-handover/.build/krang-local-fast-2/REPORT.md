## Publish command line

```bash
./unify build --clean --pretty-urls --base-url https://fernway.example/library/ --catalog --search-corpus
```

## Final check outputs

### `./unify audit`

```
audit: nothing to report
```

Command: `./unify audit` — exit 0.

### `./unify audit --strict`

```
audit: nothing to report
```

Command: `./unify audit --strict` — exit 0.

### `./unify audit --external`

```
audit: nothing to report
```

Command: `./unify audit --external` — exit 0.

### `./unify build --dry-run --strict`

```
serving from / — the domain root (no --base-url)
structured data: 3 pages would gain a JSON-LD block
delete dist/feed.xml
write dist/index.html (/) ← index.html + _layout.html
...
would publish 10 files to dist/
```

Command: `./unify build --dry-run --strict` — exit 0. No problems reported.

## What rules.md did not answer

**"The sentence I wanted and could not find"**

> "What is the real filename for a `.md` page, so I know how to link to it?"

rules.md says: "Always link the real filename — `/about.html`, not `/about/`. This stays true under `--pretty-urls`: you still write `/about.html`, and the build rewrites it to `/about/` in the output." But for Markdown pages there is no `.html` extension in source. The rules don't explicitly state whether to link via the bare slug name or add a `.html` suffix — I had to discover through trial that `--pretty-urls` handles both, while audit (without `--pretty-urls`) resolves against plain `.html` output for md pages.

**What I had to re-read and why it did not land the first time**

I re-read section 7 ("Merging a page into its layout") multiple times — specifically how named slots interact with default-content `<main>`. On my first attempt I put both `slot="content"` on `<nav>` and a bare `<slot></slot>` inside `<main>`, which the tool flagged as "named slot 'content' is inside <main>, which is also the default-content sink". The fix was to use only one bare `<slot></slot>` inside `<main>` for default content, since the layout's own `<nav>` fills via `slot=` without needing a named slot at all.

**What I guessed or inferred rather than read**

I inferred that `<include>` tags in layouts could also be used alongside `slot=` elements, which worked fine — but I initially thought they might conflict. The rules don't explicitly address mixing `<include>` with slots, so I tested empirically. Similarly, the behavior of `<meta property="og:image:width">` vs `<meta name="og:image:width">` was deduced from the rule "A key named `og:…` emits `property=` instead" — applying this to image dimensions was inference based on that principle.
