---
title: Sowing Tomatoes in March – Our Volunteer Guide
date: 2026-03-08T09:00:00Z
author: David Okon
description: A step-by-step guide to sowing tomato seed early, from choosing packets at Fernway to potting up seedlings by May.
schema: BlogPosting
og:image: /notes/sowing-in-march.svg
og:image:width: 800
og:image:height: 400
---

# Sowing Tomatoes in March

**By David Okon · March 8, 2026**

March is the month that decides your summer tomatoes. We have been lending Cherry Tomato and Beefsteak packets since 2019, and I have accumulated enough mistakes to make a proper guide.

## Choosing your packet

When you borrow in February, think about what you want at harvest. Cherry types ripen early and are reliable in cooler springs — pick them if you live where May can still drop below five degrees. Beefsteaks need heat, so only choose those if you have a greenhouse or very sheltered south wall.

## The sowing process

1. **Fill small cells** with compost labelled for seedlings. Do not use garden soil; it compacts and drowns the roots.
2. **Sow two seeds per cell**, half a centimetre deep. A cocktail stick makes an ideal hole.
3. **Cover with cling film** to trap moisture, then place on top of the fridge or near the radiator — never directly on heat. Germination takes ten days at room temperature; sooner if it is warmer.
4. **Remove the film** as soon as you see green cotyledons, and move cells to a bright windowsill.

## From sowing to planting out

By mid-May, your seedlings should have their first set of true leaves. Harden them off gradually over ten days before moving outdoors. The Fernway lending card includes a handout with more detail on feeding and tying once the plants are outside.

<div class="post-image" aria-hidden="true">
  <svg xmlns="http://www.w3.org/2000/svg" width="800" height="400" viewBox="0 0 800 400">
    <rect fill="#e9f0df" width="800" height="400"/>
    <rect x="350" y="140" width="100" height="60" rx="6" fill="#c4a76a"/>
    <line x1="400" y1="200" x2="400" y2="160" stroke="#5a7c47" stroke-width="3"/>
    <ellipse cx="385" cy="155" rx="14" ry="8" fill="#8fbf5a"/>
    <ellipse cx="415" cy="155" rx="14" ry="8" fill="#8fbf5a"/>
    <circle cx="360" cy="320" r="35" fill="#e9f0df" stroke="#c4a76a" stroke-width="2"/>
    <rect x="352" y="310" width="16" height="10" rx="2" fill="#8fbf5a"/>
  </svg>
</div>

## A note on patience

Tomatoes reward slow growing. Do not rush the heat; do not overwater. I have lost more seedlings to drowning than to cold. Next time I will try my luck with a late-sown batch and report back in August.
