---
title: Our favourite flower seeds this season
layout: /_layout.html
description: Cosmos, sunflowers, and sweet peas top the list of most-requested flower varieties — plus a surprise entry from a first-year grower.
date: 2026-03-15T09:00:00Z
author: Priya Nair
schema: BlogPosting
og:image: /notes/images/flower-seeds.jpg
og:image:width: "800"
og:image:height: "400"
---

# Our favourite flower seeds this season

## Cosmos: easy, abundant, endlessly popular

If you are new to the library and want a flower that gives back generously, start with cosmos. The Celestial Cherry tomato is our best-selling vegetable, but for flowers, cosmos wins by a wide margin. Plant thickly, let seeds set naturally, and brush them dry — you will have enough to share at next spring's swap and still colour your own garden all summer long.

## Sunflowers: the giant variety

The Ember sunflower is another crowd favourite. These produce large, heavy seed heads that are easy to harvest. Let the heads droop naturally on the stem; when they turn brown and the centre feels rough rather than soft, cut and hang upside down in a dry spot. Strip the seeds with your hands and store as you would any vegetable seed — cool, dry, sealed.

## Sweet peas: a first-year surprise

Sweet peas were not originally part of our programme, but a member asked to borrow some last spring and returned with three bags of seed in August. Since then they have been our fastest-growing flower category. They self-seed freely in gardens, so even one planting yields multiple harvests. The seed coat is thick enough that viability lasts four or five years if stored properly — perfect for a library model.

## What to note on your labels

When you return sweet pea seed, please write not just the variety name but also the colour and whether it was double or single bloom. These distinctions matter next season when growers choose their packets. A short sentence about how the plant performed in your garden is helpful too — soil type, sun exposure, any pest issues.
