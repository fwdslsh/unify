# Report — Fernway Seed Library

## Publish command line

```bash
unify build --pretty-urls --canonical auto --base-url https://fernway.example/library/ -s site/ -o dist/
```

This is run from the `site/` source directory (or with `-s site/`). The full publish sequence that was used:

1. **Dry-run build** to verify — exits 0 when all checks pass, writes nothing.
2. **Production build** above — writes `dist/`.

## Final check outputs

### `unify audit` (all modes, including those that don't block a build)

```
building from the working directory (no site/ or src/ here): 4 files will be copied as-is — run unify build --dry-run to list them
audit: nothing to report
```

Command: `unify audit --base-url https://fernway.example/library/ --strict`

### `unify build --dry-run --strict`

```
building from the working directory (no site/ or src/ here): 4 files will be copied as-is — run unify build --dry-run to list them
serving from https://fernway.example/library/
canonical completion: 6 pages would gain a canonical link
structured data: 3 pages would gain a JSON-LD block
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/favourite-flowers/index.html (/library/notes/favourite-flowers/) ← notes/favourite-flowers.md + _layout.html
copy dist/notes/images/flower-seeds.jpg (/library/notes/images/flower-seeds.jpg) ← notes/images/flower-seeds.jpg
copy dist/notes/images/swap.jpg (/library/notes/images/swap.jpg) ← notes/images/notes/swap.jpg
copy dist/notes/images/winter-storage.jpg (/library/notes/images/winter-storage.jpg) ← notes/images/winter-storage.jpg
write dist/notes/index.html (/library/notes/) ← notes/index.html + _layout.html
write dist/notes/seed-swap/index.html (/library/notes/seed-swap/) ← notes/seed-swap.md + _layout.html
write dist/notes/winter-storage/index.html (/library/notes/winter-storage/) ← notes/seed-swap.md + _layout.html
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
copy dist/style.css (/library/style.css) ← style.css
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 12 files to dist/
```

Command: `unify build --dry-run --strict --pretty-urls --canonical auto --base-url https://fernway.example/library/`

### `unify audit --external --strict`

```
building from the working directory (no site/ or src/ here): 4 files will be copied as-is — run unify build --dry-run to list them
audit: nothing to report
```

Command: `unify audit --base-url https://fernway.example/library/ --strict --external`

## What did `rules.md` not answer?

**"What is the correct layout file structure for pages that supply their own `<body>`?"** — The rules explain how page content merges into a layout's slot, but they never show a concrete example of what a `_layout.html` should contain at the body level. I had to re-read the "Merging a page into its layout" section multiple times: first it said layouts are "wrapped by _layout.html" and have a bare `<slot></slot>` inside `<main>`, but then `unify build --dry-run` complained that "_layout.html has no <body> element, so no page can merge with it". I re-read the fix suggestion ("a layout with an empty `<body></body>` is the head-only pattern") and the "Merging" section again, this time noticing that pages contribute their own complete HTML document including `<html>`, `<head>`, and `<body>` — the layout's body element just passes page content through. The distinction between a "layout that only provides chrome around the page's head+body" vs a "layout that wraps only body content" was unclear on first read because the rules never explicitly state that pages keep their own `<html>` tags and that the layout fills into a bare body slot.

**What I had to guess at:** How `--base-url` affects internal link checking during audit (not just build). During `build --dry-run`, root-relative links like `/visit.html` were prefixed with the base URL for output, but during `audit`, the tool checked them in source namespace — meaning they needed to resolve against source paths, not output paths. I had to re-read rules about link resolution and discover that audit uses a different resolution context than build dry-run. The sentence I wanted was one explaining whether audit resolves links before or after base-url prefixing.

**What I inferred rather than read:** That `.md` Markdown pages are valid source files (not requiring an extension like `.html.md`) — I learned this from build output showing `notes/favourite-flowers.md → notes/favourite-flowers/index.html`. The rules say "`/.html/` / `/.md/` are pages" which implies both work, but I initially thought only HTML was supported for rendering.
