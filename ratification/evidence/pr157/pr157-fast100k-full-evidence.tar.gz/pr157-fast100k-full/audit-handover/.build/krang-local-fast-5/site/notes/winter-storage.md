---
title: Winter seed storage tips from our members
layout: /_layout.html
description: Three simple methods our longest-tenured librarians use to keep seeds viable through the dark months — glass jars, paper envelopes, and breathable canvas.
date: 2025-10-02T09:00:00Z
author: Thomas Okonkwo
schema: BlogPosting
og:image: /notes/images/winter-storage.jpg
og:image:width: "800"
og:image:height: "400"
---

# Winter seed storage tips from our members

## Keep it cool, dry, and dark

Our members have been saving seeds for decades. When asked what matters most in winter storage, the answers converged on three things: temperature control, moisture management, and light protection. Here are their tried-and-true methods.

### Glass jars with desiccant

Maria Patel, who has been swapping since 2018, swears by clean glass jam jars fitted with a silica gel pack (food safe). She labels each jar with the variety name, date saved, and source of the original packet. Her tomatoes came through two winters with germination rates above ninety percent.

### Paper envelopes in a tin box

James Whitfield uses plain manila envelopes for every seed type inside a sealed biscuit tin placed in his garden shed. The tin buffers against humidity spikes; the paper lets seeds breathe if any residual moisture is present. He adds a short note on the envelope with variety and growing notes.

### Breathable canvas pouches

For larger volumes — carrots and parsley, which lose viability faster than tomato or bean seed — Elena Rodriguez uses unbleached cotton bags stored in her basement. She checks them monthly for signs of weevils or mould. Her rule: if you smell anything beyond earth and green, open the bag immediately.

## The golden rules everyone follows

All three members agree on a few basics regardless of their chosen method:

1. Let seeds dry fully before storing — two weeks on a paper plate at room temperature is enough.
2. Never store seeds in the refrigerator without first ensuring they are bone-dry; condensation is the enemy.
3. Date every packet clearly. Seeds older than four years deserve a germination test before planting.
