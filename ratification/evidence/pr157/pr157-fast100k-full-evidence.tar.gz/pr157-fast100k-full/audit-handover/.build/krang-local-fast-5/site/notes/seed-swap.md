---
title: Seed swaps and summer harvests
layout: /_layout.html
description: What we learned after our first open seed swap last August — lessons on storage, variety selection, and community building.
date: 2025-09-14T09:00:00Z
author: Miriam Chen
schema: BlogPosting
og:image: /notes/images/swap.jpg
og:image:width: "800"
og:image:height: "400"
---

# Seed swaps and summer harvests

## Our first seed swap was a success

Last August brought our very first open seed swap to the library. Over thirty members showed up, each carrying a bag of home-saved seeds and a story about their garden. We swapped more than two hundred packets in a single afternoon — heirloom tomatoes from the north quadrant, peppers from the south, and enough flower seeds to keep everyone entertained through planting season.

## What went well

People loved having a dedicated space for swapping rather than doing it at the counter. The table layout made it easy to spread everything out and compare varieties. We had extra packets on hand as backups when someone took more than they expected — those back-up seeds were claimed by members who wanted a second chance at a variety.

## What we'd improve next time

The signup sheet got messy after the first fifteen people. Next year we plan to use numbered cards so each person can reserve their spot ahead of time. We also ran low on labels; more are coming this winter.
