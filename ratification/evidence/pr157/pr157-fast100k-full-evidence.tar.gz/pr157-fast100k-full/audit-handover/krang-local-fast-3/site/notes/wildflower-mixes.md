---
title: Wildflower Mixes and Why We Love Them
date: 2025-09-03T09:00:00Z
author: Sam Okonkwo
description: A volunteer writes about why growing wildflowers at the seed library matters for local pollinators.
schema: BlogPosting
layout: /_notes-layout.html
---

# Wildflower Mixes and Why We Love Them

I have been volunteering at Fernway since March of this year, and I still get excited every time we open a new packet from our wildflower collection. There is something about watching a field that started as seed in April turn into colour by midsummer — not neat rows or trimmed borders, just a riot of purple and gold that brings bees everywhere.

## Where the seeds come from

Our stock comes from three places: seeds we harvested ourselves over five seasons, packets traded with two seed libraries in neighbouring counties, and a donation of rare varieties from the heritage farm co-operative down the valley. We try to keep everything open-pollinated so you can save your own seed back at season's end.

## How I grow them

I plant our mixes where nothing else will compete — bare soil or thin turf scraped away with a spade, sown in October when we hand out packets, or early April if you miss the autumn window. No fertiliser, no watering once they are up. They do not care that it is dry weather; in fact they prefer it.

## What comes next

By September every mix I have sown has gone to seed. Some of the patches went straight back into our library bins for re-lending, and others were left standing as habitat. If you would like to try your hand at growing wildflowers here are a few varieties worth starting with: corn poppy, yellow rattle, self-heal, and red clover. Each one does something different for pollinators, and each one saves cleanly.

<p><a href="../notes.html">Back to all Notes</a></p>
