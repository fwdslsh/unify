---
title: Bean Seed Storage — What We Learned in 2024
date: 2026-01-22T09:00:00Z
author: Priya Nair
description: A report on how beans stored through winter at Fernway — which varieties kept best and what went wrong.
schema: BlogPosting
layout: /_notes-layout.html
---

# Bean Seed Storage — What We Learned in 2024

Every spring we ask our members to return seed by November, but I have always wondered whether that is enough time for the seed to stay strong through winter storage. This article shares what I found after examining our 2024 bean harvest across four varieties: Borlotti, Blue Lake, King of the West, and Provider.

## The basics

Dry beans need very little special handling — they are already well protected by their hard coats. The main enemies are moisture and weevils. Beans stored in airtight glass jars tend to last longer than those left in envelopes, but I found that paper bags kept in cardboard boxes work just as well if the room is cool and dry.

## Results by variety

Borlotti seeds had the highest germination rate at 92 % after eight months, while Provider held steady at 88 %. Blue Lake dropped noticeably — down to 71 % — which may have been due to humidity in the storage cupboard near the kitchen. King of the West surprised us all by reaching 95 %; we had expected it to perform closer to Borlotti.

## Lessons for next year

Store beans in a cool room, away from ovens and radiators. A simple dehumidifier would help during wet spells. And always label your envelopes with both variety name and the date you saved them — I cannot count how many times I opened an unlabeled packet wondering whose seed it was before remembering that the library does not keep inventory records for individual members.

<p><a href="../notes.html">Back to all Notes</a></p>
