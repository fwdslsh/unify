---
title: Saving Tomato Seed Through the Wet Season
date: 2025-07-18T09:00:00Z
author: Mae Chen
description: Our tips for fermenting and drying tomato seed so it stays viable through wet, humid weather.
schema: BlogPosting
layout: /_notes-layout.html
---

# Saving Tomato Seed Through the Wet Season

Last July I was frustrated by every method I tried — the seeds would stick together in clumps, or the paper towel mold showed white fuzz before they were dry. Then a neighbor from the community garden shared an old trick with me, and it has worked every time since. Here is what I learned along the way, written for anyone who grows tomatoes but isn't sure about saving seed yet.

## Why ferment?

Tomato seeds sit inside a gelatinous sac that carries substances to inhibit germination. If you dry them without removing that coating first, they will not sprout even if they look clean and crisp. Fermentation for two or three days breaks down the coating — the same process that turns overcomer tomatoes into sauce at home.

## The jar method

1. Scoop seeds and gel from ripe fruit straight into a glass jar filled to about halfway with water.
2. Leave the lid off, loose on top, and set the jar somewhere warm out of direct light. You will see bubbles within a day — that is yeast working. Let it sit for two days; on humid mornings three days may be better.

## Rinsing and drying

When fermentation is done, top seeds float and good ones sink. Gently pour off the floating matter, refill with clean water, and repeat until only seed floats at rest. Spread the wet seed on a sheet of white paper or glass to dry for five to seven more days. They are ready when they sound like popcorn — shake them near your ear.

Store dry seed in a small paper envelope labeled with the variety name and date. A box in the refrigerator will keep them viable for four years; leave them at room temperature and plan to use them within two.

<p><a href="../notes.html">Back to all Notes</a></p>
