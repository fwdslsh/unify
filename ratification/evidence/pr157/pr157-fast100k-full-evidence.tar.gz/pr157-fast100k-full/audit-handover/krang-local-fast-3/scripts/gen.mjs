const fs = require('fs');
const path = require('path');

// Find all .md files in site/notes/, extract frontmatter date and title
const notesDir = path.join(__dirname, '..', 'site', 'notes');
let posts = [];

if (fs.existsSync(notesDir)) {
  for (const file of fs.readdirSync(notesDir)) {
    if (!file.endsWith('.md')) continue;
    const full = path.join(notesDir, file);
    const raw = fs.readFileSync(full, 'utf8');
    // extract frontmatter (between first --- and second ---)
    const parts = raw.split('\n---');
    let title = '';
    let dateStr = '';
    let desc = '';
    if (parts.length > 1) {
      for (const line of parts[0].split('\n')) {
        if (line.startsWith('title: ')) title = line.replace(/^title:\s*/, '').trim();
        else if (line.startsWith('date: ')) dateStr = line.replace(/^date:\s*/, '').trim();
        else if (line.startsWith('description:') || line.startsWith('desc: ')) desc = line.replace(/^description:\s*/, '').replace(/^desc:\s*/, '').trim();
      }
    }
    // derive slug from filename (remove extension)
    const slug = file.replace(/\.md$/, '');
    posts.push({ title, dateStr, description: desc, slug });
  }
}

// sort newest first
posts.sort((a, b) => {
  if (b.dateStr && a.dateStr) return new Date(b.dateStr).getTime() - new Date(a.dateStr).getTime();
  if (a.dateStr && !b.dateStr) return 1;
  if (!a.dateStr && b.dateStr) return -1;
  return 0;
});

const html = `<!doctype html>
<html data-layout="/_layout.html">
  <head>
    <link rel="stylesheet" href="assets/style.css">
    <title>Notes</title>
    <meta name="description" content="Fernway Seed Library Notes — volunteer writings about seed saving, growing tips, and seasonal reports.">
    <meta property="og:title" content="Notes">
    <meta property="og:description" content="Volunteer writings from the Fernway Seed Library on seed-saving, growing, and seasonal reports.">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
  </head>
  <body class="notes-index">
    <h1>Notes</h1>
    <ul class="notes-list">
${posts.map(p => `      <li><a href="/notes/${p.slug}/index.html">${p.title}</a></li>`).join('\n')}
    </ul>
    <p slot="footer">&copy; Fernway Seed Library. Seeds shared, seeds returned.</p>
  </body>
</html>
`;

const outDir = path.join(__dirname, '..', 'site');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, 'notes.html'), html);

console.log(`Generated notes/index for ${posts.length} post(s)`);
