---
title: First wind of the season turns the sails
date: 2025-10-18
author: Tom Easleigh
description: The north-easter finally broke our heat-haze and we put the stones to grain for the first time in weeks.
schema: Article
---

# First Wind Of The Season Turns The Sails

The heat had been oppressive all September, but on Saturday morning a north-easterly breeze swept down from the Fenland horizon at around seven. By eight o'clock the sails were turning lazily, and by nine we had started the runners.

We ground organic spelt wheat brought in by the local community grain co-op. The flour came out pale and fine — you could tell even without a sieve that it would make excellent bread dough. Three visitors bought bags home with them, and I have four more orders to fill next week.

If the wind holds we may be able to mill through to Christmas. Please do come and watch; tours run at ten and two on Saturdays and Sundays.
