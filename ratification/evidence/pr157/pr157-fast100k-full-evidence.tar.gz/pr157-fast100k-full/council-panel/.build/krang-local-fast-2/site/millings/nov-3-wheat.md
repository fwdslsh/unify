---
title: Grinding wheat after a long dry spell
date: 2025-11-03
author: Martha Linfield
description: After three weeks of calm, the easterly breeze finally turned the sails and we produced a sack of flour.
schema: Article
---

# Grinding Wheat After A Long Dry Spell

On Monday morning the wind picked up from the east at around 8 o'clock, a gentle but steady fourteen miles an hour. We let the mill run through to lunchtime before clapping in the sails — there were children visiting from the primary school and they wanted to see the stones themselves.

Mrs Patel was kind enough to bring along her grandfather's wheat sheaf for us to try. It was quite hard work; our runner millstone needed dressing but after some careful chiselling we got through about two kilograms of grain before the wind dropped again at half twelve.

I think this will be a good week for milling if the weather holds. Come and see it working — it only costs £4 for adults, £2 for children, and under fives are free.
