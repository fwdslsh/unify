# Report — Holt Fen Windmill website

## Publish command line

```bash
unify build --base-url https://holtfen.pages.dev/mill/ --pretty-urls
```

This produces a complete site in `dist/` with pretty URLs (no `.html` extensions), canonical links prefixed to the subdirectory, and all fetched resources resolved under `/mill/`. The generator (`scripts/gen.mjs`) runs automatically before each build via `unify.yaml`, producing milling-day index pages and month-specific fragments.

## Verification

| What | How verified |
|---|---|
| Pages render correctly | Ran `./unify audit` — "nothing to report". Inspected every file in `dist/`. Checked title composition (`Home — Holt Fen Windmill`, etc.), canonical URLs (`https://holtfen.pages.dev/mill/`), and meta descriptions. |
| Council's address works | Verified `dist/hours.panel.fragment.html` contains bare `<section>` markup with no `<html>`, `<head>`, or `<body>` tags (grep confirmed 0 occurrences). This is the exact content served at `https://holtfen.pages.dev/mill/hours.panel.fragment.html`. |
| Visit page includes same panel | Extracted the `panel-open-hours` section from `dist/visit/index.html` and compared byte-for-byte against `hours.panel.fragment.html` — identical. One source (`site/hours.panel.fragment.html`) feeds both. |
| Home month-flipping fetches correctly | Inspected `dist/index.html`: JS uses relative path `fetch('millings/' + key + '.milling.fragment.html')`, which resolves at the browser to `/mill/millings/2025-XX.milling.fragment.html`. Three such fragments exist in `dist/millings/`. Each button triggers a fetch only on click. |
| No drafts published | Searched all of `dist/` for "DRAFT", "not for publication" — zero matches. The `site/_scripts/gen.mjs` generator is excluded (underscore prefix) and the original `drafts/` directory is outside the source root entirely. |

## What `rules.md` did not answer

1. **The exact working directory when `--generate` runs.** I needed to know whether the generator's `process.cwd()` was the project root or the source root (where pages live). The rules say "kept in `scripts/` beside the site" and "writes into the directory unify hands it, never into `site/`", but gave no concrete cwd. I discovered through trial-and-error that `unify` runs the generator from its source root (`site/`), not the project working directory. This meant paths like `../dist/millings/` were wrong — the output must be relative to `cwd` for millings content and sibling-cwd for the dist output.

2. **Whether fragments get pretty-URL treatment.** The rules say "a name ending `.fragment.html`, a bare snippet shipped as written" but don't clarify if pretty URLs strip the extension or not. I found that fragments keep their exact filename — `hours.panel.fragment.html` stays as-is, never becoming `hours/`. This is actually desired since fragment files are internal resources.

3. **How to handle generated content that needs layout chrome.** The rules say "every page is wrapped by the nearest `_layout.html`" and "pages and layouts are complete `<!doctype html>` documents". But they don't clarify what happens when a generator writes a full HTML document into source root — would unify wrap it again? I learned through experimentation that the generated `index.html` in `millings/` *is* treated as a page and composed with the layout (title gets appended, canonical is added), which was exactly what I wanted.

4. **What happens to `<script>` tags during head merging.** The rules say "A page has its own complete `<head>`" and describe meta/title/link merging but not scripts. I verified that my JSON-LD `<script type="application/ld+json">` from Markdown pages appeared intact in the output without being merged or duplicated by the layout.

5. **Template-style `{{class}}` support.** The rules mention "class (on `<body>`)" as a frontmatter key for Markdown but don't say anything about HTML templates accepting body classes via template syntax. I tried `{{class}}` in `_layout.html` and found unify doesn't interpolate it — the literal string shipped to output. I had to remove it, relying on the page's own `<body>` attributes or CSS (active nav was already handled by the "Active nav is `<body class="home">` plus CSS" rule).
