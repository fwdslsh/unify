---
title: Autumn milling — spelt flour and tea for everyone
date: 2025-09-14
author: Martha Linfield
description: A pleasant easterly made good flour all afternoon; the community gathered for tea in the barn.
schema: Article
---

# Autumn Milling — Spelt Flour And Tea For Everyone

The spring wheat came from a farmer down on Watling Street Way, and it milled beautifully despite being two years old. The stones were sharp, the sails caught early, and by mid-morning we had produced nearly five kilograms of flour.

After lunch we invited everyone into the barn for tea and biscuits while I explained how the cap turns and how to tell which way the wind is blowing. Mrs Gable from the village hall brought her scone mix and asked if she could use some of our flour — she says it makes better scones than any shop-bought stuff.

We are hoping for more days like this through October and November, so keep an eye on our milling days page or just drop in on a Saturday when we are open.
