#!/usr/bin/env node

import { mkdir, readdir, readFile, writeFile } from 'node:fs/promises';
import { existsSync }  from 'node:fs';
import { join }        from 'node:path';

// Determine where the millings markdown notes live.
var MILLINGS_DIR = join(process.cwd(), 'site', 'millings');
if (!existsSync(MILLINGS_DIR)) MILLINGS_DIR = join(process.cwd(), 'millings');
if (!existsSync(MILLINGS_DIR)) {
  console.error('Could not find millings notes — tried:',
    join(process.cwd(), 'site', 'millings'),
    join(process.cwd(), 'millings'));
  process.exit(0);
}

async function main() {
  var files;
  try {
    files = await readdir(MILLINGS_DIR);
  } catch (e) {
    console.error('Cannot read millings directory:', e.message);
    return;
  }

  // Parse every .md file in the notes dir
  const notes = [];
  for (const f of files) {
    if (!f.endsWith('.md')) continue;
    const content = await readFile(join(MILLINGS_DIR, f), 'utf-8');
    var parts = content.split('---\n');
    if (parts.length < 3) continue;

    var fmStr   = parts[1].trim();
    var body    = parts.slice(2).join('---').replace(/^(\r?\n)+/, '');

    var fm = {};
    for (const line of fmStr.split('\n')) {
      var ci = line.indexOf(':');
      if (ci === -1) continue;
      var key   = line.substring(0, ci).trim();
      var val   = line.substring(ci + 1).trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      fm[key] = val;
    }

    if (!fm.date) continue;

    // Simple markdown -> HTML for the note body
    var mdHtml = '';
    var bLines = body.split('\n');
    for (var li2 = 0; li2 < bLines.length; li2++) {
      var l = bLines[li2].trim();
      if (!l) continue;
      if (l.startsWith('# ')) continue;
      else if (/^#{1,6}\s/.test(l)) mdHtml += '<h3>' + l.replace(/^#+\s+/, '') + '</h3>\n';
      else mdHtml += '<p>' + l + '</p>\n';
    }

    notes.push(Object.assign({}, fm, { body: mdHtml.trim(), file: f }));
  }

  // Sort newest first
  notes.sort(function(a, b) {
    return parseInt(b.date.replace(/-/g, '')) - parseInt(a.date.replace(/-/g, ''));
  });

  var months = {};
  for (var i = 0; i < notes.length; i++) {
    var n   = notes[i];
    var ym  = n.date.substring(0, 7);
    if (!months[ym]) months[ym] = [];
    months[ym].push('<li><a href="/millings/' + n.file.replace('.md', '.html') + '">' + n.title + '</a> — <em>' + n.date + '</em></li>');
  }

  // Write generated files into the source root so unify can pick them up.
  var siteRoot = join(process.cwd(), 'site');
  if (!existsSync(siteRoot)) siteRoot = process.cwd();
  var millingsOut = join(siteRoot, 'millings');

  // Month-specific fragment files for AJAX loading on home page
  await mkdir(millingsOut, { recursive: true });
  for (var ym in months) {
    const fragHtml = '<ul class="month-list">\n' + months[ym].join('\n') + '\n</ul>';
    await writeFile(join(millingsOut, ym + '.milling.fragment.html'), fragHtml);
  }

  // Generate the millings index page (newest first)
  var indexItems = '';
  for (var i4 = 0; i4 < notes.length; i4++) {
    var nn     = notes[i4];
    var link   = '/millings/' + nn.file.replace('.md', '.html');
    indexItems += '<li><a href="' + link + '">' + nn.title + '</a> — ' + nn.date + '</li>\n';
  }

  // Month links sorted newest-first
  var monthLinks = '';
  var ymKeys = Object.keys(months).sort().reverse();
  for (var j3 = 0; j3 < ymKeys.length; j3++) {
    var ky     = ymKeys[j3];
    var parts  = ky.split('-');
    var dObj   = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1);
    var label  = dObj.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
    monthLinks += '<li><a href="/millings/' + ky + '.milling.fragment.html">' + label + '</a></li>\n';
  }

  await writeFile(join(millingsOut, 'index.html'),
    '<!DOCTYPE html>\n<html lang="en">\n<head>\n' +
    '  <meta charset="utf-8">\n' +
    '  <meta name="viewport" content="width=device-width, initial-scale=1">\n' +
    '  <title>Milling Days — Index</title>\n' +
    '  <link rel="stylesheet" href="/assets/style.css">\n' +
    '</head>\n<body class="">\n\n' +
    '<h1>Milling Days</h1>\n\n' +
    '<p>All volunteer notes about days when the mill was turning, listed newest first.</p>\n\n' +
    '<ul class="index-list">\n' + indexItems + '</ul>\n\n' +
    '<h3>Browse By Month</h3>\n\n' +
    '<ul class="index-list">\n' + monthLinks + '</ul>\n\n' +
    '</body>\n</html>'
  );

  console.error('gen.mjs: wrote', Object.keys(months).length, 'month fragments and index.html');
}

main().catch(function(e) { console.error(e); process.exit(1); });
