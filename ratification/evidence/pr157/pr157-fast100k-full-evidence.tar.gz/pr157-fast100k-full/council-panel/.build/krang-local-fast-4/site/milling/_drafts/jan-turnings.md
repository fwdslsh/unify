---
title: First turnings of 2026
date: 2026-01-15
description: The mill turned for the first time this year when a brisk east wind filled the sails on Monday morning. Volunteers ground wheat all afternoon, and the smell of fresh flour drifted down to the village.
author: Marjorie
---

# First turnings of 2026

The mill turned for the first time this year when a brisk east wind filled the sails on Monday morning. Volunteers ground wheat all afternoon, and the smell of fresh flour drifted down to the village.

We had a good turnout — families with children came to watch the stones wake up after their winter rest. Old Tom, who has been volunteering since the restoration in 1985, said it reminded him of the first time he heard the mill turn in '76.
