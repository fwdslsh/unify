---
layout: /_layouts/layout.html
schema: WebPage
title: Home
description: Holt Fen Windmill is a restored windmill run by a small trust. Come see us on the open fenland, taste our stoneground flour, and watch history turn with the wind.
og:image: /logo.svg
---

<section id="home-hero">
  <h1>Holt Fen Windmill</h1>
  <p>A working monument to centuries of craft. The Holt Fen trust tends the sails, turns the stones, and shares its story with everyone who climbs the steps.</p>
</section>

<section id="story">
  <h2>Our Story</h2>
  <p>Built in 1852 on the edge of the fen, Holt Fen Windmill ground grain for local farmers through two world wars and decades of agricultural change. By the 1970s it was standing roofless, its sails gone to firewood.</p>

  <p>The community restored her between 1984 and 1991. Volunteers hauled stone, re-sailed the windwheel with help from Norfolk craftsmen, and rebuilt every runner stone by hand. The mill turned for the first time in over a decade on a grey March afternoon, to cheers that carried across the flats.</p>

  <p>Today the trust operates the mill as it always has &mdash; when the wind blows and the grain is ready, she works. Visit us any Sunday through the season and watch the sails carve out the sky.</p>
</section>

<section id="month-flipper" class="month-panel">
  <h2>Milling Days</h2>
  <div class="month-buttons">
    <button type="button" data-month="0">This month</button>
    <button type="button" data-month="1">Next month</button>
  </div>
  <div id="milling-lists"></div>
</section>

<script>
(function(){
  const months = document.querySelectorAll('#month-flipper button');
  const container = document.getElementById('milling-lists');
  let loading = {};

  async function loadMonth(offset) {
    if (loading[offset]) return;
    loading[offset] = true;

    // Use the first available month fragment, or construct URL from date
    const now = new Date();
    const targetDate = new Date(now.getFullYear(), now.getMonth() + parseInt(offset), 1);
    const ym = `${targetDate.getFullYear()}-${String(targetDate.getMonth()+1).padStart(2,'0')}`;

    try {
      const res = await fetch(`/mill/months/${ym}.fragment.html`);
      if (!res.ok) throw 'not found';
      container.innerHTML += '<div data-month="' + offset + '" class="month-list">' + (await res.text()) + '</div>';
    } catch(e) {
      container.innerHTML += '<div data-error="true" data-month="' + offset + '">No milling days recorded for that period.</div>';
    }
  }

  months.forEach(btn => {
    btn.addEventListener('click', () => loadMonth(btn.dataset.month));
  });

  /* Load "this month" automatically */
  loadMonth('0');
})();
</script>
