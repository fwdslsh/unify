---
title: Light breeze, light grinding
date: 2026-03-08
description: A gentle northerly kept the mill turning slowly through the morning. Enough to grind a few sacks of wheat, not quite enough for a proper day's work — but the children loved watching every turn of the sails.
author: Sarah
---

# Light breeze, light grinding

A gentle northerly kept the mill turning slowly through the morning. Enough to grind a few sacks of wheat, not quite enough for a proper day's work — but the children loved watching every turn of the sails.

We ran a special children's tour at midday and showed them how the stones are dressed. Several asked if they could help next time; one boy, about eight, has already volunteered through his school's science club. We're expecting a larger group in April.
