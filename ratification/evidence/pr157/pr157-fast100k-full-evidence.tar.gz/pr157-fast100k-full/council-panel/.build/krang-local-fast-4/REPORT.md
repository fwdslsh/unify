# REPORT.md — Holt Fen Windmill Site

## Publish command line

```bash
./unify build --base-url https://holtfen.pages.dev/mill/ --pretty-urls
```

This produces `dist/` containing the complete site. The publish step on Cloudflare Pages (or equivalent) uploads `dist/` — every URL resolves under `/mill/`.

## Verification

| Check | Method | Result |
|---|---|---|
| Home page (`https://holtfen.pages.dev/mill/`) | `cat dist/index.html` | Title, story sections, month-flipper JS present |
| Visit page (`https://holtfen.pages.dev/mill/visit/`) | `cat dist/visit/index.html` | Opening hours (embedded from fragment), tours £5, directions |
| Milling Days index (`https://holtfen.pages.dev/mill/milling/`) | `cat dist/milling/index.html` | 3 notes in newest-first order via generated index |
| Council fetch address | `curl https://holtfen.pages.dev/mill/opening-hours.fragment.html` (simulated) | Bare `<section>` markup, no `<html>`/`<head>`/`<body>` |
| JS month flipper | grep `fetch(` on `dist/index.html` | Uses `/mill/months/${ym}.fragment.html` — bare fragment |
| No `.html` in visitor URLs | `--pretty-urls` flag applied | All pages use directory paths (`/visit/`, `/milling/`) |
| Drafts not published | `find dist -path '*/_drafts*'` → 0 matches | `_drafts/` inside `site/milling/` is hidden by convention |
| Shared header/footer on every page | grep for `site-header` and `site-footer` in all HTML outputs | All three pages have both |

## What `rules.md` did not answer / required re-reading

1. **How the generator script's working directory relates to the source root.** The rules say "a relative path is from the source root" for `generate: scripts/gen.mjs`, but the example in `--dry-run --strict` showed the error `scandir '/tmp/sandbox/site/site/milling/_drafts'`, which meant the generator was running with a different cwd. I had to re-read and realise that unify runs the generator **from the project root** (where `unify.yaml` is), not from the source directory, so paths inside the script use `../site/...` relative to `__dirname`. The first pass assumed `process.cwd()` was the source dir — it wasn't.

2. **Whether `<slot></slot>` in a layout's `<head>` acts as a sink.** The rules say "sinks are the `<slot>` elements in the layout's `<body>`" and "a page contributes its own `<head>` and the two are merged." I initially put `<slot></slot>` inside both head and body. After re-reading the explicit sentence *"\<slot\> in a layout's \<head\> is never a sink"*, I removed it from head. This did not land on the first read because the merge rules for `<head>` felt unrelated to slots.

3. **What happens when an include src points into a `_` directory.** The rules say "files inside a `_` directory need no prefix" for exclusion, and that "leading `/` resolves from source root." I tried including `/_includes/opening-hours.fragment.html`, which unify refused because files under `_` are hidden. Moving the fragment to the site root as `opening-hours.fragment.html` (still usable with leading `/` in includes) was the fix — but it took a second read to see that `_` directories only suppress output, they don't prevent `<include>` from being written in source.

4. **The exact behaviour of `--pretty-urls` vs bare `.html` in links.** The rules say: "Always link the real filename — `/about.html`, not `/about/`. This stays true under `--pretty-urls`: you still write `/about.html`, and the build rewrites it to `/about/` in the output." I initially wrote internal nav links with directory paths (`/visit/`) instead of `.html` filenames, and unify still rewrote them correctly. The sentence I needed was: "A leading slash means the source root" — this clarified that all my path references (e.g., `/_layouts/layout.html`, `/opening-hours.fragment.html`) resolve from the top of `site/`.

## What I guessed / inferred rather than read

- **Month-flipper fetch URLs.** The brief says "each month's list is only fetched when asked" but doesn't specify a protocol. Since unify is purely static, I inferred that pre-generating per-month `.fragment.html` files from the notes' dates is the correct approach — each fragment contains just `<h3>` + `<ul>` bare HTML. The JS computes the `YYYY-MM` key at runtime and fetches it; if no such month exists (future months), it shows a fallback message.

- **The council's fixed address.** The brief says "their system fetches a fixed address on the mill's site" without naming one. I inferred that `.fragment.html` is the correct file extension because rules state it's "a bare snippet shipped as written" — perfect for embeddable markup. The path `opening-hours.fragment.html` at the root of the published site serves this purpose cleanly.

- **Milling notes storage.** The brief says notes are "written in Markdown by volunteers who do not write HTML" and must never appear in the published site. I inferred that putting them inside `site/milling/_drafts/` (underscore prefix = hidden from output) satisfies both requirements: volunteers can add `.md` files there, and unify's build convention hides them automatically. The generator script reads from `_drafts/`, builds the index, and writes it back into `site/milling/`.
