import { readdir, readFile } from 'fs/promises';
import path from 'path';
import { writeFileSync, mkdirSync } from 'fs';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const millDir = path.join(root, 'site', 'milling');
const draftsDir = path.join(millDir, '_drafts');
const monthsDir = path.join(millDir, 'months');
mkdirSync(monthsDir, { recursive: true });

// Lazy-load js-yaml (it might not be installed when running directly)
let yamlLoad;
try { yamlLoad = (await import('../node_modules/js-yaml/dist/js-yaml.mjs')).load; } catch {}

// Gather notes from _drafts/
const entries = [];
for (const f of await readdir(draftsDir)) {
  if (!f.endsWith('.md')) continue;
  const file = await readFile(path.join(draftsDir, f), 'utf-8');
  const lines = file.split('\n');
  let fm = {};
  const endIdx = lines.indexOf('---', 1);
  if (endIdx > 1) {
    try { fm = yamlLoad ? yamlLoad(lines.slice(1, endIdx).join('\n')) : {}; } catch {}
  } else { continue; }

  // Skip draft-only files
  const isDraft = (fm.title && /DRAFT/i.test(fm.title)) ||
                  (fm.description && /draft/i.test(fm.description));
  if (isDraft) continue;

  entries.push({ ...fm });
}

entries.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));

// Group by YYYY-MM for monthly fragments
const byMonth = {};
for (const e of entries) {
  if (!e.date) continue;
  const d = new Date(e.date);
  const key = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
  if (!byMonth[key]) byMonth[key] = [];
  byMonth[key].push(e);
}

// Generate a fragment per month (newest first overall, sorted within groups)
for (const [key] of Object.entries(byMonth).sort((a,b) => b[0].localeCompare(a[0]))) {
  const notes = byMonth[key];
  const displayDate = new Date(`${key}-01`).toLocaleDateString('en-GB', {month:'long',year:'numeric'});
  let listHtml = `<h3>${displayDate}</h3><ul>`;
  for (const n of notes) {
    const d = n.date ? new Date(n.date).toLocaleDateString('en-GB', {day:'numeric'}) : '';
    listHtml += `<li>${d} — <em>${n.title}</em></li>`;
  }
  listHtml += '</ul>';

  writeFileSync(path.join(monthsDir, `${key}.fragment.html`), listHtml);
  console.log(`months/${key}.fragment.html`);
}

// Generate the milling index (main page) — newest first globally
let indexItems = '';
for (const e of entries) {
  const d = e.date ? new Date(e.date).toLocaleDateString('en-GB', {day:'numeric',month:'long',year:'numeric'}) : '';
  indexItems += `<li>${e.title} &mdash; ${d} (${e.author || 'volunteer'})</li>`;
}

const indexPage = `<!doctype html>\n<html lang="en-GB" data-layout="/_layouts/layout.html">\n<head><meta charset><title>Milling Days</title><meta name="description" content="Reports from the mill crew on every day the mill turns its sails. Browse by date below."><link rel="stylesheet" href="/styles.css"></head>\n<body>\n<section id="milling-days">\n  <h1>Milling Days</h1>\n  <p>The mill crew posts their reports as soon as the stones stop turning.</p>\n  <ol class="milling-index">${indexItems}</ol>\n</section>\n</body>\n</html>`;

writeFileSync(path.join(millDir, 'index.html'), indexPage);
console.log('milling/index.html');
