---
title: A proper southwester grinds barley
date: 2026-02-14
description: A strong south-wester blew through on Sunday and the mill didn't stand idle. The crew took on a load of two tonnes of barley, ground it to malt for a local brewery, and sold small bags of flour at the gate.
author: Peter
---

# A proper southwester grinds barley

A strong south-wester blew through on Sunday and the mill didn't stand idle. The crew took on a load of two tonnes of barley, ground it to malt for a local brewery, and sold small bags of flour at the gate.

The sails were turning so fast that even people on the lane could hear them humming. We had coffee and biscuits served by the village hall committee — standard Sunday routine now, and always popular after a good grinding session.
