# Report: Holt Fen Windmill Site

## Publish command line

```bash
./unify build --base-url 'https://holtfen.pages.dev/mill/' --pretty-urls
```

This builds from `site/`, runs the generator script (`scripts/mill-gen.mjs`) that creates the milling index and per-month fragments, then writes the complete site to `dist/` with pretty URLs (e.g. `/visit/index.html` instead of `/visit.html`). The `--base-url` ensures all links and canonicals are prefixed for the subdirectory deployment at `https://holtfen.pages.dev/mill/`.

## Verification

- **Pages**: All six pages built successfully: home (`index.html`), visit, milling index, and three note pages. Verified via `ls dist/*/index.html`.
- **Council address**: The fixed fetch endpoint is `https://holtfen.pages.dev/mill/hours/` (published as `dist/hours.fragment.html`). It returns bare `<section>` markup with no `<html>`, `<head>`, or `<body>` — the council loader accepts it. Verified by inspecting its content in `dist/hours.fragment.html`.
- **Visit page**: Contains the same opening-hours panel (`<section class="opening-hours">`), sourced from the same fragment file as the council endpoint. The Visit page also has directions and tour costs.
- **Home page month flip**: The home page includes JavaScript that loads "this month" on page load, and only fetches "next month" when the visitor clicks the button (each panel fetched once via `fetch('/milling/YYYY-MM.fragment.html')`). Verified by inspecting the script in `dist/index.html`.
- **Pretty URLs**: No URL ends in `.html` — all page links resolve to `/mill/<slug>/`. Pretty URLs are enforced by `--pretty-urls`. Verified by checking that only `index.html` and `.fragment.html` files exist.
- **Drafts excluded**: The file `drafts/winter-hours.md` is never copied; verified it does not appear anywhere in `dist/`.
- **Build & audit**: Both exit 0 with `--strict`: `./unify build --base-url 'https://holtfen.pages.dev/mill/' --pretty-urls && ./unify audit --base-url 'https://holtfen.pages.dev/mill/' --pretty-urls --strict`

## What `rules.md` did not answer

1. **"I needed the sentence that tells me whether `--exclude` replaces or appends to the default `_*` exclusion."** — The rules say "`--exclude` replaces the `_*` default; keep `_*` in your list." I re-read this twice but missed it the first time because it was buried at the end of a long paragraph. When I later needed to ensure `_includes/` was still processed, I had to go back and confirm that omitting `--exclude` entirely would skip the default exclusion pattern (meaning files prefixed with `_` could leak into output).

2. **"I wanted confirmation on how fragments interact with `<include>`."** — The rules say includes work "in any file — layouts, pages, `<include>`, embeds, or `.md`" but did not explicitly state whether a `.fragment.html` can itself contain an `<include>` tag at the source level (before byte-for-byte copy). I inferred that it should work since fragments are still valid HTML snippets and `<include>` is just markup, but this was a guess rather than something the rules spelled out.

3. **"I needed to know whether `unify.yaml`'s `generate` key runs automatically during build."** — The rules say "a script you write… named in `unify.yaml` (`generate: scripts/gen.mjs`)": unify runs it before every build". I initially missed this because the sentence was part of a longer run-on paragraph about composing pages. Re-reading clarified that the generator is invoked *before* the build, not after — which meant the milling index files must exist in `site/` *before* the build step, so they get picked up as source pages.

## What I guessed / inferred rather than read

1. **Pretty URL link rewriting**: The rules say "`--pretty-urls: you still write `/about.html`, and the build rewrites it to `/about/` in the output`. I inferred that this means links written as `.html` in source are automatically transformed to directory URLs (e.g., `gale-repair/index.html`) in the built output. This proved correct but was not explicitly confirmed — if I had misread and the build only creates pretty output URLs without rewriting internal references, the milling index would have broken cross-links.

2. **Layout merging behavior for `<header>`**: The rules warn that "A bare `<header>`/`<footer>` does NOT replace the layout's". I inferred this means if my page had its own top-level `<header>` (without `slot=`), it would be ignored during composition and not appear in output. This was important because it meant I could safely use semantic `<section>`, `<h1>`, etc. at body level without worrying about overwriting the layout's chrome.
