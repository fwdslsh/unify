---
title: The mill is turning — wheat day!
description: The sails turned steadily, grinding three tonnes of winter wheat with a southerly breeze. Visitors flocked up the spiral stairs for the proper mill-dust atmosphere.
date: 2025-10-18
---

# Milling Day — Wheat Harvest

The sails have been turning steadily today. We ground three tonnes of winter wheat, and the smell in the grinding room was proper mill-dust thick by midday. Visitors were flocking up the spiral stairs.

A good day for it — southerly breeze all afternoon, plenty of work to do on the stones.
