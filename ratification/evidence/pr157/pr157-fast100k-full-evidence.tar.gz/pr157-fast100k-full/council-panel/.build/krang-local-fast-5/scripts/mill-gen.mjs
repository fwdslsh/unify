import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const siteDir   = path.join(__dirname, '..', 'site');

function readMd(dir) {
  return fs.readdirSync(dir).filter(f => f.endsWith('.md')).map(filename => {
    const raw = fs.readFileSync(path.join(dir, filename), 'utf-8');
    const lines = raw.split('\n');
    let fm = false;
    let title = '', dateStr = '';
    for (const line of lines) {
      if (!fm && line.startsWith('---')) { fm = true; continue; }
      if (fm && line === '---') break;
      const m1 = /^title:\s*(.*)/.exec(line);
      const m2 = /^date:\s*(.*)/.exec(line);
      if (m1) title  = m1[1].trim();
      if (m2) dateStr = m2[1].trim();
    }
    return { file: filename, title, dateStr };
  });
}

const notes = readMd(siteDir).filter(n => n.dateStr);
notes.sort((a,b) => b.dateStr.localeCompare(a.dateStr));

// Build index — newest first
let idxHTML = '<ol>\n';
for (const n of notes) {
  const slug = path.basename(n.file, '.md');
  idxHTML += `  <li><a href="/${slug}.html">${n.title}</a> — ${n.dateStr}</li>\n`;
}
idxHTML += '</ol>';

  // Write /milling/index.html (the pretty URL version) — full page with layout
const outDir = path.join(siteDir, 'milling');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir);

let pgHTML = `<!doctype html>
<html lang="en" data-layout="/_layout.html">
<head>
  <meta charset>
  <link rel="stylesheet" href="../style.css">
  <title>Milling Days — Holt Fen Windmill</title>
  <meta name="description" content="Milling days at Holt Fen Windmill — dated notes from volunteers about each time the millstones turn.">
</head>
<body>

<h1>Milling Days</h1>

<p>Dated notes from volunteers who keep the mill turning.</p>

<div class="milling-index" id="milling-index">
${idxHTML}
</div>

</body>
</html>`;
fs.writeFileSync(path.join(outDir, 'index.html'), pgHTML);

// Build per-month data for the home page AJAX (as fragment HTML): key by YYYY-MM
const months = {};
for (const n of notes) {
  const ym = n.dateStr.substring(0,7); // "2025-10"
  if (!months[ym]) months[ym] = [];
  const slug = path.basename(n.file, '.md');
  months[ym].push(`<p><a href="/${slug}.html">${n.title}</a> — <time datetime="${n.dateStr}">${n.dateStr}</time></p>`);
}

// For month-specific fetches: write per-month .fragment.html files
const keys = Object.keys(months).sort();
for (const k of keys) {
  const frag = '<div>\n' + months[k].join('\n') + '</div>';
  fs.writeFileSync(path.join(siteDir, 'milling', `${k}.fragment.html`), frag);
}
