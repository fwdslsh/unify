---
title: Sails repaired after the gale
description: The mill patched a torn sail and ground spelt for an education visit during a brief north-easterly.
date: 2025-12-02
---

# Milling Day — Repairs and a Short Run

The gale on Monday tore a sail on the windward side. By Wednesday we'd got it patched enough to stand up, and with a light north-easter in we managed a short grinding of spelt for the education visit at 2 pm. The schoolchildren were delighted.

We need a full sail replacement by spring or won't be able to turn properly in winter winds. If you're handy with canvas, please drop a note to the Trust — we'd love your help.
