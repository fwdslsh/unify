---
title: Grinding maize for the chickens
description: A calm milling day grinding maize for the Trust's poultry and a local farm shop. The stones needed re-dressing after last week's heavy run.
date: 2025-11-05
---

# Milling Day — Maize Run

A calm day, only two turns of the sails before they settled. We ground a load of maize for the Trust's chickens and the village farm shop down at Oldstead. The stones needed re-dressing after last week's heavy run but we got it sorted by lunchtime.

Went home with empty sacks full — nobody can complain about that round here.
