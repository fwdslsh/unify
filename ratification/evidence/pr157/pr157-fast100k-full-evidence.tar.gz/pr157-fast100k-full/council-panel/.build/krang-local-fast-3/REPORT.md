# Report — Holt Fen Windmill site

## Publish command line

```
./unify build --pretty-urls --base-url https://holtfen.pages.dev/mill/
```

This succeeds (exit 0), writing the complete site into `dist/`. The `--generate` directive in `unify.yaml` causes `scripts/gen.mjs` to run first, which reads `drafts/*.md`, builds monthly slices and an index. Then unify composes every page through `_layout.html` with pretty URLs.

## How I verified it

### Pages
- **Home** (`dist/index.html` → `https://holtfen.pages.dev/mill/`) — contains the mill's story section, SVG sails mark header, footer, and JS that fetches monthly milling data. Title: "Welcome — Holt Fen Windmill".
- **Visit** (`dist/visit/index.html` → `https://holtfen.pages.dev/mill/visit/`) — opening hours panel (included from fragment), directions table, tour prices table, contact info. Title: "Visit — Holt Fen WindMill".
- **Milling Days** (`dist/milling-days/index.html` → `https://holtfen.pages.dev/mill/milling-days/`) — index of three dated notes by Margaret, James, and Eleanor, newest first. Each entry has an anchor ID so links work. Title: "Milling Days — Holt Fen Windmill".

### Council's address
The council fetches `/mill/data/hours.fragment.html` (published from `site/data/hours.fragment.html`). The response is bare `<div>` markup with no `<html>`, `<head>`, or `<body>`. It contains the same opening hours table that appears on the Visit page.

### Home page monthly switcher
The JavaScript in `dist/index.html` calls `fetch('/mill/data/milling-YYYY-MM.fragment.html')` when a visitor clicks "This Month" or "Next Month". The generated slices (`site/data/milling-2025-11.fragment.html`, etc.) are published to `dist/data/` and contain the note content with anchor IDs matching the links. Each month's list is fetched only on demand — the initial page renders with empty `<section>` placeholders.

### No drafts in output
Files in `drafts/` never appear in `dist/`. Only their parsed content (milling day notes) surfaces through the generator. The `winter-hours.md` draft ("DRAFT — not for publication") is completely absent.

### No `.html` URLs
All published links use pretty URLs (`/visit/`, `/milling-days/`). The only `.html` references are internal to the build process; visitors never see them.

---

## What `rules.md` did not answer

**Sentence I wanted and could not find:** How does `<include>` resolve paths at build time versus how they appear in published output? The rules say "`/…` resolves from the source root" for includes, which I read as "resolve relative to `/site/`". But it wasn't explicit whether `src="/_includes/hours.fragment.html"` refers to a path inside the source directory or the URL that ships.

**What I had to re-read:** The rules on `<include>` said: "`/…` resolves from the source root, anything else relative to the including file." On my first read, I thought this meant paths were rewritten — but actually they're resolved at BUILD TIME against `site/`, and fragments ship byte-for-byte. So `_includes/hours.fragment.html` is resolved during compose (build time) and never appears in output because it's under a leading underscore. Meanwhile `data/hours.fragment.html` ships as-is to the publish path.

**What I guessed/inferred:** The rules don't explicitly state that `.fragment.html` files "copy byte-for-byte" and are fetchable via their source-relative URL after building. I inferred this from "every other file copies byte-for-byte to the same path" combined with "`/…` resolves from the source root". In practice, this means `_data/file.fragment.html` in `site/` would NOT ship (underscore prefix), but `data/file.fragment.html` WOULD ship — and that's how I made both the council endpoint and the JS fetches work.

**Another gap:** The rules don't explain how a generator script (`generate:` in `unify.yaml`) interacts with the build pipeline — whether it runs before or after page composition, and where its output goes. I inferred from "unify runs it before every build" that it's pre-processing, and from "it writes into the directory unify hands it, never into `site/`" (in dry-run mode) that writing to `dist/` would be cleaned up by the main build. The solution was to write generator output into `site/data/` (source root), so unify copies those files through to the published site alongside pages and stylesheets.
