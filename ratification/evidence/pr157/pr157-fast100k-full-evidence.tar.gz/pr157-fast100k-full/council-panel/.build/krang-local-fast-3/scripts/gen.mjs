#!/usr/bin/env node
// Generate monthly milling-day slices from drafts/*.md files.
const fs = require('fs');
const path = require('path');

const DRAFTS_DIR = path.join(__dirname, '..', 'drafts');
const DATA_DIR   = path.join(__dirname, '..', 'site', 'data');
const INC_DIR    = path.join(__dirname, '..', 'site', '_includes');

try { fs.mkdirSync(DATA_DIR, { recursive: true }); } catch {}
try { fs.mkdirSync(INC_DIR, { recursive: true }); } catch {}

function mdToHtml(md) {
  const lines = md.split('\n');
  let html = '';
  let paraBuf = [];
  function flush() {
    if (paraBuf.length > 0) {
      const text = paraBuf.join(' ').replace(/\r/g, '');
      html += '<p>' + text + '</p>\n';
      paraBuf = [];
    }
  }
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) { flush(); continue; }
    if (/^#\s/.test(line)) { continue; }
    paraBuf.push(line);
  }
  flush();
  return html;
}

function parseTitle(md) {
  const m = md.match(/^#\s*Milling Day\s*—\s*(.*)$/m);
  if (!m) return { date: '', month: '' };
  const parts = m[1].split(/\s+/);
  if (parts.length >= 3) {
    const day = parseInt(parts[0], 10);
    const monthName = parts[1];
    const year = parts[2];
    const months = ['january','february','march','april','may','june',
                    'july','august','september','october','november','december'];
    const mi = months.indexOf(monthName.toLowerCase());
    if (mi >= 0) {
      return { date: year + '-' + String(mi+1).padStart(2,'0'), month: parts[1] };
    }
  }
  return { date: '', month: '' };
}

function parseAuthor(md) {
  const m = md.match(/^[-\u2014]\s*([A-Za-z]+)$/m);
  if (!m) return 'Anonymous';
  return m[1];
}

function extractDateText(md) {
  const m = md.match(/^#\s*Milling Day\s*—\s*(.*)$/m);
  if (!m) return '';
  // e.g. "8 November 2025" or "4 October 2025" or "6 September 2025"
  const parts = m[1].split(/\s+/);
  if (parts.length >= 3) {
    return parts[0] + ' ' + parts[1] + ' ' + parts[2];
  }
  return m[1];
}

const files = fs.readdirSync(DRAFTS_DIR).filter(f => f.endsWith('.md'));
const entries = [];

for (const f of files) {
  const full = path.join(DRAFTS_DIR, f);
  const md = fs.readFileSync(full, 'utf-8');
  const { date, month } = parseTitle(md);
  if (!date || !month) continue;
  entries.push({ filename: f, date, month, rawDate: extractDateText(md), body: mdToHtml(md), author: parseAuthor(md) });
}

entries.sort((a,b) => b.date.localeCompare(a.date));

const byMonth = {};
for (const e of entries) {
  if (!byMonth[e.date]) byMonth[e.date] = [];
  byMonth[e.date].push(e);
}

// Write monthly slices to data/ for JS fetch access AND _includes/ for page embedding
let indexHtml = '';

for (const [ym, notes] of Object.entries(byMonth)) {
  let sliceHtml = '<ul>\n';
  let monthBlock = '';

  for (const n of notes) {
    const slug = n.filename.replace('.md','').toLowerCase().replace(/\s+/g, '-');
    // Slice file: bare <li> elements with IDs
    sliceHtml += '  <li id="' + slug + '">' + n.body + '</li>\n';
    // Page content: month header + entries with IDs for anchors
    if (!monthBlock) {
      monthBlock = '\n<h2><time>' + ym + '</time></h2>\n';
    }
    monthBlock += '<section id="' + slug + '">\n';
    monthBlock += '<p class="note-date"><strong>' + n.rawDate + '</strong> — recorded by ' + n.author + '</p>\n';
    monthBlock += '<div>' + n.body + '</div>\n</section>\n';
  }

  sliceHtml += '</ul>';
  const slicePath = path.join(DATA_DIR, 'milling-' + ym + '.fragment.html');
  fs.writeFileSync(slicePath, sliceHtml);

  indexHtml += monthBlock;
}

// Write the monthly blocks to _includes/ for page embedding
const incFp = path.join(INC_DIR, 'milling-entries.fragment.html');
fs.writeFileSync(incFp, indexHtml);

console.log('Generated milling data for months: ' + Object.keys(byMonth).join(', ') + ', wrote entries to ' + incFp);
