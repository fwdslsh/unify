# Report — Holt Fen Windmill site

## Publish command line

```bash
./unify build --base-url 'https://holtfen.pages.dev/mill/' --pretty-urls --clean --strict
```

This builds the site (via `scripts/gen.mjs`) and publishes to `dist/`. The `--base-url` prefixes all root-relative links with `/mill/`, makes `<link rel="canonical">` and `og:` URLs absolute, and generates `sitemap.xml`. `--pretty-urls` strips `.html` from visible paths (e.g. `/visit.html` → `/visit/`). `--clean` clears old output first; `--strict` exits non-zero on any problem.

---

## What `rules.md` did not answer

**The sentence I wanted but could not find:**

> "When a `.fragment.html` file is included via `<include>` inside an HTML page, does unify rewrite the hrefs inside that fragment's content after splicing it into the parent?"

The rules say fragments "copy byte-for-byte" and "`unify never … rewrites`" fragments. But they also describe how `<include>` "splices the file in verbatim." I had to **re-read** this part several times because the behaviour wasn't obvious on first pass: a fragment used as an include gets spliced into its parent HTML, and then *that* HTML (now containing the spliced bytes) goes through href rewriting. The same fragment shipped standalone does NOT get rewritten. This distinction was not stated plainly — I had to infer it from the interaction of those two sentences plus trial-and-error with links in published pages.

**What I guessed at or inferred:**

- That `--pretty-urls` also rewrites root-relative paths (`/visit.html` → `/visit/`) while leaving stylesheet URLs (`/style.css`) alone — I verified this by grepping the output rather than finding it in the docs.
- That fragments are truly byte-for-byte copies, meaning their internal `<a>` hrefs won't be prefixed when `--base-url` is used. This meant I had to write absolute URLs in the council-facing fragment and use `./relative` paths inside JS-fetched monthly fragments.
- That `window.location.pathname` returns `/mill/` for a page at `https://holtfen.pages.dev/mill/`, which means I needed the `getBase()` JavaScript helper on the home page to compute the subdirectory prefix dynamically, since unify doesn't inject any JS variable.

**What I had to re-read and why it didn't land:**

I reread the section on `<include>` twice (around line 23 of rules.md). The first read told me "an include is still not a component" which led me to think `<include>` just copies content verbatim — correct, but I missed that *after* splicing, the resulting HTML page then goes through href rewriting. My second reading caught this because I was already seeing broken links in audit output from earlier builds.

---

## What I verified

| Requirement | How checked | Result |
|---|---|---|
| Pages load correctly for the published address | Inspected `dist/index.html`, `dist/visit/index.html`, `dist/milling-days/index.html`, and each `milling-data/*/index.html` — all have correct `<link rel="stylesheet" href="/mill/style.css">`, canonical URLs under `/mill/`, and proper titles (`Title — Holt Fen Windmill`) | ✓ |
| Council address (opening-hours fragment) | Verified `dist/opening-hours.fragment.html` contains bare markup with no `<html>`/`<head>`/`<body>`, and uses absolute href to `https://holtfen.pages.dev/mill/milling-days/` so the link works when the council embeds it on their own domain | ✓ |
| Home page month flipper | Verified JS computes subdirectory base from pathname, fetches `/mill/milling-data/month-202611.fragment.html`, and the injected links use `./milling-data/...` to resolve correctly from `/mill/index.html` context | ✓ |
| No `.html` in published URLs | Ran `grep -r '\.html"' dist/` — only fragments have `.fragment` extension; all page paths end in `/` (e.g. `/visit/`, `/milling-days/`) | ✓ |
| Drafts never publish | Searched output for "Do not publish" and the draft miller content — none found. The `winter-hours.md` has no date so gen.mjs skips it, and drafts/ lives outside site/ | ✓ |
| Index newest-first | Confirmed milling-days index lists Nov → Oct → Sep in generated HTML | ✓ |
| Build & audit clean | `./unify build --base-url ... --pretty-urls --clean --strict` exits 0; `./unify audit --strict` reports "nothing to report" (exit 0) | ✓ |
