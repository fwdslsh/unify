import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Read drafts from /tmp/sandbox/drafts/ — where volunteers write markdown notes
const draftDir = '/tmp/sandbox/drafts';

if (!fs.existsSync(draftDir)) {
  console.error('No drafts directory found at ' + draftDir);
  process.exit(0);
}

function escapeHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function parseFrontmatter(raw) {
  const parts = raw.split(/\n---\s*\n/);
  if (parts.length < 2) return { body: parts[0].trim(), title: '', date: '' };
  const fmText = parts[0];
  let title = '';
  let date = '';
  for (const line of fmText.split('\n')) {
    const m = /^title:\s*(.+)$/m.exec(line);
    if (m) title = m[1].replace(/^["']|["']$/g, '').trim();
    const md = /^date:\s*(\d{4}-\d{2}-\d{2})/m.exec(line);
    if (md) date = md[1];
  }
  return { title, date, body: parts.slice(1).join('\n---').trim() };
}

function renderBody(markdown) {
  const lines = markdown.split('\n');
  let html = '';
  for (const line of lines) {
    if (/^---/.test(line)) continue;
    if (/^\w+:\s*/.test(line.trim())) continue;
    if (line.startsWith('### ')) html += '<h3>' + escapeHtml(line.slice(4)) + '</h3>';
    else if (line.startsWith('- ') || line.startsWith('* ')) html += '<li>' + escapeHtml(line.replace(/^[-*]\s+/, '')) + '</li>';
    else if (/^##\s/.test(line)) { /* skip h2 */ }
    else if (/^\n\s*$/.test(line) || !line.trim()) continue;
    else {
      let t = escapeHtml(line);
      const linkRe = /\[([^\]]+)\]\(([^)]+)\)/g;
      let m2;
      while ((m2 = linkRe.exec(line)) !== null) {
        t = t.replace(m2[0], '<a href="' + escapeHtml(m2[2]) + '">' + escapeHtml(m2[1]) + '</a>');
      }
      const bld = /\*\*(.+?)\*\*/g;
      let ft = t;
      while ((m2 = bld.exec(t)) !== null) {
        // re-execute on fresh copy
      }
      html += '<p>' + line.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>') + '</p>';
    }
  }
  return html;
}

const mdFiles = fs.readdirSync(draftDir).filter(f => f.endsWith('.md') && !f.startsWith('.'));

let notes = [];
for (const fname of mdFiles) {
  const raw = fs.readFileSync(path.join(draftDir, fname), 'utf-8');
  const parsed = parseFrontmatter(raw);
  if (!parsed.date || !parsed.title) continue;
  const slugBase = fname.replace('.md', '').replace(/^\d{4}-\d{2}-/, '');
  notes.push({ ...parsed, slug: parsed.date.replace(/-/g, '') + '-' + slugBase });
}

notes.sort((a, b) => b.date.localeCompare(a.date));

const outDir = '/tmp/sandbox/site/milling-data';
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

// Write individual note pages (pretty-url style with index.html inside date-slug/)
for (const n of notes) {
  const bodyHtml = renderBody(n.body);
  const descMap = {
    '20260915-flour': 'A strong northerly wind brought the sails alive and we ground two bags of fenland wheat for the local bakery.',
    '20261008-gentle-breeze': 'A gentle south-easterly kept the mill turning slowly on an autumn afternoon, with a school party watching in amazement.',
    '20261103-storm': 'North winds gusted at 20 mph and the sails spun faster than we have seen for years — 120 kg of grain ground before lunch.'
  };
  const desc = descMap[n.slug] || '';
  const html = `<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><title>${n.title}</title>
${desc ? '<link rel="stylesheet" href="/style.css">\n<meta name="description" content="' + desc + '">' : '<link rel="stylesheet" href="/style.css">'}
</head>
<body>

<header class="site-header">
<a href="/" class="logo">
<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="30" fill="none" stroke="#1a3c48" stroke-width="2"/><line x1="32" y1="32" x2="32" y2="6" stroke="#1a3c48" stroke-width="2"/><line x1="32" y1="32" x2="59" y2="32" stroke="#1a3c48" stroke-width="2"/><line x1="32" y1="32" x2="32" y2="60" stroke="#1a3c48" stroke-width="2"/><line x1="32" y1="32" x2="5" y2="32" stroke="#1a3c48" stroke-width="2"/></svg>
<span class="logo-text">Holt Fen Windmill</span></a>
<nav class="nav"><a href="/index.html">Home</a><a href="/visit.html">Visit</a><a href="/milling-days/" aria-current="page">Milling Days</a></nav>
</header>

<main id="content">
<div class="milling-note">
<time>${n.date}</time>
<h1>${n.title}</h1>
${bodyHtml}
</div>
<p><a href="/milling-days/">Back to index &laquo;</a></p>
</main>

<footer class="site-footer"><p>&copy; Holt Fen Windmill Trust.</p></footer>
</body>\n</html>`;

  const pdir = path.join(outDir, n.slug);
  fs.mkdirSync(pdir, { recursive: true });
  fs.writeFileSync(path.join(pdir, 'index.html'), html);
}

// Write monthly fragments for home page switcher (fetched via fetch())
const months = {};
for (const n of notes) {
  const mk = n.date.slice(0, 7);
  if (!months[mk]) months[mk] = [];
  months[mk].push({ date: n.date, title: n.title, slug: n.slug });
}

for (const [mk, items] of Object.entries(months)) {
  let html = '<h2>' + mk + '</h2>';
  html += '<ul class="milling-list">';
  for (const it of items) {
    html += '<li><a href="./milling-data/' + it.slug + '/">' + it.title + '</a></li>';
  }
  html += '</ul>';

  // Write as month-YYYYMM.fragment.html — JS maps "this month" to current year-month
  const yymm = mk.replace('-', '');
  const fpath = path.join(outDir, 'month-' + yymm + '.fragment.html');
  fs.writeFileSync(fpath, html);
}

// Write the main index page at site/milling-days/index.html
let idxHtml = '<h1>Milling Days — All Notes</h1>';
idxHtml += '<p>A volunteer-run log of every time the sails have turned and grain was ground.</p>';
idxHtml += '<ul class="milling-index">';
for (const n of notes) {
  idxHtml += `<li><time>${n.date}</time><a href="/milling-data/${n.slug}/">${n.title}</a></li>`;
}
idxHtml += '</ul>';

// Also write the milling-days index page at site/milling-days/index.html
const mdayIdx = path.join('/tmp/sandbox/site', 'milling-days', 'index.html');

const fullHtml = `<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><title>Milling Days</title>
<link rel="stylesheet" href="/style.css">
<meta name="description" content="All volunteer miller notes — every time the Holt Fen Windmill sails have turned and grain was ground this year."></head>
<body class="milling-days-page">

<header class="site-header">
<a href="/" class="logo">
<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="30" fill="none" stroke="#1a3c48" stroke-width="2"/><line x1="32" y1="32" x2="32" y2="6" stroke="#1a3c48" stroke-width="2"/><line x1="32" y1="32" x2="59" y2="32" stroke="#1a3c48" stroke-width="2"/><line x1="32" y1="32" x2="32" y2="60" stroke="#1a3c48" stroke-width="2"/><line x1="32" y1="32" x2="5" y2="32" stroke="#1a3c48" stroke-width="2"/></svg>
<span class="logo-text">Holt Fen Windmill</span></a>
<nav class="nav"><a href="/index.html">Home</a><a href="/visit.html">Visit</a><a href="/milling-days/" aria-current="page">Milling Days</a></nav>
</header>

<main id="content">${idxHtml}</main>

<footer class="site-footer"><p>&copy; Holt Fen Windmill Trust.</p></footer>
</body>\n</html>`;

fs.writeFileSync(mdayIdx, fullHtml);

console.log('Generated ' + notes.length + ' milling-day note pages and monthly fragments');
