---
title: A gentle breeze and a lot of patience
date: 2026-10-08
schema: Article
---

## Still turning slowly today

It was not the strongest wind — maybe 10 mph from the south-east — but enough to keep the sails moving most of the afternoon. We milled a single small batch, mostly for show rather than production. A party of school children came in and loved watching the stones warm up; they spent half an hour asking questions about every gear and pulley.

The weathervane on top of the tower is squeaking again — I have a can of oil waiting but I need a steadier day to climb up there safely. If anyone has ideas for a silent bearing please drop us a note!

We are looking forward to the autumn millers' meet in October next year. Three mills confirmed so far, and we hope more will join.
