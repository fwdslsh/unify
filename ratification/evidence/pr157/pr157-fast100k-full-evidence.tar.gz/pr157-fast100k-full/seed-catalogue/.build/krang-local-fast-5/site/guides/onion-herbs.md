---
title: Onions, Herbs & Aromatic Plants
layout: /_layout.html
schema: Article
date: 2026-03-05
---

# Onions, Herbs & Aromatic Plants

The Allium family and the aromatic herbs that grow alongside them form an essential part of every kitchen garden. At Fernhollow we have varieties of onions, leeks, garlic, chives, parsley, and many other herbaceous plants passed down through generations of valley growers.

## Starting from seed

Onions are often started indoors in modules before planting out into their final positions. Early-maturing varieties can be sown under cover in late winter. Most herbs grow well from seed sown directly into the ground once the soil has warmed in spring.

## Spacing and placement

Alliums need good spacing to allow bulbs to mature — typically 10–15 cm apart depending on variety. Herbs have different needs: parsley prefers partial shade while thyme and oregano thrive in sunny, well-drained spots. Keep aromatic herbs away from damp areas where fungal issues may arise.

## Maintenance

Onions need consistent moisture during bulb formation but the ground should not remain waterlogged. Regular weeding is essential around all members of this family since they are shallow-rooted competitors. Herbs generally need little maintenance once established — a light trim after flowering keeps most varieties productive through summer.

---

Written by volunteer grower R. Simms, Openfield Lane section of the valley allotment.
