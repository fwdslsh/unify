<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>{{title}} — Fernhollow Seed Library</title>
  <style>
    .guide-body { font-size: 1.05rem; }
    .guide-body h2 { margin-top: 1.5em; color: #3a4e3a; }
    .guide-body h3 { margin-top: 1.5em; color: #4a6b4a; }
    .guide-body p, .guide-body li { line-height: 1.7; }
    .guide-body blockquote { border-left: 4px solid #8aab8a; padding-left: 1rem; margin-left: 0; color: #556b55; font-style: italic; }
  </style>
</head>
<body data-layout="/_layout.html" class="guides-page">
<h2>{{title}}</h2>
<div class="guide-body">{{content}}</div>
</body>
</html>
