---
title: "Salad Greens & Seasonal Crops"
layout: /_layout.html
schema: Article
date: 2026-04-15
---

# Salad Greens & Seasonal Crops

The Asteraceae and Apiaceae families provide many of the fresh greens that make summer salads so rewarding. From lettuce varieties to wild herbs, these crops keep producing throughout the growing season when looked after properly.

## Sowing salad crops

Lettuce is best sown in short successive batches from March through August for a continuous harvest. Broadleaf chives, endive, and purslane can follow on once spring warmth arrives. The early-sown varieties will bolt quickly in high summer — sow shade-tolerant types later and provide partial cover during heat waves.

## Maintaining the patch

Salad greens grow fast when moisture is reliable and soil is rich with organic matter. Pick outer leaves of cutting lettuce regularly to encourage new growth from the centre. Wild herbs like dandelion, sorrel, and wild rocket need no special attention — they thrive on being left alone and will self-seed generously each year.

## Harvesting salad greens

Lettuce heads are ready when firm but not hard; cut just below surface level or pick individual outer leaves as needed for continuous harvesting. Chicory and endive improve after a light frost, becoming sweeter and more tender in autumn weather. Many wild herbs are at their most flavourful before flowering — harvest young leaves from plants in partial shade for the least bitter results.

---

Written by volunteer grower J. Vance, Care of the Common Field.
