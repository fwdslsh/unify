const fs = require('fs');
const path = require('path');

const srcPath = path.join(__dirname, '..', 'varieties.json');
if (!fs.existsSync(srcPath)) {
  process.exit(1);
}

const data = JSON.parse(fs.readFileSync(srcPath, 'utf8'));
const varieties = [];
const seenSlugs = new Set();

// Deduplicate by slug - keep the last occurrence of each slug
for (let i = data.varieties.length - 1; i >= 0; i--) {
  const v = data.varieties[i];
  if (!seenSlugs.has(v.slug)) {
    seenSlugs.add(v.slug);
    varieties.unshift(v);
  }
}

const families = [...new Set(varieties.map(v => v.family))].sort();
const siteDir = path.join(__dirname, '..', 'site');

// Generate individual variety pages
for (const v of varieties) {
  const content = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${v.name}</title>
</head>
<body data-layout="/_layout.html">

<h2>${v.name}</h2>

<div class="variety-meta">
  <p><strong>Family:</strong> ${v.family}</p>
  <p><strong>Season to sow:</strong> ${v.sow}</p>
  <p><strong>Days to maturity:</strong> ${v.days_to_maturity}</p>
  <p><strong>Packets available this season:</strong> ${v.packets_available}</p>
</div>

<p>${v.notes}</p>

<p><em>Seed keeper: ${v.seed_keeper} — contact: ${v.keeper_contact}</em></p>

<div style="margin-top:1.5rem;"><a href="/browse/">← Back to catalogue</a></div>

</body>
</html>`;

  const filePath = path.join(siteDir, 'varieties', v.slug + '.html');
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, content);
}

// Per-family JSON for lazy loading (no member PII)
const familyMap = {};
for (const v of varieties) {
  if (!familyMap[v.family]) familyMap[v.family] = [];
  familyMap[v.family].push({ slug: v.slug, name: v.name });
}

// Families index (just names — ~200 bytes)
fs.writeFileSync(path.join(siteDir, 'families.json'), JSON.stringify(families));

// Write per-family data files alongside varieties directory
for (const family of Object.keys(familyMap).sort()) {
  fs.mkdirSync(path.join(siteDir, 'data'), { recursive: true });
  fs.writeFileSync(
    path.join(siteDir, 'data', `${family}.json`),
    JSON.stringify({ family, varieties: familyMap[family] })
  );
}
