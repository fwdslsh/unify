---
title: How lending works
layout: /_layout.html
class: lending-layout
schema: WebPage
---

# How lending works

The Fernhollow Seed Library lends vegetable seed to its members each growing season. Here is how the process works from start to finish.

## Joining the library

Become a member by visiting us at Care of the Common Field, Openfield Lane, or contacting us by email or phone. Current members receive a seed catalogue for each new season, exported directly from our membership system with every variety we have available.

## Selecting your seeds

Browse our full catalogue and choose varieties that suit your growing conditions. We grow across twelve plant families, offering everything from root vegetables to climbing beans.

## Receiving seed

Once you have selected your varieties, collect your packets in person or we can post them for members who cannot travel. Each variety comes with a small information sheet written by the seed keeper who looked after it last season.

## Growing and saving

Grow as you normally would, following our growing guides for best practices. When harvest is complete, save seed from the healthiest specimens of your chosen varieties.

## Returning seed

Dry your saved seed thoroughly and return it in a labelled packet by early autumn. Each returning member replenishes the library stock for another family's use that season.

<div class="terms-box">
  <h3>Membership terms and conditions</h3>
  <ol style="margin-left:1em; margin-top:0.5rem;">
    <li>Membership is annual, renewable at the beginning of each growing season.</li>
    <li>Members may borrow up to six varieties per season.</li>
    <li>Each variety is lent as one standard packet containing approximately thirty seeds.</li>
    <li>Borrowed seed must be returned in the following season with any saved seed attached.</li>
    <li>Seed returned must be of good quality and true to type for the named variety.</li>
    <li>The library reserves the right to limit borrowings if a particular variety becomes scarce.</li>
    <li>Members are responsible for growing conditions and should grow seed only within the recommended seasonal windows.</li>
    <li>If a member fails to return seed, they may not borrow again until two seasons have passed.</li>
  </ol>
</div>
