---
title: Growing Brassicas — Cabbage, Kale & Peas
layout: /_layout.html
schema: Article
date: 2026-01-15
---

# Growing Brassicas

Brassicas form one of our largest families at Fernhollow. These hardy vegetables grow well in the valley conditions and include cabbages, kales, and various peas that have been cultivated here for generations.

## When to sow

Most brassica varieties are sown between April and August depending on which variety you choose. Early-sown crops will establish before winter, while late-sown varieties mature through autumn.

## Planting

Brassicas prefer well-drained soil with good organic matter. Space plants according to the specific variety — larger cabbages need more room than compact kale varieties. Water well at planting time and keep weed-free until established.

## Care

Most brassicas benefit from a mulch around the base of young plants and regular watering during dry spells. Watch for cabbage white butterflies, which are common in the valley throughout summer months.

## Harvest

Cabbages are ready when heads feel firm to the touch. Kale can be harvested continuously from mid-season onwards, picking lower leaves first. Peas should be picked as soon as pods swell — leave too long and they become tough.

---

Written by volunteer grower M. Hargreave, Care of the Common Field.
