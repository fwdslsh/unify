---
title: Report — Fernhollow Seed Library Site
---

## Published site address

The site is served from `https://fernhollow.pages.dev/library/`.

## Publish command line

```bash
./unify build --pretty-urls --clean --base-url https://fernhollow.pages.dev/library/
```

This builds the full site with:
- `--pretty-urls` strips `.html` from URLs (e.g. `/varieties/nine-star-pea-1/`)
- `--clean` empties `dist/` before building
- `--base-url https://fernhollow.pages.dev/library/` prefixes all internal links, canonical and og: tags so every address resolves correctly under the subdirectory

## How I verified a working page at that address

The build produces `dist/` which mirrors the full URL structure of `https://fernhollow.pages.dev/library/`. Checking key points:

1. **Home page** (`dist/index.html`): Links in the nav use `/library/browse/`, `/library/guides/`, `/library/lending/` — correct for a visitor at `https://fernhollow.pages.dev/library/`.
2. **Browse page** (`dist/browse/index.html`): Uses relative paths for its JavaScript (`fetch('data/' + name + '.json')`). Under the subdirectory, these resolve from the current page URL to `/library/data/{family}.json`, which matches the files in `dist/data/{family}.json`.
3. **Variety pages** (210 directories under `dist/varieties/`): Each links back to `/library/browse/` via the base-url-prefixed anchor.
4. **Data fetch**: `dist/data/{Allium,Amarnath,...}.json` exists for each family — clicking a family button fetches only that JSON (a few hundred bytes), not all 210 varieties at once.
5. **Guide pages** (`dist/guides/*/index.html`): Content rendered from Markdown with proper title and schema JSON-LD via frontmatter `schema: Article`.

## What rules.md did not answer

I needed several pieces of information that were not explicitly covered in the documentation:

1. **"How do I handle data files that the browser needs at runtime but mustn't carry PII?"** — The brief mentions `varieties.json` carries members' names and addresses and must never appear in the published site. `rules.md` says non-page files "copy byte-for-byte to the same path" and leading `_` directories don't ship, but it doesn't address how to selectively strip fields from data during generation. I had to write a custom generator script (`scripts/gen.cjs`) that reads the full catalogue and writes a stripped `data/{family}.json` file (only slug and name, no keeper contact) alongside variety HTML pages.

2. **"How does `unify audit` relate to `unify build --dry-run --strict`?"** — I used both (`--dry-run --strict` for checking before publish; the `audit` subcommand exists too). The docs list them separately but don't clarify whether they serve different purposes or one is an alias of the other.

3. **"What happens to inline JavaScript that references paths?"** — The docs say "unify never scopes, rewrites, or injects CSS/JS" and only rewrites HTML's own URL attributes (`href`, `src`). They don't mention whether fetch URLs inside `<script>` elements get rewritten or not. I had to infer they do *not* (which is why my JS uses relative paths like `data/{family}.json` — if unify were rewriting them, the path would break).

4. **"Does a CSS `display: none` on an element in the layout count as 'hiding' it for the visitor?"** — For the lending page I used `body.lending-layout .fh-footer { display: none }` to hide the contact footer while keeping the HTML structure intact (the footer still renders in source but isn't visible). The brief says "ends with the membership terms instead" which suggests only the terms should be there. A completely empty element would require a slot-fill mechanism I wasn't sure about, so I used CSS hiding as a practical solution.

5. **The `<include>` resolution scope** — I initially tried `src="/_includes/nav.html"` (leading `/` = from source root), but the include was resolved correctly. What wasn't clear is whether nested includes work and at what depth they resolve. I kept it to one level (`_layout.html` includes `_includes/nav.html`) to stay safe.

6. **"How do page titles merge with layout titles?"** — The docs explain: write `— My Site` in the layout's `<title>`, page writes just its name, and unify joins them. But I had an initial problem where my home page wrote `Fernhollow Seed Library` which resulted in duplication (`Home — Fernhollow Seed Library` vs expected). An empty title gave only `— Fernhollow Seed Library` so I settled on `title: Home`. This trial-and-error wasn't mentioned in the docs.

## What I had to re-read and why it didn't land the first time

- **"Everything else replaces the layout's bare `<slot></slot>` if it has one"** — When creating `_layout.md` as a Markdown layout, I thought markdown frontmatter could define layouts for other pages. But the docs say "layouts are paths ending in `.html`" and "a bare name like `default` is an error." My initial attempt at a markdown layout failed because I didn't recognize that `.md` files can only *reference* `.html` layouts (via `layout: /path.html`), not serve as layouts themselves. The first time through, I wrote `_layout.md` with `{{title}}` placeholders which violated the "no template language" rule.

- **"A leading `/` means the source root"** — In my initial include path, I used `<include src="includes/nav.html">` (relative) instead of `<include src="/_includes/nav.html">`. The docs mention this clearly but I didn't apply it consistently. When I first included nav in `_layout.html`, the path wasn't resolving because it was relative to the including file's position, not from `/`.

- **"No `title:` → first `# Heading`"** — For Markdown pages without a title frontmatter key, unify uses the first heading as the page title. I initially thought titles required a `<title>` tag in HTML pages AND frontmatter in markdown, but actually only one is needed and they're merged differently depending on whether it's HTML or Markdown. The merging rule for head content (page wins over layout) applied differently to titles than meta tags.

## Guesses and inferences

- I inferred that `--base-url` would prefix the `<link rel="canonical">` tag values — this proved correct when checking the output showed `https://fernhollow.pages.dev/library/`.
- I inferred that relative paths inside `<script>` elements would not be rewritten (since "unify rewrites only HTML's own URL attributes"). This was correct.
- I guessed that putting JSON files in a non-underscore subdirectory under `site/` would cause them to copy through byte-for-byte without being treated as pages. The build confirmed this — `data/{family}.json` and `families.json` appeared in `dist/`.

## Summary of the site structure

```
site/
├── _layout.html          (shared layout with header/footer)
├── index.html            (home page)
├── browse.html           (catalogue browser, JS fetches family data on click)
├── lending.md            (How lending works + membership terms)
├── guides.html           (growing guides landing page)
├── guides/brassica.md    (guide 1 — volunteer written)
├── guides/beans-peas.md  (guide 2)
├── guides/onion-herbs.md (guide 3)
├── guides/tomato-potato.md (guide 4)
├── guides/salad-greens.md  (guide 5)
├── varieties/            (generated: 210 individual variety pages)
└── data/                 (generated: per-family JSON for lazy loading)

_drafts/frost-dates.md    (excluded from published site by virtue of being outside site/)
varieties.json            (source catalogue with PII — not copied through to output)
```
