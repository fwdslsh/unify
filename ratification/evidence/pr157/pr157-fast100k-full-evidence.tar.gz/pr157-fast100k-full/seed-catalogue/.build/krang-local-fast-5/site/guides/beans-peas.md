---
title: Beans, Peas & Climbing Vines
layout: /_layout.html
schema: Article
date: 2026-02-10
---

# Beans, Peas & Climbing Vines

The Fabaceae family provides some of the most reliable crops in our vegetable garden. These climbing plants are not only productive but also fix nitrogen in the soil, making them excellent companions for neighbouring crops.

## Sowing peas

Peas prefer cool weather and can be sown as early as February through to May, depending on your chosen variety. They like free-draining soil and benefit from a cane framework or wall to climb upon. Sow seeds about 5 cm deep in double rows, allowing space between plants for air circulation.

## Growing beans

Beans are tender and should only be planted after the last frost, generally April through July depending on which type you grow. They need warmer conditions than peas and benefit from sheltered positions. Bush varieties will need no support, but climbing types require sturdy frames at least two metres tall.

## Harvest tips

Peas are at their sweetest when picked in the morning after a warm night. Pick regularly to encourage continued cropping. Bean pods should be firm and brightly coloured — harvest frequently for the best flavour. Allow some beans on selected plants to mature fully if saving seed for return.

---

Written by volunteer grower T. Okonkwo, Fernhollow allotment society.
