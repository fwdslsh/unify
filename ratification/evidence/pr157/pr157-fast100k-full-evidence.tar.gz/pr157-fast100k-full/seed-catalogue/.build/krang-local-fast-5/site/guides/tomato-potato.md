---
title: "Tomatoes & Potatoes — Solanum Family"
layout: /_layout.html
schema: Article
date: 2026-04-01
---

# Tomatoes & Potatoes — Solanum Family

The Solanum family provides some of the most rewarding crops for home gardens. From heirloom tomatoes to reliable potatoes, these varieties have been cultivated at Fernhollow for over a century.

## Starting from seed

Both tomatoes and potatoes are best started indoors in modules. Tomatoes benefit from early sowing — February through March under cover. Potatoes can be 'chitted' (pre-sprouted) from mid-winter onwards, ready for planting out in spring.

## Planting positions

Tomatoes need the sunniest sheltered spot available and rich soil worked with well-rotted compost. Potatoes prefer lighter sandy soils where tubers can swell freely. Avoid planting either family where they grew the previous year — rotation is essential to prevent disease build-up.

## Growing on

Tomatoes benefit from side-lining (removing side shoots) in summer and tying up main stems as they grow. Water consistently during fruit set for even-sized, crack-free tomatoes. Potatoes need regular earthing-up — drawing soil around the base of stems as they grow to protect tubers from light exposure.

## Harvest

Tomatoes are ready when fragrant, colour is even, and fruits yield slightly to gentle pressure. Potatoes can be dug carefully once foliage begins to yellow; new potatoes can be harvested earlier for a tender, sweet result. Store mature potatoes in a cool dark place for winter use.

---

Written by volunteer grower P. Aluko, Fernhollow South field.
