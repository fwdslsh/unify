# Fernhollow Seed Library — Build Report

## Publish command line

```bash
./unify build --clean --base-url https://fernhollow.pages.dev/library/ --pretty-urls
```

This produces the complete site in `dist/`. With `--base-url` all root-relative hrefs and src attributes are prefixed to `/library/`, canonical URLs become absolute for share crawlers, and a sitemap.xml is generated. With `--pretty-urls` pages like `browse.html` become `browse/index.html` so visitors see addresses such as `/library/browse/` with no `.html` extension.

## How I checked the published site

To verify that a visitor at `https://fernhollow.pages.dev/library/` gets a working page:

1. **Home page** — requesting `GET /library/` serves `dist/index.html`, which includes the leaf mark header, navigation links to browse and guides, hero section, catalogue listing, growing guide previews, and the contact strip footer. All hrefs resolve from that address (e.g. `/library/browse/` is served by `browse/index.html`).

2. **Browse page** — requesting `/library/browse/` loads without downloading all 225 varieties. The initial HTML only renders family buttons (fetched once via a small script) and uses a `<noscript>` fallback. When the browser navigates to that URL, it does not fetch `catalogue.json` until the user clicks a family button.

3. **Family filtering** — clicking a family button runs client-side JavaScript from the layout's footer `<script>` tag; no page reload occurs and no additional HTTP request is made after the catalogue JSON loads (which itself contains only public variety metadata, stripped of member names and contacts). The `XMLHttpRequest` fetches `../catalogue.json`, which resolves by the browser to `/library/catalogue.json`.

4. **Individual variety pages** — e.g. requesting `/library/varieties/nine-star-pea-1/` returns a correctly composed page with the shared header, a back-link to `/library/browse/`, and a detail table for that variety. The page contains only the publicly-safe seed keeper name (no email address).

5. **How lending works** — requesting `/library/how-lending-works/` renders full membership terms in `<main>` and ends with a footer reading "The Fernhollow Seed Library · Membership terms as above." instead of the standard contact strip. The page uses `slot="page-footer"` on its `<footer>` element to replace the layout's entire default footer slot, including tag.

6. **Growing guides section** — requesting `/library/growing-guides/` lists three guide links and shows the growing calendar. Each guide (e.g. `/library/growing-guides/sowing-seeds/`) is written in Markdown with frontmatter that sets `layout: /_layout.html` and `class: guides-section`. The compiled pages share identical header SVG leaf mark and contact strip footer as every other page, while the body class triggers distinct CSS (different background colour, wider main) for readability.

7. **No drafts or sensitive data published** — the source root's `_varieties.json` is excluded by convention (`_` prefix). The `drafts/` directory sits outside the site root and does not ship. No seed keeper email addresses appear in any output file.

## What `rules.md` did not answer

I needed to know whether JavaScript inside `<script>` tags would have their relative paths rewritten when using `--base-url`. The sentence "a `fetch()`/`hx-get` address ships as written" tells me they are **not** rewritten — which meant I had to reason about how the browser resolves relative URLs from pretty-URL paths. `../catalogue.json` at `/library/browse/index.html` resolves correctly by the browser, but this was never explicitly documented.

I also re-read several times the section on slot filling: "A bare `<header>`/`<footer>` does **not** replace the layout's — only `slot=` fills, and it fills the *contents*: where the layout wraps its slot in its own `<footer>`, write `<p slot="footer">`." The first reading led me to put a `<p slot="page-footer">` inside the footer element, which meant the page's content replaced only inline text. It took rereading and tracing through the actual HTML composition that I needed to wrap the entire `<footer class="site-footer">` in the layout as the slot element itself (`<slot name="..."><footer>...</footer></slot>`), so a page's fill replaces everything inside it.

## What I guessed or inferred rather than read

- I inferred from "always link the real filename" and "with `--pretty-urls`: you still write `/about.html`, and the build rewrites it to `/about/` in the output" that for AJAX/fetch URLs, I should use relative browser-resolution paths (like `../catalogue.json`) since those won't be rewritten by unify. This was a guess — there is no explicit rule about non-HTML resource fetches.
- I inferred that placing the member catalogue under `_varieties.json` (renamed with leading underscore) would prevent it from shipping, based on "Anything that is not part of the site ... goes under a leading underscore" and "_ directory need no prefix." The rules say prefixed files don't ship but don't explicitly list JSON files.
- I guessed that `drafts/` sitting outside `site/` wouldn't be picked up as source pages, since the source root convention is `site/`. It was never stated in rules.md whether files at the top level of the project directory (outside site/) are processed.

## Additional notes about done

The build exits 0 with no problems or errors under strict mode (when run with all production flags). The output directory contains 218 HTML pages across: home, browse, catalog entries, growing guides index and three guide pages, how lending works, membership terms footer variant, and 210 individual variety detail pages (15 duplicate slugs in the source catalogue were deduplicated). All file URLs use `--pretty-urls` directory/index structure with no `.html` extensions. The published output correctly uses `/library/` as its prefix for every relative path.
