---
title: Season Extension — protecting crops through frost
layout: /_layout.html
class: guides-section
schema: Article
description: How to extend the growing season with cloches, cold frames, and fleece.
---

## Extending the season

The length of our growing season in the Fernhollow valley depends almost entirely on how well we protect tender crops from early frosts in autumn and late frosts in spring. A few simple tools can add at least a month to both ends of the season.

### Cloches

Cloches come in wooden frames, plastic tunnels, or small glass cabinets called bell cloches. All three work by trapping heat radiated from the soil during the day and reducing wind chill overnight. Plastic tunnel cloches are cheapest and fastest; they also let you drape fleece over them for an extra layer of insulation.

A good time to put up a cloche is as soon as the soil thaws enough to be worked. Even if you do not plant inside it straight away, leaving it uncovered will warm the ground ahead of schedule.

### Cold frames

Cold frames are box-like structures with transparent lids that sit close to the ground. They do not heat themselves; instead they capture solar energy and hold warmth above the soil surface. In bright weather even a mild spring day can make the inside of a cold frame ten degrees warmer than the surrounding air.

Use them as hardening stations for seedlings or, later in autumn, to grow leaf salads through winter if they are covered at night with an insulating mat.

### Frost fleece

Frost fleece is a lightweight woven fabric that you drape over crops. It lets light and moisture through while still providing a degree of insulation — typically two to three degrees Celsius on a calm night. The edges must be tucked under soil or stones so the wind does not lift it away.

Place fleece on as soon as frost is forecast. You can leave it up during daytime if there is no rain, but remove it when rain is expected so the water can reach the plants.

---

*Written by L. Barr, volunteer growing guide and member of the frost dates working group. Last updated: February 2026.*
