---
title: Sowing Seeds — a beginner's guide
layout: /_layout.html
class: guides-section
schema: Article
description: A practical introduction to starting vegetable seeds from scratch.
---

## Getting started

Sowing seeds is the most rewarding part of growing vegetables, and also the easiest place to go wrong. The key thing to remember is that every seed has a depth it wants you to plant at — usually no deeper than twice its own thickness.

### When to sow indoors

Most vegetables are started in modules or trays somewhere between late February and May, depending on whether they need warmth indoors before being planted outside. Tender crops such as beans, cucumbers, and tomatoes will not survive a spring frost; these should wait until after the last expected date of frost in your area. Hardy crops like broad beans and peas can go into the ground in early March if the soil is workable.

### Sowing depth and moisture

A general rule: sow at a depth equal to twice the diameter of the seed. Very fine seeds — carrots, lettuce, some brassicas — barely need covering at all. Larger seeds — beans, sweet peas, squash — should be placed deeper.

Keep the compost just damp, never waterlogged. Overwatering is one of the most common causes of failure; it drowns the tiny rootlets before they have a chance to reach for light.

### Hardening off

Before plants go outside, they need to acclimatise. Start by placing them out during the day and bringing them in at night for a week. Once they are showing steady growth over several days without signs of wilting or scorching, they can be planted out for good.

---

*Written by M. O'Brien, volunteer growing guide. Last updated: March 2026.*
