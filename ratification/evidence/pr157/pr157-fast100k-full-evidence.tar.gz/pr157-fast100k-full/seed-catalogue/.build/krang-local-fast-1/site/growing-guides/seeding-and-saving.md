---
title: Seeding and Saving — keeping your own seed
layout: /_layout.html
class: guides-section
schema: Article
description: A guide to saving healthy, true-to-type seed from your home garden.
---

## Saving seed for next season

One of the core principles of the Fernhollow Seed Library is that every packet lent out should ultimately produce saved seed to replenish our collection. Learning how to harvest and store seed properly ensures that both you and your neighbours will have viable seed for years to come.

### Choosing which plants to save from

Not every plant produces true-to-type seed when saved. Cross-pollinating crops like brassicas and alliums need isolation distances of at least two hundred metres, while self-pollinating crops such as beans, tomatoes, and lettuce can be grown next to one another and still breed true — provided you remove rogue plants later in the season.

### Harvesting dry seeds

Beans, peas, lettuce, spinach, most brassicas, onions, and leeks all produce seed that dries well on the plant or after harvest. Leave a healthy representative sample until pods or capsules feel brittle and light. Harvest them when they begin to split open naturally.

Thresh by hand inside a large bin bag to catch loose seeds, then winnow by pouring the mix slowly between two containers on a breezy day. Store cleaned seed in labelled paper envelopes inside an airtight tin with a desiccant packet.

### Saving wet seeds

Tomatoes, cucumbers, squash, and some beans produce seeds coated in a juicy pulp that must be fermented before drying. Place the seeds in a small container with some of the surrounding gel and leave to ferment at room temperature for three days until a mould layer forms on top. Rinse gently on a sieve, spread to dry completely on a plate or tile, and store as above.

### Storing your seed

Labels are everything: record variety, date saved, and any notes on colour or vigour of the parent plants. Most vegetable seed remains viable for two to four years if stored cool and dry; beans and peas will last longer than lettuce or onion seed.

---

*Written by J. Vance, Seed Keeper at Fernhollow. Last updated: January 2026.*
