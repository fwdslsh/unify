import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

const catalogueFull = JSON.parse(readFileSync(join(process.cwd(), '_varieties.json'), 'utf8'));
const varieties = catalogueFull.varieties;

// Generate individual variety pages in site/varieties/<slug>/index.html
varieties.forEach(function(v) {
  const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${v.name}</title>
</head>
<body class="">

<main>
  <a href="/browse/" class="back-link">&larr; Back to catalogue</a>

  <div class="variety-detail">
    <h2>${v.name}</h2>

    <dl>
      <dt>Family</dt><dd>${v.family}</dd>
      <dt>Season</dt><dd>${v.season}</dd>
      <dt>Sow</dt><dd>${v.sow}</dd>
      <dt>Days to maturity</dt><dd>${v.days_to_maturity}</dd>
      <dt>Packets available</dt><dd>${v.packets_available}</dd>
    </dl>

    <p>${v.notes}</p>

    <p><em>Seed keeper: ${v.seed_keeper}</em></p>
  </div>
</main>

</body>
</html>`;

  const dir = join(process.cwd(), 'site', 'varieties', v.slug);
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  writeFileSync(join(dir, 'index.html'), html);
});

console.log('Generated ' + varieties.length + ' variety pages.');
