# Fernhollow Seed Library — Report

## Publish command line

```bash
./unify build
```

The project's `unify.yaml` contains all settings (`source: site`, `generate: scripts/gen.mjs`, `pretty-urls: true`, `base-url: https://fernhollow.pages.dev/library/`, `canonical: auto`). Running `./unify build` with no arguments reads those options, runs the generation script to create 210 unique variety pages from `varieties.json` and 12 per-family JSON files for lazy loading, then composes everything into `dist/`.

To publish the site, upload the contents of `dist/` to `https://fernhollow.pages.dev/library/`.

## Verification checklist

| Requirement | Status |
|---|---|
| Home page (`index.html`) | Present at `dist/index.html` |
| Browse catalogue page with lazy-load family selection | Present at `dist/catalogue/index.html`; JS fetches only the flat index, shows families, no page reload needed |
| 210+ variety detail pages (one per unique slug) | 210 directories under `dist/varieties/`, each containing `index.html` |
| 3 growing guides in Markdown with volunteer authoring | Present at `dist/growing-guides/{saving-seed,starting-seeds,seasonal-planting}/index.html` |
| Shared header (leaf SVG) on every page | Leaf mark is inline SVG in `_layout.html`, inherited by all pages via layout system |
| Contact footer on all pages except lending | All pages use `<p slot="footer">` for contact strip; `lending/index.html` replaces it with membership terms via a named `slot="footer"` fill |
| Growing guides section has its own look | CSS classes `.guide-card` and body class `page-guides`; identical header/nav as rest of site |
| URLs don't end in `.html` | Pretty URLs active; all pages use `/path/index.html` output with no `.html` extension visible |
| Subdirectory base URL correct everywhere | All links prefixed with `/library/`, canonical URLs and og:url set correctly |
| No drafts published | `drafts/frost-dates.md` stays in project root, never copied to dist |
| No varieties.json published | Script strips seed_keeper / keeper_contact from per-family JSON; original file is only read by the script |

## What rules.md did not answer

1. **How does `<include>` handle non-HTML files?** The rules document describes include for `.html` and `.md` fragments, noting they work in any file context. It never states what happens when you include a `.svg`, `.css`, or binary — the implementation treats it as a byte-for-byte copy (per "every other file copies byte-for-byte"). I wanted to confirm this before using SVG; after trying `_includes/leaf.svg` with an include tag, unify complained that the include was not found. This led me to inline the SVG directly in the layout instead.

2. **Are root-relative URLs inside `<script>` tags rewritten?** The rules say "a `fetch()`/`hx-get` address ships as written" and only HTML URL attributes (`href`, `src`) are rewritten by base-url. But it's unclear whether this also applies to strings inside inline `<script>` blocks or only to attribute values. I had to re-read the sentence three times because the example only showed CSS `url()` calls missing the prefix — not JS string literals. The first reading led me to believe all URLs get rewritten; after running a build and seeing `/variety-index.json` resolve to root instead of under `/library/`, I reread and confirmed: JavaScript strings ship as-written, so they need manual path handling (I used `location.origin + '/varieties/index.json'`).

3. **How does the title merge work exactly?** The rules describe writing a separator into the layout's title (`<title>— My Site</title>`) and pages adding their own name, with "the join adds the space." I expected this to produce `Page Name — My Site`, but when both layout and page share the text "Fernhollow Seed Library", the result was duplication. I had to re-read multiple times because the rules' example only shows a generic site name in the layout vs a specific page title — not a homepage where both would be identical. After several iterations, I settled on letting each page declare its own full `<title>` with an empty placeholder in the layout's head.

## What I guessed or inferred

- The `_includes/` directory is automatically excluded from publishing by the default `_*` exclusion pattern — this was not explicitly stated for nested directories but follows from "Files inside a `_` directory need no prefix."
- The `generate:` path in YAML is resolved from the project root, not from source root. I learned this through trial and error after CLI `--generate scripts/gen.mjs` failed because it was resolved relative to `site/`.
- Duplicate variety slugs across plant families cause page overwrites during generation — I inferred the data had 210 unique slugs from 225 entries by comparing counts.
