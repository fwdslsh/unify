#!/usr/bin/env node
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const root = join(dirname(__filename), '..');

const data = JSON.parse(readFileSync(join(root, 'varieties.json'), 'utf8'));
const outDir = join(root, 'site', 'varieties');
if (!existsSync(outDir)) mkdirSync(outDir, { recursive: true });

// Build family groups with safe variety data (strip seed keeper contacts)
const byFamily = {};
for (const v of data.varieties) {
  if (!byFamily[v.family]) byFamily[v.family] = [];
  const safe = { ...v };
  delete safe.seed_keeper;
  delete safe.keeper_contact;
  byFamily[v.family].push(safe);
}

// Write per-family JSON files for lazy-loading
for (const [family, varieties] of Object.entries(byFamily)) {
  writeFileSync(
    join(outDir, family + '.json'),
    JSON.stringify({ family, varieties }, null, 2)
  );
}

// Generate individual variety pages
for (const v of data.varieties) {
  const html = `<!doctype html>
<html lang="en" data-layout="/_layout.html">
<head><title>${v.name}</title></head>
<body class="page-variety">

<main>
  <h2>${v.name}</h2>
  <p><strong>Family:</strong> <a href="/catalogue.html#family-${v.family}">${v.family}</a></p>

  <table style="margin:1rem 0;border-collapse:collapse">
    <tr><td style="padding:.35em .75em;vertical-align:top"><strong>Season to sow</strong></td><td style="padding:.35em .75em">${v.season}</td></tr>
    <tr><td style="padding:.35em .75em;vertical-align:top"><strong>Sow</strong></td><td style="padding:.35em .75em">${v.sow}</td></tr>
    <tr><td style="padding:.35em .75em;vertical-align:top"><strong>Days to maturity</strong></td><td style="padding:.35em .75em">${v.days_to_maturity}</td></tr>
    <tr><td style="padding:.35em .75em;vertical-align:top"><strong>Packets available</strong></td><td style="padding:.35em .75em">${v.packets_available}</td></tr>
  </table>

  <p style="margin-top:1rem;opacity:.8">${v.notes}</p>

  <p style="margin-top:1rem;font-size:.9em"><strong>Seed keeper:</strong> ${v.seed_keeper} &middot; <a href="mailto:${v.keeper_contact}">contact</a></p>
</main>

<p slot="footer" class="footer">Fernhollow Seed Library &middot; info&#64;fernhollow.example &middite; 01920 748301</p>

</body>
</html>`;
  writeFileSync(join(outDir, v.slug + '.html'), html);
}

// Also write variety index for the catalogue page to read
const flat = data.varieties.map(v => ({ slug: v.slug, name: v.name, family: v.family }));
writeFileSync(join(outDir, 'index.json'), JSON.stringify(flat, null, 2));

console.log('Generated', data.varieties.length, 'variety pages');
const families = Object.keys(byFamily).length;
console.log(families, 'family files written');
