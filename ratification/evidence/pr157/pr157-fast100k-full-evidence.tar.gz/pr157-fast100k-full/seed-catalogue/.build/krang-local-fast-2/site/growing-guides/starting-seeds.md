---
title: Starting Seeds
layout: /_layout.html
schema: Article
description: The basics of sowing, watering, and keeping seedlings healthy indoors.
date: 2026-02-20
---

# Starting Seeds

Most vegetables at Fernhollow grow best when started off indoors and then moved out to the garden once the weather warms. This guide walks through everything from sowing a packet to planting your first seedling outside.

## Getting started

You will need seed, compost, pots or trays, and a light place — a windowsill or greenhouse counts. Do not buy expensive equipment; cardboard egg boxes doubled with foil make excellent starter pots.

## The basics of sowing

Fill your container with compost to about a centimetre below the rim. Press gently, never pack hard. Place seeds at roughly their own diameter beneath the surface — tiny ones on top, larger ones deeper. Cover lightly and water from below by setting the tray in warm water for ten minutes.

## Keeping seedlings happy

Place trays somewhere bright and warm, ideally above fifteen degrees Celsius. Do not let compost dry out between waterings. If seedlings start leggy or stretched they need more light — move them closer to the window or add a reflective backing behind the pot.

## Hardening off

When seedlings have their second set of true leaves it is time to move outside. Start by leaving them in shade for an hour, then gradually increase sun exposure over ten days. This process is called hardening off and prevents shock when plants meet real weather.

## Planting out

Once the last frost has passed and the soil feels warm (not cold) under your fingers, you are ready to plant outside. Space according to the variety — crowded plants do not thrive. Water well after planting and keep a lookout for slugs over the next few days.
