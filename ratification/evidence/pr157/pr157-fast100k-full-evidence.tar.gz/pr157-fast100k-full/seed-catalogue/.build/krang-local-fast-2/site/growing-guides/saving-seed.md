---
title: Saving Seed
layout: /_layout.html
schema: Article
description: How to save seed from your harvest and store it through the winter.
date: 2026-03-15
---

# Saving Seed

Saving seed is one of the oldest and most rewarding practices a home gardener can learn. At Fernhollow we have saved the same varieties for generations — each packet carries a story, and every season we add to it.

## Why save your own seed

When you grow from saved seed you keep varieties that work in our local conditions. Imported or catalogue seeds may not perform as well here, but seed from plants already growing in the valley will settle into the soil over time and become more reliable each year.

## When to harvest

Harvest seed when the fruit or pod is fully ripe and dry on the plant. If it splits open when you touch it, it is ready. For tomatoes and peppers wait until the fruit softens past ripe. For beans and peas leave them on the stalk until brown and brittle.

## How to extract

**From pods (beans, peas):** Shell the seeds from completely dry pods. Winnow by pouring them slowly between two bowls in a light breeze — the empty shells will blow away and the good seed will fall straight down.

**From fruit (tomatoes, cucumbers):** Scoop the seeds into a jar of water and let it ferment for three days. Bad seeds float; good seeds sink. Wash the good ones in clean water and spread on a plate to dry.

**From heads or pods (carrots, parsnips):** Cut off the seed head once the seeds are mature and dry. Place inside a paper bag and rub gently over several days. The chaff will separate through the mesh.

## Storing your seed

Always use paper envelopes, never plastic bags. Write on them with pencil only — ink will run if damp. Keep packets in an airy place until you are certain they are thoroughly dry, then store in a cool dark cupboard through winter.

Check them every few months: tap one open and listen for the rattle of healthy, dry seed. If it sounds dull or feels soft it is time to grow something fresh.
