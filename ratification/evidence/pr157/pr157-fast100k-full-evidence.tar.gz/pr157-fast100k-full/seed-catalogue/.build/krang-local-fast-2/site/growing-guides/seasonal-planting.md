---
title: Seasonal Planting Calendar
layout: /_layout.html
schema: Article
description: When to sow what — a month-by-month guide for the temperate garden.
date: 2026-01-15
---

# Seasonal Planting Calendar

A good garden follows the seasons. This month-by-month guide pulls from decades of growing experience at Fernhollow, showing when each common vegetable should go into the ground and what to watch for along the way.

## January — Planning sowing time

The year starts indoors. Sow onions, leeks, and early potatoes in pots on a warm windowsill. Check your seed packets for dates — most of our varieties do best sown between February and April. Use this month to order extra seed if needed.

## February — Early sows

Carrots, parsnips, and broad beans can go into cold frames or under cover now. Start tomatoes and peppers indoors; they need a long warm window before planting out. Watch for mice in the seed store — paper packets are not enough on their own.

## March — Main sowing begins

Brassicas go in: broccoli, cabbage, cauliflower, and kale can all be sown direct or started in modules. Peas, beetroot, and lettuce follow soon as the soil warms. Keep horticultural fleece handy; late frosts are still possible through early spring.

## April — Outdoors take over

Most vegetables go directly into the ground now. Plant maincrop potatoes, runner beans, courgettes, and squashes after all frost danger has passed. Continue with lettuce and radishes every few weeks for a steady supply.

## May — Warm weather gardening

Succession sow everything you eat regularly: beans, carrots, beetroot, turnips. Tie up early peas and broad beans as they flower. Start hardening off any indoor seedlings grown for summer transplanting.

## June — First harvests

Pick what is ready: spring onions, radishes, lettuce, spinach, early potatoes. Keep weeds down between rows; thin crops so plants have room to grow. Start preparing beds for autumn planting of over-wintering crops.

## July — Midsummer management

Keep brassicas watered and watch for cabbage white caterpillars. Succession sow beetroot and carrots for autumn harvest. Continue picking beans regularly to keep them cropping well into September.

## August — Late sowing

Sow quick-maturing salads: lamb's lettuce, corn salad, and winter purslane. Plant over-wintering onions and garlic from sets or small divisions. Start preparing beds with green manures where summer crops are finished.

## September — Autumn work

Harvest maincrop potatoes as soon as foliage dies down. Harvest seed heads for saving — let them dry fully in a paper bag indoors. Start covering cold frames for protecting early spring sowings through winter.

## October — Closing the season

Clear beds of spent crops and return compostable material to your pile. Save seed from all remaining varieties and label carefully with pencil. Store hardy roots like carrots and parsnips in sand or root sleeves.

## November — Preparing for rest

Focus on soil health. Dig resting ground, add compost and well-rotted manure where possible. Order next year's seed from the Fernhollow catalogue and plan your rotation so families do not follow themselves.

## December — Rest and reflect

Take stock of what grew well and what did not. Keep seed warm and dry in a dark cupboard. Plan next year's planting map while the garden sleeps. The new season is always worth thinking about now.
