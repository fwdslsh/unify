---
title: Growing carrots for a steady harvest
date: 2026-01-20
description: Tips and techniques for growing straight, sweet carrots from sowing to harvest.
---

# Growing carrots for a steady harvest

Carrots reward patience with sweet, earthy roots that store well through winter. The trick lies in getting the soil right before you sow anything at all.

## Preparing your bed

Carrots need deep, stone-free soil. If you have clay-heavy ground, fork in plenty of compost or well-rotted manure in autumn so it works down by planting time. A shallow, firm surface is what you want — never overly rich or the roots will fork and split.

## Sowing carrots

Sow thinly from March through August for a continuous harvest. The seed is tiny and slow to germinate, which can take three to four weeks. Sow in short rows beside markers so you know where each sowing date goes. Light watering after sowing keeps the surface from crusting over.

## Thinning

Once seedlings are ten centimetres tall and firmly established, thin them out to five centimetres apart. Do not skip this step — crowded carrots will not swell properly. Use your shears rather than pulling, to avoid disturbing neighbours.

## Harvesting

Pull when they reach pencil thickness, or leave them in the ground and harvest as needed through winter after the first frost makes them sweeter. The soil should be moist when you dig, so water lightly a day before if it has been dry.

---

Written by T. Okonkwo, volunteer grower. Updated January 2026.
