---
title: Growing tomatoes in cooler climates
date: 2026-01-25
description: How to grow productive tomato crops even when the summers are short and cloudy.
---

# Growing tomatoes in cooler climates

Tomatoes can thrive beyond the south of England if you choose the right varieties and give them shelter. Fernhollow's damp, cool summers are well suited to a number of heirloom types that need less sun than commercial hybrids.

## Choosing varieties

Select varieties rated for early ripening — look for anything under 70 days to maturity. The Fernhollow Seed Library carries several local selections bred specifically for our valley climate: the Early Pride line and the late-summer Sunset Bush are particularly reliable.

## Starting plants

Start tomatoes indoors in April, sowing seeds in small pots of multipurpose compost. Keep them warm until they germinate — a windowsill above radiators works well. Plant them deeper than you would for most vegetables; burying part of the stem encourages stronger roots.

## Position and care

Choose the sunniest wall or fence on your property, ideally with south-facing orientation. A cold frame or polytunnel in front adds enough warmth to make a two-week difference to ripening. Feed weekly once fruits begin setting and keep soil evenly moist to avoid blossom-end rot.

## Harvesting early

Pick firm green tomatoes near the end of September and bring them indoors on a sunny sill to finish ripening. A basket of these will colour up through October, long after the outdoor crops have surrendered.

---

Written by R. Simms, Fernhollow growing group. Updated January 2026.
