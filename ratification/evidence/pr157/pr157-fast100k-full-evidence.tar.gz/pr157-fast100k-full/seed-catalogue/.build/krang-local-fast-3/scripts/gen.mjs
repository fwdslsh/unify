import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const catalogPath = path.join(__dirname, '..', 'varieties.json');
const data = JSON.parse(fs.readFileSync(catalogPath, 'utf8'));
const siteRoot = path.join(__dirname, '..', 'site');

// Group varieties by family (sorted for determinism)
const famMap = {};
for (const v of data.varieties) {
  if (!famMap[v.family]) famMap[v.family] = [];
  famMap[v.family].push(v);
}
const famNames = Object.keys(famMap).sort();

// Per-family JSON files for AJAX (published alongside browse page)
ensureDir(path.join(siteRoot, 'data'));
for (const fn of famNames) {
  const slug = slugify(fn);
  fs.writeFileSync(
    path.join(siteRoot, 'data', 'variations-' + slug + '.json'),
    JSON.stringify({ family: fn, varieties: famMap[fn] }, null, 2) + '\n'
  );
}

// Individual variety detail pages (published at site/data/<family>/<slug>.html)
ensureDir(path.join(siteRoot, 'data'));
for (const fn of famNames) {
  ensureDir(path.join(siteRoot, 'data', slugify(fn)));
  for (const v of famMap[fn]) {
    const html = renderVarietyPage(v);
    fs.writeFileSync(
      path.join(siteRoot, 'data', slugify(fn), slugify(v.name) + '.html'),
      html
    );
  }
}

// Read browse template and inject family names into JS
let browseHtml = fs.readFileSync(path.join(siteRoot, 'browse.html'), 'utf8');
const familiesJs = JSON.stringify(famNames.map(n => ({ name: n })));
browseHtml = browseHtml.replace(
  'var familiesData = {{FAMILIES}};',
  'var familiesData = ' + familiesJs + ';'
);
fs.writeFileSync(path.join(siteRoot, 'browse.html'), browseHtml);

console.log('Generated', data.varieties.length, 'variety pages across', famNames.length, 'families');

// --- helpers ---

function ensureDir(d) { try { fs.mkdirSync(d, { recursive: true }); } catch(e) {} }

function slugify(s) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-)|(-$)/g, '');
}

function renderVarietyPage(v) {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>${esc(v.name)}</title>
  <style>
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    body{font-family:system-ui,-apple-system,sans-serif;line-height:1.6;color:#2d3a2d;background:#f7faf4}
    a{color:#2b5e27;text-decoration:none}
    a:hover{text-decoration:underline}
    .header{display:flex;align-items:center;gap:1rem;padding:.8rem 1.5rem;background:#3a6b30;color:#fff;font-size:.95rem}
    .header svg{width:34px;height:34px;flex-shrink:0;margin-right:-.25rem}
    nav{background:#e8f0e6;padding:.6rem 1.5rem;display:flex;gap:1.2rem;flex-wrap:wrap;font-size:.85rem}
    nav a{color:#2b5e27;border-bottom:2px solid transparent;padding:.3rem 0}
    main{max-width:860px;margin:2rem auto;padding:1.5rem;background:#fff;min-height:60vh}
    h2{font-size:1.6rem;color:#3a6b30;margin-bottom:1rem}
    p{margin-top:.5rem;line-height:1.8}
    .meta{background:#eef5e9;padding:1rem;margin:1rem 0;border-radius:4px;line-height:2.2;font-size:.95rem}
    .meta dt{font-weight:700;min-width:160px;display:inline-block}
    body footer { display: none !important; }
  </style>
</head>
<body data-layout="/_layout.html">
  <h2>${esc(v.name)}</h2>
  <p>${esc(v.notes || '')}</p>
  <dl class="meta">
    <dt>Plant family</dt><dd>${esc(v.family)}</dd>
    <dt>Sowing window</dt><dd>${esc(v.sow || '—')}</dd>
    <dt>Days to maturity</dt><dd>${typeof v.days_to_maturity === 'number' ? v.days_to_maturity + ' days' : '—'}</dd>
    <dt>Packets available</dt><dd>${typeof v.packets_available === 'number' ? v.packets_available : '—'}</dd>
    <dt>Season</dt><dd>${esc(v.season || '—')}</dd>
    <dt>Seed keeper</dt><dd>${esc(v.seed_keeper || '—')}</dd>
  </dl>
</body>
</html>`;
}

function esc(s) {
  return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;');
}
