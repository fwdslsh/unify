(function(){
function esc(s){var d=document.createElement('div');d.textContent=s||'';return d.innerHTML}

// Derive base path from current URL (handles subdirectory deployment)
var parts = window.location.pathname.split('/');
var basePath = '/' + (parts[1]||'') + '/';

var familiesEl=document.getElementById('families');
var table=document.getElementById('varieties');
var tbody=document.getElementById('var-tbody');
var countEl=document.getElementById('variety-count');

async function load(family){
  try{
    var fs=family.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-)|(-$)/g,'');
    var r=await fetch(basePath+'data/variations-'+fs+'.json');if(!r.ok)return;
    var d=await r.json();tbody.innerHTML='';var c=0;
    (d.varieties||[]).forEach(function(v){
      var tr=document.createElement('tr');
      var nm='<a href="'+basePath+'data/'+fs+'/'+v.slug+'">';nm+=esc(v.name);nm+='</a>';
      var sow=v.sow?'<td>'+esc(v.sow)+'</td>':'';
      var days=typeof v.days_to_maturity==='number'?('<td>' + v.days_to_maturity +' days</td>'):'';
      var pkts=typeof v.packets_available==='number'?('<td>'+v.packets_available+'</td>') : '';
      tr.innerHTML='<td>'+nm+'</td>'+sow+days+pkts;
      tbody.appendChild(tr);c++;
    });
    countEl.textContent='Showing '+c+' variety'+(c!==1?'':'')+' in '+esc(family);
  }catch(e){countEl.textContent='Could not load varieties for '+family}
}

var fams=[{"name":"Allium"},{"name":"Amaranth"},{"name":"Apiaceae"},{"name":"Asteraceae"},{"name":"Brassica"},{"name":"Chenopod"},{"name":"Cucurbita"},{"name":"Fabaceae"},{"name":"Lamiaceae"},{"name":"Poaceae"},{"name":"Solanum"},{"name":"Umbellifer"}];

fams.forEach(function(f){
  var card=document.createElement('a');card.className='family-card';card.href='#';card.textContent=f.name;
  card.addEventListener('click',function(e){e.preventDefault();load(f.name);table.classList.add('show');document.querySelectorAll('.family-card').forEach(function(c){c.classList.remove('active')});card.classList.add('active')});
  familiesEl.appendChild(card);
});

if(fams.length>0) load(fams[0].name);
})();
