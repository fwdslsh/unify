---
title: How to grow beans
date: 2026-01-15
description: A practical guide to planting, supporting, and harvesting beans from seed.
---

# How to grow beans

Beans are one of the easiest vegetables to grow, even for beginners. With a little care at sowing time and some simple support structures, you will have a steady harvest through summer.

## When to sow

Sow beans outdoors once the soil has warmed — generally from April onwards in our valley area. The old gardener's rule is: plant beans when dandelions flower. Sow them two inches deep and six inches apart along a firm row.

## Sowing

Soak your bean seeds overnight before sowing to help them germinate faster. This makes the difference between waiting two weeks and having sprouts in ten days. Plant each seed at least five centimetres deep in warm, well-drained soil.

## Supporting

Bush beans need nothing special, but climbing varieties will benefit from pea sticks or a trellis placed beside the row before planting. Train the stems gently upward as they grow and tie them loosely with twine once they reach eye height.

## Harvesting

Pick podded beans regularly — the more you pick, the more your plant produces. Check every couple of days during peak season. A good first harvest from a single row can yield enough for three meals.

---

Written by M. Cross, Fernhollow growing group. Last updated January 2026.
