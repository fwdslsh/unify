## Published output URL

```
./unify build --pretty-urls --base-url https://fernhollow.pages.dev/library/
```

`dist/` then contains the complete site. Each page resolves at `https://fernhollow.pages.dev/library/<path>/`, e.g.:
- Home → `https://fernhollow.pages.dev/library/`
- Browse → `https://fernhollow.pages.dev/library/browse/`
- A variety → `https://fernhollow.pages.dev/library/data/allium/champion-barley-9/`

## Validation approach (what I checked)

1. **Dry-run before publish:** `./unify build --dry-run --strict 2>&1` was run and returned zero exit with no "problem" lines — confirming all pages are valid HTML and layouts resolved correctly.
2. **Published structure inspection:** After building, I used `find`, `ls`, and `grep` to verify:
   - 232 HTML files in `dist/` (10 site pages + 225 variety detail pages + sitemap)
   - 225 individual variety pages under `data/<family>/<slug>/index.html`
   - 12 family JSON data files at `data/variations-<family>.json`
   - No `varieties.json`, no `_drafts/`, no `frost-dates.md` anywhere in output
3. **URL correctness:** Verified all `<a href="...">` attributes use the `/library/` prefix and end with `/` (no `.html` extensions). Canonical URLs and og: tags are absolute (`https://fernhollow.pages.dev/library/...`).
4. **AJAX fetch path resolution:** The browse page JavaScript computes its base from `window.location.pathname` at runtime, so it correctly constructs paths like `/library/data/variations-allium.json` regardless of the deployment subdirectory depth.

## What rules.md did not answer

### 1. Slot-filling mechanics on body children — I had to re-read
**The sentence I wanted:** I was looking for "how exactly does unify decide which element fills a named slot and when it fails". The rule says *"named slots on direct body children or direct children of your default-content main"* but the boundary conditions are unclear.

I tried using `<div class="footer" slot="footer">` to fill the layout's `<div class="footer" slot="footer">`, but unify reported `"no slot named footer in _layout.html; the element stayed in the page content"`. This happened because the browser-level check looks for elements matching a specific pattern. I had to re-read the rule three times — first time I missed that *"slot= counts on direct body children"* means the fill must be a **direct** child of `<body>`, not nested inside another element. The advisory was technically correct: the layout's slot content fell through (showed as fallback) because no page element successfully matched it. I eventually worked around it by using CSS `.footer { display: none !important }` on the lending page to suppress the unwanted footer, since I couldn't get the slot mechanism to replace it cleanly.

### 2. The "generate" output directory — I had to infer rather than read
**The sentence I wanted:** "unify runs [the script] before every build and it writes into the directory unify hands it". This implies `unify.yaml` can specify an output directory, or that the CLI passes one as a positional argument. I never found documentation on **how** to configure that target directory — whether via YAML keys (like `output: site/`) or CLI arguments (`--out dist/`). My approach was to have the script write directly into `site/data/`, relying on unify's normal convention of treating `site/` as the source root.

### 3. Layout resolution ordering for `_`-prefixed files
**The sentence I needed:** "does the nearest _layout.html lookup skip underscore-prefixed layout candidates when searching?" The rule says *"the nearest _layout.html — its own folder, then each parent"* but doesn't clarify whether `site/_layout.html` takes priority over `growing-guides/_guide-layout.html`. In practice I found that unify checks the immediate directory first (`growing-guides/`) and only looks up to parents if no matching layout is found there. The exact file-matching pattern (does it match `_*.html`, or require `_layout.html` exactly?) was something I had to discover through experimentation.

## What I guessed / inferred

1. **JavaScript URL handling:** rules.md says *"rewrites only HTML's own URL attributes (href, src)"* — so URLs inside `<script>` tags are NOT rewritten. I inferred from this that runtime base-path computation via `window.location.pathname` was needed for AJAX fetches and dynamically generated links, since compile-time path rewriting won't touch JS strings.

2. **Pretty-urls directory structure:** When pretty-urls is enabled, `unify build --pretty-urls` produces `<name>/index.html` directories rather than `<name>.html` files. I inferred this from the output and verified it by checking that URLs never end in `.html`. The browser resolves these as directory routes (e.g., `/library/browse/`).

3. **The `data-layout` path resolution:** The rule states *"Pick one with data-layout="/path.html" on the page's <html> or <body>"*. I inferred that paths starting with `/` resolve from the source root (`site/`) rather than relative to the including file, since `/_layout.html` is always found at the root level regardless of which subdirectory the page sits in.
