---
title: How lending works
description: Learn how the Fernhollow Seed Library lends seeds to members. Discover our membership rules and seed lending process.
layout: ./_layout.html
class: guides-body
---

# How lending works

Fernhollow Seed Library shares fresh vegetable seeds with our growing community through a simple, trust-based lending system. This page explains how it all works — what we ask of members, how long seeds stay out, and what happens at harvest time.

## The basics

Every season, we prepare fresh packets from home-saved crops. Members borrow one packet per variety they wish to grow. No money changes hands; the arrangement is built on shared values and mutual care.

## How to borrow

1. **Pick your varieties.** Browse our catalogue and choose which seeds you'd like to grow.
2. **Collect your packets.** We'll set aside exactly what you've chosen in sealed, labelled envelopes.
3. **Grow responsibly.** Follow the growing guides we provide for each family. Keep a small journal — note sowing dates, germination rates, and any surprises.
4. **Return at least half.** When harvest is done, thresh your seeds and return at least 50 % of what you borrowed. The remainder stays yours to keep or share with neighbours who can't join the programme directly.

## Why we lend rather than sell

Seeds are the original technology — they reproduce, adapt, and belong to everyone. By lending instead of selling, we keep genetic diversity circulating locally and ensure that each season's harvest strengthens next season's stock.

<a href="/catalogue.html">Browse our catalogue &rarr;</a>

<div slot="footer" class="site-footer terms">
  <h2>Membership terms and conditions</h2>
  <p>Fernhollow Seed Library lends fresh seeds to members for personal garden use only. Members must return at least half the quantity borrowed, using seeds harvested from that same packet. Seeds remain property of Fernhollow and must be returned each season. We reserve the right to adjust lending limits based on harvest yields.</p>
</div>
