---
title: Growing Tomatoes in the Valley Climate
layout: ./_layout.html
class: guides-body
description: Learn how to grow productive tomato plants even with Fernhollow's short, cool summers.
date: 2026-04-02
---

# Growing Tomatoes in the Valley Climate

Tomatoes can thrive at Fernhollow given the right choice of variety and a little patience. The key is selecting early-maturing types and giving plants every advantage from the start.

## Choosing varieties

Select varieties with days-to-maturity under 70 for the best harvest. Our valley's growing season simply does not support late-harvesting types unless you have a very warm, sheltered site.

The Nine Star Pea-adjacent selections often perform well here — they are bred to ripen before autumn frosts.

## Starting strong

Start seeds indoors in February or March. Use a free-draining compost and provide warmth (18–20°C) until germination. Hardy off gradually once seedlings have their first true leaves.

Plant out only after all danger of frost has passed, usually early June. Space plants 45–60 cm apart and stake or cage immediately.

## Feeding and watering

Water deeply but infrequently — consistent moisture prevents splitting and blossom-end rot. Feed weekly with a tomato-specific fertiliser from the first truss set.

Remove all side-shoots on cordon varieties to concentrate energy on fruit production. Indeterminate types need regular disbudding throughout summer.

<include src="/_includes/footer-contact.html"></include>
