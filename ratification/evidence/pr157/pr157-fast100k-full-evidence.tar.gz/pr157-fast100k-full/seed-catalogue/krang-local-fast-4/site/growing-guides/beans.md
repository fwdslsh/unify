---
title: Growing Beans from Seed
layout: ./_layout.html
class: guides-body
description: A practical guide to sowing, nurturing, and harvesting beans in your garden.
date: 2026-03-15
---

# Growing Beans from Seed

Beans are among the easiest crops for beginner growers and one of the most rewarding for experienced ones. With careful sowing and regular picking, a small patch can feed a family through summer.

## When to sow

Wait until after the last frost. In Fernhollow valley that usually means late April or early May. The soil should feel warm — at least 15°C at planting depth.

Sow beans 3 cm deep and 10 cm apart, in short rows or blocks. Push the seed firmly into firm ground; they need good contact with moisture.

## Care through the season

Keep young plants weeded but do not disturb roots when hoeing. Bean leaves are shallow and easily damaged. Water only during prolonged dry spells — established beans prefer drier conditions to disease-prone ones.

Support varieties with canes and string if they grow tall. Lower-climbing types need no assistance at all.

## Harvest and saving

Pick green beans when firm but before the pods swell noticeably underneath. Pick regularly to encourage more flowers. For runner beans, allow pods to mature on the plant, then harvest dry seeds from opened pods.

Save seed from your best-producing plants — you will find your varieties becoming ever better adapted to our valley over successive seasons.

<include src="/_includes/footer-contact.html"></include>
