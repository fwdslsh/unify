---
title: Seed Saving Basics — Keeping Varieties Alive
layout: ./_layout.html
class: guides-body
description: The essentials of collecting, drying, and storing vegetable seed for future planting seasons.
date: 2026-05-10
---

# Seed Saving Basics

Seed saving is the heart of what we do at Fernhollow. Every saved variety carries not just genetics but generations of local growing knowledge. Learning to save seed means you become part of that chain.

## Before you start

Select only from your healthiest, most productive plants. Mark them with a ribbon or tag when they flower so you know where to harvest later. Poor plants produce poor seed — cull ruthlessly throughout the season and keep only the best.

## Basic techniques

Most vegetables in our catalogue are open-pollinated and breed true from saved seed. The method depends on how seeds are packaged:

- **Dry-saved varieties** (beans, peas, tomatoes, peppers): Seeds sit inside a dry pod or fruit. Extract by hand, ensure thorough drying for two weeks, then store cool and dry.
- **Wet-saved varieties** (tomatoes, cucumbers): Ferment the seed mass to remove the coating that carries disease, wash clean, and dry thoroughly.

## Storing your harvest

Dry seeds completely before storage — any residual moisture will rot them in a week. Pack into labelled paper envelopes or glass jars with a desiccant pack. Store cool (ideally 4–10°C) and dark. Most varieties remain viable for four to six years when stored properly.

Record your variety name, date saved, and source on every packet. Future-you will be grateful.

<include src="/_includes/footer-contact.html"></include>
