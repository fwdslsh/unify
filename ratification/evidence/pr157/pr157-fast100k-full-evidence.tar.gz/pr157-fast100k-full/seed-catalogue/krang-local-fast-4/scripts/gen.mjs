import { readFileSync, writeFileSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';

// The script may run from site/ or project root; look for varieties.json upward
let varietiesPath = null;
function findVar() {
  const p1 = join(process.cwd(), 'varieties.json');
  try { readFileSync(p1); return p1; } catch(e) {}
  const p2 = join(process.cwd(), '..', 'varieties.json');
  try { readFileSync(p2); return p2; } catch(e) {}
}

const varPath = findVar();
if (!varPath) throw new Error('Cannot find varieties.json');
const varieties = JSON.parse(readFileSync(varPath, 'utf8'));

// Also determine project root for finding other files
let projRoot = process.cwd();
for (let i = 0; i < 3; i++) {
  try { readFileSync(join(projRoot, 'unify.yaml')); break; } catch(e) {}
  projRoot = join(projRoot, '..');
}

let distDir;
if (process.env.UNIFY_DIST) {
  distDir = process.env.UNIFY_DIST;
} else if (process.argv[2]) {
  distDir = process.argv[2];
} else {
  distDir = join(projRoot, 'dist');
}

mkdirSync(distDir, { recursive: true });

// Build unique slugs (some varieties share the same slug in the source data)
const seenSlugs = {};
const genVarieties = [];
for (const v of varieties.varieties) {
  let s = v.slug;
  const orig = s;
  let counter = 1;
  while (seenSlugs[s]) {
    s = orig + '-' + counter++;
  }
  seenSlugs[s] = true;
  genVarieties.push(Object.assign({}, v, { slug: s }));
}

// Collect families from unique variety list
const familyMap = {};
for (const v of genVarieties) {
  if (!familyMap[v.family]) familyMap[v.family] = [];
  familyMap[v.family].push(v);
}
const families = Object.keys(familyMap).sort();

// Generate individual variety HTML pages into dist/
for (const v of genVarieties) {
  const html = `<!doctype html>
<html lang="en" data-layout="none">
<head>
<meta charset="utf-8">
<meta name="description" content="${v.name} — ${v.family} vegetable seed from Fernhollow Seed Library.">
<link rel="stylesheet" href="/site.css">
<title>${v.name} | Fernhollow Seed Library</title>
</head>
<body>

<header class="site-header" role="banner">
<a href="/" aria-label="Fernhollow Seed Library"><img src="/includes/leaf.svg" alt="" width="32" height="32"></a>
<nav class="main-nav"><a href="/">Home</a><a href="/catalogue.html">Browse the catalogue</a><a href="/growing-guides/">Growing guides</a><a href="/how-lending-works.html">How lending works</a></nav>
</header>

<main id="main">
<article class="variety-page">
<h1>${v.name}</h1>

<p><strong>Plant family:</strong> <a href="/catalogue.html?family=${encodeURIComponent(v.family)}">${v.family}</a></p>

<dl>
  <dt>Season</dt><dd>${v.season}</dd>
  <dt>Sow time</dt><dd>${v.sow}</dd>
  <dt>Days to maturity</dt><dd>${v.days_to_maturity} days</dd>
  <th>Packets available this season</th><td>${v.packets_available}</td>
</dl>

<p class="variety-notes">${v.notes}</p>

<div class="seed-keeper">
<h2>Seed keeper</h2>
<p>Saved by ${v.seed_keeper}</p>
</div>
</article>

<nav><a href="/catalogue.html?family=${encodeURIComponent(v.family)}">&larr; Back to ${v.family} varieties</a></nav>
</main>

<footer class="site-footer">
<p>Fernhollow Seed Library &middot; seeds@fernhollow.example</p>
<a href="/how-lending-works.html">Membership terms apply to all seed lending.</a>
</footer>

</body>
</html>`;

  const path = join(distDir, 'varieties', v.slug + '.html');
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, html);
}

// Generate per-family JSON for catalogue page fetch (using unique slugs)
for (const family of families) {
  const data = familyMap[family].map(v => ({
    slug: v.slug, name: v.name, season: v.season, sow: v.sow,
    days_to_maturity: v.days_to_maturity, packets_available: v.packets_available,
    notes: v.notes, seed_keeper: v.seed_keeper
  }));
  const p = join(distDir, 'catalogue', family + '.json');
  mkdirSync(dirname(p), { recursive: true });
  writeFileSync(p, JSON.stringify(data));
}

const famIndex = Object.entries(familyMap).map(([name, items]) => ({ name, count: items.length }));
writeFileSync(join(distDir, 'families.json'), JSON.stringify({ families: famIndex.sort((a,b) => a.name.localeCompare(b.name)) }));

console.error('Generated', genVarieties.length, 'variety pages across', families.length, 'families');
