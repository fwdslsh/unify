const http=require('node:http');
const fs=require('node:fs');
const {Readable,pipeline}=require('node:stream');
const key=JSON.parse(fs.readFileSync('/run/provider-key.json','utf8')).key;
const server=http.createServer(async(req,res)=>{
 if(req.method==='GET'&&req.url==='/health'){res.end('ready');return;}
 if(req.method!=='POST'||req.url!=='/v1/chat/completions'){res.writeHead(404);res.end();return;}
 try{
  const chunks=[];for await(const chunk of req)chunks.push(chunk);
  const body=Buffer.concat(chunks),data=JSON.parse(body);
  if(data.model!=='local/fast'){res.writeHead(403);res.end('This test permits only local/fast');return;}
  const upstream=await fetch('https://ai.lab.fwdslsh.dev/v1/chat/completions',{method:'POST',headers:{'content-type':'application/json','authorization':'Bearer '+key},body,signal:AbortSignal.timeout(1800000)});
  res.writeHead(upstream.status,{'content-type':upstream.headers.get('content-type')||'application/json'});
  pipeline(Readable.fromWeb(upstream.body),res,(error)=>{if(error)console.log(JSON.stringify({time:new Date().toISOString(),streamError:error.name}));});
  console.log(JSON.stringify({time:new Date().toISOString(),status:upstream.status,model:data.model,stream:!!data.stream,max_tokens:data.max_tokens,max_completion_tokens:data.max_completion_tokens}));
 }catch(e){if(!res.headersSent)res.writeHead(502);res.end('Inference relay failed');console.log(JSON.stringify({error:e.name}));}
});server.listen(8080,'0.0.0.0',()=>console.log('ready'));
