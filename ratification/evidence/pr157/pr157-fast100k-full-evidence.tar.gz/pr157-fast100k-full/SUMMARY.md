# Ratification round pr157-fast100k-full

- **unify** 0.11.18 at `1ced77bc3a24` (working tree)
- **rules** `fb07d931bd36` · **prompt** `456131468750` · **agent** opencode 1.18.25 · **models** krang/local/fast · **isolation** mount namespace, probe clean
- 2026-11-09T04:42:58.974Z to 2026-11-09T10:23:57.702Z; scored 2026-11-09T10:23:57.727Z

## Score

**14 of 35 samples completed their brief: every scored check passed (40%).**

The protocol's bar, at least 4 of 5 samples of a model on each brief: **not met**.

| Brief | Model | Passed | Checks that failed |
|---|---|---|---|
| audit-handover | krang/local/fast | 2/5 | addresses (3), strict-build (2), fresh-build (2), audit-strict (2), article-data (2), share-cards (2) |
| callouts | krang/local/fast | 0/5 | addresses (1), no-slot-shipped (1), strict-build (4) |
| council-panel | krang/local/fast | 3/5 | strict-build (2), addresses (1) |
| photo-banners | krang/local/fast | 4/5 | strict-build (1) |
| publishing | krang/local/fast | 5/5 | — |
| seed-catalogue | krang/local/fast | 0/5 | private-data (5), variety-pages (4), strict-build (3), agent-finished (1), publish-command (1), fresh-build (1), addresses (1), drafts-and-export-unpublished (1) |
| svelte-estimator | krang/local/fast | 0/5 | agent-finished (5), publish-command (5), strict-build (5), fresh-build (5), addresses (5), drafts-unpublished (5) |

## audit-handover — Hand over only when every check the tool offers reports nothing

*round 28; checks follow its pre-registered V1-V4, plus the brief's extensionless addresses.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | audit-strict | article-data | share-cards | ran-audit | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-local-fast-1 | 5m21s | 77 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | ✓ (i) | fail |
| krang-local-fast-2 | 5m51s | 114 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-local-fast-3 | 9m40s | 140 | $0.00 | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✓ (i) | fail |
| krang-local-fast-4 | 6m53s | 126 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ (i) | **pass** |
| krang-local-fast-5 | 9m39s | 132 | $0.00 | ✓ | ✓ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✓ (i) | fail |

- krang-local-fast-1 · **addresses**: 29 internal links (0 in fetched fragments); 3 invalid: notes/index.html: /library/notes/winter-sorting-nov-2025/index.html (.html); notes/index.html: /library/notes/july-swap-2025/index.html (.html); notes/index.html: /library/notes/spring-lending-march-2025/index.html (.html)
- krang-local-fast-1 · **ran-audit** (not scored): 4 runs matching /unify audit/
- krang-local-fast-2 · **ran-audit** (not scored): 11 runs matching /unify audit/
- krang-local-fast-3 · **strict-build**: exit 1: 1 problems, 0 advisories — site/scripts/gen.mjs: problem: --generate scripts/gen.mjs failed (exit 1): error: Module not found "/tmp/sandbox/site/scripts/gen.mjs"
- krang-local-fast-3 · **fresh-build**: publish command could not be rebuilt
- krang-local-fast-3 · **addresses**: no build output
- krang-local-fast-3 · **audit-strict**: exit 1: /work/unify/ratification/scripts/isolate.sh: line 36: cd: /work/unify/ratification/rounds/pr157-fast100k-full/audit-handover/.build/krang-local-fast-3: No such file or directory
- krang-local-fast-3 · **article-data**: no build output
- krang-local-fast-3 · **share-cards**: no build output
- krang-local-fast-3 · **ran-audit** (not scored): 4 runs matching /unify audit/
- krang-local-fast-4 · **ran-audit** (not scored): 9 runs matching /unify audit/
- krang-local-fast-5 · **strict-build**: exit 1: 25 problems, 0 advisories — site/dist/index.html:6: problem: /library/style.css does not resolve to any emitted file
- krang-local-fast-5 · **fresh-build**: exit 1:   fix: check the path spelling and casing / site/dist/visit/index.html:48: problem: /library/notes/ does not resolve to any emitted file /   in: /library/notes/ /   fix: check the path spelling and casing
- krang-local-fast-5 · **addresses**: no build output
- krang-local-fast-5 · **audit-strict**: exit 1:   in: /library/notes/ /   fix: check the path spelling and casing
- krang-local-fast-5 · **article-data**: no build output
- krang-local-fast-5 · **share-cards**: no build output
- krang-local-fast-5 · **ran-audit** (not scored): 14 runs matching /unify audit/

What the agents said the rules did not answer:

**krang-local-fast-1**

> ## What `rules.md` Did Not Answer

**krang-local-fast-2**

> ## What rules.md did not answer
> 
> **"The sentence I wanted and could not find"**
> 
> > "What is the real filename for a `.md` page, so I know how to link to it?"
> 
> rules.md says: "Always link the real filename — `/about.html`, not `/about/`. This stays true under `--pretty-urls`: you still write `/about.html`, and the build rewrites it to `/about/` in the output." But for Markdown pages there is no `.html` extension in source. The rules don't explicitly state whether to link via the bare slug name or add a `.html` suffix — I had to discover through trial that `--pretty-urls` handles both, while audit (without `--pretty-urls`) resolves against plain `.html` output for md pages.
> 
> **What I had to re-read and why it did not land the first time**
> 
> I re-read section 7 ("Merging a page into its layout") multiple times — specifically how named slots interact with default-content `<main>`. On my first attempt I put both `slot="content"` on `<nav>` and a bare `<slot></slot>` inside `<main>`, which the tool flagged as "named slot 'content' is inside <main>, which is also the default-content sink". The fix was to use only one bare `<slot></slot>` inside `<main>` for default content, since the layout's own `<nav>` fills via `slot=` without needing a named slot at all.

**krang-local-fast-3**

> ## What `rules.md` did not answer
> 
> **What I wanted and couldn't find:**

**krang-local-fast-4**

> ## 3. What rules.md did not answer — honest answers
> 
> **The sentence I wanted but couldn't find:** I needed a clear rule about how `<title>` merging works across the layout and page, specifically whether removing `<title>` from a page lets the layout's title survive intact or whether an empty head is always an error. The rules say "pages never contain `<head>`" for Markdown pages, but HTML pages must be complete documents — including `<head>`. I had to re-read the "Head" section in the layout merging rules twice: *"A page has its own complete `<head>`; the layout's is the base, and where both declare `<meta charset>` the layout's wins."* The second time I noticed that only same-`name`/same-`property` `<meta>` elements are replaced — `<title>` isn't mentioned as something that merges or replaces. When I removed `<title>` from index.html, the build simply used the layout's title unchanged. That was an inference rather than a read.
> 
> **What I guessed / inferred:** How `.html.md` vs plain `.md` extensions affect output paths under `--pretty-urls`. The rules say "Always link the real filename — `/about.html`, not `/about/`" and that pretty-urls rewrites links, but they don't explicitly state whether a file named `notes/post.md` (no `.html` in its source name) produces `/notes/post/` or `/notes/post.html/`. I had to try both conventions and inspect the actual output directory to resolve it. The fact that `dist/visit/index.html` appeared (pretty URLs creating a directory structure from a `.html`-named page, but not from a plain `.md` file) was discovered empirically, never read in documentation.
> 
> **What I had to re-read:** The section on Markdown frontmatter keys — specifically that `og:…` keys emit `property=` meta tags and that an indented block two levels deep is "an error." This was important because the brief required social preview cards (Open Graph images), which meant adding `og:image`, `og:image:width`, and `og:image:height` to frontmatter. The first time I read it, I missed the colon-in-name nuance — thinking `og:image:width` would be parsed as a nested key rather than a flat meta tag with literal property name. On re-reading I caught that these are three separate flat keys, each emitting its own `<meta>` line.

**krang-local-fast-5**

> ## What did `rules.md` not answer?
> 
> **"What is the correct layout file structure for pages that supply their own `<body>`?"** — The rules explain how page content merges into a layout's slot, but they never show a concrete example of what a `_layout.html` should contain at the body level. I had to re-read the "Merging a page into its layout" section multiple times: first it said layouts are "wrapped by _layout.html" and have a bare `<slot></slot>` inside `<main>`, but then `unify build --dry-run` complained that "_layout.html has no <body> element, so no page can merge with it". I re-read the fix suggestion ("a layout with an empty `<body></body>` is the head-only pattern") and the "Merging" section again, this time noticing that pages contribute their own complete HTML document including `<html>`, `<head>`, and `<body>` — the layout's body element just passes page content through. The distinction between a "layout that only provides chrome around the page's head+body" vs a "layout that wraps only body content" was unclear on first read because the rules never explicitly state that pages keep their own `<html>` tags and that the layout fills into a bare body slot.
> 
> **What I had to guess at:** How `--base-url` affects internal link checking during audit (not just build). During `build --dry-run`, root-relative links like `/visit.html` were prefixed with the base URL for output, but during `audit`, the tool checked them in source namespace — meaning they needed to resolve against source paths, not output paths. I had to re-read rules about link resolution and discover that audit uses a different resolution context than build dry-run. The sentence I wanted was one explaining whether audit resolves links before or after base-url prefixing.
> 
> **What I inferred rather than read:** That `.md` Markdown pages are valid source files (not requiring an extension like `.html.md`) — I learned this from build output showing `notes/favourite-flowers.md → notes/favourite-flowers/index.html`. The rules say "`/.html/` / `/.md/` are pages" which implies both work, but I initially thought only HTML was supported for rendering.


## callouts — One equipment callout in ten places with different words, its border changed in one file

*round 26, the slotted-include ship condition (conformance spec §32.7).*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-unpublished | no-slot-shipped | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-local-fast-1 | 12m39s | 94 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✗ | ✓ | ✗ | fail |
| krang-local-fast-2 | 6m42s | 75 | $0.00 | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | ✓ | fail |
| krang-local-fast-3 | 5m06s | 55 | $0.00 | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | ✓ | fail |
| krang-local-fast-4 | 6m13s | 79 | $0.00 | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | ✓ | fail |
| krang-local-fast-5 | 6m26s | 81 | $0.00 | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | ✓ | fail |

- krang-local-fast-1 · **addresses**: 3 internal links (0 in fetched fragments); 3 invalid: observing-log/index.html: /observing-log/2025-11-05/ (outside /observatory/); observing-log/index.html: /observing-log/2025-10-29/ (outside /observatory/); observing-log/index.html: /observing-log/2025-10-15/ (outside /observatory/)
- krang-local-fast-1 · **no-slot-shipped**: <slot> in fragments/equip.fragment.html
- krang-local-fast-2 · **strict-build**: exit 1: 0 problems, 3 advisories — site/log/andromeda-moonless.md: advisory: date is "2025-11-05", which names a day rather than an instant — this page is not in feed.xml
- krang-local-fast-3 · **strict-build**: exit 1: 0 problems, 3 advisories — site/log/2025-05-31.md: advisory: date is "2025-05-31", which names a day rather than an instant — this page is not in feed.xml
- krang-local-fast-4 · **strict-build**: exit 1: 0 problems, 3 advisories — log/andromeda.md: advisory: date is "2025-02-14", which names a day rather than an instant — this page is not in feed.xml
- krang-local-fast-5 · **strict-build**: exit 1: 0 problems, 3 advisories — observing-log/mars-opposition-2024.md: advisory: date is "2024-08-16", which names a day rather than an instant — this page is not in feed.xml

What the agents said the rules did not answer:

**krang-local-fast-1**

> ## What `rules.md` did not answer

**krang-local-fast-2**

> ## What did rules.md not answer?
> 
> I could not find a sentence answering **how to prevent drafts from appearing in output when they live outside the source root**. The rules say "Anything that is not part of the site ... goes under a leading underscore" but my draft files sit in `drafts/` at the project level, not inside the source root (`site/`). Since unify only processes files within the source root by default, the drafts were safely excluded without any prefix — but this was an assumption I made rather than something rules.md explicitly confirmed.
> 
> I also needed to find (but didn't find) a sentence clarifying **whether HTML pages with their own `<head>` fully replace or merge with the layout's head**. The title duplication ("Harrowgate Observatory — Harrowgate Observatory") taught me they merge, but I had to re-read and experiment rather than finding an explicit rule.

**krang-local-fast-3**

> ## What rules.md did not answer

**krang-local-fast-4**

> ### 1. What did `rules.md` not answer?
> 
> **The sentence I wanted but could not find:** "How does `<include>` with slots interact with Markdown files?" The rules say includes "Works in any file — layouts, pages, `<head>`, fragments, and `.md`", but they only describe the slot-filling mechanics for HTML fragments (the `slot=` attribute on direct children). They don't explicitly explain whether a `.md` page that contains an `<include>` with multiple named-slot fills will correctly merge them. I had to re-read that paragraph several times because the prose about "main elements stay intact and their children are not fills" conflicted with my expectation of how the fragment's slots would receive content from Markdown-rendered HTML. I eventually verified by rebuilding and inspecting `dist/log/andromeda/index.html` — it worked, confirming that the include resolves correctly inside `.md`.

**krang-local-fast-5**

> ## What did `rules.md` not answer?
> 
> I wanted to find guidance on how `<include>` with `<slot>` works inside `.fragment.html` files when used for templating-like reuse (e.g., equipment callouts where only content differs). The rules document states that "an include is still not a component" and describes slot filling in general, but it never explicitly explains the pattern of including a fragment as a reusable panel shell. I had to infer from the slot semantics section — specifically "Content between the tags fills slots" and "allowed only when the target is a `*.fragment.html` declaring `<slot>`" — that an include with child content could fill slot placeholders in a fragment template, effectively making `<include>` behave as a partial-templating mechanism. The sentence I needed was:
> 
> > "allowed only when the target is a `*.fragment.html` declaring `<slot>`, with `slot="name"` on direct child elements"
> 
> This tells you that child content maps to named slots, but it doesn't explicitly say "this lets you create reusable panel templates." It was implicit.


## council-panel — A bare opening-hours panel another site fetches, kept in one place, and month lists fetched on demand

*round 23, the first exposure of *.fragment.html.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-unpublished | bare-fragment | fetch-targets | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-local-fast-1 | 13m41s | 176 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-local-fast-2 | 12m15s | 171 | $0.00 | ✓ | ✓ | ✗ | ✓ | ✗ | ✓ | ✓ | ✓ (i) | fail |
| krang-local-fast-3 | 11m59s | 126 | $0.00 | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | fail |
| krang-local-fast-4 | 7m36s | 117 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |
| krang-local-fast-5 | 5m42s | 109 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ (i) | **pass** |

- krang-local-fast-1 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-local-fast-2 · **strict-build**: exit 1: 0 problems, 3 advisories — gen.mjs: wrote 3 month fragments and index.html
- krang-local-fast-2 · **addresses**: 33 internal links (3 in fetched fragments); 3 invalid: index.html ← millings/2025-09.milling.fragment.html: /millings/sep-14-autumn-flour.html (outside /mill/); index.html ← millings/2025-10.milling.fragment.html: /millings/oct-18-first-wind.html (outside /mill/); index.html ← millings/2025-11.milling.fragment.html: /millings/nov-3-wheat.html (outside /mill/); 1 static-analysis coverage note(s)
- krang-local-fast-2 · **fetch-targets** (not scored): 1 of 1 resolved, 0 built at runtime
- krang-local-fast-3 · **strict-build**: exit 1: 0 problems, 3 advisories — site/index.html:10: advisory: no slot named "content" in _layout.html; its content stayed in the page content
- krang-local-fast-3 · **fetch-targets** (not scored): 0 of 1 resolved, 0 built at runtime
- krang-local-fast-4 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-local-fast-5 · **fetch-targets** (not scored): 0 of 1 resolved, 0 built at runtime

What the agents said the rules did not answer:

**krang-local-fast-1**

> ## What `rules.md` did not answer
> 
> **The sentence I wanted but could not find:**
> 
> > "When a `.fragment.html` file is included via `<include>` inside an HTML page, does unify rewrite the hrefs inside that fragment's content after splicing it into the parent?"
> 
> The rules say fragments "copy byte-for-byte" and "`unify never … rewrites`" fragments. But they also describe how `<include>` "splices the file in verbatim." I had to **re-read** this part several times because the behaviour wasn't obvious on first pass: a fragment used as an include gets spliced into its parent HTML, and then *that* HTML (now containing the spliced bytes) goes through href rewriting. The same fragment shipped standalone does NOT get rewritten. This distinction was not stated plainly — I had to infer it from the interaction of those two sentences plus trial-and-error with links in published pages.
> 
> **What I guessed at or inferred:**
> 
> - That `--pretty-urls` also rewrites root-relative paths (`/visit.html` → `/visit/`) while leaving stylesheet URLs (`/style.css`) alone — I verified this by grepping the output rather than finding it in the docs.
> - That fragments are truly byte-for-byte copies, meaning their internal `<a>` hrefs won't be prefixed when `--base-url` is used. This meant I had to write absolute URLs in the council-facing fragment and use `./relative` paths inside JS-fetched monthly fragments.

**krang-local-fast-2**

> ## What `rules.md` did not answer

**krang-local-fast-3**

> ## What `rules.md` did not answer
> 
> **Sentence I wanted and could not find:** How does `<include>` resolve paths at build time versus how they appear in published output? The rules say "`/…` resolves from the source root" for includes, which I read as "resolve relative to `/site/`". But it wasn't explicit whether `src="/_includes/hours.fragment.html"` refers to a path inside the source directory or the URL that ships.
> 
> **What I had to re-read:** The rules on `<include>` said: "`/…` resolves from the source root, anything else relative to the including file." On my first read, I thought this meant paths were rewritten — but actually they're resolved at BUILD TIME against `site/`, and fragments ship byte-for-byte. So `_includes/hours.fragment.html` is resolved during compose (build time) and never appears in output because it's under a leading underscore. Meanwhile `data/hours.fragment.html` ships as-is to the publish path.
> 
> **What I guessed/inferred:** The rules don't explicitly state that `.fragment.html` files "copy byte-for-byte" and are fetchable via their source-relative URL after building. I inferred this from "every other file copies byte-for-byte to the same path" combined with "`/…` resolves from the source root". In practice, this means `_data/file.fragment.html` in `site/` would NOT ship (underscore prefix), but `data/file.fragment.html` WOULD ship — and that's how I made both the council endpoint and the JS fetches work.
> 
> **Another gap:** The rules don't explain how a generator script (`generate:` in `unify.yaml`) interacts with the build pipeline — whether it runs before or after page composition, and where its output goes. I inferred from "unify runs it before every build" that it's pre-processing, and from "it writes into the directory unify hands it, never into `site/`" (in dry-run mode) that writing to `dist/` would be cleaned up by the main build. The solution was to write generator output into `site/data/` (source root), so unify copies those files through to the published site alongside pages and stylesheets.

**krang-local-fast-4**

> ## What `rules.md` did not answer / required re-reading

**krang-local-fast-5**

> ## What `rules.md` did not answer


## photo-banners — Photo banners on every section under a subpath, with extensionless addresses

*round 22: does anyone ship a root-relative url() that 404s under the subpath.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | css-urls | Result |
|---|---|---|---|---|---|---|---|---|---|---|
| krang-local-fast-1 | 2m09s | 39 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-local-fast-2 | 2m40s | 56 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-local-fast-3 | 3m06s | 54 | $0.00 | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | fail |
| krang-local-fast-4 | 2m48s | 40 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-local-fast-5 | 10m57s | 142 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |

- krang-local-fast-3 · **strict-build**: exit 1: 0 problems, 3 advisories — site/collections/guides/maples.md: advisory: date is "2026-01-08", which names a day rather than an instant — this page is not in feed.xml

What the agents said the rules did not answer:

**krang-local-fast-1**

> ## What `rules.md` did not answer
> 
> **I needed the sentence on how `<include>` works with slots, but I re-read it twice.** The sentence "Content between the tags fills slots" did not land at first because I was looking for an example of a page filling a layout's named slot. I reread to find: "The layout writes `<slot name="footer">fallback…</slot>`; the page fills it with `slot=` on a real element." That is what I needed, and that sentence did not immediately click because it was bundled together with fragment/`.fragment.html` content in one long paragraph.
> 
> **What did I guess or infer?** The rules never explicitly state that `<body class="home">` from the page gets merged into the layout's `<body>` — they say "your classes are added" to body attributes, which I inferred means merging rather than replacing. Also, I inferred (and later confirmed) that `data-layout="/_layout.html"` on a page resolves from the source root because `/…` in rules.md "resolves from the source root."
> 
> **What did I have to re-read?** The section about `<slot>` merging: "The first default-content page main unwraps, even for a bare slot outside a layout main" — this was important to understand why my pages' `<main>` content ended up inside the layout's `<main>`. I had to re-read it because I initially misunderstood and tried to put everything inside named slots.

**krang-local-fast-2**

> ## What `rules.md` did not answer

**krang-local-fast-3**

> ## What `rules.md` did not answer
> 
> **The sentence I needed but could not find:** "How do you set the base path so that every link, image source, and stylesheet href gets prefixed for a subdirectory deployment?" The documentation says:
> 
> > "`--base-url https://you.example/handbook/` — the site's whole address, never a bare path — prefixes every link"
> 
> —but it doesn't explain whether `href="/css/style.css"` in the HTML source becomes `href="/arboretum/css/style.css"` after prefixing (it does), nor that `<img src="/images/logo.png">` gets the same treatment. I had to re-read that sentence three times and then verify by checking the actual output before it landed: "oh, any root-relative path gets prefixed." The key was in the rules line about CSS `url()` being rewritten versus fetched addresses shipping as written — which implied links get rewritten but also left me guessing about images. I checked the output to confirm.
> 
> **Also unclear:** Whether `<body class="home">` on a page adds to an already-set body class or replaces it. The rule says "your classes are added" and "Active nav is `<body class=\"home\">` plus CSS", but my pages all got `class="home"` from the layout regardless of whether I declared empty `class:` in frontmatter. I inferred that the layout's class wins because page body has no explicit `class=` attribute (the HTML pages don't declare one), so it falls through to the default "home".
> 
> **Another gap:** The rules document never explicitly states what happens when you omit a `<title>` from an HTML page (it becomes empty, which then merges with the layout separator giving just "— Alderfen Arboretum"). I discovered this by accident — my first build produced `Alderfen Arboretum — Alderfen Arboretum` because both the layout and the page declared titles. The fix was to give each page its own short title ("Home", "Visit", etc.) so the separator join produces readable results like "Visit — Alderfen Arboretum".

**krang-local-fast-4**

> ## What `rules.md` did not answer
> 
> I needed a sentence that clearly states: **can `.md` files be used as guide pages with frontmatter?** The rules say "HTML pages never have frontmatter" and "Markdown pages never contain `<head>`", but there is no single sentence that says "write `.md` files for content authored by non-technical writers." I had to re-read the Frontmatter section three times before understanding that `.html` with YAML at the top would render as visible text, and that I should use `.md` extension instead. The first pass didn't land because the rules never explicitly say "use .md for curator guides" — it is implied through what `.html` cannot do, but the implication was not obvious on first reading.
> 
> I also needed to find: **does `--base-url` prefix `url()` in CSS?** The rules warn that "`url()` in a stylesheet file...ship as written" and that root-relative paths miss the prefix under `--base-url`. But it does not say whether `background-image: url('/images/…')` in inline styles or in a `.css` file gets rewritten. I inferred from "keep every `url()` in a stylesheet file" that CSS files are NOT rewritten by unify — only HTML's own URL attributes (`href`, `src`) get the prefix. This meant my `<img src="...">` tags were correctly prefixed, but I had to be careful that no images used CSS `url()` backgrounds (I used inline `<img>` elements instead).
> 
> ---

**krang-local-fast-5**

> ## What `rules.md` did not answer


## publishing — Publishing surface: schema:, og: share cards, dated posts, a feed, a subpath

*round 27, re-run unchanged in round 29; checks follow round 27's pre-registered V1-V5.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | feed | article-data | share-cards | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-local-fast-1 | 6m52s | 73 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-local-fast-2 | 10m16s | 80 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-local-fast-3 | 7m10s | 91 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-local-fast-4 | 6m27s | 65 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |
| krang-local-fast-5 | 5m26s | 84 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | **pass** |

What the agents said the rules did not answer:

**krang-local-fast-1**

> ## 1. What did `rules.md` not answer?
> 
> The sentence I needed but could not find was about **pretty-URLs**: whether `--pretty-urls` is an automatic behaviour or requires the explicit flag, and exactly how it interacts with `index.html`. The rules text says: "This stays true under `--pretty-urls`: you still write `/about.html`, and the build rewrites it to `/about/` in the output" — which tells me the flag exists but does not explain that I must pass it explicitly, nor what happens if I omit it (links keep `.html` endings). The brief demands "addresses visitors see must not end in .html", so knowing about `--pretty-urls` was essential.
> 
> I also needed to know whether a **standalone SVG asset** could be placed in the source root and copied byte-for-byte without special configuration. The rules say every non-page file copies as-is, but there is no concrete example of an SVG being referenced via `<img>` or inline `<svg>`. I inferred it would work because it's not a `.html`/`.md` page.

**krang-local-fast-2**

> ### 1. What did `rules.md` not answer? Name the sentence you wanted and could not find.
> 
> I needed a clear example of how **footer slotting** works in practice. The rules document mentions named slots (`<slot name="X">`) and page fills (`slot="X"`) but never shows a complete pattern where both layout and page collaborate on shared chrome (header + footer). I had to re-read the paragraph about "A bare `<header>`/`<footer>` does **not** replace the layout's — only `slot=` fills, and it fills the *contents*" multiple times. The first reading led me to put a plain `<footer>` tag inside `_layout.html`, which produced nested footers. Only after re-reading did I see that the slot declaration itself (`<slot name="footer">`) is what matters — not wrapping tags around it.
> 
> The sentence I wanted but couldn't find: **"Here's exactly how to put chrome (header + footer) in a layout so every page gets it."** Instead, the rules describe the mechanics of slots and merging abstractly. The concrete pattern for shared layout chrome was something I had to infer from the pieces described separately.

**krang-local-fast-3**

> ## 1. What did `rules.md` not answer?
> 
> **The sentence I needed but could not find:** How to create a dynamic index page that lists all news posts sorted by date, automatically picking up new Markdown files added later. The rules say "Derived files (a post index) come from a script you write, kept in `scripts/` beside the site and named in `unify.yaml` (`generate: scripts/gen.mjs`): unify runs it before every build and it writes into the directory unify hands it, never into `site/`." This tells me *where* to put the generator and that it writes somewhere other than `site/`, but it didn't specify which output directory or whether the script should write back into `site/` (so unify picks up its own generated page on the next run). I had to infer that writing to `site/` was correct since generate runs *before* the build, and then subsequent build processing includes whatever files exist in the source root at that point.

**krang-local-fast-4**

> ### 1. What did `rules.md` not answer?
> 
> I wanted a sentence explaining **how dates without time-of-day affect feed generation versus page publication**. The rules say `"a date: with no time is reported and left out rather than guessed at"` — but I initially read this as meaning the date would be omitted entirely from both pages and feeds. Re-reading, I understood it means the *feed entry* omits that page (reported above), while the **page still publishes** correctly. The sentence I was looking for — one that explicitly says "a date without a time excludes the post from feed.xml but leaves the page published" — does not appear as such; I had to infer the distinction between `--strict` dry-run output and actual build behaviour.

**krang-local-fast-5**

> ## What did `rules.md` not answer?
> 
> The single sentence I needed but could not find is one about **how to handle `<footer>` elements in pages alongside a layout's footer slot**. Specifically: what happens when a page already has a bare `<footer>` (not using `slot=`) AND the layout also provides a `<slot name="footer">`? The rules say "a bare `<header>`/`<footer>` does not replace the layout's", which I read to mean it would be inert — but in practice, with the layout having `<slot name="footer">`, the page's bare `<footer>` became an additional element alongside the layout's slot-based footer. I had to re-read this three times because the distinction between "bare elements are ignored" and "the first default-content main unwraps" made me expect that a footer outside `<main>` would simply not affect the layout at all — but instead it appended after.


## seed-catalogue — A 225-variety catalogue generated from a JSON export, fetched one family at a time

*round 20; the judge's default marker and privacy fields are this brief's.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-and-export-unpublished | private-data | variety-pages | fetch-targets | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| krang-local-fast-1 | 15m53s | 156 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ | ✗ | ✗ (i) | fail |
| krang-local-fast-2 | 12m09s | 183 | $0.00 | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | ✗ | ✗ | ✗ (i) | fail |
| krang-local-fast-3 | 21m11s | 206 | $0.00 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ | ✓ | ✗ (i) | fail |
| krang-local-fast-4 | 45m00s | 549 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ (i) | fail |
| krang-local-fast-5 | 18m14s | 152 | $0.00 | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | ✗ | ✗ | ✗ (i) | fail |

- krang-local-fast-1 · **private-data**: no varieties.json and no privateValues — skipped
- krang-local-fast-1 · **variety-pages**: 218 pages (needs 225)
- krang-local-fast-1 · **fetch-targets** (not scored): 0 of 0 resolved, 0 built at runtime (no fetch()/hx-get targets in the output)
- krang-local-fast-2 · **strict-build**: exit 1: 0 problems, 3 advisories — site/growing-guides/saving-seed.md: advisory: date is "2026-03-15", which names a day rather than an instant — this page is not in feed.xml
- krang-local-fast-2 · **private-data**: 6 of 6 private values published
- krang-local-fast-2 · **variety-pages**: 217 pages (needs 225)
- krang-local-fast-2 · **fetch-targets** (not scored): 0 of 0 resolved, 0 built at runtime (no base URL (none in config, none in the command) — skipped)
- krang-local-fast-3 · **private-data**: 6 of 6 private values published
- krang-local-fast-3 · **fetch-targets** (not scored): 0 of 0 resolved, 1 built at runtime
- krang-local-fast-4 · **agent-finished**: exit 124 (timed out), no REPORT.md
- krang-local-fast-4 · **publish-command**: no REPORT.md
- krang-local-fast-4 · **strict-build**: not judged: no REPORT.md
- krang-local-fast-4 · **fresh-build**: publish command could not be rebuilt
- krang-local-fast-4 · **addresses**: no build output
- krang-local-fast-4 · **drafts-and-export-unpublished**: no build output
- krang-local-fast-4 · **private-data**: not checked
- krang-local-fast-4 · **variety-pages**: no build output
- krang-local-fast-4 · **fetch-targets** (not scored): 0 of 0 resolved, 0 built at runtime
- krang-local-fast-5 · **strict-build**: exit 1: 0 problems, 5 advisories — site/guides/beans-peas.md: advisory: date is "2026-02-10", which names a day rather than an instant — this page is not in feed.xml
- krang-local-fast-5 · **private-data**: 6 of 6 private values published
- krang-local-fast-5 · **variety-pages**: 219 pages (needs 225)
- krang-local-fast-5 · **fetch-targets** (not scored): 0 of 1 resolved, 0 built at runtime

What the agents said the rules did not answer:

**krang-local-fast-1**

> ## What `rules.md` did not answer
> 
> I needed to know whether JavaScript inside `<script>` tags would have their relative paths rewritten when using `--base-url`. The sentence "a `fetch()`/`hx-get` address ships as written" tells me they are **not** rewritten — which meant I had to reason about how the browser resolves relative URLs from pretty-URL paths. `../catalogue.json` at `/library/browse/index.html` resolves correctly by the browser, but this was never explicitly documented.
> 
> I also re-read several times the section on slot filling: "A bare `<header>`/`<footer>` does **not** replace the layout's — only `slot=` fills, and it fills the *contents*: where the layout wraps its slot in its own `<footer>`, write `<p slot="footer">`." The first reading led me to put a `<p slot="page-footer">` inside the footer element, which meant the page's content replaced only inline text. It took rereading and tracing through the actual HTML composition that I needed to wrap the entire `<footer class="site-footer">` in the layout as the slot element itself (`<slot name="..."><footer>...</footer></slot>`), so a page's fill replaces everything inside it.

**krang-local-fast-2**

> ## What rules.md did not answer

**krang-local-fast-3**

> ## What rules.md did not answer

**krang-local-fast-5**

> ## What rules.md did not answer
> 
> I needed several pieces of information that were not explicitly covered in the documentation:


## svelte-estimator — A Svelte component compiled to a browser asset by one repeatable command

*round 24 (round 25 re-ran it with docs/integrations.md seeded); needs the npm registry.*

| Sample | Time | Turns | Cost | agent-finished | publish-command | strict-build | fresh-build | addresses | drafts-unpublished | Result |
|---|---|---|---|---|---|---|---|---|---|---|
| krang-local-fast-1 | 10m04s | 120 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-local-fast-2 | 2m08s | 20 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-local-fast-3 | 1m05s | 0 | — | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-local-fast-4 | 1m06s | 0 | — | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |
| krang-local-fast-5 | 30m37s | 277 | $0.00 | ✗ | ✗ | ✗ | ✗ | ✗ | ✗ | fail |

- krang-local-fast-1 · **agent-finished**: exit 0, no REPORT.md
- krang-local-fast-1 · **publish-command**: no REPORT.md
- krang-local-fast-1 · **strict-build**: not judged: no REPORT.md
- krang-local-fast-1 · **fresh-build**: publish command could not be rebuilt
- krang-local-fast-1 · **addresses**: no build output
- krang-local-fast-1 · **drafts-unpublished**: no build output
- krang-local-fast-2 · **agent-finished**: exit 1, agent error: Cannot connect to API: Unable to connect. Is the computer able to access the url?, no REPORT.md
- krang-local-fast-2 · **publish-command**: no REPORT.md
- krang-local-fast-2 · **strict-build**: not judged: no REPORT.md
- krang-local-fast-2 · **fresh-build**: publish command could not be rebuilt
- krang-local-fast-2 · **addresses**: no build output
- krang-local-fast-2 · **drafts-unpublished**: no build output
- krang-local-fast-3 · **agent-finished**: exit 1, agent error: Cannot connect to API: Unable to connect. Is the computer able to access the url?, no REPORT.md
- krang-local-fast-3 · **publish-command**: no REPORT.md
- krang-local-fast-3 · **strict-build**: not judged: no REPORT.md
- krang-local-fast-3 · **fresh-build**: publish command could not be rebuilt
- krang-local-fast-3 · **addresses**: no build output
- krang-local-fast-3 · **drafts-unpublished**: no build output
- krang-local-fast-4 · **agent-finished**: exit 1, agent error: Cannot connect to API: Unable to connect. Is the computer able to access the url?, no REPORT.md
- krang-local-fast-4 · **publish-command**: no REPORT.md
- krang-local-fast-4 · **strict-build**: not judged: no REPORT.md
- krang-local-fast-4 · **fresh-build**: publish command could not be rebuilt
- krang-local-fast-4 · **addresses**: no build output
- krang-local-fast-4 · **drafts-unpublished**: no build output
- krang-local-fast-5 · **agent-finished**: exit 1, agent error: request (103466 tokens) exceeds the available context size (102400 tokens), try increasing it, no REPORT.md
- krang-local-fast-5 · **publish-command**: no REPORT.md
- krang-local-fast-5 · **strict-build**: not judged: no REPORT.md
- krang-local-fast-5 · **fresh-build**: publish command could not be rebuilt
- krang-local-fast-5 · **addresses**: no build output
- krang-local-fast-5 · **drafts-unpublished**: no build output

---

`✓` passed, `✗` failed, `(i)` reported but not scored. Each sample's directory is `<brief>/<sample>/`, its OpenCode event stream and session data are in `<brief>/.harness/<sample>/`, and the build the checks read is `<brief>/.build/<sample>/`. Triage every failure with ratification/ratification-protocol.md before changing anything.
