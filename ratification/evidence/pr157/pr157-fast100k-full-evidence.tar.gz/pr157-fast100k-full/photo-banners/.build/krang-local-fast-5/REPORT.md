# Report — Alderfen Arboretum site build

## Publish command line

```
./unify build --pretty-urls --base-url https://alderfen.pages.dev/arboretum/
```

This produces `dist/` with the complete site under `/arboretum/`. The output can be deployed to `https://alderfen.pages.dev/` as-is.

## What `rules.md` did not answer

1. **How should banner background images be placed?** I initially used inline `style="background-image: url(...)"` attributes on `<section>` elements, but these are HTML style attributes — not `href` or `src` — so unify's URL rewriting (including with `--base-url`) does not touch them. I had to re-read the rules section "Styles, scripts, finishing" which says "a url() in CSS and a fetch()/hx-get address ship as written". This led me to move banner backgrounds into the stylesheet using relative paths (`../images/...`), which resolve from the CSS file's directory regardless of subdirectory deployment. The sentence I needed was: *"keep every url() in a stylesheet file"* — but this doesn't explain what happens when you deploy under `--base-url` and expect root-relative paths to work, because css url() isn't rewritten by unify.

2. **How does unify merge titles for Markdown pages without their own `<head>`?** The rules say *"Write the separator into the layout's title — <title>&mdash; My Site</title> ... a page writes only its own name"*, but this is written in the context of HTML pages that DO have their own `<head>`. For `.md` files with no `<head>`, I needed to figure out whether the frontmatter `title:` or first `# Heading` gets inserted into the layout's `<title>` tag. After multiple rebuilds I inferred that the page's title (from frontmatter or heading) replaces whatever is in the layout's `<title>`. When I left it empty (`<title></title>`), unify correctly placed "The Oaks of Alderfen" there. But when I used template-style `{{title}}`, it stayed literal — which confirmed that templates are NOT supported: *"unify composes plain HTML at build time, without a template language."* The sentence confirming this was on the very first line of rules.md but didn't register because I expected `.html` layouts to be "templates" in some sense.

3. **How should links work when building for subdirectory with `--base-url`?** The rules say *"Always link the real filename — /about.html, not /about/"* and "*This stays true under --pretty-urls: you still write /about.html*". But I initially wrote `/visit/` (without `.html`) in my pages. The fix was to rewrite every internal link back to its `.html` form and let `--pretty-urls` handle the transformation. What I re-read twice was: *"A directory link you write yourself (/guides/) builds only when the output has a guides/index.html"* — this clarified that writing `/visit/` would produce a broken link unless `visit/index.html` existed as source or was created by pretty-urls from `visit.html`.

## What I guessed at / inferred

- **Layout composition for markdown pages**: I initially assumed layouts work like templates where `{{title}}` and `{{content}}` get substituted. The rules explicitly say no template language — so I had to infer that `.md` frontmatter titles are merged into the layout's existing `<head>`, not interpolated as variables.

- **Title merge for "home" page**: When both the site name and page title are identical ("Alderfen Arboretum"), the merge produced duplicated output: "Alderfen Arboretum Alderfen Arboretum". I inferred (through trial) that the page's title replaces the layout's `<title>` content, not appends to it.

- **CSS `url()` paths**: Since unify doesn't rewrite CSS `url()`, I had to infer that relative paths (`../images/...`) are needed when building for subdirectory deployment — they resolve from the stylesheet directory rather than the domain root. This wasn't explicitly stated; I deduced it from the rule about css url() "shipping as written".
