---
layout: /collections/guides/_guide.html
---

# The Witch Hazel of Alderfen

Curated by **Priya Nanda**, Head Horticulturist.

The witch hazels are our winter stars — twenty-five shrubs from temperate woodland across the Northern Hemisphere, all planted between 1982 and 1986 along the eastern path. They earn their common name for two reasons: the flower shape resembles a claw or talon (hazelnut-shaped) and the scent, which many people once mistook for damp leaves.

## What to look for

* **_H. virginiana_** (Virginia witch hazel) — native from the eastern United States; flowers appear before the leaves in October, when they are still mostly green with a few purple streaks.
* **_H. intermedia_** (the hybrid witch hazel) — a cross between _H. orientalis_ and _H. virginiana_; blooms earliest, often in September, and carries the strongest citrus scent on a cold morning.
* **_H. mollis_** (the golden witch hazel) — our largest specimen reaches three metres and flowers from January onward. The petals are a vivid yellow that holds well into February even after early frosts.

## Seasonal highlights

The witch hazels reach their peak in February, when few other plants offer colour of any kind. Priya Nanda recommends visiting on a clear morning after frost, when the petals open to full display and the fragrance carries along the path for nearly twenty metres.

> *I have been coming here since 1986, and every winter I still feel surprised that something as unassuming as witch hazel can stop you in your tracks.* — Priya Nanda, February 2025
