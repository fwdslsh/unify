---
layout: /collections/guides/_guide.html
---

# The Maples of Alderfen

Curated by **James Halbert**, Volunteer Curator.

Our maple collection sits on the southern lawn, bordering the pond edge. It holds seventeen species of *Acer*, including several Japanese forms that were propagated from cuttings we collected during a visit in 2015. The leaves turn earlier than most other trees here — usually mid-October for the first flush, with many still holding colour into November.

## What to look for

* **_Acer palmatum_** — the classic Japanese maple with finely divided leaves. Several cultivars occupy the pond edge, and their roots help hold the bank together in winter floods.
* **_Acer cappadocicum_** — broader canopy than most maples; its seeds are red-winged helicopters you will see everywhere by November. The bark exfoliates on older stems, revealing pale underbark that looks white in moonlight.
* **_Acer pensylvanicum_** (the striped maple) — a smaller species with greenish autumn colour and very striking lenticels (the pale patches along the twigs). A personal favourite of James Halbert.

## Seasonal highlights

The maples are at their best in November, when the Japanese forms have settled into deep scarlet and purple. Curator's note: "November is when I usually invite school groups down to the pond edge," writes Mr. Halbert. "They love counting how many shades of red one tree can hold."

> *We planted these maples for quiet conversation, not for grand statements. If you find yourself sitting long enough to hear a frog croak from the pond, you are doing it right.* — James Halbert, November 2024
