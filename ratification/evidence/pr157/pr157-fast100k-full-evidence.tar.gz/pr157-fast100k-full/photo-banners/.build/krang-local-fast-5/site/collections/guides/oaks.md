---
layout: /collections/guides/_guide.html
---

# The Oaks of Alderfen

Curated by **Dr. Eleanor Voss**, Head Botanist at Alderfen Arboretum.

The oaks here are our oldest living collection, planted in 1978 from acorns sourced across Britain and Europe. Twenty-eight *Quercus* species occupy the gentle slope north of the visitor path, each tagged with a numbered wooden plate.

## What to look for

* **_Q. robur_** (the English oak) — the dominant species and easily spotted by its long-stalked leaves without lobes near the base. Best viewed in July when the new flush is bright green.
* **_Q. cerris_** (the hornbeam oak, or hazel-like oak) — narrower crown, corky bark that smells of tannin and wet leather. The acorns are small but deeply flavoured.
* **_Q. palustris_** (the swamp white oak) — glossy dark-green leaves with a distinctive bronze cast in autumn. A favourite with photographers from November onward.

## Seasonal highlights

The oaks reach their peak colour from late September through October. The canopy turns a rich, golden brown and the acorns drop steadily underfoot, making for excellent walking. Curator's note: "October is when the whole collection speaks at once," writes Dr. Voss.

> *A great oak tree takes more than one lifetime to mature. At Alderfen we are planting for people who have not yet been born.* — Dr. Eleanor Voss, October 2023
