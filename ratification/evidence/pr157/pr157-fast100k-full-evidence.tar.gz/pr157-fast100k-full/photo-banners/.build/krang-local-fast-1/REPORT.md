# Alderfen Arboretum — Build Report

## Publishing command

```
./unify build --pretty-urls --base-url https://alderfen.pages.dev/arboretum/ --clean
```

This publishes 12 files to `dist/`, including all HTML pages, the CSS stylesheet, and four images. The output resolves at `https://alderfen.pages.dev/arboretum/` with clean URLs (no `.html` extensions).

## Pages published

| Page | Source path | Output URL |
|---|---|---|
| Home | `index.html` + `_layout.html` | `/arboretum/` |
| Visit landing | `visit/index.html` + `_layout.html` | `/arboretum/visit/` |
| Collections landing | `collections/index.html` + `_layout.html` | `/arboretum/collections/` |
| Oaks guide | `collections/guides/oaks/index.md` + `_layout.html` | `/arboretum/collections/guides/oaks/` |
| Maples guide | `collections/guides/maples/index.md` + `_layout.html` | `/arboretum/collections/guides/maples/` |
| Witch hazel guide | `collections/guides/witch-hazel/index.md` + `_layout.html` | `/arboretum/collections/guides/witch-hazel/` |

## What `rules.md` did not answer

**I needed the sentence on how `<include>` works with slots, but I re-read it twice.** The sentence "Content between the tags fills slots" did not land at first because I was looking for an example of a page filling a layout's named slot. I reread to find: "The layout writes `<slot name="footer">fallback…</slot>`; the page fills it with `slot=` on a real element." That is what I needed, and that sentence did not immediately click because it was bundled together with fragment/`.fragment.html` content in one long paragraph.

**What did I guess or infer?** The rules never explicitly state that `<body class="home">` from the page gets merged into the layout's `<body>` — they say "your classes are added" to body attributes, which I inferred means merging rather than replacing. Also, I inferred (and later confirmed) that `data-layout="/_layout.html"` on a page resolves from the source root because `/…` in rules.md "resolves from the source root."

**What did I have to re-read?** The section about `<slot>` merging: "The first default-content page main unwraps, even for a bare slot outside a layout main" — this was important to understand why my pages' `<main>` content ended up inside the layout's `<main>`. I had to re-read it because I initially misunderstood and tried to put everything inside named slots.
