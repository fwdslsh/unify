---
title: Guide to the Maples
author: Dr. Samuel Ealing
best-month: September
---

# Guide to the Maples

The maple collection is a compact but colourful grouping of nine species, mostly native to Japan and China. Margaret Halder introduced the first Japanese maples in 1983, and they have thrived ever since in the sheltered hollow beside the old stone wall.

## Notable Specimens

| Botanical name | Common name | Origin |
|---|---|---|
| *Acer palmatum* | Japanese Maple | Japan |
| *Acer buergerianum* | Trident Maple | China |
| *Acer griseum* | Bark Maple | China (Sichuan) |
| *Acer pictum subsp. kinoshitae* | Kinship Maple | Japan |

The Bark Maple is particularly prized for its exfoliating cinnamon-coloured bark, which adds interest to the collection well into winter. However, September brings the most vivid display of all — the Japanese maples burst into scarlet and gold before dropping their leaves entirely.

## Walking the Collection

Follow the gravel path past the visitor centre and down the gentle slope; you will find the maples sheltered on the south-eastern side where the wind cannot disturb them. A bench beside *Acer palmatum 'Atropurpureum'* offers a fine vantage point for photography. — Dr Samuel Ealing, Collections Manager
