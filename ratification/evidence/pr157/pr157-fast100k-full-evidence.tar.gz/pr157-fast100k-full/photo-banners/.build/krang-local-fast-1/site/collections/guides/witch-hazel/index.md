---
title: Guide to the Witch Hazel
author: Dr. Eleanor Voss
best-month: November
---

# Guide to the Witch Hazel

The witch hazel (*Hamamelis*) collection at Alderfen features six cultivars selected for winter flowering — a season when most gardeners would consider their work complete, but which here is merely beginning. The plants were donated in 2005 by the National Arboretum at Wakehurst and have since established themselves as the crowning feature of our late-wild collection.

## Collection Overview

| Cultivar | Flower colour | Notable trait |
|---|---|---|
| *Hamamelis × intermedia 'Arnold's Autumn Bloom'* | Pale yellow | Double flowers, fragrant |
| *H. × intermedia 'Diane'* | Rose-red | Excellent autumn foliage |
| *H. × intermedia 'Jalisco'* | Crimson | Large flowers up to 5 cm across |
| *H. japonica* | Soft yellow | Early flowering |
| *Hamamelis virginiana* | Bright yellow | Native North American species |

## Best Viewing

The witch hazels flower from November through December, depending on the severity of the season. They are at their absolute best in late November after a light frost has stimulated bud burst. The collection sits beside the oaks on the eastern fence line — walk past them and turn left to see the shrubs lining the path edge.

> These plants are our quietest treasures. While summer crowds flock to the oaks for shade, it is in mid-winter that I most love walking among the witch hazels, watching their ribbon-like petals unfurl against the grey sky. — Dr Eleanor Voss, Head Curator
