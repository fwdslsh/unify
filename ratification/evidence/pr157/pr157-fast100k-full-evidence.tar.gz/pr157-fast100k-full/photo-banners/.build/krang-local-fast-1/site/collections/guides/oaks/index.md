---
title: Guide to the Oaks
author: Dr. Eleanor Voss
best-month: October
---

# Guide to the Oaks

The oak collection at Alderfen comprises seventeen specimens of *Quercus* from across Europe and western Asia, planted between 1978 and 1985 by our founding botanist, Margaret Halder. The oldest is a pedunculate oak (*Quercus robur*) that stands nearly twelve metres tall beside the eastern fence.

## Species in Collection

| Common name | Botanical name | Year planted |
|---|---|---|
| Pedunculate Oak | *Quercus robur* | 1978 |
| Sessile Oak | *Quercus petraea* | 1979 |
| Turkish Oak | *Quercus cerris* | 1980 |
| Scarlet Oak | *Quercus coccinea* | 1981 |
| White Oak | *Quercus alba* | 1982 |

All oaks are at their finest from late September through October, when the acorns drop and the leaves turn rich russet. Visitors walking the oak glade in autumn should watch for the distinctive cup-like acorn caps scattered among the leaf litter.

## Curator's Note

> The pedunculate oak was one of the first trees planted at Alderfen, and it remains our most celebrated specimen. We monitor its health each spring through a programme run by the Ancient Tree Hunt, which records girth growth and canopy spread annually. — Dr Eleanor Voss, Head Curator
