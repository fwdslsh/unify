# Report: Alderfen Arboretum site

## Publishing command line

```bash
unify build --pretty-urls --base-url https://alderfen.pages.dev/arboretum/
```

Run this from the `site/` source directory (or, equivalently, run it from `/tmp/sandbox` — unify auto-detects that `site/` exists and uses it as the source root). The output lands in `dist/`, a complete static site ready for upload to Netlify or any static host serving at `https://alderfen.pages.dev/arboretum/`.

## What `rules.md` did not answer

**The sentence I needed but could not find:** "How do you set the base path so that every link, image source, and stylesheet href gets prefixed for a subdirectory deployment?" The documentation says:

> "`--base-url https://you.example/handbook/` — the site's whole address, never a bare path — prefixes every link"

—but it doesn't explain whether `href="/css/style.css"` in the HTML source becomes `href="/arboretum/css/style.css"` after prefixing (it does), nor that `<img src="/images/logo.png">` gets the same treatment. I had to re-read that sentence three times and then verify by checking the actual output before it landed: "oh, any root-relative path gets prefixed." The key was in the rules line about CSS `url()` being rewritten versus fetched addresses shipping as written — which implied links get rewritten but also left me guessing about images. I checked the output to confirm.

**Also unclear:** Whether `<body class="home">` on a page adds to an already-set body class or replaces it. The rule says "your classes are added" and "Active nav is `<body class=\"home\">` plus CSS", but my pages all got `class="home"` from the layout regardless of whether I declared empty `class:` in frontmatter. I inferred that the layout's class wins because page body has no explicit `class=` attribute (the HTML pages don't declare one), so it falls through to the default "home".

**Another gap:** The rules document never explicitly states what happens when you omit a `<title>` from an HTML page (it becomes empty, which then merges with the layout separator giving just "— Alderfen Arboretum"). I discovered this by accident — my first build produced `Alderfen Arboretum — Alderfen Arboretum` because both the layout and the page declared titles. The fix was to give each page its own short title ("Home", "Visit", etc.) so the separator join produces readable results like "Visit — Alderfen Arboretum".

## What I guessed at or inferred rather than read

- **Pretty URLs:** `--pretty-urls` turns `/visit.html` into `/visit/`. This was explicitly documented ("`about.html → about/index.html, and rewrite internal links to match`") but I missed it on first reading because the surrounding text focused heavily on `<include>` syntax. The re-read that stuck came after I saw `dist/visit/index.html` in the file listing rather than `dist/visit.html`.

- **Source root detection:** The rule says "Source root is `site/` if it exists (else `src/`, else the current directory)." I guessed at this ordering but couldn't find an explicit statement of priority — only the parenthetical. I verified by creating a `site/` directory and running build without specifying `-s`.

- **Markdown frontmatter vs `<head>`:** The rule states "HTML pages never have frontmatter (use `<head>`); Markdown pages never contain `<head>`." This seemed contradictory at first — how can a Markdown page describe itself without `<head>`? Then I understood: the layout provides `<head>`, and frontmatter becomes meta tags during merge. My re-read was necessary because the sentence structure was inverted in my mental parsing.

- **The `_layout.html` convention:** The rules mention "Every page is wrapped by the nearest `_layout.html` — its own folder, then each parent." I inferred that a single file at `/_layout.html` acts as the global layout for all pages. This was correct but not explicitly called out as a fallback — only described through the "its own folder, then each parent" phrase which left room to wonder whether every section needed its own `_layout.html`.
