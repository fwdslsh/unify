---
title: Witch Hazels
layout: /_layout.html
schema: Article
description: A curator's guide to the forty-eight witch hazel varieties at Alderfen Arboretum, blooming January through February.
date: 2026-01-12
---

# Witch Hazels

*Curated by Margaret Linley*

Witch hazels are a delight in the deepest days of winter, when few other plants bother to bloom. Alderfen's collection contains forty-eight witch hazel varieties spread along the southern hedgerow and across the frost lawn, where their late-winter flowers provide vital nectar for emerging pollinators.

## Best viewed: January – February

The blossoms appear earliest in mild winters — usually starting mid-January — and persist longest in sheltered spots near our old walled garden. Frosty mornings catch the wax-like petals in an iridescent shimmer that visitors describe as magical.

## Notable specimens

- **_Hamamelis × intermedia_ 'Diane'** — a deep-red-flowered form whose blooms last well into February and attract the first hoverflies of the year.
- **_H. mollis* **'JL Hitchcott'** — an exceptionally hardy hybrid with pale yellow flowers that carry a honey fragrance on cold afternoons.
- **_Hamamelis japonica** — the Japanese witch hazel, whose leaf-before-flower habit gives it a distinctly different character from its European and Chinese relatives.
