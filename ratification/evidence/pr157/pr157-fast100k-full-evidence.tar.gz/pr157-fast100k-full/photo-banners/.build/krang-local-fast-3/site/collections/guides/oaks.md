---
title: The Oaks
layout: /_layout.html
schema: Article
description: A curator's guide to the sixty oak specimens at Alderfen Arboretum, at their best September through October.
date: 2026-01-05
---

# The Oaks

*Curated by Dr Eleanor Voss*

The oaks of Alderfen form the backbone of our collection. Sixty specimens spanning twenty species and varieties are planted along the North Walk and in the lower meadow, where they were laid out by our founding botanist, Thomas Halder, in 1954.

## Best viewed: September – October

The fall colour of our oaks draws hundreds of visitors each autumn. The Italian oak (*Quercus cerris*) puts on an especially striking display, its leaves turning from gold to deep mahogany over three weeks.

## Notable specimens

- **_Quercus robur_ 'Stemford Hill'** — a remarkably upright form reaching twenty-two metres since planting in 1982.
- **_Quercus macrantha** — the Persian oak, unusually drought-tolerant and one of our tallest at thirty-one metres.
- **_Quercus palustris_ 'Pringle'** — the pin oak whose autumn colour is unsurpassed in this collection, turning scarlet with copper tones that rival the finest maple stands.
