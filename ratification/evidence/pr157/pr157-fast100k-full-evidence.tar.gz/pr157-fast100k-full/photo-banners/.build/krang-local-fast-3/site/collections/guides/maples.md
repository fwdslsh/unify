---
title: The Maples
layout: /_layout.html
schema: Article
description: A curator's guide to the thirty-seven maple varieties at Alderfen Arboretum, glowing October through early November.
date: 2026-01-08
---

# The Maples

*Curated by James Whitcombe*

Our maple collection is the youngest of Alderfen's three featured collections, but it has become one of its most popular. Thirty-seven varieties are grown in two adjoining beds near the café, chosen for their compact growth and brilliant autumn colour.

## Best viewed: October – early November

The peak display usually arrives around the first week of November — a brief window during which every shade of crimson, amber, and gold is visible at once.

## Notable specimens

- **_Acer palmatum_ 'Discolor'** — the flame maple, whose leaves are rose-coloured in spring and fiery red through autumn.
- **_Acer buchananii** — the leatherleaf maple from the Himalayas, with massive dark-red leaf clusters that turn crimson before dropping.
- **_Acer niigatense*** — a hardy species from northern Japan, tolerating temperatures down to twenty-five degrees below zero and turning spectacular shades of orange and scarlet.
