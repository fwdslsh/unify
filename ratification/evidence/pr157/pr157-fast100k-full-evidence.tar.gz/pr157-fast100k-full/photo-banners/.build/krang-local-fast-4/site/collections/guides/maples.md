---
title: Maples — Alderfen Arboretum
layout: /_layout.html
description: A guide to the maple collection at Alderfen. Curated by Thomas Linley, Head Gardener. Best in November.
schema: Article
author: Thomas Linley
og:title: "The Maples"
---

# The Maples

<section class="content collections-overview">

  <div class="guide-hero">
    <img src="/images/collections-banner.png" alt="Maple leaves ablaze with autumn colour">
    <div class="guide-meta">
      <p><strong>Curator:</strong> Thomas Linley, Head Gardener</p>
      <p><strong>Month at its best:</strong> November</p>
      <p><strong>Number of specimens:</strong> 32 species of deciduous and evergreen maples.</p>
    </div>
  </div>

  <article>
    <h2>About the collection</h2>
    <p>We began our maple collection in 1954, when Thomas's father — also named Thomas Linley, as you might say — brought back a handful of Japanese specimens from a trip to Kyoto and planted them along the southern drive.</p>

    <p>Today we have thirty-two species, from the dwarfed *A. japonicum 'Aconifolium'*, which barely clears six inches at maturity, up through the towering *A. pensylvanicum* and several of our prized Chinese tree maples — all thriving in the mild clay that runs under the lower lawn.</p>

    <h2>Visiting in November</h2>
    <p>The leaves turn late here, sometimes as late as mid-November depending on how quickly the autumn frosts come. The Japanese varieties hold their crimson longest; *A. palmatum 'Dissectum'* and its friends do not shed a single leaf until after the first hard frost.</p>

    <p>The evergreen species, which are fewer in number but none less interesting, keep their leaves right through winter — a good reminder that these trees were never just autumn show-offs.</p>
  </article>

</section>
