---
title: Oaks — Alderfen Arboretum
layout: /_layout.html
description: A guide to the oak collection at Alderfen. Curated by Dr Eleanor Voss, Senior Botanist. Best in October.
schema: Article
author: Dr Eleanor Voss
og:title: "The Oaks"
---

# The Oaks

<section class="content collections-overview">

  <div class="guide-hero">
    <img src="/images/collections-banner.png" alt="Oak canopy in autumn colour">
    <div class="guide-meta">
      <p><strong>Curator:</strong> Dr Eleanor Voss, Senior Botanist</p>
      <p><strong>Month at its best:</strong> October</p>
      <p><strong>Number of specimens:</strong> 48 species from across the Northern Hemisphere.</p>
    </div>
  </div>

  <article>
    <h2>About the collection</h2>
    <p>The oak collection at Alderfen began in 1950 when our first foreman, Walter Finch, planted a row of English oaks along the north lane. Those original trees are now well over twenty metres tall and still produce acorns each autumn.</p>

    <p>We have representatives from every major oak group — *Quercus alba*, the white oaks of eastern North America; the tall, dark-barked *Q. robur*; and several of the rarest Chinese species, which we have kept in the sheltered hollow near the pond since 1967.</p>

    <h2>Visiting in October</h2>
    <p>The collection is at its best from mid-September through early November, when the leaves turn a rich amber-gold. The white-barked species — particularly *Q. ilex* and *Q. pubescens* — hold their colour longest.</p>

    <p>If you are only able to visit once, plan for early October after two or three days of dry weather. The acorns fall then and the paths between the trees are quietest in the morning light.</p>
  </article>

</section>
