# Alderfen Arboretum — Publish Report

## Command line

```bash
./unify build --pretty-urls --base-url https://alderfen.pages.dev/arboretum/ --clean
```

---

## What `rules.md` did not answer

I needed a sentence that clearly states: **can `.md` files be used as guide pages with frontmatter?** The rules say "HTML pages never have frontmatter" and "Markdown pages never contain `<head>`", but there is no single sentence that says "write `.md` files for content authored by non-technical writers." I had to re-read the Frontmatter section three times before understanding that `.html` with YAML at the top would render as visible text, and that I should use `.md` extension instead. The first pass didn't land because the rules never explicitly say "use .md for curator guides" — it is implied through what `.html` cannot do, but the implication was not obvious on first reading.

I also needed to find: **does `--base-url` prefix `url()` in CSS?** The rules warn that "`url()` in a stylesheet file...ship as written" and that root-relative paths miss the prefix under `--base-url`. But it does not say whether `background-image: url('/images/…')` in inline styles or in a `.css` file gets rewritten. I inferred from "keep every `url()` in a stylesheet file" that CSS files are NOT rewritten by unify — only HTML's own URL attributes (`href`, `src`) get the prefix. This meant my `<img src="...">` tags were correctly prefixed, but I had to be careful that no images used CSS `url()` backgrounds (I used inline `<img>` elements instead).

---

## What I guessed or inferred

1. **Layout merging for `.md` pages:** The rules say "Markdown: `layout: /path.html`" but do not explicitly describe whether the layout wraps rendered Markdown body content into a full HTML document before composition, or whether the page's `<head>` (from frontmatter meta) is merged. I inferred that when you write both YAML frontmatter and an HTML document in a `.md` file, unify strips the markdown-wrapped head/body and composes it into the layout — which turned out to be correct.

2. **Pretty URL behavior:** The rules state `--pretty-urls` rewrites internal links from `/about.html` → `/about/` and creates directory-based output (`about/index.html`). I inferred that this applies recursively to all pages, including subdirectory pages — confirmed by the output showing `visit/opening-times/index.html`.

3. **Schema generation:** The rules mention `schema: Article` writes JSON-LD from "what the page already declares." I could not find a sentence listing exactly which fields are extracted (title, description, canonical, og:image, author, date). I inferred from context that it pulls whatever it can read and reports missing dates — confirmed by the output containing headline, description, url, author, inLanguage.
