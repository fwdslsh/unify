---
title: Witch Hazel — Alderfen Arboretum
layout: /_layout.html
description: A guide to the witch hazel collection at Alderfen. Curated by Dr Eleanor Voss, Senior Botanist. Best in December.
schema: Article
author: Dr Eleanor Voss
og:title: "Witch Hazel"
---

# Witch Hazel

<section class="content collections-overview">

  <div class="guide-hero">
    <img src="/images/collections-banner.png" alt="Yellow witch hazel flowers in winter light">
    <div class="guide-meta">
      <p><strong>Curator:</strong> Dr Eleanor Voss, Senior Botanist</p>
      <p><strong>Month at its best:</strong> December</p>
      <p><strong>Number of specimens:</strong> 26 selections of Hamamelis and hybrids.</p>
    </div>
  </div>

  <article>
    <h2>About the collection</h2>
    <p>The witch hazels were planted in stages over three decades, starting in 1974 when we acquired a small plot of former pasture on the east slope. The first batch came from two nurseries in Norfolk and a third private collection near St Ives — all with very different genetics and very different flowers.</p>

    <p>We have twenty-six selections today, including four that are not yet officially registered. *H. x intermedia 'Diane'* is the one visitors ask about most; its crimson petals open early in December and can last through snow if the weather is mild enough.</p>

    <h2>Visiting in December</h2>
    <p>The witch hazels are our best winter bloomers, flowering between late November and mid-January depending on how kind the season has been. A mild autumn means they will open sooner — often as early as the first week of December.</p>

    <p>We recommend visiting after a night of frost: the flowers seem to unfurl further in the cold air and their honeyed scent travels further too, especially on still mornings.</p>
  </article>

</section>
