---
title: The Maples
layout: /_layout.html
---

Maples are the colour champions of our autumn display, and the Alderfen collection has earned a reputation across the county for its autumn show. We cultivate approximately sixty taxa within the genus *Acer*, ranging from the low-growing *Acer caespitosum* to towering Himalayan maples that have established themselves as the stars of the mid-canopy layer.

Curator: James Whitfield, Curator of Broadleaf Trees.

The collection is at its best in **early November**, when the Japanese varieties begin their slow decline and hold colour for weeks — some into December. The key to enjoying it well is to check after the first frosts; that is when everything ignites.

## Highlights from the garden

- *Acer palmatum* 'Bloodgood' — the most reliable of the red cultivars, reliably vivid year on year
- *Acer cappadocicum* — native to central Asia, its fruits look like little helicopters in late summer
- *Aer attenuata* — an alpine species from Bhutan, smaller than you might expect for its reputation
