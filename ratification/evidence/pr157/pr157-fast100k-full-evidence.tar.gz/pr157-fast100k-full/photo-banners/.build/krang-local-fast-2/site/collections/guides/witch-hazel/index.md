---
title: The Witch Hazels
layout: /_layout.html
---

There is perhaps no better way to spend an afternoon in late winter than a walk through the witch hazel border at Alderfen. *Hamamelis* species and hybrids flower while almost everything else is dormant, and their crinkled, ribbon-like petals are unmistakable from ten metres away. Our collection includes both hardy European species and tender Chinese varieties that have taken years to establish.

Curator: Priya Menon, Senior Horticulturist.

The collection is at its best from **January to February**. The flowers open on warm afternoons and close as the temperature drops each evening — it is one of those rare plants that rewards patient visitors who can return several times over a few weeks to watch them unfold.

## A selection worth seeking out

- *Hamamelis × intermedia* 'Diane' — deep crimson flowers with a fragrance that draws pollinators from across the garden
- *Hamamelis virginiana* — American witch hazel, its autumn leaves turn yellow before falling, and the flowers open months later on bare branches
- *Hamamelis mollis* — the golden variant from Fujian province, possibly our most spectacular winter-flowering plant
