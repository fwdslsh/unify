# Report — Alderfen Arboretum site

## Publish command line

```bash
./unify build --clean --pretty-urls --canonical auto --base-url https://alderfen.pages.dev/arboretum/
```

The output in `dist/` deploys to **https://alderfen.pages.dev/arboretum/**. Every link and image resolves there with the `/arboretum/` prefix, and pretty URLs are used (e.g. `/arboretum/visit/` not `/arboretum/visit.html`).

## What `rules.md` did not answer

1. **Title merging across layouts and pages** — The rules describe how a page's `<head>` merges with the layout's, including the separator pattern for titles: "write the separator into the layout's title" and "a page writes only its own name". I read this sentence but it didn't immediately click because the brief never specified what the home page should do when there is no subtitle to append. The rules say to write a `<title>` in both, but the example given (`<title>— My Site</title>` with a page of `<title>About</title>`) leaves out the edge case where the page's own name *is* the site name — which would produce "Alderfen Arboretum — Alderfen Arboretum". I had to re-read the rules several times and reason that for the home page I should omit its title entirely so it falls back, but even then I got an empty-title edge case (" — Alderfen Arboretum"). The rules never say "if a page has no subtitle, use nothing" — I inferred that from how head merging works.

2. **Image asset resolution** — The rules state: "a leading `/` means the source root, in any path you write". I read this as meaning `<img src="/images/logo.png">` would resolve to `site/images/logo.png`, but when the images were sitting at `site/*.png` (files directly in the source root), I couldn't figure out why they didn't resolve. It took me a second pass through the rules and re-reading "every other file copies byte-for-byte to the same path" before I understood that the `<img>` tag referenced `/images/logo.png`, which means `images/logo.png` — requiring an actual subdirectory called `images/`. The first read didn't land because I was conflating source root path resolution (`/images` = root + `/images`) with file placement. I had to re-read it and trace the exact path through the HTML tag to see that the `<img>` src attribute defines a nested directory structure.

3. **Markdown frontmatter delimiters** — The rules say: "Frontmatter is YAML:" followed by key descriptions, but never explicitly shows the `---` fence delimiters around frontmatter (though the dash is shown in the context of being an error). I guessed at and inferred from common Markdown conventions that frontmatter needs `---` fences. When my guide pages rendered without titles, I had to re-read carefully and notice the rules mention YAML keys like `title` and `layout` but never show the fence syntax — I needed to look more closely and infer from "Frontmatter is YAML: quote any value containing a colon". The first read I missed this because I assumed frontmatter would work without fences, since the rules don't explicitly say "use `---` around it."

## What I guessed or inferred rather than read

- **The `<slot>` placement rule** — The error message said sinks are only in body. The rules state that head merging happens separately from body slotting, but the connection between these two sections wasn't obvious on first reading. I had to re-read and cross-reference section 8 ("Head") with section 5 ("Include") before understanding that `<slot>` in a layout's `<head>` is never a sink — it was a build error, not just an advisory.

- **Pretty URLs directory structure** — The rules say `--pretty-urls` makes `about.html → about/index.html`. I inferred from this that pretty URLs work by creating index files inside directories, which meant the output paths like `/visit/` would come from `visit/index.html`. This wasn't explicitly stated but was inferable from "A directory link you write yourself (`/guides/`) builds only when the output has a guides/index.html."
