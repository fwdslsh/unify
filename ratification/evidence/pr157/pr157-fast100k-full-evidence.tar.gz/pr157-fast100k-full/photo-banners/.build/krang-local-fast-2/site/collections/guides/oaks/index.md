---
title: The Oaks
layout: /_layout.html
---

The oaks (*Quercus*) are the backbone of any great arboretum, and Alderfen is no exception. Our collection spans species from every corner of the Northern Hemisphere — European sessile oak, Japanese serrated oak, American northern red oak, and a magnificent specimen of *Quercus variabilis* that stands nearly forty metres tall in the upper valley.

Curator: Dr Elena Vostok, Head Arborist.

The collection is at its best from **October to November**, when the leaves turn gold and russet across dozens of species simultaneously. It is a spectacle that draws visitors from the whole region each autumn.

## Notable specimens

- *Quercus robur* — planted 1765, trunk circumference over five metres
- *Quercus rubra* — 'Alderfen Pride', selected for exceptional blight resistance in 1932
- *Quercus mongolica* — from the forests of Manchuria, holds colour later than any other species on site
