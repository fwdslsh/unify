const { createRequire }  = require('module');
const path             = require('path');
const fs               = require('fs');

// Resolve from site/ where node_modules are installed  
const req              = createRequire(path.join(__dirname, '..', 'site') + '/');
const esbuild          = req('esbuild');
const sveltePkg        = req('svelte/compiler');
const { compile }      = sveltePkg;

const projectRoot      = path.resolve(__dirname, '..');
const svelteSrcPath    = path.join(projectRoot, 'components', 'FeeCalculator.svelte');
const siteAssets       = path.join(projectRoot, 'site', 'assets', 'forge-calculator');

console.log('Building FeeCalculator from:', svelteSrcPath);

// Compile Svelte → ESM  
const compiled         = compile(fs.readFileSync(svelteSrcPath, 'utf8'), { name: 'ThistleknapFeeCalculator' });
console.log('Compiled:', compiled.js.code.length, 'bytes of JS');

if (!compiled || !compiled.js || !compiled.js.code) { console.error('Compile produced no output'); process.exit(1); }

// Create staging dir  
const stagedDir        = path.join(projectRoot, '.staged-svelte');
fs.mkdirSync(stagedDir, { recursive: true });

function collectAllJS(rootDir) {
  const files = [];
  function walk(dir) {
    if (!fs.existsSync(dir)) return;
    for (const e of fs.readdirSync(dir)) {
      const full = path.join(dir, e);
      try {
        const st = fs.statSync(full);
        if (st.isDirectory()) walk(full);
        else if (e.endsWith('.js')) files.push(full);
      } catch (err) {}
    }
  }
  walk(rootDir);
  return files;
}

const internalSrc      = '/tmp/sandbox/site/node_modules/svelte/src/runtime/internal';
const sharedSrc        = '/tmp/sandbox/site/node_modules/svelte/src/shared';

let jsFiles            = collectAllJS(internalSrc);
if (sharedSrc && fs.existsSync(sharedSrc)) {
  jsFiles.push(...collectAllJS(sharedSrc));
}

console.log('Found ' + jsFiles.length + ' source JS files');

// Copy to flat dir with fixed relative imports  
for (const file of jsFiles) {
  let content          = fs.readFileSync(file, 'utf8');
  const parent         = path.dirname(file);
  // Fix ../x.js and ./x.js patterns — resolve real path then flatten
  content              = content.replace(/from\s+['"](\.[^'\"]+)['"]/g, (m, mod) => {
    const real         = path.resolve(parent, mod);
    if (!fs.existsSync(real)) return m; // skip non-existent paths (symlinks etc.)  
    return 'from "./' + path.basename(real).replace('.js', '') + '"';  
  });

  fs.writeFileSync(path.join(stagedDir, path.basename(file)), content);
}

// Replace svelte/internal imports in compiled code  
let jsCode             = compiled.js.code.replace(/"svelte\/internal"/g, '"./runtime.js"');
jsCode                 = jsCode.replace(/import\s*"svelte\/internal\/disclose-version"\s*;?\n?/g, '');

// Create runtime.js (flat) — from internal/index.js  
const srcIndex         = path.join(internalSrc, 'index.js');
let indexContent       = fs.readFileSync(srcIndex, 'utf8');
indexContent           = indexContent.replace(/from\s+['"]\.\/(\w+\.js)['"]/g, 
  (m, mod) => 'from "./' + mod.replace('.js', '') + '"');
fs.writeFileSync(path.join(stagedDir, 'runtime.js'), indexContent);

// Write the compiled entry point  
const entryFile        = path.join(stagedDir, 'FeeCalculator.entry.js');
fs.writeFileSync(entryFile, jsCode);

console.log('Staging done. Running esbuild...');

// Run esbuild — output directly to site/assets/forge-calculator/FeeCalculator.min.js  
esbuild.build({
  absWorkingDir: stagedDir,
  entryPoints: [entryFile],
  bundle: true,
  outfile: path.join(siteAssets, 'FeeCalculator.min.js'), // single file output
  format: 'esm',
  platform: 'browser',
}).then(() => {
  console.log('OK → assets/forge-calculator/FeeCalculator.min.js');

  // Cleanup temp  
  fs.rmSync(stagedDir, { recursive: true });
});
