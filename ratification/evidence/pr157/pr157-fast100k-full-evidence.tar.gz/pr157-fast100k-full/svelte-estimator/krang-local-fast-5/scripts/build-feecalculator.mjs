import path from 'path';
import { readFileSync } from 'fs';
import { createRequire } from 'module';
import { fileURLToPath, pathToFileURL } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Use dynamic imports to load from site/node_modules  
const vitePkgUrl  = path.join(__dirname, '..', 'site', 'node_modules', 'vite');
const vitePkg     = JSON.parse(readFileSync(path.join(vitePkgUrl, 'package.json'), 'utf8'));
const viteMain    = vitePkg.main || vitePkg.exports?.['.']?.require || vitePkg.exports?.['.']?.default;

// The .svelte file — stays untouched in components/ at the project root  
const svelteSrcPath  = path.resolve(__dirname, '..', 'components', 'FeeCalculator.svelte');
console.log('Building FeeCalculator...');
console.log('Source:', svelteSrcPath);
