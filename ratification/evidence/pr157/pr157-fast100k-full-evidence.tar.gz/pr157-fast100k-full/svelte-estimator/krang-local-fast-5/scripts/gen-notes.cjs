const { readFileSync, writeFileSync, readdirSync, statSync } = require('fs');
const { join, basename } = require('path');

// Resolve source root: the script lives inside a "site" directory
const p = __dirname;
let sourceRoot = process.cwd();
const parts = p.split('/');
for (let i = 0; i < parts.length - 1; i++) {
  if (parts[i] === 'site' && i > 0) {
    sourceRoot = parts.slice(0, i + 1).join('/');
    break;
  }
}

console.error(`sourceRoot: ${sourceRoot}`);
console.error(`script __dirname: ${__dirname}`);

const notesDir = join(sourceRoot, 'courses', 'notes');
const outPath = join(sourceRoot, 'courses', 'notes-index.html');

function parseFrontmatter(content) {
  const parts = content.split('---\n').filter(Boolean);
  if (parts.length < 2) return { frontmatter: {}, body: content };
  const fmStr = parts[0];
  // Body is everything after the frontmatter section, stripped of leading ---
  let body = parts.slice(1).join('---\n').trim();
  const fm = {};
  for (const line of fmStr.trim().split('\n')) {
    const colonIdx = line.indexOf(':');
    if (colonIdx > -1) {
      const key = line.substring(0, colonIdx).trim();
      let val = line.substring(colonIdx + 1).trim();
      if ((val[0] === '"' && val[val.length - 1] === '"') || (val[0] === "'" && val[val.length - 1] === "'")) {
        val = val.slice(1, -1);
      } else if (val === 'true') {
        val = true;
      } else if (val === 'false') {
        val = false;
      } else if (!isNaN(Number(val))) {
        val = Number(val);
      }
      fm[key] = val;
    }
  }
  return { frontmatter: fm, body };
}

const notes = [];
for (const file of readdirSync(notesDir)) {
  if (!file.endsWith('.md') || file.startsWith('notes-index')) continue;
  const fullPath = join(notesDir, file);
  if (!statSync(fullPath).isFile()) continue;
  try {
    const content = readFileSync(fullPath, 'utf8');
    const { frontmatter } = parseFrontmatter(content);
    notes.push({
      filename: file.replace('.md', ''),
      slug: basename(file, '.md'),
      title: frontmatter.title || '',
      date: frontmatter.date ? String(frontmatter.date) : '',
      author: frontmatter.author || ''
    });
  } catch (e) {
    console.error(`Skipping ${file}:`, e.message);
  }
}

notes.sort((a, b) => b.date.localeCompare(a.date));

const hrefBase = '/courses/notes/';

let html = `<!doctype html>
<html lang="en">
<head>
<meta charset>
<title>Course Notes — Thistleknap Forge</title>
<link rel="stylesheet" href="/css/style.css">
</head>
<body class="home">
<header></header>
<main slot="content">
<h1>Course Notes</h1>

<p>Pick up any dropped pieces or ask questions about a technique covered in our sessions. These notes are from instructors and regulars at the forge, collected here for reference.</p>

`;

for (const note of notes) {
  const href = `${hrefBase}${note.slug}.html`;
  html += `
<h2><a href="${href}">${note.title}</a></h2>
<p class="meta">By ${note.author} · ${note.date}</p>
<p>`;

  try {
    const fullContent = readFileSync(join(notesDir, `${note.slug}.md`), 'utf8');
    const { body } = parseFrontmatter(fullContent);
    // Skip the heading line (first # ...), then grab paragraph text
    let excerptLines = body.split('\n').filter(l => l.trim());
    // Remove leading blank lines and heading line (lines starting with '#')
    while (excerptLines.length > 0 && (excerptLines[0].trim().startsWith('#') || !excerptLines[0].trim())) {
      excerptLines.shift();
    }
    let excerpt = '';
    for (let i = 0; i < Math.min(excerptLines.length, 3); i++) {
      const trimmed = excerptLines[i].trim();
      if (!trimmed) continue;
      excerpt += ` ${trimmed}`.substring(1);
    }
    html += `${excerpt}…`;
  } catch (e) {
    // no body available
  }

  html += `</p>`;
}

html += `
</main>
<footer></footer>
</body>
</html>`;

writeFileSync(outPath, html);
console.log(`Generated notes index at ${outPath}`);
console.log(`Notes indexed: ${notes.length}`);
