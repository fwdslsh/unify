---
title: On Flux Quantities — A Practical Guide
date: 2025-09-14
author: Mara Winters
---

# On Flux Quantities — A Practical Guide

We have been having trouble with welds cracking on the third heat for people using only borax as flux. Borax is honest but limited — it does not cover the whole range of oxidation states you see at welding temperature.

Here are some observations from our last three sessions:

1. Start with a pinch of borax (about ¼ teaspoon per forge mouthful).  
2. Add a small amount of silica sand if you see heavy slag formation — this lowers the flux melting point and helps it flow faster over the metal.  
3. If the weld still looks spongy after three draws, check that your fire is not too far forward on the hearth.

A full write-up will follow once we have tested these ratios with a dozen different steels.
