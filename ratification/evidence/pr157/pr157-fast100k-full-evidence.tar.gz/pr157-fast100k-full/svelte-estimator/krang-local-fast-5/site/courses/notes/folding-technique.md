---
title: Folding Technique for Beginners
date: 2025-08-27
author: Tomas Kell
---

# Folding Technique for Beginners

Most people trying pattern welding for the first time fold too early. They see layers and think they have succeeded — but layers are not the same as welds. A layer that does not fuse is just an inclusion waiting to crack later.

The test I use on my own pieces: take a cold chisel, place it across the bar at a ninety-degree angle, and give it a light tap with a 16-ounce hammer. If there is any sound different from the normal metallic ring — anything that sounds dull or soft — the fold has not welded.

I find that people who have done woodcarving before tend to push too aggressively when folding. Let the metal guide you. Watch how it flows and stop before it feels forced. The anvil tells you what it needs if you listen.

Most people trying pattern welding for the first time fold too early. They see layers and think they have succeeded — but layers are not the same as welds. A layer that does not fuse is just an inclusion waiting to crack later.

The test I use on my own pieces: take a cold chisel, place it across the bar at a ninety-degree angle, and give it a light tap with a 16-ounce hammer. If there is any sound different from the normal metallic ring — anything that sounds dull or soft — the fold has not welded.

I find that people who have done woodcarving before tend to push too aggressively when folding. Let the metal guide you. Watch how it flows and stop before it feels forced. The anvil tells you what it needs if you listen.
