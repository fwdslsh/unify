---
title: Quenching Temperatures for Common Steels
date: 2025-07-19
author: Mara Winters
---

# Quenching Temperatures for Common Steels

Several people asked about quenching temperatures during our last session, so I put together some notes on the colours we look for and when to pull.

| Steel type | Quench colour        | Pull timing                    |
|------------|----------------------|--------------------------------|
| Carbon 1080 | Cherry red          | Just before it loses its glow — about three seconds into a steady cherry-red with a hint of orange at the edges |
| High carbon (O1) | Orange-yellow | When the yellow starts to dominate over red. This is earlier than you think. |
| Mild steel | Dull red            | Pull well before you think it is hot enough — mild steel will not take an edge anyway, so the quench temperature matters less for forming. |

A word of caution: do not let the metal sit at temperature longer than ten seconds before pulling. Anything longer and the grain starts to coarsen even if the colour looks correct. I have seen three pieces ruined this way in one session.
