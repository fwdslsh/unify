import 'svelte/internal/disclose-version';
import 'svelte/internal/flags/legacy';
import * as $ from 'svelte/internal/client';

var root = $.from_html(`<div class="fee-calc"><label>People <input type="number" min="1" max="8"/></label> <label>Hours <input type="number" min="2" max="6"/></label> <p> </p></div>`);

export default function FeeCalculator($$anchor, $$props) {
	$.push($$props, false);

	const total = $.mutable_source();
	let hourlyRate = $.prop($$props, 'hourlyRate', 8, 18);
	let materialsFee = $.prop($$props, 'materialsFee', 8, 12);
	let people = $.mutable_source(2);
	let hours = $.mutable_source(3);

	$.legacy_pre_effect(
		() => (
			$.get(people),
			$.get(hours),
			$.deep_read_state(hourlyRate()),
			$.deep_read_state(materialsFee())
		),
		() => {
			$.set(total, $.get(people) * $.get(hours) * hourlyRate() + $.get(people) * materialsFee());
		}
	);

	$.legacy_pre_effect_reset();

	var div = root();
	var label = $.child(div);
	var input = $.sibling($.child(label));

	$.remove_input_defaults(input);
	$.reset(label);

	var label_1 = $.sibling(label, 2);
	var input_1 = $.sibling($.child(label_1));

	$.remove_input_defaults(input_1);
	$.reset(label_1);

	var p = $.sibling(label_1, 2);
	var text = $.only_child(p);

	$.reset(div);
	$.template_effect(() => $.set_text(text, `Estimated cost: £${$.get(total) ?? ''}`));
	$.bind_value(input, () => $.get(people), ($$value) => $.set(people, $$value));
	$.bind_value(input_1, () => $.get(hours), ($$value) => $.set(hours, $$value));
	$.append($$anchor, div);
	$.pop();
}