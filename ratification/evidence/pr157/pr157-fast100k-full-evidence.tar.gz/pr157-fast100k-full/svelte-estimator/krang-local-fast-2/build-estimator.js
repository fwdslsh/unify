import { compile } from 'svelte/compiler';
import fs from 'fs';

const src = fs.readFileSync('components/FeeCalculator.svelte', 'utf8');

// Compile with generate: 'dom' for standalone output (no runtime dependency on svelte/internal)
const { js, css } = compile(src, { 
  name: 'FeeCalculator', 
  filename: 'FeeCalculator.svelte',
  generate: 'dom'  // Server-side / static DOM rendering
});

fs.writeFileSync('site/forge/components/FeeCalculator.js', js.code);
if (css && css.code) fs.writeFileSync('site/forge/components/FeeCalculator.css', css.code);

console.log('Done');
console.log(js.code.substring(0, 300));
