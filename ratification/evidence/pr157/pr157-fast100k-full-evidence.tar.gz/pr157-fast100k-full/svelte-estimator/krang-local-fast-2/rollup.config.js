import { nodeResolve } from '@rollup/plugin-node-resolve';
import svelte from 'rollup-plugin-svelte';

export default {
  input: 'components/FeeCalculator.svelte',
  output: {
    file: 'site/forge/components/FeeCalculator.js',
    format: 'es',
    sourcemap: true
  },
  plugins: [
    svelte({ compilerOptions: { format: 'esm' } })
  ],
  external: ['svelte/internal/client']
};
