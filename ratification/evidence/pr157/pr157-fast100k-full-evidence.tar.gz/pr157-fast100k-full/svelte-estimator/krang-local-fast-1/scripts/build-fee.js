const { compile } = require('svelte/compiler');
const esbuild = require('esbuild');
const fs = require('fs');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..');
const srcPath = path.join(projectRoot, 'components', 'FeeCalculator.svelte');
const outDir = path.join(projectRoot, 'site', 'components');

if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

const outPath = path.join(outDir, 'FeeCalculator.runtime.js');

const src = fs.readFileSync(srcPath, 'utf8');
const result = compile(src, { css: 'injected' });

fs.writeFileSync(outPath, result.js.code);
console.log('Compiled Svelte component to JS.');

esbuild.build({
  entryPoints: [outPath],
  bundle: true,
  outfile: outPath,
  format: 'iife',
  platform: 'browser',
  allowOverwrite: true,
  minify: false,
}).then(() => {
  console.log('Bundled with esbuild.');
});
