---
title: Heating and Drawing — Session Notes
date: 2025-09-15
schema: Article
description: What we learned in our first blacksmithing session on heating steel to the right temperature.
---

# Heating and Drawing — Session Notes

Today's class covered the fundamentals of getting coal-fired steel to a workable temperature. The main takeaway: watch for colour, not time.

## Key points

- Low red is around 600 °C; cherry red ~800 °C; forging starts at 900 °C and above.
- When drawing out stock, keep the flame neutral to avoid burning — a sulphury smell means your fire is too aggressive.
- Everyone in our group managed their first simple hook joint by the third blow.

## What went well

The coal mix held heat better than expected. We should buy that brand again next time.
