---
title: Intermediate Techniques — Scroll Work and Twisting
date: 2025-11-20
schema: Article
description: Notes on scroll work, bar twisting, and decorative elements from our intermediate class.
---

# Intermediate Techniques — Scroll Work and Twisting

Our intermediate group tackled scrolls and bar twists today. Half made their first single scroll; everyone finished with a twisted section they recognised as their own.

## Key points

- A scroll starts as a flat bar drawn to a rectangle, then pinned in the vice at 90° increments.
- Twist pattern: draw square, twist with a wrench, set with heat and quench — don't skip the tempering step if it's going to take load.
- Keep a consistent grip distance (about one hammer-length) for uniform twists.

## Group highlights

Marta did a double-helix on her last piece — we're proud of that. We should consider an advanced-only slot next quarter.
