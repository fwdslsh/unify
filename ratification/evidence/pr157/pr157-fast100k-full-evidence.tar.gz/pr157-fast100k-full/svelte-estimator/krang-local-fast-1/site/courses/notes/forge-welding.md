---
title: Forge Welding — Session Notes
date: 2025-10-03
schema: Article
description: Instructor notes from the forge welding workshop on flux, timing, and successful welds.
---

# Forge Welding — Session Notes

We ran a full-day welding session today. Three of five participants made successful welds on their first attempt.

## Key points

- Flux (borax) must be added before the metal reaches full heat; if it chars on the surface, start again.
- The "butter and squeeze" technique — apply flux, draw out a buttery flash, then hammer quickly while still bright.
- Don't quench a weld you haven't verified; inspect for cracks after slow cooling.

## What to watch next time

Borax availability is low. Order more before the next workshop. Also: one extra bellows would have helped with crowd size.
