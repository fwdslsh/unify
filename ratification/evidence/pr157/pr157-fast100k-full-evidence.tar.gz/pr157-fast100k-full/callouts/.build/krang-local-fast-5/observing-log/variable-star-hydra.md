---
title: "Monitoring Eta Carinae during outburst"
date: 2024-10-19
schema: Article
description: We caught the early stages of a brightness fluctuation in Eta Carinae, writing down visual estimates that match our photometric follow-up.
---

# Monitoring Eta Carinae during outburst

Eta Carinae has been brightening steadily since September, and on Wednesday night I took it upon myself to watch for several hours. The sea was rough off the coast but the sky above Harrowgate Hill held clear enough for visual estimates.

I used a 10×50 binocular and compared Eta against HD 93204 (magnitude 6.7) plus two comparison stars in the field at 7.4 and 8.3 mag. On the Wilson scale I wrote down estimates roughly every thirty minutes — all fell between 5.1 and 5.3, with no sudden dips. The surrounding Trumpler 16 cluster was a bonus: three of its fainter members showed clear emission lines on our slit-scope add-on.

<include src="/_includes/callout.fragment.html">
  <h3 class="callout-heading" slot="heading">Spectrograph Add-On (Slit-scope)</h3>
  <p>A low-resolution dispersion attachment for our 4-inch refractor, capable of separating emission and absorption lines on bright nebulae and variable stars.</p>
  <div class="callout-difficulty">Difficulty: advanced — requires prior training</div>
</include>

<include src="/_includes/callout.fragment.html">
  <h3 class="callout-heading" slot="heading">10×50 Binoculars</h3>
  <p>The go-to for variable-star comparisons and quick field checks. Our pair of high-quality binocs with wide fields — essential for framing Eta Carinae with comparison stars.</p>
  <div class="callout-difficulty">Difficulty: intermediate, good practice for newcomers</div>
</include>

Tomorrow I will upload the estimates to AAVSO's public database. The automated photometers back home showed a small dip at mid-October but our visual record fills in gaps between their duty cycles nicely.
