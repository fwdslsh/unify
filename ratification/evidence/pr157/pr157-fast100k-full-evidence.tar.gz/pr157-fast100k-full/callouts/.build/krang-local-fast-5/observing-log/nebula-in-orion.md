---
title: "Methane frost and a surprise"
date: 2024-11-06
schema: Article
description: A volunteer's notes on our first observing night after the early-frost warning. We expected poor seeing — instead, Venus stole the show.
---

# Methane frost and a surprise

The weather forecast called for heavy frosts again overnight, so we were prepared for terrible seeing. The dome had already beaded with condensation when we arrived, which was discouraging in the worst way.

We pointed our 6-inch refractor at Venus first — it is rising fast now, and near greatest illumination. Even through the thin cirrus that drifted overhead the crescent shape was crisp. One of our new volunteers noticed a faint yellowish tinge to the limb, which I had never seen before. Turns out methane absorption in the upper atmosphere can do this when Venus is near its eastern elongation — it surprised me too.

Later we swung the Dobsonian over to M45 again. The frost on the primary mirror took ten minutes to clear with the dehumidifier, and by then the Pleiades were already low enough that seeing was smeared. Still worth it: you cannot beat the sight of fifteen or sixteen stars in a single field, even when they dance.

<include src="/_includes/callout.fragment.html">
  <h3 class="callout-heading" slot="heading">6″ Refractor (189 cm focal length)</h3>
  <p>The workhorse of our inventory. A 6-inch achromat that handles Venus, double stars, and tight clusters with sharp colour-free images at low power.</p>
  <div class="callout-difficulty">Difficulty: beginner-friendly</div>
</include>

<include src="/_includes/callout.fragment.html">
  <h3 class="callout-heading" slot="heading">14″ Dobsonian Reflector</h3>
  <p>A light bucket that collects enough photons to make the Moon's rilles and craters vivid under steady skies. The frost took its toll tonight.</p>
  <div class="callout-difficulty">Difficulty: intermediate — best with a volunteer nearby</div>
</include>

I spent some time tracking a few of the Pleiades' variable stars through the hand-held photometer app on my phone, and got readings consistent with what the AAVSO publishes. It felt like doing real science for the first time since I started volunteering here three years ago.
