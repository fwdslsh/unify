---
title: "Mars at opposition — close and red"
date: 2024-08-16
schema: Article
description: Opposition night for Mars. The red planet was blazing low in the south-west, and its surface features came into sharp focus through our largest telescopes.
---

# Mars at opposition — close and red

Opposition day arrived with perfect seeing — a rare treat that we have not seen this well since 2018. Mars climbed to about thirty degrees above the horizon by half-nine and refused to twinkle, which is when you know the atmosphere has stilled.

I took first watch through the 14″ Dobsonian at 300× and spent forty minutes mapping the polar ice cap as it continued to shrink. The dark region known as the Solis Fortunata patch was clearly visible, along with faint dust clouds drifting over the western hemisphere. At one point a bright flash appeared near the limb — I later checked the satellite imagery and it matched no known feature; most likely an optical illusion caused by albedo contrast.

<include src="/_includes/callout.fragment.html">
  <h3 class="callout-heading" slot="heading">14″ Dobsonian Reflector</h3>
  <p>The largest telescope we own. Its primary mirror gathers enough light to reveal polar caps, surface markings, and dust storms on Mars at opposition.</p>
  <div class="callout-difficulty">Difficulty: intermediate — requires a trained observer</div>
</include>

<include src="/_includes/callout.fragment.html">
  <h3 class="callout-heading" slot="heading">Red Filter (Wratten #25)</h3>
  <p>A deep-red interference filter that enhances contrast on Mars's polar caps and dark surface features. Essential for planetary observing at opposition.</p>
  <div class="callout-difficulty">Difficulty: intermediate — recommended with the Dobsonian</div>
</include>

My colleague Elena took a different approach, tracking Phobos as it crossed the disk over forty minutes using our 4-inch refractor. Its motion was barely perceptible at low power but unmistakable when drawn on graph paper. We all took turns and every single person who looked reported seeing something — even though most had never viewed Mars through a telescope before.
