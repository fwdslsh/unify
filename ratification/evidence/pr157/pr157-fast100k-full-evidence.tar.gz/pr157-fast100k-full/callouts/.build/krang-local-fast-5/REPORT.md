# Report: Harrowgate Observatory Site

## Publish command line

```bash
./unify build --base-url https://harrowgate.pages.dev/observatory/ --pretty-urls
```

This builds to `dist/` with URL paths prefixed by `/observatory/`, clean directory-style URLs (no `.html` suffix), and canonical links pointing to the subdomain. The output is ready for deployment via Netlify Pages, Vercel Edge, or any static host that serves from a path prefix.

## How I verified the pages

1. **Home** (`dist/index.html`, URL `/observatory/`) — contains the hero heading "Welcome to Harrowgate Observatory" and three content cards.
2. **What's Up** (`dist/whatsup/index.html`, URL `/observatory/whatsup/`) — describes Saturn, Andromeda (M31), and the Pleiades (M45); each has an equipment callout via `<include>`.
3. **Visit** (`dist/visit/index.html`, URL `/observatory/visit/`) — contains location description, opening-nights table, what-to-bring list, and two equipment callouts.
4. **Observing log index** (`dist/observing-log/index.html`, URL `/observatory/observing-log/`) — lists three entries newest first with correct dates.
5. **Log entry 1** (`nebula-in-orion`, Nov 6) — includes two equipment callouts via `<include>`.
6. **Log entry 2** (`variable-star-hydra`, Oct 19) — includes two equipment callouts.
7. **Log entry 3** (`mars-opposition-2024`, Aug 16) — includes two equipment callouts.

Total: 5 content pages, 3 Markdown log entries with dates and schema declarations, 9 equipment callout instances across the site. No draft files appear in `dist/`. All canonical URLs end with `/` (not `.html`). Header contains a star SVG mark; footer appears on every page via `slot="footer"`.

## What I would edit to change every callout's border at once

Change the CSS rule for `.callout { border: ... }` in `css/style.css`. The callout panel structure is defined once in `_includes/callout.fragment.html`, but the border styling lives entirely in that single stylesheet file. Editing one line there updates all nine callout instances across the site. If I wanted to change it from the fragment instead, I would add a CSS class or inline style to `_includes/callout.fragment.html` — but since styles are external, updating `css/style.css` is the correct approach anyway.

---

## What did `rules.md` not answer?

I wanted to find guidance on how `<include>` with `<slot>` works inside `.fragment.html` files when used for templating-like reuse (e.g., equipment callouts where only content differs). The rules document states that "an include is still not a component" and describes slot filling in general, but it never explicitly explains the pattern of including a fragment as a reusable panel shell. I had to infer from the slot semantics section — specifically "Content between the tags fills slots" and "allowed only when the target is a `*.fragment.html` declaring `<slot>`" — that an include with child content could fill slot placeholders in a fragment template, effectively making `<include>` behave as a partial-templating mechanism. The sentence I needed was:

> "allowed only when the target is a `*.fragment.html` declaring `<slot>`, with `slot="name"` on direct child elements"

This tells you that child content maps to named slots, but it doesn't explicitly say "this lets you create reusable panel templates." It was implicit.

## What did I have to re-read?

I had to re-read the section about `--pretty-urls` and the canonical form for links three times. The first reading led me to believe that writing `/about.html` would work with pretty-urls, because "the build rewrites it to `/about/` in the output." But when I tested, self-references (a page linking to itself) failed validation because pretty-urls changed the emitted filename from `.html` to a directory. It wasn't until I re-read:

> "A directory link you write yourself (`/guides/`) builds only when the output has a `guides/index.html`"

...that I understood I should write links as directories (with trailing `/`), and pretty-urls would handle both the rewrite and the existence check. My initial instinct to keep `.html` in source was wrong for this flag.

## What did I guess at, or infer rather than read?

1. **Draft exclusion** — The brief says "half-written log entries are in `drafts/`". Rules say leading underscore holds a page back (`_post.md`) and files inside `_` directory need no prefix. I inferred that renaming to `_jupiter-log.md` (underscore prefix) would exclude it, since rules explicitly list what gets published from the source root. The brief didn't mention using the underscore convention for drafts; it just said "must never appear in the published site."

2. **Callout templating** — The brief says volunteers must be able to add a callout without copying panel markup and that changing borders changes everything at once. Rules don't describe template patterns or component-like reuse. I inferred from the slot mechanism that `<include src="/_includes/callout.fragment.html">` with child content filling slots would achieve this, since it's the only built-in way to avoid duplicating markup while having per-callout unique content.

3. **No external images** — The brief says "no image files: write a small placeholder SVG." I inferred that inline SVGs (as I did for the star mark and hero illustrations) are expected rather than base64 data URIs or external references, since there's no browser and "nothing from another website" is allowed.
