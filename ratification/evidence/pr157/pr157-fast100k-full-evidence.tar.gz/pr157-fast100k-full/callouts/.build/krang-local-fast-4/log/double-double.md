---
title: "A double-double in Lyra"
layout: /_layout.html
schema: Article
description: Observing session report for January 2025.
date: 2025-01-07
author: "Amara Chen"
lang: en
---

# A double-double in Lyra

The weather held through a cold snap and gave us pristine skies on New Year's Eve. We aimed at Epsilon Lyrae — the celebrated double-double — and split every component cleanly with the 80 mm refractor at 120x.

<include src="/_includes/callout.fragment.html"><span slot="heading">Double-split through the 80 mm refractor at 120×</span><span slot="body">Both pairs resolved instantly, and the colour contrast between the orange primary and blue-white companions was striking.</span><span slot="difficulty">Advanced</span></include>

## Notes

We lingered on Albireo for a while longer; the gold-sapphire pairing never gets old. Seeing held at 4/5 despite the cold.
