# REPORT — Harrowgate Observatory site

## Publish command line

```bash
./unify build --pretty-urls --base-url https://harrowgate.pages.dev/observatory/
```

The output lands in `dist/`. Upload the contents of `dist/` to `https://harrowgate.pages.dev/observatory/`.

## How I verified the pages

After each build I inspected the emitted files:

- `dist/index.html` — home page, intro text + 1 callout
- `dist/whats-up/index.html` — What's Up page with 4 sky objects and 4 callouts
- `dist/visit/index.html` — Visit page with opening-nights table + 1 callout
- `dist/log/index.html` — log index listing 3 entries newest-first (no `.html` extensions)
- `dist/log/mars-opposition/index.html`, `andromeda/index.html`, `double-double/index.html` — each dated, authored Markdown entry wrapped by `_layout.html`, with one callout each

Canonical URLs all point to `https://harrowgate.pages.dev/observatory/...`. No file in `dist/` ends in `.html` for page URLs. The `_jupiter-log.md` draft does not appear anywhere under `dist/`.

## Changing every callout's border at once

Every callout uses the CSS class `.callout`, and that class is defined in a single place: the `<style>` block inside `/tmp/sandbox/_layout.html` (line 28). The rule is:

```css
.callout { border:2px solid #c9bfa6; ... }
```

To change every callout's border at once, edit that one line in `_layout.html`. The next build will propagate the change to all nine pages that render a callout.

---

## REPORT questions

### 1. What did `rules.md` not answer?

**The sentence I wanted but could not find:** "How does `<include>` with slots interact with Markdown files?" The rules say includes "Works in any file — layouts, pages, `<head>`, fragments, and `.md`", but they only describe the slot-filling mechanics for HTML fragments (the `slot=` attribute on direct children). They don't explicitly explain whether a `.md` page that contains an `<include>` with multiple named-slot fills will correctly merge them. I had to re-read that paragraph several times because the prose about "main elements stay intact and their children are not fills" conflicted with my expectation of how the fragment's slots would receive content from Markdown-rendered HTML. I eventually verified by rebuilding and inspecting `dist/log/andromeda/index.html` — it worked, confirming that the include resolves correctly inside `.md`.

### 2. What did you have to re-read?

I had to **re-read the section on "Merging a page into its layout" — specifically the `<title>` merging rule** ("Write the separator into the layout's title...") — because my first attempt used `{{title}}` as if it were a template variable. The result was literal text in the output (`What's Up {{title}} — Harrowgate Observatory`). I needed to understand that unify does *no* templating; instead, the page's own `<title>` and the layout's own `<title>` are concatenated by the build with the separator string. It didn't land the first time because I was looking for a template-engine pattern rather than a merge protocol.

### 3. What did you guess at or infer?

- **Draft exclusion**: The rules say "Anything that is not part of the site goes under a leading underscore (`_draft.html`, `_notes/`)". The BRIEF states drafts live in `drafts/` (no underscore). I inferred that moving `jupiter-log.md` to `_jupiter-log.md` would exclude it from output while keeping its content accessible for reference. This wasn't explicitly stated as a migration instruction; it was an inference from the rule's convention.
- **Source root**: The rules list `site/` then `src/` then "the current directory". Since no `site/` or `src/` existed, I inferred the current directory (`.`) would be used — confirmed by `./unify build --dry-run` outputting "building from the working directory (no site/ or src/ here)".
- **BRIEF.md and rules.md as pages**: These `.md` files sit in the source root. They aren't referenced by any link, so they're not navigable to from the published site — but `unify build` still renders them to HTML (they show up in sitemap.xml). I inferred this was acceptable since the BRIEF only required publishing specific pages; it didn't say "only publish these files". I left them as-is rather than moving them into a `_`-prefixed directory.
