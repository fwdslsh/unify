---
title: "Mars opposition seen through haze"
layout: /_layout.html
schema: Article
description: Observing session report for March 2025.
date: 2025-03-10
author: "Amara Chen"
lang: en
---

# Mars opposition seen through haze

Tonight the telescope pointed toward Mars at its closest approach, but a thin high cirrus swept across the sky and reduced contrast to near nothing. Still caught a brief moment of colour — the polar cap stood out as pale pink against the rust-red disk.

<include src="/_includes/callout.fragment.html"><span slot="heading">Mars filter with the 80 mm refractor</span><span slot="body">The blue C-clamp filter brought out subtle surface shading at low power. Even through cirrus you can sense the disc is truly round, not a point source.</span><span slot="difficulty">Intermediate</span></include>

## Notes

Saturn was also up but too far east; we swapped to Jupiter's cloud belts for the final hour. Seeing was 3/5.
