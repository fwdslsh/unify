---
title: "Andromeda through the 12 inch"
layout: /_layout.html
schema: Article
description: Observing session report for February 2025.
date: 2025-02-14
author: "Tomasz Kowalski"
lang: en
---

# Andromeda through the 12 inch

Crystal-clear skies and a moonless sky made tonight perfect for deep-sky work. We pulled up the 12 inch reflector, put in the 10 mm eyepiece, and aimed at M31 — the Andromeda galaxy — just after dusk. The nebulous glow was visible even at low power as an extended fuzzy patch roughly two degrees across.

<include src="/_includes/callout.fragment.html"><span slot="heading">Wide-field scan with the 12 inch reflector</span><span slot="body">Switching to our custom UHC filter, the core of Andromeda brightened noticeably against the dark background sky. Members could resolve faint spiral structure near the edges.</span><span slot="difficulty">Advanced</span></include>

## Notes

Afterward we swept through NGC 2146 (lens-shaped galaxy in Orion) and caught a hint of its dusty lanes. Seeing was excellent at 5/5.
