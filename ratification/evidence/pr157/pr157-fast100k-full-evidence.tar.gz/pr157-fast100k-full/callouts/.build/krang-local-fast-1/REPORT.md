# Report: Harrowgate Observatory Site

## Publish command line

```
./unify build --pretty-urls
```

The site publishes to `dist/`, and the visitor URLs map as:

| Address | Source file |
|---|---|
| `https://harrowgate.pages.dev/observatory/` | `site/index.html + _layout.html` |
| `https://harrowgate.pages.dev/observatory/whats-up/` | `site/whats-up.html + _layout.html` |
| `https://harrowgate.pages.dev/observatory/visit/` | `site/visit.html + _layout.html` |
| `https://harrowgate.pages.dev/observatory/observing-log/` | `site/observing-log/index.html + _layout.html` |
| `https://harrowgate.pages.dev/observatory/observing-log/2025-11-05/` | `site/observing-log/2025-11-05.md + _layout.html` |
| `https://harrowgate.pages.dev/observatory/observing-log/2025-10-29/` | `site/observing-log/2025-10-29.md + _layout.html` |
| `https://harrowgate.pages.dev/observatory/observing-log/2025-10-15/` | `site/observing-log/2025-10-15.md + _layout.html` |

To publish, the contents of `dist/` would be served at that subdirectory.

## How I verified the pages

I ran `./unify build --pretty-urls`, inspected every generated file in `dist/`, confirmed:

- No `.html` suffix appears in any `href` attribute
- Every page has a `<header>` with a star SVG and navigation, plus a `<footer>`
- The observing-log index lists entries newest first (2025-11-05 before 2025-10-29 before 2025-10-15)
- No content from `drafts/jupiter-log.md` appears in the output
- Equipment callouts render identically across all pages

## Changing every callout's border at once

Change the CSS rule `.equip-callout { border: ... }` in `site/_includes/css/style.css`. Every page includes the equipment panel via `<include src="/fragments/equip.fragment.html">`, which copies one fragment into each page. The border is defined in that single CSS file.

---

## What `rules.md` did not answer

1. **"What if a page needs to include a fragment but also have its own `<body>` attributes?"** — I expected the rules to address how slot fills with elements like `<h3 slot="heading">` interact with fragments that declare slots as children of other elements (e.g., `<slot name="body">` inside a `<p>`). This led me into nesting issues where I put `<p slot="body">text</p>` which doubled the `<p>`. I had to re-read the rules about how fills work and realize the fill replaces the entire `<slot>` element (not just its children), so plain text or spans are needed.

2. **The sentence I wanted but could not find:** How do slot-fill elements interact when the target fragment declares slots as *children* of other elements, rather than standalone? The rules say "Content between the tags fills slots" and "A named `<main slot="content">` fill and its subtree stay intact; nested fills there are inert" — but I needed to know what happens with an `<h3 slot="heading">` inside an include when the fragment has just `<slot name="heading"></slot>` (a standalone bare slot). The fix was clear from context: the element replaces the slot tag, so any attributes except `slot=` stay.

3. **What did I re-read?** I re-read the "Merging a page into its layout" section about named slots and found it didn't apply cleanly to includes with filled slots — that section describes pages filling layout slots with elements like `<footer slot="footer">`, not fragments receiving fills from include contents. The distinction between *page-to-layout* slot-filling and *include-content-to-fragment* slot-filling was never explicitly drawn. I inferred they work the same way (content between tags goes to matching `slot=` declarations) by reading "Content between the tags fills slots" on its own.

## What I guessed or inferred rather than read

1. **The underscore convention for excludes.** The rules say "`--exclude` replaces the `_*)` default" — I initially tried putting CSS and fragments inside `site/_includes/`, not realizing files *inside* an underscore directory are also excluded by that glob pattern. I had to move them to `css/` and `fragments/`. This wasn't explicitly stated beyond "Files inside a `_` directory need no prefix" (meaning they need no underscore prefix — but the exclude still applies).

2. **The default source root.** The rules say "Source root is `site/` if it exists (else `src/`, else the current directory)" — I assumed the default would be the working directory since that's where `rules.md` sits, but the tool defaults to looking in `site/`.

3. **Frontmatter vs `<head>` for Markdown.** The rules say "Markdown pages never contain `<head>` (use frontmatter)" and "HTML pages have no frontmatter; use `<head>`" — I initially put YAML frontmatter on HTML files, which produced build errors. Re-reading the error messages made it clear: HTML pages must use raw `<meta>` tags in a real `<head>`.

4. **The `--base-url` requirement for canonical/og: links.** The dry-run output showed "serving from / — the domain root (no --base-url)" which meant no canonical or og: URLs were generated as absolute. Since the brief says the site is served at a subdirectory on `harrowgate.pages.dev`, I would add `--base-url https://harrowgate.pages.dev/observatory/` to make share links correct for crawlers (as noted in the rules about `og:` and `canonical`).
