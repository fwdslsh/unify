---
title: Andromeda on a moonless night
date: 2025-11-05
layout: /log/_entry.html
schema: BlogPosting
---

<p class="log-date">2025-11-05 — Written by Clara Voss</p>

## Andromeda on a moonless night

No Moon tonight — the darkest sky we've had this season. The galaxy was visible as a soft glow even through binoculars.

<include src="/_includes/callout-andromeda.html"></include>

The whole village seemed to turn out. Twenty-four people watched, some lying on blankets in the drizzle (we ran out of roof space). A local school group came for their first ever visit; one of the children spotted M31 without a telescope at all and gasped.

Clear skies, 4 °C. Seeing poor due to low humidity shimmer, but plenty of excitement.
