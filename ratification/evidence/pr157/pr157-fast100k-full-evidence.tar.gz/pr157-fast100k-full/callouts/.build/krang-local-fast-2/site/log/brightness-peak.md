---
title: Brightness peaks at Saturn
date: 2025-10-18
layout: /log/_entry.html
schema: BlogPosting
---

<p class="log-date">2025-10-18 — Written by Clara Voss</p>

## Brightness peaks at Saturn

The rings were dazzling tonight — three members of the team took turns at the refractor. A couple spotted Cassini's Division with patience and a clear sky.

<include src="/_includes/callout-saturn.html"></include>

A few first-timers came along on their bikes from the village. One child asked whether Saturn's rings were made of ice, which led to a nice chat about density and rotation. We closed at 21:40 when a light drizzle started.

Clear skies, 8 °C. Seeing was steady — excellent for planetary detail.
