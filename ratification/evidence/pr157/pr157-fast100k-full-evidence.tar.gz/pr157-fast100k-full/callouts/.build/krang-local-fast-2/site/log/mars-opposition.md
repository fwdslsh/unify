---
title: Mars at opposition — a red dot grows
date: 2025-10-28
layout: /log/_entry.html
schema: BlogPosting
---

<p class="log-date">2025-10-28 — Written by Thomas Eade</p>

## Mars at opposition — a red dot grows

Mars is bright enough to cast shadows tonight. The colour filter brought out the polar cap and Syrtis Major.

<include src="/_includes/callout-mars.html"></include>

Six people waited in line, some of them having driven from the next valley over. We ended early because our main finder was drifting south — a loose screw on the tripod. Repaired before the next session. Wind 12 mph from the north-west.
