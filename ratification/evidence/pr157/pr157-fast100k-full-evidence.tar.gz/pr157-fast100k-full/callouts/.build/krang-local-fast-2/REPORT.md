# Harrowgate Observatory — Build Report

## Publish command line

```bash
./unify build --base-url https://harrowgate.pages.dev/observatory/ --pretty-urls
```

This produces the `dist/` directory ready to deploy. The output is served from `https://harrowgate.pages.dev/observatory/`, with pretty URLs (no `.html` in addresses) and all links prefixed for the subdirectory path.

## How I verified the pages

1. Ran `./unify build --dry-run --strict` — no problems, 7 pages would gain canonical links, 3 would gain JSON-LD blocks.
2. Ran `./unify build --base-url https://harrowgate.pages.dev/observatory/ --pretty-urls` — exited with code 0.
3. Confirmed `dist/` contains: `index.html`, `whatsup/index.html`, `visit/index.html`, `log/index.html`, and three log entries under `log/`. No files from the top-level `drafts/` directory appeared in output.
4. Searched all HTML output for `.html` URLs — none found outside of `index.html` filenames themselves. All links use pretty-URL form (`/whatsup/`, `/log/brightness-peak/`).
5. Confirmed every page contains the star mark (`&#9733;`) in both header and footer (2 occurrences per page).
6. Counted equipment callouts: 8 total across the site (4 on What's Up, 1 on Visit, 3 in log entries), each with unique heading/body/difficulty text but identical panel/border/icon structure.

## Changing every callout's border at once

Edit `site/css/style.css` — the single CSS file that defines `.callout { border: 2px solid #aaa; }`. Change the one line and rebuild. All eight callouts on all five pages pick up the change automatically because they share this stylesheet and fragment structure.

## What did rules.md not answer?

I could not find a sentence answering **how to prevent drafts from appearing in output when they live outside the source root**. The rules say "Anything that is not part of the site ... goes under a leading underscore" but my draft files sit in `drafts/` at the project level, not inside the source root (`site/`). Since unify only processes files within the source root by default, the drafts were safely excluded without any prefix — but this was an assumption I made rather than something rules.md explicitly confirmed.

I also needed to find (but didn't find) a sentence clarifying **whether HTML pages with their own `<head>` fully replace or merge with the layout's head**. The title duplication ("Harrowgate Observatory — Harrowgate Observatory") taught me they merge, but I had to re-read and experiment rather than finding an explicit rule.

## What did I have to re-read?

I reread the **title merging rules** multiple times: "Write the separator into the layout's title" and "a page writes only its own name." The first time through, I missed that HTML pages with a complete `<head>` still participate in head merging (not replacement), which is why my home page title duplicated. I had to re-read until it landed: the layout's head is the base, and page-head elements replace or merge — both declare `<title>`, and they join rather than one winning.

I also reread the **`<include>` section** — "an include is still not a component" — because I initially tried to create parameterized callout templates with placeholders. The rules make clear includes are verbatim splices, so each variant needs its own fragment file (or inline markup).

## What did I guess at or infer?

- **The star mark**: I chose `&#9733;` (U+2605 BLACK STAR) as the "small star mark" because no other hint existed. This is a guess — any suitable symbol would work.
- **The SVG telescope icon**: The brief says "a small telescope icon" but provides no asset. I hand-wrote an inline SVG that depicts a simple refractor telescope, since there are no image files available.
- **Drafts exclusion mechanism**: I inferred that because the source root is `site/`, any file or directory outside it (like `drafts/jupiter-log.md`) simply isn't processed by unify at all. This wasn't explicitly stated for files *outside* the source root, only for underscore-prefixed files *within* it.
- **Log layout approach**: The rules say layouts are `_layout.html` in each folder or specified via `data-layout`. I inferred that `log/_entry.html` (a per-page layout) would be found under `log/` rather than the site-wide `_layout.html`, and confirmed this worked when testing.
- **No browser available**: The brief states "There is no browser available to you" — so I couldn't use devtools or any online service. All CSS uses system fonts only; no external resources are loaded.

## Done checklist

- `./unify build` exits with code 0
- Published output at `dist/` maps correctly to the subdirectory URL via `--base-url` and `--pretty-urls`
- No `.html` in visitor-facing URLs
- Drafts from `drafts/` do not appear in `dist/`
- Every page has shared header (star mark) and footer via `_layout.html`
- 8 equipment callouts across the site, each with unique text but identical structure
- Border defined once in CSS (`site/css/style.css`) for single-point change
