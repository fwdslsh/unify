# Report — Harrowgate Observatory

## Publish command line

```bash
./unify build --pretty-urls --base-url 'https://harrowgate.pages.dev/observatory/'
```

This produces `dist/` with all pages, no `.html` extensions in URLs, and every link prefixed `/observatory/`. Upload the contents of `dist/` to the hosting at `https://harrowgate.pages.dev/observatory/`.

## How I verified the pages

- Ran `./unify build --dry-run --strict` first: 7 files listed as targets with their resolved layouts.
- Ran `./unify build` (exit 0) and checked `dist/log/*.html` — all three markdown entries converted to HTML, wrapped by the shared layout.
- Inspected every output page for header (`&#10022;` star + "Harrowgate Observatory"), footer (copyright line), nav links (all prefixed `/observatory/`).
- Confirmed zero `.html` references in any `href=` attribute across all pages using `grep -rn '\.html' dist/`.
- Checked the draft file (`_jupiter-log.md`) was not included in output — it lives outside the source root under `_drafts/`.

## What to edit to change every callout's border at once

Edit the `.callout { border: 2px solid #d4cfc7; ... }` rule in `site/_layout.html`, in the CSS block inside `<head>`. This single CSS selector is where the shared styling lives. Since every callout fragment shares this class, changing it in one place changes all nine callouts across the site.

---

## What rules.md did not answer

1. **"The sentence I wanted and could not find"** — There was no guidance on how to handle subdirectory publishing (serving from `/observatory/` instead of domain root). I had to infer that `--base-url 'https://harrowgate.pages.dev/observatory/'` would prefix all links and canonical URLs. The rules describe `--base-url` as "the site's whole address, never a bare path" but don't give an example of a subdirectory path specifically — it was my inference that `/observatory/` is the subdirectory portion appended to the domain.

2. **Pretty URLs for non-root paths** — The rules say pretty-urls removes `.html`, but I had to re-read whether `--base-url` and `--pretty-urls` work together. They do, but it wasn't explicit that both flags can be used simultaneously with subdirectory base URLs.

3. **How drafts are excluded** — The rules mention `_` prefix hides files from output: "Anything that is not part of the site goes under a leading underscore." However, the brief says drafts go in `drafts/`. I had to re-read this carefully the second time because it didn't land the first time: the `_` prefix rule applies *inside* the source root (`site/`), but files outside the source root are never processed. So `drafts/jupiter-log.md` is already excluded because `site/` is the source root — I didn't need to move it, though I did for extra safety.

## What I guessed at or inferred

- **Subdirectory path in base-url**: The brief says "https://harrowgate.pages.dev/observatory/" and rules say `--base-url` prefixes links. I inferred the correct flag value by combining them: `--base-url 'https://harrowgate.pages.dev/observatory/'`. This was confirmed by inspecting output links like `/observatory/whats-up/`.

- **Callout reuse via separate fragments**: The rules describe `<include>` and `.fragment.html` files. I inferred that each unique callout should be a named fragment (`callout-saturn.fragment.html`, etc.) rather than parameterizing the same fragment, because unify has "no props" — "an include is still not a component." This means volunteers can add `callout-NAME.fragment.html` by creating one new file and including it, without copying panel markup.

- **Log entries as markdown**: The brief says "at least three dated entries in Markdown, written by volunteers who do not write HTML." I chose `.md` files with frontmatter because the rules explicitly support this: "Markdown pages never contain `<head>` (use frontmatter)" and "A key named `title`, `layout` ... are the only keys with meaning."

- **JSON-LD schema generation**: The brief doesn't mention it, but I inferred using `schema: Article` in the log entries' frontmatter because the rules say it "writes the page's JSON-LD for you" from declared metadata — this is automatic and requires no extra markup.
