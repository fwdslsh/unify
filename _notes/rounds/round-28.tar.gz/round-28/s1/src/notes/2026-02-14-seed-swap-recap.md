---
title: "Seed Swap Recap: Full Drawers Before Spring"
description: "Fifty neighbors traded envelopes at our February seed swap, and the catalog drawers have never been fuller."
og:title: "Seed Swap Recap: Full Drawers Before Spring"
og:description: "Fifty neighbors traded envelopes at our February seed swap, and the catalog drawers have never been fuller."
schema: BlogPosting
date: 2026-02-14T10:00:00Z
author: "Priya Nandakumar"
---

# Seed Swap Recap: Full Drawers Before Spring

Fifty of you showed up to the community center on Saturday with envelopes,
jars, and paper bags full of seed, and by noon the sign-out binder had run
out of blank lines. Thank you.

## What came in

The bean and pea drawers are the fullest they've been in the three years
I've been volunteering here. We also picked up a nice run of donated
marigold and calendula seed, which is perfect for anyone borrowing for
the first time this spring — both are forgiving, both come back true from
seed you save yourself.

## What's still thin

Tomatoes and peppers are always the first drawers to empty out once
spring planting starts, so if you have saved seed from last year sitting
in a drawer at home, now is the time to bring it in.

## A reminder on labeling

A few envelopes came in this year without a date on them. If you're not
sure how old your seed is, write your best guess — "sometime last summer"
is more useful to the next borrower than nothing at all.

See you at the drawers. Regular hours resume this Tuesday.
