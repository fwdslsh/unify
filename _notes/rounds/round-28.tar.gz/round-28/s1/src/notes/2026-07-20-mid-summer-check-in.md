---
title: "Mid-Summer Check-In: What's Ready to Save"
description: "Lettuce is bolting, peas are dry on the vine, and it's the right week to start saving seed from your earliest spring plantings."
og:title: "Mid-Summer Check-In: What's Ready to Save"
og:description: "Lettuce is bolting, peas are dry on the vine, and it's the right week to start saving seed from your earliest spring plantings."
schema: BlogPosting
date: 2026-07-20T14:00:00Z
author: "Odalys Reyes"
---

# Mid-Summer Check-In: What's Ready to Save

Halfway through the season is a good time to walk your garden with an
envelope in your pocket. A few things are ready right now if you borrowed
them this spring.

## Lettuce

Any lettuce that bolted in the June heat is likely flowering or already
gone to seed. Once the fluffy white seed heads dry out and turn tan,
shake them into a paper bag — you'll get a surprising amount of seed from
just one or two plants.

## Peas and beans

Let a handful of pods stay on the vine well past the point you'd pick them
to eat, until they rattle and the pod itself has dried brown. Shell them
indoors on a dry day and let the seed cure another week before it goes in
an envelope.

## Not yet

Tomatoes, peppers, and squash are still weeks out — hold off until the
fruit is fully ripe, even past the point of good eating, before pulling
seed from any of those.

## Bring what you save

The drop box by the catalog drawers is open during all regular hours.
Even a small envelope helps keep a variety in circulation for the next
grower who borrows it.
