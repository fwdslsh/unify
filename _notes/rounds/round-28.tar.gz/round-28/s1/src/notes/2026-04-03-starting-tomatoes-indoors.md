---
title: "Starting Tomatoes Indoors"
description: "A borrower's guide to starting library tomato seed on a sunny windowsill, six to eight weeks before the last frost."
og:title: "Starting Tomatoes Indoors"
og:description: "A borrower's guide to starting library tomato seed on a sunny windowsill, six to eight weeks before the last frost."
schema: BlogPosting
date: 2026-04-03T09:30:00Z
author: "Marcus Toledo"
---

# Starting Tomatoes Indoors

Fernway's frost date usually falls in mid-May, which means tomato seed
started indoors now will be ready to transplant right on schedule. Here's
what I do with the packets I borrow every year.

## What you need

- A shallow tray or repurposed yogurt cups with drainage holes poked in the bottom
- Seed-starting mix, not garden soil
- A sunny south-facing window, or a simple grow light
- Patience for about a week before anything pokes through

## The steps

1. Fill each cup with damp seed-starting mix and press two seeds about a
   quarter inch deep.
2. Keep the tray somewhere warm — on top of the fridge works well — until
   you see the first sprouts, usually five to ten days.
3. Move sprouted seedlings into direct light immediately. Leggy, pale
   seedlings almost always mean they needed more light sooner.
4. Once each cup has its true leaves, thin to the strongest single
   seedling.
5. Harden off outdoors for a week before transplanting, starting with an
   hour of shade and working up to a full day of sun.

## Save some seed this year

If you borrow a tomato variety and love it, let one fruit ripen fully past
the point you'd normally eat it, scoop out the seeds, ferment them in a
little water for a couple of days to strip the gel coating, then dry and
return an envelope to the drawer. That's how every packet in the library
got there in the first place.
