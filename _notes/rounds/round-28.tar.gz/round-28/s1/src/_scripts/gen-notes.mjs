// Regenerates notes/index.html — the derived post listing — from notes/*.md.
// Run before building: node _scripts/gen-notes.mjs && unify build
// (from the project root, with src/ as the source tree: node src/_scripts/gen-notes.mjs && unify build)
import { readdirSync, readFileSync, writeFileSync } from "node:fs";

const HERE = import.meta.url;
const NOTES = new URL("../notes/", HERE);

const esc = (s = "") => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const escAttr = (s = "") => esc(s).replace(/"/g, "&quot;");
const cmp = (x, y) => (x < y ? -1 : x > y ? 1 : 0);

function readFrontmatter(text) {
  const m = text.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?/);
  const data = {};
  for (const line of m ? m[1].split(/\r?\n/) : []) {
    const kv = line.match(/^([\w:-]+):\s*(.*)$/);
    if (kv) data[kv[1]] = kv[2].trim().replace(/^"([\s\S]*)"$/, "$1");
  }
  return data;
}

const posts = readdirSync(NOTES)
  .filter((f) => f.endsWith(".md"))
  .map((file) => {
    const fm = readFrontmatter(readFileSync(new URL(file, NOTES), "utf8"));
    const slug = file.slice(0, -3);
    return {
      slug,
      title: fm.title || slug,
      date: fm.date || "",
      description: fm.description || "",
      author: fm.author || "",
    };
  })
  .sort((a, b) => cmp(b.date, a.date) || cmp(a.slug, b.slug));

const items = posts
  .map((p) => {
    const when = p.date
      ? '<time datetime="' + escAttr(p.date) + '">' + esc(p.date.slice(0, 10)) + "</time>"
      : "";
    const by = p.author ? '<p class="byline">by ' + esc(p.author) + "</p>" : "";
    return (
      "      <li>\n" +
      '        <h2><a href="/notes/' + escAttr(p.slug) + '.html">' + esc(p.title) + "</a></h2>\n" +
      "        " + when + "\n" +
      "        <p>" + esc(p.description) + "</p>\n" +
      "        " + by + "\n" +
      "      </li>"
    );
  })
  .join("\n");

writeFileSync(
  new URL("index.html", NOTES),
  "<!doctype html>\n" +
    '<html lang="en">\n' +
    "  <head>\n" +
    "    <title>Notes from the Library</title>\n" +
    '    <meta name="description" content="Dispatches from Fernway Seed Library volunteers, newest first.">\n' +
    '    <meta property="og:title" content="Notes — Fernway Seed Library">\n' +
    '    <meta property="og:description" content="Dispatches from Fernway Seed Library volunteers, newest first.">\n' +
    "  </head>\n" +
    "  <body>\n" +
    "    <h1>Notes from the Library</h1>\n" +
    "    <p>Dispatches from the volunteers who keep the drawers full, newest first.</p>\n" +
    '    <ul class="notes-list">\n' +
    items +
    "\n    </ul>\n" +
    "  </body>\n" +
    "</html>\n",
);

console.log("gen-notes.mjs: wrote notes/index.html from " + posts.length + " post(s)");
