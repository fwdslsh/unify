# Fernway Seed Library Site Build Report

## Publish Command

```
./unify build --base-url https://fernway.example/library/ --pretty-urls
```

## Build Verification (Dry-Run with Strict Checks)

```
./unify build --dry-run --strict --base-url https://fernway.example/library/ --pretty-urls
```

Output:
```
serving from https://fernway.example/library/
structured data: 3 pages would gain a JSON-LD block
copy dist/basil-flowers.svg (/library/basil-flowers.svg) ← basil-flowers.svg
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
copy dist/lettuce-head.svg (/library/lettuce-head.svg) ← lettuce-head.svg
write dist/notes/basil-saving-seeds/index.html (/library/notes/basil-saving-seeds/) ← notes/basil-saving-seeds.md + notes/_note.html
write dist/notes/growing-heirloom-tomatoes/index.html (/library/notes/growing-heirloom-tomatoes/) ← notes/growing-heirloom-tomatoes.md + notes/_note.html
write dist/notes/index.html (/library/notes/) ← notes/index.html + _layout.html
write dist/notes/lettuce-season/index.html (/library/notes/lettuce-season/) ← notes/notes/lettuce-season.md + notes/_note.html
copy dist/seed-library.svg (/library/seed-library.svg) ← seed-library.svg
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
copy dist/style.css (/library/style.css) ← style.css
copy dist/tomato-plant.svg (/library/tomato-plant.svg) ← tomato-plant.svg
write dist/visit/index.html (/library/visit/) ← visit.html + _layout.html
would publish 13 files to dist/
```

## Audit Check

```
./unify audit --base-url https://fernway.example/library/
```

Output:
```
audit: nothing to report
```

## Site Structure

The site includes:

- **Home page** (`/`) — Introduction to Fernway Seed Library with information about the organization and how seed lending works
- **Visit page** (`/visit/`) — Location, hours, and instructions for borrowing and returning seeds
- **Notes section** (`/notes/`) — Index of growing notes written by volunteer gardeners
- **Three blog posts** with complete metadata for search engines and social media:
  1. "Growing Heirloom Tomatoes: A Beginner's Guide" by Sarah Chen (2026-08-15)
  2. "Basil: One of the Easiest Seeds to Save" by Marcus Rodriguez (2026-08-08)
  3. "Cool-Season Greens: Planning for Fall Lettuce" by Elena Kowalski (2026-07-31)

All pages include:
- Shared header with navigation and seed library logo
- Shared footer with copyright
- Responsive design with mobile support
- SEO metadata and Open Graph tags for social sharing
- BlogPosting schema for blog posts to enable search engine indexing
- SVG placeholder images (no external assets)

## Reflection on Documentation

### What rules.md did not answer clearly:

The sentence "a page writes only its own name (`<title>About</title>`); the join adds the space, giving `About — My Site`" did not initially clarify that the layout's title needs to include the separator (`—`) and that pages should only provide their own short title. This became clear only after encountering the audit findings that flagged title-H1 mismatches.

### What needed re-reading:

The section on includes and slots required re-reading because the distinction between filling a named slot with `slot=` attributes versus replacing the default bare `<slot></slot>` is subtle. The phrase "an unfilled slot showing its own fallback" initially suggested fallback content appears when no content is provided, but the actual behavior is more nuanced around how direct children vs. nested elements interact with slots.

### What was guessed or inferred rather than read:

1. **Date format requirement**: The rules mention dates in the frontmatter but don't explicitly state that feed generation requires ISO 8601 format with time zones. This was discovered through the audit tool's output.

2. **Markdown H1 handling**: The rules state "headings get slug `id`s" but don't explicitly say that markdown pages don't automatically emit an `<h1>` based on the title frontmatter. This had to be inferred from the audit tool reporting missing H1 tags.

3. **Image dimension requirement for social sharing**: The need for `og:image:width` and `og:image:height` was learned from the audit tool, not from rules.md.

4. **Unify's structured data generation**: The phrase "write your own `<script type="application/ld+json">` for any other type" implies that unify generates JSON-LD when `schema:` is declared, but this behavior wasn't explicitly stated in rules.md.

## Build Result

✓ Build successful with no errors
✓ All audit checks pass
✓ Feed generated (Atom XML with BlogPosting entries)
✓ Sitemap generated
✓ Pretty URLs enabled (no .html extensions in public paths)
✓ Base URL correctly applied to absolute paths and social metadata
