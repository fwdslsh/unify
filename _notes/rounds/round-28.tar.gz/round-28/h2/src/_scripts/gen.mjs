#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const srcDir = path.join(__dirname, '..');
const notesDir = path.join(srcDir, 'notes');

// Read all markdown files in the notes directory
const files = fs.readdirSync(notesDir).filter(file => file.endsWith('.md'));

// Extract metadata from each file
const posts = files.map(file => {
  const content = fs.readFileSync(path.join(notesDir, file), 'utf8');
  const match = content.match(/^---\n([\s\S]*?)\n---/);

  if (!match) {
    console.error(`No frontmatter in ${file}`);
    return null;
  }

  const frontmatter = match[1];
  const metadata = {};

  // Parse simple YAML frontmatter
  const lines = frontmatter.split('\n');
  for (const line of lines) {
    const [key, ...valueParts] = line.split(':');
    if (key && valueParts.length > 0) {
      let value = valueParts.join(':').trim();
      // Remove quotes if present
      if ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      metadata[key.trim()] = value;
    }
  }

  // Use the markdown filename (without .md) as the URL
  const slug = file.replace('.md', '');
  const url = `/notes/${slug}.html`;

  return {
    title: metadata.title || 'Untitled',
    date: metadata.date || '',
    author: metadata.author || 'Anonymous',
    description: metadata.description || '',
    url: url,
    dateObj: new Date(metadata.date || '2000-01-01')
  };
}).filter(Boolean);

// Sort by date, newest first
posts.sort((a, b) => b.dateObj - a.dateObj);

// Generate the index HTML
const indexContent = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Growing Notes</title>
  <meta name="description" content="Growing notes and seed-saving tips from Fernway Seed Library volunteers.">
  <meta name="og:title" content="Notes — Fernway Seed Library">
  <meta name="og:description" content="Growing notes and seed-saving tips from Fernway Seed Library volunteers.">
  <meta name="og:image" content="/seed-library.svg">
  <schema>WebPage</schema>
</head>
<body>
  <h1>Growing Notes</h1>
  <p>Stories and tips from our volunteer growers. Each season brings new lessons and discoveries.</p>

  <ul class="notes-list">
${posts.map(post => `    <li>
      <a href="${post.url}" class="note-card">
        <div class="note-title">${post.title}</div>
        <div class="note-meta">${post.date} • by ${post.author}</div>
        <div class="note-description">${post.description}</div>
      </a>
    </li>`).join('\n')}
  </ul>
</body>
</html>`;

// Write the index file
fs.writeFileSync(path.join(notesDir, 'index.html'), indexContent);
console.log('Generated notes/index.html with', posts.length, 'posts');
