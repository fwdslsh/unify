---
title: "Cool-Season Greens: Planning for Fall Lettuce"
layout: /notes/_note.html
date: 2026-07-31T09:00:00Z
author: Elena Kowalski
description: "August is the time to think about fall lettuce. Learn which varieties to plant now for a harvest before frost and how to extend your growing season."
og:image: /lettuce-head.svg
og:image:width: 400
og:image:height: 400
schema: BlogPosting
---

# Cool-Season Greens: Planning for Fall Lettuce

While summer heat peaks, many gardeners are already thinking ahead to fall. August is the time to start fall lettuce—and from our seed library, you'll find varieties bred for quick maturity and cool-season flavor.

## Why Fall Lettuce is Special

Lettuce planted in late summer thrives in cooling temperatures and shorter days. Fall lettuce is sweeter than spring lettuce, less prone to bolting, and often more tender. Plus, many home gardeners skip fall planting, so you'll have fewer pests and healthier plants.

## Quick-Maturing Varieties

For a fall harvest before hard frost, you need varieties that mature in 45–60 days. Our library has several:

- **'Buttercrunch'**: Tender butterhead, matures in 60 days, excellent flavor
- **'Oakleaf'**: Beautiful loose-leaf, fast growing, handles cold well
- **'Tatsoi'**: Asian mustard green, 45 days, nutty flavor and gorgeous texture
- **'Arugula'**: Not quite lettuce, but perfect for fall cool-season planting

## Timing Your Planting

Count backward from your average first frost date. In our zone, that's mid-October. A 60-day lettuce planted August 15th will mature around mid-October—perfect timing.

You can succession-plant every two weeks through August if you have space. Each planting extends your harvest window.

## Direct Sow or Transplant

I direct-sow lettuce seeds right into garden beds. The soil is still warm enough for quick germination, and the seedlings will establish roots before cold weather arrives.

Space seeds 6 inches apart. No need to start indoors for fall lettuce; direct seeding is faster and less fussy.

## Cool-Season Care

Unlike summer lettuce, fall lettuce needs minimal shade. In fact, extra sun helps plants mature before frost. Water deeply but less frequently—cool soil encourages slower, sweeter growth.

Mulch around plants once they're 3–4 inches tall. Straw keeps soil temperature moderate and holds moisture.

## Extending the Season

You can harvest well into November with row covers or a simple cold frame. Even after a frost, protected lettuce keeps growing. Some gardeners harvest until December in mild years.

## The Gift of Planning Ahead

Fall gardening is often quieter, more reflective than spring. It's a time to appreciate the year's work and plan next year's harvests. Start with lettuce—it's one of the most forgiving ways to extend your growing season.

---

*Elena Kowalski is a market gardener who supplies local restaurants with heirloom greens. She's been growing fall lettuce for fifteen years and loves the cooler weather growing season.*
