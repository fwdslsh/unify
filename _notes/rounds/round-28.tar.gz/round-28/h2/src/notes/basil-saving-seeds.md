---
title: "Basil: One of the Easiest Seeds to Save"
layout: /notes/_note.html
date: 2026-08-08T09:00:00Z
author: Marcus Rodriguez
description: "Basil seed saving is simple, forgiving, and rewarding. Learn when to let flowers go to seed and how to harvest dried seed heads."
og:image: /basil-flowers.svg
og:image:width: 400
og:image:height: 400
schema: BlogPosting
---

# Basil: One of the Easiest Seeds to Save

If you're new to seed saving, basil is your friend. Unlike many herbs, basil wants to flower, and when you let it, it rewards you with abundant seeds that are easy to harvest and store.

## When to Stop Harvesting

Growing basil for cooking means pinching off flower buds to extend leaf production. But to save seeds, let some flower buds open. I usually harvest leaves for about a month, then choose the strongest plant and let it flower freely.

## Watching the Flowers

Basil flowers are beautiful—delicate spires of small white, pink, or purple blooms depending on the variety. Bees love them. As flowers fade, seeds develop inside tiny calyxes. The key is timing your harvest for when seeds are mature but before they drop.

## Harvesting Seeds

Once the flowers have faded and dried, the seed head turns brown and papery. This usually happens 3–4 weeks after flowering stops. Cut the entire flower head and place it in a paper bag or over a sheet.

The seeds will fall naturally as the seed head dries further. Gently rub the dried heads over the bag if needed. You'll get surprising amounts of seed—often enough for dozens of plants next year.

## Cleaning & Storage

Basil seeds are fairly easy to separate from chaff. You can blow gently across your pile of seeds to let the lighter bits blow away, or pass them through a fine sieve.

Store dried seeds in an envelope in a cool, dark place. Basil seeds stay viable for 3–4 years with proper storage. Label your envelope with the variety and the date you harvested.

## A Simple First Seed

Starting with basil teaches you the satisfaction of seed saving without complicated techniques. Next season, try cilantro or dill—herbs are forgiving teachers.

---

*Marcus Rodriguez grows herbs and vegetables at Fernway Community Garden. He's been saving basil seeds for three years and experiments with different varieties each season.*
