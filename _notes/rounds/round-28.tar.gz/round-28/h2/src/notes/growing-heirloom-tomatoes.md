---
title: "Growing Heirloom Tomatoes: A Beginner's Guide"
layout: /notes/_note.html
date: 2026-08-15T09:00:00Z
author: Sarah Chen
description: "Learn how to grow heirloom tomatoes from seed, with tips on variety selection, planting, staking, and harvesting for maximum flavor."
og:image: /tomato-plant.svg
og:image:width: 400
og:image:height: 400
schema: BlogPosting
---

# Growing Heirloom Tomatoes: A Beginner's Guide

Heirloom tomatoes are a treasure for any gardener—they come in stunning colors, flavors range from sweet to tangy, and they're endlessly rewarding to grow from seed. This summer, I grew six varieties from our seed library, and each one surprised me.

## Choosing Your Varieties

Start with one or two varieties if you're new to seed saving. I recommend beginning with 'Brandywine' for its classic flavor or 'Sungold' for reliable production. If you're feeling adventurous, try 'Black Cherry' or 'Cherokee Purple'.

When you borrow seeds, ask about the plant's typical height (determinate vs. indeterminate) and days to maturity. That helps you plan your garden layout and know when to expect ripe fruit.

## Starting from Seed

Tomato seeds need warmth to germinate—aim for soil temperatures around 70°F. I start mine indoors 6–8 weeks before the last frost date, under grow lights. Keep the soil moist but not waterlogged.

Once seedlings develop their true leaves, thin them out or transplant to larger pots. Strong seedlings lead to healthy plants.

## Planting & Staking

Heirloom tomatoes love sun. Plant in a spot that gets at least 6–8 hours of direct sunlight daily. Space plants 24–36 inches apart, burying the stem up to the first true leaves—they'll develop roots along the buried stem.

Stake or cage your plants early, before they get heavy with fruit. A sturdy stake and soft ties work well, or use Florida weave method for rows. Indeterminate varieties (those that keep growing all season) need serious support.

## Feeding & Watering

Water deeply and consistently—tomatoes need about 1–2 inches per week. Irregular watering causes blossom-end rot and cracks. Water at the soil level to keep foliage dry.

Feed every 2–3 weeks with compost tea or balanced fertilizer once flowering begins. Too much nitrogen encourages foliage at the expense of fruit.

## Harvesting for Seed

If you're saving seeds this season, let a few perfectly ripe fruits mature fully on the plant. Harvest when they're at peak color and flavor—that's when seed viability is highest.

Seed tomatoes should ripen on the vine; don't pick early. When you bring them in to ferment and extract seeds, the flavor will be fully developed and the seeds will be viable for years.

## The Reward

Growing tomatoes from seed connects you to their journey—from seed to plant to fruit to seed again. Return your harvest to our library this fall, and next year, another gardener will grow the varieties you nurtured.

---

*Sarah Chen is a volunteer gardener at Fernway Seed Library. She's been growing vegetables from seed for five years and specializes in heirloom tomatoes.*
