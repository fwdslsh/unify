# Fernway Seed Library — Build Report

## Publish Command

```
./unify build --base-url https://fernway.example/library/
```

## Build Output (Dry-Run Strict)

```
serving from https://fernway.example/library/
structured data: 3 pages would gain a JSON-LD block
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/fall-harvest-storing-seeds.html (/library/notes/fall-harvest-storing-seeds.html) ← notes/fall-harvest-storing-seeds.md + _layout.html
copy dist/notes/harvest-card.svg (/library/notes/harvest-card.svg) ← notes/harvest-card.svg
copy dist/notes/heirloom-card.svg (/library/notes/heirloom-card.svg) ← notes/heirloom-card.svg
write dist/notes/index.html (/library/notes/) ← notes/index.html + _layout.html
copy dist/notes/seed-swap-card.svg (/library/notes/seed-swap-card.svg) ← notes/seed-swap-card.svg
write dist/notes/spring-seed-swap-recap.html (/library/notes/spring-seed-swap-recap.md + _layout.html
write dist/notes/starting-heirloom-varieties.html (/library/notes/starting-heirloom-varieties.html) ← notes/starting-heirloom-varieties.md + _layout.html
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit.html (/library/visit.html) ← visit.html + _layout.html
would publish 11 files to dist/
```

Command: `./unify build --dry-run --strict --base-url https://fernway.example/library/`

## Audit Output

```
audit: nothing to report
```

Command: `./unify audit --base-url https://fernway.example/library/`

## Reflection

### What did rules.md not answer — name the sentence you wanted

The rules explain how to write pages and layouts, but I wanted clearer guidance on: **"How do I know which URL attributes unify rewrites when I use --base-url?"** 

The rules state: "unify rewrites only HTML's own URL attributes (`href`, `src`) — a `url()` in CSS and a `fetch()`/`hx-get` address ship as written." This is clear, but examples of what gets rewritten in different contexts (meta tags, og:image, canonical) would have helped. I initially assumed og:image paths would be rewritten but had to test to confirm.

### What did you have to re-read, and why did it not land the first time?

I had to re-read the section on **"Files"** multiple times. Specifically: "Always link the real filename — `/about.html`, never `/about/`; a directory link (`/guides/`) resolves only if you wrote a `guides/index.html`. This stays true under `--pretty-urls`: you still write `/about.html`, and the build rewrites it to `/about/` in the output."

This confused me initially because I thought `--base-url` would affect how I write paths in the source. I wrote links as `/library/visit.html` before realizing that the `--base-url` is only for the published site's address, not for source-relative paths. The section is technically clear, but the distinction between source paths and published URLs could be emphasized more directly. "You always use source-relative paths; `--base-url` only affects the published site's URLs, never what you write in HTML."

### What did you guess at or infer rather than read?

1. **SVG for placeholder images**: The task said "write a small placeholder SVG wherever one is needed," but I had to infer that for `og:image` meta tags, I needed actual image files (SVGs) that would be copied to the dist/ folder. I guessed that the SVG files would need to match the og:image paths in the frontmatter.

2. **Frontmatter quoting for colons**: The rules mention quoting values with colons for Markdown frontmatter, but I initially wrote unquoted titles and only discovered the requirement when the build failed with a YAML error. The guidance is there, but it's easy to miss until you hit the error.

3. **Date format for feeds**: I initially used dates without times (`2026-04-15`) and had to guess that adding times and timezones (`2026-04-15T10:00:00Z`) would fix the feed inclusion. The rules say dates without times are "reported and left out rather than guessed at," which is clear, but seeing that they're just advisory (not errors) meant I had to decide whether to fix them based on inferred intent.

## Site Contents

The published site includes:

- **Home page** (`/library/`) — Introduction to the seed library, its mission, and how it works
- **Visit page** (`/library/visit.html`) — Location, hours, borrowing process, and seed-saving guidelines
- **Notes index** (`/library/notes/`) — Listing of all blog posts, newest first
- **Three dated posts** with author, description, and og:image metadata:
  - "Starting Heirloom Varieties This Season" (April 15, 2026)
  - "Spring Seed Swap Recap and Next Steps" (April 8, 2026)
  - "Fall Harvest: How to Dry and Store Your Seeds Properly" (March 22, 2026)
- **SVG images** for social media previews
- **Generated feeds** — `sitemap.xml` and `feed.xml` for search engines
- **Shared header and footer** on all pages with navigation

All pages pass unify audit with no errors or incomplete sections. The site is ready for publication.
