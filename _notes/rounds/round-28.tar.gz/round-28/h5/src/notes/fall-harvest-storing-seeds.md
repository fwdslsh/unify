---
title: "Fall Harvest: How to Dry and Store Your Seeds Properly"
description: "Complete instructions for harvesting, drying, and storing vegetable and flower seeds for maximum viability."
date: 2026-03-22T11:00:00Z
author: Sarah Williams
schema: BlogPosting
og:image: /notes/harvest-card.svg
og:image:width: 1200
og:image:height: 630
---

# Fall Harvest: How to Dry and Store Your Seeds Properly

As spring progresses toward summer and then fall, many of you will be thinking about harvest. Proper seed drying and storage are essential to maintaining seed viability—without them, your carefully grown seeds won't germinate next year. Here's what you need to know.

## Timing the Harvest

Different plants mature at different times, but the key indicator is **dryness**. Wait until:

- Seed pods turn brown and papery
- Beans rattle in their pods
- Flower heads droop and dry on the stem
- The seed inside feels hard when you press it

If rain threatens before seeds are fully dry, harvest early and finish drying indoors.

## Drying Methods

**Dry indoors in shallow containers:**
- Spread seeds in a single layer on a paper plate or cloth
- Place in a warm, dry, well-ventilated area away from direct sunlight
- Leave for 2-4 weeks until completely bone-dry (seeds should snap, not bend)

**The freezer test:**
- Place a few seeds in the freezer overnight
- If they crack when you bite or press them (don't really bite—just test), they're dry enough

## Storage Tips

Once completely dry, store seeds in:

- **Sealed envelopes or paper packets** (moisture-proof)
- **Cool location**: 50°F or below is ideal (a basement, root cellar, or garage works)
- **Dark space**: Avoid light, which degrades viability
- **Low humidity**: Use desiccant packets if your storage area is damp

Properly stored seeds can remain viable for 3-10 years, depending on the variety.

## Labeling

Always label with:
1. Plant variety name
2. Harvest date
3. Your name (optional, but nice for the person who borrows them next!)

See you in the fall with your harvest!
