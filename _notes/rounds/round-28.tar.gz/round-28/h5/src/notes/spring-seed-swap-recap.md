---
title: "Spring Seed Swap Recap and Next Steps"
description: "Reflections from our April community seed swap and what we learned about local growing preferences."
date: 2026-04-08T14:00:00Z
author: James Rodriguez
schema: BlogPosting
og:image: /notes/seed-swap-card.svg
og:image:width: 1200
og:image:height: 630
---

# Spring Seed Swap Recap and Next Steps

Our April seed swap was a huge success! More than 40 gardeners gathered to share seeds, stories, and growing tips. Here's what we learned and where we're headed.

## Highlights from the Swap

The energy was incredible. We saw:

- Over 200 different seed varieties shared
- Gardeners connecting across neighborhoods they'd never visited before
- Three children claiming their first gardening plots this year
- An impromptu workshop on seed storage led by Maria, one of our long-time members

## Most Requested Seeds

Based on the swap, it's clear what grows best in our region:

1. **Lettuce varieties**—especially 'Buttercrunch' and 'Lolla Rossa'
2. **Snap peas**—gardeners want quick, reliable harvests
3. **Zucchini**—because apparently everyone plants it, and nobody has enough people to give it to

The demand far exceeded our current stock of these varieties, so we're prioritizing seed donations in these categories.

## Next Steps

We're planning:

- **May 15th Starts Sale**: Pre-grown seedlings for those who missed seed-starting season
- **Monthly tips column**: We'll share one seed-saving technique each month in our notes
- **Growing guide library**: Physical copies available at the library for reference

Come by and tell us what you grew last year—your feedback shapes our collection!
