import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const notesDir = path.join(__dirname, '../notes');

// Parse YAML frontmatter
function parseFrontmatter(content) {
  const match = content.match(/^---\n([\s\S]*?)\n---\n/);
  if (!match) return null;

  const fm = {};
  const lines = match[1].split('\n');
  for (const line of lines) {
    const [key, ...valueParts] = line.split(':');
    if (key && valueParts.length > 0) {
      let value = valueParts.join(':').trim();
      // Remove quotes if present
      if ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      fm[key.trim()] = value;
    }
  }
  return fm;
}

// Read all post files
const postFiles = fs.readdirSync(notesDir)
  .filter(f => f.endsWith('.md') && f !== 'index.md')
  .sort()
  .reverse();

const posts = postFiles.map(file => {
  const content = fs.readFileSync(path.join(notesDir, file), 'utf8');
  const fm = parseFrontmatter(content);
  if (!fm) return null;

  const slug = file.replace('.md', '');
  return {
    title: fm.title,
    date: fm.date,
    description: fm.description,
    author: fm.author,
    slug: slug,
    url: `/library/notes/${slug}.html`
  };
}).filter(Boolean)
  // Sort by date, newest first
  .sort((a, b) => new Date(b.date) - new Date(a.date));

// Generate index content
let indexContent = `---
title: "Notes"
description: "Posts and updates from Fernway Seed Library volunteers"
---

# Notes

Volunteer growers share growing tips, seed-saving advice, and library updates.

`;

for (const post of posts) {
  const date = new Date(post.date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  indexContent += `## [${post.title}](${post.slug}.html)

*${date}* by ${post.author}

${post.description}

`;
}

// Write index file
fs.writeFileSync(path.join(notesDir, 'index.md'), indexContent);
console.log(`Generated index with ${posts.length} posts`);
