---
title: "Notes"
description: "Posts and updates from Fernway Seed Library volunteers"
---

# Notes

Volunteer growers share growing tips, seed-saving advice, and library updates.

## [Tomato Seed Saving: A Beginner's Guide](2026-08-15-tomato-saving.html)

*August 15, 2026* by Maria Chen

Learn how to save seeds from your favorite tomato varieties. It's easier than you think!

## [When Basil Gets Out of Hand: Seed Saving Tips](2026-07-22-basil-abundance.html)

*July 22, 2026* by James Rodriguez

Basil is prolific—here's how to manage it and save seeds for next year.

## [June Update: New Varieties and Growing Strong](2026-06-10-spring-update.html)

*June 10, 2026* by Sarah Williams

A mid-season update on how our borrowers are growing, and new varieties joining the library this fall.

