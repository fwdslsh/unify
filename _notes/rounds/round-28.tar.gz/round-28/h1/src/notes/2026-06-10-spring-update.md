---
title: "June Update: New Varieties and Growing Strong"
date: 2026-06-10T09:00:00Z
author: "Sarah Williams"
description: "A mid-season update on how our borrowers are growing, and new varieties joining the library this fall."
og:image: /seed-card.svg
og:image:width: 1200
og:image:height: 630
og:title: "June Update: New Varieties and Growing Strong"
og:description: "A mid-season update on our seed library's progress this season."
schema: BlogPosting
---

# June Update: New Varieties and Growing Strong

Three months into the growing season, and we're seeing wonderful things in the gardens of our borrowers. Here's what's happening at Fernway Seed Library.

## The Crops Are Thriving

Reports from our members show healthy plants across the board. Early spring borrowers are already seeing first harvests of leafy greens, and their tomato, pepper, and bean transplants are growing strong. One member shared a photo of her Armenian cucumber running up a trellis—it's a vigorous grower!

## Seed Saves Already Underway

Some borrowers are already thinking ahead. We've had inquiries about mid-season seed saving for bolting lettuce varieties and early-maturing peas. The library is a place for learning, so we're helping them document what works and what doesn't.

## New Arrivals Coming Soon

This summer, we've received seed donations from three new growers in the region. Come fall, the library will have several new varieties to offer:
- A heat-loving eggplant from a local farm
- An heirloom carrot blend in three colors
- A productive snap pea that matures reliably in our climate

## Mark Your Calendar

Seed return begins in August. If you borrowed from us in spring, start thinking about which seeds you want to save. Questions? Email us or stop by a Saturday open hour.

Growing together!
