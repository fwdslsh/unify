# Fernway Seed Library Website - Build Report

## Publish Command

```bash
./unify build --base-url https://fernway.example/library/
```

## Final Checks

### Audit Check
All checks passed with no findings:

```bash
$ ./unify audit --base-url https://fernway.example/library/
audit: nothing to report
```

### Dry-Run Strict Check
All structural checks and validation passed:

```bash
$ ./unify build --dry-run --strict --base-url https://fernway.example/library/
serving from https://fernway.example/library/
structured data: 3 pages would gain a JSON-LD block
copy dist/card.svg (/library/card.svg) ← card.svg
write dist/feed.xml (/library/feed.xml) ← generated (--base-url)
write dist/index.html (/library/) ← index.html + _layout.html
write dist/notes/first-season-reflections.html (/library/notes/first-season-reflections.html) ← notes/first-season-reflections.md + _layout.html
write dist/notes/growing-heirloom-tomatoes.html (/library/notes/growing-heirloom-tomatoes.html) ← notes/growing-heirloom-tomatoes.md + _layout.html
write dist/notes/index.html (/library/notes/) ← notes/index.html + _layout.html
write dist/notes/preserving-biodiversity.html (/library/notes/preserving-biodiversity.html) ← notes/preserving-biodiversity.md + _layout.html
write dist/sitemap.xml (/library/sitemap.xml) ← generated (--base-url)
write dist/visit.html (/library/visit.html) ← visit.html + _layout.html
would publish 9 files to dist/
```

## Site Structure

The completed website includes:

- **Home page** (`/`) - Introduction to Fernway Seed Library
- **Visit page** (`/visit.html`) - Location, hours, borrowing information, and volunteer opportunities
- **Notes section** (`/notes/index.html`) - Index of community posts
  - 3 dated blog posts in Markdown with authors:
    1. "Growing Heirloom Tomatoes from Library Seeds" (Aug 20, 2026, Sarah Chen)
    2. "Preserving Biodiversity Through Seed Saving" (Jul 15, 2026, Marcus Rodriguez)
    3. "Reflections on Our First Season" (Jun 10, 2026, Elena Vasquez)
- **Card image** (`/card.svg`) - Social media preview image
- **Sitemap** (`/sitemap.xml`) - Auto-generated site map
- **Feed** (`/feed.xml`) - Atom feed of blog posts

All pages include:
- Shared header with Fernway Seed Library branding and navigation
- Shared footer with copyright and contact information
- Semantic HTML with proper title, description, and schema tags
- Open Graph metadata for social media sharing with proper image dimensions
- JSON-LD structured data for search engines

## Reflection Questions

### What did `rules.md` not answer?
The document did not explicitly explain how to handle conflicting `og:` metadata keys with colons in their names (like `og:image:width`). The rule mentions "a colon inside a name is not nesting" but the exact syntax for declaring these in YAML frontmatter could have been clearer with an example showing multiple `:` characters in one key name.

### What did you have to re-read, and why didn't it land the first time?
I had to re-read the section on page addresses and linking. Initially, I missed that in the source code you "always link the real filename — `/about.html`, never `/about/`" even though the build output uses pretty URLs. The distinction between what you write in source and what the build produces wasn't immediately clear. Re-reading clarified that `--pretty-urls` is an output transformation, not a source-level concern.

### What did you guess at or infer rather than read?
I inferred that the notes posts should be in Markdown files rather than HTML files based on the phrase "written by volunteers who do not write HTML" — I should have found that explicitly stated elsewhere in TASK.md where it says "at least **three dated posts** in Markdown."
