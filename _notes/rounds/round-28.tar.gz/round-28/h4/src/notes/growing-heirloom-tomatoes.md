---
title: Growing Heirloom Tomatoes from Library Seeds
date: 2026-08-20T09:00:00Z
author: Sarah Chen
description: Tips and techniques for successfully growing and saving seeds from heirloom tomato varieties.
schema: BlogPosting
og:image: /card.svg
og:image:width: 1200
og:image:height: 630
---

# Growing Heirloom Tomatoes from Library Seeds

Heirloom tomatoes are some of the most rewarding plants to grow and save seeds from. This season, I borrowed three varieties from Fernway Seed Library and wanted to share what I learned.

## Starting Strong

The seeds from the library came well-prepared and clearly labeled. I started mine indoors in late February, about 6-8 weeks before our last frost date. Tomato seeds germinate best at 70-75°F and prefer consistent moisture without being waterlogged.

## Growing in the Garden

Once the seedlings had two sets of true leaves, I hardened them off gradually over a week. I transplanted them into the garden after the last frost date, spacing them 2-3 feet apart in full sun.

The key to healthy plants:
- Water deeply and consistently, especially during fruiting season
- Prune suckers on indeterminate varieties to encourage fruit production
- Provide sturdy stakes or cages for support
- Pinch off the growing tip 4-6 weeks before first frost to direct energy to ripening

## Saving Seeds

The best part about heirloom tomatoes is saving seeds for next year. Here's my process:

1. **Select the best fruits** from healthy plants
2. **Scoop out the seeds and gel** into a jar
3. **Ferment for 2-3 days** to break down the gel (stir daily)
4. **Rinse thoroughly** until seeds are clean
5. **Dry completely** on a paper plate for 3-4 weeks
6. **Store in a cool, dry place** in a paper envelope

## Returning to the Library

I'm excited to return fresh seeds from my harvest to Fernway Seed Library. This cycle of borrowing, growing, and sharing is what makes our community stronger.

If you're interested in trying heirloom tomatoes this year, I highly recommend visiting the library to see what varieties are available!
