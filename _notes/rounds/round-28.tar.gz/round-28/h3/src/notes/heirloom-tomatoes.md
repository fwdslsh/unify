---
title: Growing Heirloom Tomatoes This Season
date: 2026-08-15T09:00:00Z
author: Sarah Chen
description: Tips for selecting and growing heirloom tomato varieties from our collection.
schema: BlogPosting
og:image: /og-image.svg
og:image:width: 1200
og:image:height: 630
---

# Growing Heirloom Tomatoes This Season

Heirloom tomatoes are the pride of any seed library collection. Their diverse colors, flavors, and growing characteristics make them worth the extra attention they deserve.

## Choosing Your Varieties

This year, we've expanded our heirloom collection to include some exciting varieties:

- **Brandywine** – Rich, complex flavor; needs support
- **Cherokee Purple** – Deep color, sweet-tart taste
- **Black Cherry** – Sweet, small fruits; great for snacking
- **Green Zebra** – Striped when ripe; tangy flavor

Each variety has unique requirements, so reading our growing guides is worth your time.

## Starting Strong

Heirloom tomatoes benefit from a long growing season. If you're starting from seed indoors, begin 6-8 weeks before your last frost date. Use seed-starting mix and keep the soil consistently moist until germination.

The seedlings are ready to transplant when they have two true leaves. A gentle fan and good air circulation will help prevent damping off.

## In the Garden

Heirloom tomatoes are heavier feeders than modern hybrids. Work compost into your planting holes and consider adding a balanced fertilizer when planting. As they grow, support is essential – these varieties can reach 6+ feet tall.

Water deeply and consistently. Uneven watering leads to blossom end rot and cracked fruit. Mulch around plants to conserve moisture and regulate soil temperature.

## Saving Seed

The beauty of heirlooms is that they breed true. To save seed:

1. Let your best fruits fully ripen on the plant
2. Scoop out seeds and pulp into a container
3. Ferment for 2-3 days (it's a bit smelly, but necessary!)
4. Rinse seeds thoroughly and dry on a plate
5. Store in a cool, dry place until spring

Return your seeds to us in October, and next year's gardeners will benefit from your best-performing plants.

**Happy growing!**
