---
title: Fall Planting Guide for Cool Season Crops
date: 2026-06-30T09:00:00Z
author: Elena Rodriguez
description: Plant cool-season vegetables this fall for a second harvest and excellent seed production.
schema: BlogPosting
og:image: /og-image.svg
og:image:width: 1200
og:image:height: 630
---

# Fall Planting Guide for Cool Season Crops

While summer gardeners are winding down, it's time to plan your fall garden. Cool-season crops produce better seeds and often taste sweeter after a light frost.

## Why Fall Gardening?

Fall gardens have several advantages:

- **Fewer pests** – Many insects are disappearing as temperatures drop
- **Less water** – Cooler weather means less evaporation
- **Better seed quality** – Cool temperatures favor seed production in many crops
- **Extended harvest** – Fresh greens and roots through early winter

## Planting Timeline

Successful fall gardening means planning backward from your first frost date. Check your local date, then count back:

### Direct Sow Now (Early July)
- Spinach (40-50 days)
- Arugula (40 days)
- Beans (50-60 days)
- Beets (50-70 days)

### Plant Mid-July
- Lettuce and other greens (30-45 days)
- Radishes (25-30 days)
- Carrots (60-80 days)

### Plant Late July to Early August
- Broccoli and cabbage transplants (40-60 days from transplant)
- Kale (50-70 days)

## Soil Preparation

Fall gardens benefit from summer's stored nutrients. However, intensive summer gardening may have depleted your soil. Work in compost or aged manure a few weeks before planting.

Mulching is especially important in fall gardens. A 2-3 inch layer conserves moisture during dry spells and protects plants from early frosts.

## Saving Fall-Grown Seeds

Many cool-season crops go to seed if left unpicked:

- **Spinach** – Let a few plants flower and mature seed heads
- **Arugula** – Will bolt and produce abundant seed
- **Carrots** – Need two seasons but can overwinter in mild climates
- **Brassicas** – Kale and cabbage seed production often requires overwintering

Your fall harvest will flower in spring, providing stunning blooms and excellent seed returns.

## Tips for Success

- Keep seedlings moist until established
- Thin seedlings to proper spacing early
- Provide shade cloth for early plantings if heat spikes
- Harvest outer leaves of greens to encourage continued production

By fall, you'll be harvesting fresh vegetables and planning next year's seed donations. Nothing tastes better than food you've grown twice over!
