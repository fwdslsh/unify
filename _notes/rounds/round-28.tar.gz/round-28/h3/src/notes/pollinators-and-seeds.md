---
title: Pollinators and Seed Production
date: 2026-07-22T09:00:00Z
author: Marcus Williams
description: How to attract and support pollinators in your garden for better seed production.
schema: BlogPosting
og:image: /og-image.svg
og:image:width: 1200
og:image:height: 630
---

# Pollinators and Seed Production

Want better seeds to return to the library? A healthy population of pollinators is your secret weapon. Here's what you need to know about supporting them in your garden.

## Who Does the Work?

While we think of bees, many creatures pollinate flowers:

- **Honeybees** – The hard workers, present mid-morning through afternoon
- **Native bees** – Bumblebees, mason bees, carpenter bees; often more efficient
- **Butterflies and moths** – Especially important for evening-blooming flowers
- **Hoverflies and other insects** – Often overlooked but essential

Each pollinator has preferences for flower shapes, colors, and times of day. A diverse garden attracts all of them.

## Creating Pollinator Habitat

### Flowers Everywhere

Pollinators need nectar and pollen year-round. Plant a succession of flowers:

- Spring: crocuses, hellebores, early bulbs
- Summer: zinnias, cosmos, borage, sunflowers
- Fall: asters, sedum, goldenrod

Many of these can be saved for seed at the library next season!

### Water and Shelter

Shallow water sources (a saucer with pebbles) help tired bees. Leave some areas unmulched and undisturbed for ground-nesting bees. Dead wood provides homes for carpenter bees.

### No Pesticides

This is non-negotiable. Chemical pesticides kill pollinators. Even organic options can harm beneficial insects. Focus on healthy soil and plant diversity instead.

## Protecting Your Seeds

If you're saving seeds from vegetables or flowers, you need pollinators. Plant bee-friendly flowers nearby to attract them. Let some of your best plants go to seed – distance them from related varieties to prevent cross-pollination if you're growing multiple types.

Squash and cucumbers need pollinators for every fruit. Plant borage or calendula nearby to guarantee good pollinator activity.

## A Note on Bees

Native bees are declining. By providing habitat and avoiding pesticides, you're helping restore their populations. It's good for your garden, good for the food system, and good for the planet.

Start small with a few pollinator-friendly flowers. Your garden will thank you – and so will next year's gardeners when you return premium seeds.
