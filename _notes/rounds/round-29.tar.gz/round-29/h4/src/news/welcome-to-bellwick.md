---
title: "Welcome to Bellwick Repair Collective"
date: 2026-08-20T09:00:00Z
author: "Sarah Chen"
description: "Join our community workshop dedicated to fixing household items and keeping things out of landfills."
schema: BlogPosting
og:image: data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1200 630'%3E%3Crect fill='%23ff6b35' width='1200' height='630'/%3E%3Ctext x='600' y='315' font-size='72' font-weight='bold' fill='white' text-anchor='middle' dominant-baseline='middle'%3EBellwick Repair Collective%3C/text%3E%3Ctext x='600' y='400' font-size='32' fill='white' text-anchor='middle'%3EFix More. Waste Less.%3C/text%3E%3C/svg%3E
og:image:width: 1200
og:image:height: 630
---

We're thrilled to launch Bellwick Repair Collective, a volunteer-run workshop dedicated to fixing household items instead of letting them end up in landfills. Whether you have a broken toaster, a pair of jeans that need mending, or a vintage lamp that just needs a new bulb, we're here to help.

Our mission is simple: extend the life of the things we own, reduce waste, and build community around the skill of repair. Every item we fix is a victory against throwaway culture.

## What Started Us

For years, community members in Bellwick have watched perfectly good items get discarded when they could be repaired. We decided to do something about it. With donated tools, expert volunteers, and a shared space, we're creating a hub where repair skills are valued and waste is minimized.

## Join Us

Visit our workshop at 482 Riverside Avenue during our opening hours. Bring your broken items, your curiosity, and a willingness to learn. Repairs are free, and donations help us stock supplies and tools.

See you soon at the workshop!
