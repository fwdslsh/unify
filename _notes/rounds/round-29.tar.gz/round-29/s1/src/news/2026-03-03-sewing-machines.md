---
title: "Sewing Machines: Our Most Requested Repair"
description: "Why more sewing machines come through our door than anything else, and the three faults that cause most of them."
date: 2026-03-03T09:00:00Z
author: Tomas Reyes
og:title: "Sewing Machines: Our Most Requested Repair"
og:description: "Why more sewing machines come through our door than anything else, and the three faults that cause most of them."
og:image: /assets/news/sewing-card.svg
og:image:width: 1200
og:image:height: 630
og:type: article
schema: Article
---

# Sewing Machines: Our Most Requested Repair

*Posted 3 March 2026 by Tomas Reyes*

If you've been to a Saturday session, you've probably seen a sewing
machine on our bench. They outnumber every other repair we do, by a wide
margin, and it's not close.

Almost all of them fail for one of three reasons. The tension disc has
gathered lint and no longer grips the thread evenly, so the stitching
puckers on one side. The bobbin case has a tiny burr, usually from a
snapped needle years earlier, and it's been shredding thread ever since.
Or the timing between the needle and the hook has drifted, often after
the machine was dropped or shipped badly, and it skips stitches no matter
how carefully you thread it.

None of these need a new machine. They need someone to open the base
plate, look closely, and be patient. We keep a box of retired sewing
machines specifically for spare tension discs and bobbin cases, because
sourcing them new for a forty-year-old model is often impossible.

Bring yours in on a Saturday. Bring the manual if you still have it, but
don't worry if you don't — most of us have seen your model before.
