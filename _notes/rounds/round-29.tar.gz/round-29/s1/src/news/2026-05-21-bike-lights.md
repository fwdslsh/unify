---
title: "Bike Lights Before the Clocks Change"
description: "A short guide to the bike light faults we see every spring, so you can fix yours before the evenings draw in."
date: 2026-05-21T09:00:00Z
author: Dana Whitfield
og:title: "Bike Lights Before the Clocks Change"
og:description: "A short guide to the bike light faults we see every spring, so you can fix yours before the evenings draw in."
og:image: /assets/news/bike-card.svg
og:image:width: 1200
og:image:height: 630
og:type: article
schema: Article
---

# Bike Lights Before the Clocks Change

*Posted 21 May 2026 by Dana Whitfield*

Every year around this time, people start bringing in bike lights that
"just stopped working over the winter." Almost none of them are actually
broken.

The most common fault is corrosion on the battery contacts — a light
left in a pannier through a wet winter will grow a thin green crust that
stops current flowing even though the battery and bulb are both fine. A
few minutes with fine sandpaper and it works again. The second most
common fault is a switch that has filled with grit; those usually just
need opening and cleaning, not replacing.

The one we can't fix on the spot is a cracked lens letting water into the
electronics permanently. If yours has gone properly rusty inside, we'll
tell you honestly and help you pick a sturdier replacement instead.

Bring your lights and a bike lock — we're right by the racks outside the
hall, and we'd rather test them on your actual bike than on the bench.
