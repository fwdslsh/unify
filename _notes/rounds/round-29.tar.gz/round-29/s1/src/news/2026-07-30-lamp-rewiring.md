---
title: "Rewiring Lamps Safely: A Volunteer's Guide"
description: "What we check before we ever plug an old lamp back in, and why we replace more cord than customers expect."
date: 2026-07-30T09:00:00Z
author: Priya Anand
og:title: "Rewiring Lamps Safely: A Volunteer's Guide"
og:description: "What we check before we ever plug an old lamp back in, and why we replace more cord than customers expect."
og:image: /assets/news/lamp-card.svg
og:image:width: 1200
og:image:height: 630
og:type: article
schema: Article
---

# Rewiring Lamps Safely: A Volunteer's Guide

*Posted 30 July 2026 by Priya Anand*

Lamps are deceptively simple and that's exactly why they're dangerous to
get wrong. Before we touch a switch or a bulb holder, every lamp that
comes through the door gets its cord checked end to end, because that's
where the real risk lives.

Cracked or brittle insulation is an automatic replacement, no exceptions
— we don't repair a cord, we replace the whole length. We also check that
the earth wire, if the lamp has one, is actually connected to the metal
body and not just coiled inside the base looking connected. A loose
earth is worse than no earth, because it looks safe.

Only once the wiring is sound do we move on to the part people usually
bring the lamp in for — a switch that clicks without doing anything, or a
socket that's gone loose. Those are the easy part.

If you're doing this at home yourself: unplug it, and if you're not
completely sure what you're looking at, bring it to us on a Tuesday
evening instead. This is the one category of repair where "probably
fine" isn't good enough.
