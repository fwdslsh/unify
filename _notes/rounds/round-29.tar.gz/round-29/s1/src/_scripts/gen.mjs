// Generates src/news/index.html by reading frontmatter out of src/news/*.md.
// Run before every build: node src/_scripts/gen.mjs && ./unify build ...
import { readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const newsDir = join(dirname(fileURLToPath(import.meta.url)), "..", "news");

function parseFrontmatter(text) {
  const match = text.match(/^---\n([\s\S]*?)\n---/);
  if (!match) return {};
  const data = {};
  for (const line of match[1].split("\n")) {
    const m = line.match(/^([A-Za-z][\w:-]*):\s*(.*)$/);
    if (!m) continue;
    let value = m[2].trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    data[m[1]] = value;
  }
  return data;
}

function escapeHtml(s) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

const posts = readdirSync(newsDir)
  .filter((name) => name.endsWith(".md"))
  .map((name) => {
    const raw = readFileSync(join(newsDir, name), "utf8");
    const fm = parseFrontmatter(raw);
    return {
      href: "/news/" + name.replace(/\.md$/, ".html"),
      title: fm.title ?? name,
      description: fm.description ?? "",
      date: fm.date ?? "",
      author: fm.author ?? "",
    };
  })
  .filter((post) => post.date)
  .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));

const items = posts
  .map((post) => {
    const day = post.date.slice(0, 10);
    return `      <li>
        <time datetime="${escapeHtml(post.date)}">${escapeHtml(day)}</time>
        <h2><a href="${escapeHtml(post.href)}">${escapeHtml(post.title)}</a></h2>
        <p>${escapeHtml(post.description)} <span class="byline">— ${escapeHtml(post.author)}</span></p>
      </li>`;
  })
  .join("\n");

const html = `<!doctype html>
<html lang="en" data-layout="/_layout.html">
<head>
  <meta charset="utf-8">
  <title>News from the workshop</title>
  <meta name="description" content="Repair stories and workshop updates from Bellwick Repair Collective volunteers.">
  <meta property="og:title" content="News — Bellwick Repair Collective">
  <meta property="og:description" content="Repair stories and workshop updates from Bellwick Repair Collective volunteers.">
  <meta property="og:image" content="/assets/home-card.svg">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:type" content="website">
  <link rel="alternate" type="application/atom+xml" title="Bellwick Repair Collective — News" href="/feed.xml">
</head>
<body class="news">
  <h1>News from the workshop</h1>
  <p class="lede">
    Stories from volunteers about what came through the door and what we
    learned fixing it. Newest first.
  </p>
  <p><a class="feed-link" href="/feed.xml">Subscribe with a feed reader (Atom)</a></p>
  <ul class="post-list">
${items}
  </ul>
</body>
</html>
`;

writeFileSync(join(newsDir, "index.html"), html);
console.log(`Wrote news/index.html with ${posts.length} posts.`);
