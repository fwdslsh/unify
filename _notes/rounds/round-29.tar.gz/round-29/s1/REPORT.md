# Report

## Publish command

```
node src/_scripts/gen.mjs && ./unify build --clean --pretty-urls --canonical auto --base-url https://bellwick.example/workshop/
```

The generator script must run first because `news/index.html` is a derived
file (the newest-first post list); `unify build` only ever sees what's
already on disk.

## How I verified it

- **Build succeeds for the real address.** `unify build --dry-run --strict`
  and then the real build above both exit 0. I inspected the emitted files
  under `dist/` directly (not guessed): every internal link, the stylesheet
  `href`, canonical links, and `og:image` URLs all came out prefixed with
  `/workshop/` and made absolute (`https://bellwick.example/workshop/...`),
  because they were generated from root-relative source paths plus
  `--base-url`. None end in `.html`, because of `--pretty-urls`.
- **Audit.** `unify audit --external --format human` with the *same* flags
  as the publish command reports `nothing to report`. Running audit without
  matching flags first gave false positives (missing `feed.xml`, since the
  feed is only generated under `--base-url`) — a reminder that audit has to
  mirror the publish invocation to mean anything.
- **Preview cards.** Read the built `<head>` of each of the four post pages
  directly: each has `og:title`, `og:description`, `og:image` (absolute,
  pointing at a real placeholder SVG under `/workshop/assets/news/…`),
  and `og:image:width`/`height`, at the page's own canonical URL.
- **Article data.** Each post declares `schema: Article` in frontmatter.
  I extracted the generated `<script type="application/ld+json">` block from
  each built post with a small Node snippet and ran it through `JSON.parse`
  — all four parse cleanly and contain `headline`, `description`, `url`,
  `image`, `author`, and `datePublished`, with no JSON hand-written by me.
- **Feed.** Built with `xmllint --noout dist/feed.xml` (well-formed) and
  parsed with Python's `xml.dom.minidom` to walk every `<entry>`: each has a
  `title`, a `link href` (the address), and an `updated`/`published`
  timestamp — the three things a feed reader needs. 4 entries, newest
  (2026-07-30) first.
- **No off-site loads.** Grepped every built file for `href="http`/`src="http`
  pointing anywhere but `bellwick.example` — none found.

## Before you finish

1. **What did rules.md not answer?** It never states whether a page's own
   `<title>` is compared to the merged (page + layout-suffix) title or to
   the page-only title when checking page quality — I only learned the
   comparison is against the *merged* title by running `unify audit` and
   reading its output (a title/h1 mismatch persisted until I made the
   page's own `<title>` match the `<h1>` verbatim, letting the merged title
   contain it as a prefix). There's no sentence describing what `audit`
   itself checks for beyond broken links, so I couldn't have predicted the
   `image-missing-dimensions`, `title-h1-mismatch`, and `h1-missing`
   findings from reading the docs alone.
2. **What did I have to re-read?** The slot-filling paragraph, twice — the
   distinction between "a bare `<header>`/`<footer>` does not replace the
   layout's" versus `slot="footer"` filling the layout's `<slot
   name="footer">` didn't land until I re-read it next to "where the layout
   wraps its slot in its own `<footer>`, write `<p slot="footer">`." I ended
   up not needing a footer override at all (the fallback footer was enough),
   which sidestepped the issue rather than resolving my confusion about it.
3. **What did I guess at or infer rather than read?** Two things: (a) that
   `date:` needs a time component to survive into the feed — rules.md says a
   time-less date "is reported and left out," so I inferred (didn't
   test-and-observe, since all my dates had times from the start) that a
   bare `2026-01-12` would have been silently dropped from `feed.xml`; I
   never actually saw that failure mode. (b) That social crawlers fall back
   to `<link rel="canonical">` for the shared URL when no `og:url` is set —
   rules.md never mentions `og:url` at all, so I inferred this is
   intentionally out of scope for the tool rather than an omission, based on
   the audit passing clean without it.
