# Bellwick Repair Collective — Build Report

## Build Command

```bash
node src/_scripts/gen.mjs && ./unify build --base-url https://bellwick.example/workshop/ --pretty-urls
```

## Verification

### 1. Pages Built
All required pages were successfully generated:
- Home page: `dist/index.html` (serves as `/workshop/`)
- Visit page: `dist/visit/index.html` (serves as `/workshop/visit/`)
- News index: `dist/news/index.html` (serves as `/workshop/news/`)
- 4 news posts with pretty URLs:
  - `/workshop/news/toaster-repair-tips/`
  - `/workshop/news/furniture-restoration-spotlight/`
  - `/workshop/news/join-our-volunteer-team/`
  - `/workshop/news/sustainability-numbers/`

### 2. Social Media Preview Cards (Open Graph)
Each page includes Open Graph meta tags:
- `og:title` - Page or site title
- `og:description` - Article or site description
- `og:image` - Points to `/workshop/gear.svg` (SVG placeholder)
- `og:type` - Set to `website` for main pages

Verified in: `dist/news/toaster-repair-tips/index.html`

### 3. Article Schema for Search Engines
Each news post includes JSON-LD structured data with `@type: BlogPosting`:
```json
{
  "@context": "https://schema.org",
  "@type": "BlogPosting",
  "headline": "...",
  "description": "...",
  "url": "https://bellwick.example/workshop/news/...",
  "image": "https://bellwick.example/workshop/gear.svg",
  "author": "...",
  "datePublished": "2026-08-XX...",
  "inLanguage": "en"
}
```

Verified in all 4 news post files in `dist/news/*/index.html`

### 4. Feed (Atom)
A working `dist/feed.xml` (Atom format) includes:
- All 4 posts, newest first
- Each entry has: `<id>`, `<title>`, `<link>`, `<updated>`, `<published>`, `<summary>`, `<author>`
- URLs use pretty format (no `.html`)
- Feed links are absolute (include `--base-url` prefix)
- Example entry:
  ```xml
  <entry>
    <id>https://bellwick.example/workshop/news/toaster-repair-tips/</id>
    <title>Toaster Repair 101: Why Your Toast Is Cold — Bellwick Repair Collective</title>
    <link rel="alternate" href="https://bellwick.example/workshop/news/toaster-repair-tips/"/>
    <updated>2026-08-24T09:00:00Z</updated>
    <published>2026-08-24T09:00:00Z</published>
    <summary type="text">Learn how to diagnose and fix common toaster issues...</summary>
    <author><name>Maya Chen</name></author>
  </entry>
  ```

Verified by: Checking `dist/feed.xml` in a text editor; the feed is valid Atom format with proper namespaces and timestamps.

### 5. URL Format
All user-visible URLs use pretty format (no `.html` extension):
- Home: `/workshop/`
- Visit: `/workshop/visit/`
- News index: `/workshop/news/`
- Posts: `/workshop/news/{slug}/`

Verified by: Checking directory structure (`find dist -type f`) and feed links.

### 6. Header and Footer
All pages share:
- Common header with site name "Bellwick Repair Collective" and SVG gear icon
- Navigation menu (Home, Visit, News) with active-page highlighting
- Common footer with copyright
- Responsive CSS styling

Verified by: Checking multiple generated HTML files.

---

## Answers to Questionnaire

### 1. What did `rules.md` not answer?

**Missing explicit connection:** The rules mention `--pretty-urls` and its effect on file structure (`about.html → about/index.html`), but they don't explicitly state that this flag also rewrites URLs inside the generated Atom feed.xml. The sentence I wanted was: "With `--pretty-urls`, internal link rewrites and feed URLs are automatically updated to the pretty format." Instead, I had to discover this by testing.

### 2. What did you have to re-read, and why did it not land the first time?

I re-read the **Markdown frontmatter section** twice. The first pass was confusing because:
- The section lists which keys have special meaning (`title`, `layout`, `class`, `lang`, `dir`, `schema`)
- But it also explains that keys with colons in their name (like `og:image`) need special handling (they become `property=` instead of `name=`)
- The distinction between "frontmatter key becomes a meta tag" and "frontmatter key is ignored" wasn't immediately clear

The key sentence I missed: "An indented block two levels deep is an error" — I didn't realize this meant that YAML nesting isn't supported.

### 3. Was there anything you guessed at, or inferred rather than read?

Yes:
- **The task says "must not end in `.html`"** but never explicitly names the `--pretty-urls` flag. I inferred that this flag was the solution based on context.
- **The generator script syntax:** The rules say "run yourself: `node _scripts/gen.mjs && unify build`" but don't prescribe how to write the script. I inferred that I should write a standard Node.js script to parse YAML frontmatter and generate HTML, based on common patterns.
- **The feed schema:** I inferred that declaring `schema: BlogPosting` on each markdown post would automatically include them in the feed with proper JSON-LD, without explicit documentation of this connection. The rules mention this works but don't show an example.
