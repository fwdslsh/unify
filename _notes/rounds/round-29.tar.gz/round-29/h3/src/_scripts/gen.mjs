import { readFileSync, writeFileSync } from 'fs';
import { readdirSync } from 'fs';
import { join } from 'path';

function parseFrontmatter(content) {
  const match = content.match(/^---\n([\s\S]*?)\n---\n/);
  if (!match) return { data: {}, content };

  const frontmatterText = match[1];
  const data = {};

  frontmatterText.split('\n').forEach(line => {
    const colonIdx = line.indexOf(':');
    if (colonIdx > -1) {
      const key = line.substring(0, colonIdx).trim();
      let value = line.substring(colonIdx + 1).trim();
      // Remove quotes if present
      if ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      data[key] = value;
    }
  });

  return { data, content: content.slice(match[0].length) };
}

const newsDir = 'src/news';
const files = readdirSync(newsDir)
  .filter(f => f.endsWith('.md'))
  .sort();

// Parse each post to extract metadata
const posts = files.map(file => {
  const content = readFileSync(join(newsDir, file), 'utf8');
  const parsed = parseFrontmatter(content);
  const slug = file.replace('.md', '');

  return {
    slug,
    title: parsed.data.title,
    date: parsed.data.date,
    author: parsed.data.author,
    description: parsed.data.description,
  };
}).sort((a, b) => new Date(b.date) - new Date(a.date)); // Newest first

// Generate the news index HTML
const indexHtml = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>News</title>
  <meta name="description" content="Latest news from Bellwick Repair Collective.">
  <meta property="og:title" content="Bellwick Repair Collective News">
  <meta property="og:description" content="Latest news from Bellwick Repair Collective.">
</head>
<body class="news">
  <h1>News from Bellwick Repair Collective</h1>

  <p>
    Stay up to date with the latest news, repair tips, and stories from our volunteer workshop.
  </p>

  <ul class="post-list">
${posts.map(post => {
  const date = new Date(post.date);
  const dateStr = date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return `    <li class="post-item">
      <a href="/news/${post.slug}.html">${post.title}</a>
      <div class="post-date">${dateStr} by ${post.author}</div>
      <div class="post-excerpt">${post.description}</div>
    </li>`;
}).join('\n')}
  </ul>
</body>
</html>`;

writeFileSync('src/news/index.html', indexHtml);
console.log(`Generated news index with ${posts.length} posts`);
