---
title: "Help Wanted: Join Our Volunteer Team"
date: 2026-08-18T14:30:00Z
author: Sarah Patel
description: "We're looking for volunteers with all skill levels. Learn what skills we need most and how to get started."
schema: BlogPosting
og:image: /gear.svg
---

The Bellwick Repair Collective has grown beyond our wildest expectations. More people are discovering that repair
is possible, and fewer items are heading to the landfill. But we need your help to keep up with demand.

## Who We're Looking For

We need volunteers at all skill levels. Here are the areas where we're actively recruiting:

### Sewing & Textiles

Can you sew a straight seam? Replace a zipper? Hem a pair of pants? Our textile volunteers are some of our busiest.
We have a dedicated sewing station and we're looking for people to teach and learn.

**Current need:** High (3–4 volunteers per week)

### Woodworking & Furniture

We have more furniture repairs than we can handle. If you can use a saw, sandpaper, and stain, we need you.
Experience with wood finishing is especially valuable.

**Current need:** Very high (we have a 2-week backlog)

### Electronics & Soldering

Some of our volunteers have deep electrical knowledge. Others are just learning. We need both. If you're comfortable
with a soldering iron or circuit boards, or if you'd like to learn, reach out.

**Current need:** High (always looking for fresh perspectives)

### General Repairs & Learning

You don't need to be an expert. Some of our best volunteers are here to learn as much as to teach. We'll pair you
with an experienced volunteer and you'll pick up skills as you go.

**Current need:** Always open (we can never have too many hands)

## How to Get Started

1. **Drop by during open hours** — Just show up to the workshop and talk to us. We'll give you a tour and answer questions.
2. **Email us** — Send your name and what skills you'd like to use (or learn) to `volunteers@bellwick.local`
3. **Commit what you can** — Whether it's one Saturday morning a month or every Tuesday evening, we'll work with your schedule.

## What We Provide

- Free training on any tools or techniques you want to learn
- A community of people who care about the same things you do
- The satisfaction of knowing you're keeping items out of the landfill
- Free coffee and snacks during volunteer shifts (thanks to our sponsors!)

---

We can't do this without you. See you at the workshop.
