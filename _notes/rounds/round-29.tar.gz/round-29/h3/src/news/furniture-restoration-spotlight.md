---
title: "Furniture Restoration: Breathing Life Into a 50-Year-Old Desk"
date: 2026-08-20T10:00:00Z
author: James Okafor
description: "Follow James as he restores a beautiful oak desk from the 1970s. See before and after photos and learn about the restoration process."
schema: BlogPosting
og:image: /gear.svg
---

Last month, a community member brought in a stunning but worn oak desk from the 1970s. The surface was scarred,
the finish was dull, and one drawer barely opened. Here's how we brought it back to life.

## Assessment

When James first examined the desk, he identified several issues:

- **Surface damage:** Deep scratches and water rings
- **Finish:** Old, cloudy varnish that had lost its luster
- **Hardware:** Corroded drawer pulls and a stuck drawer
- **Structure:** Solid wood throughout, no structural damage

The good news: this desk was worth restoring.

## The Process

### Step 1: Clean and Inspect

First, we cleaned away decades of dust and grime. This revealed the beautiful wood grain underneath. James
checked for woodworm or other damage—there was none.

### Step 2: Unstick the Drawer

A combination of gentle tapping and silicone lubricant freed the stuck drawer. Sometimes patience and the
right lubricant solve the problem.

### Step 3: Refinish the Surface

James carefully sanded the top surface with 120-grit paper, then 180-grit, to remove the old finish and
level out the deep scratches. The wood dust was rich with the desk's history.

### Step 4: New Finish

After a thorough cleaning and stain (a natural oak stain), we applied three coats of water-based polyurethane.
The desk went from dull to glossy—and safe for the next generation.

### Step 5: Hardware Refresh

We cleaned the original brass drawer pulls with vinegar and brass polish. They shined like new.

## The Result

The desk is stunning. The grain pattern—hidden for decades under that cloudy finish—is now the star of the piece.
It's ready for another 50 years of use.

---

**This is what we do at Bellwick Repair Collective.** Bring your furniture. We'll restore it.
