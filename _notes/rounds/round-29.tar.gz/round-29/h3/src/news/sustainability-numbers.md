---
title: "By The Numbers: Our Impact in Q3"
date: 2026-08-10T08:00:00Z
author: David Rodriguez
description: "A look at what the Bellwick Repair Collective accomplished in the third quarter—items saved, volunteer hours, and the environmental impact."
schema: BlogPosting
og:image: /gear.svg
---

We just wrapped up our busiest quarter yet. Here are the numbers that matter:

## Items Repaired

- **287 items** brought in by community members
- **264 successfully repaired** (92% success rate)
- **23 items** beyond repair, carefully recycled or donated for parts

## Categories

Our volunteers fixed:
- **78 textiles** (clothes, bags, furniture)
- **64 furniture** pieces (tables, chairs, dressers)
- **52 small appliances** (toasters, blenders, lights)
- **38 electronics** (radios, lamps, devices)
- **32 miscellaneous** items (tools, toys, kitchenware)

## Volunteer Impact

- **156 volunteer shifts** logged
- **468 total volunteer hours** contributed
- **23 active volunteers** (up from 18 in Q2)

## Environmental Impact

If each item that came through our workshop would have ended up in a landfill:

- **264 items** kept from the waste stream
- Estimated **2.1 metric tons** of material kept from landfill
- Estimated **15,000 kWh** of embodied energy preserved (the energy that went into manufacturing these items originally)

## The Real Story

These numbers represent something bigger than statistics. They represent 264 families who got to keep using their
favorite things. They represent volunteers who discovered they love fixing things. They represent a community that
said "no" to throwaway culture.

Thank you to every volunteer, every community member who brought their items, and every donor who supported our mission.

---

Q4 is already looking busy. See you at the workshop.
