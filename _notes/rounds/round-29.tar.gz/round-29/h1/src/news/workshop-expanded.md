---
title: Workshop Expanded - New Electronics Bay Opens
date: 2026-08-20T14:00:00Z
author: Sarah Chen
description: We've added a dedicated electronics repair station with new testing equipment.
schema: BlogPosting
og:image: /og-image.svg
og:image:width: 1200
og:image:height: 630
---

We're thrilled to announce the opening of our new **Electronics Bay**! Thanks to a generous donation from local tech enthusiasts and grant funding from the city, we've expanded our workshop with a dedicated space for electronics repair.

## What's New

The new electronics bay includes:

- **Workstations** with proper lighting and ventilation for safe soldering
- **Testing equipment** including multimeters, power supplies, and oscilloscopes
- **Component storage** with an organized inventory of common parts
- **Reference materials** including repair guides and schematic diagrams
- **Safety equipment** including fume extraction and proper ESD protection

## What We Can Now Repair

With the new equipment, we're expanding our services to include:

- **Laptop and desktop computer repairs** — from hardware upgrades to motherboard repairs
- **Phone screen replacements** — we now have the tools and parts for safe glass replacement
- **Power adapter repairs** — fixing chargers and power supplies
- **Console and gaming device repairs** — Nintendo, PlayStation, Xbox, and retro systems
- **Audio equipment** — headphones, speakers, and amplifiers

## Join Us for the Grand Opening

We're hosting an **open house on Saturday, August 24th** from 10 AM to 3 PM. Come see the new space, learn about electronics repair from our volunteers, and sign up for our new workshops.

First-time visitors get a 10% discount on repair services through the end of August!

---

*Sarah Chen is a volunteer electronics technician and co-founder of the Electronics Bay initiative.*
