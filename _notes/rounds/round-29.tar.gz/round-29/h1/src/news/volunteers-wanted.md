---
title: Summer Volunteers Wanted
date: 2026-07-15T10:00:00Z
author: Elena Rodriguez
description: Help us keep the workshop running this summer! We're looking for volunteers of all skill levels.
schema: BlogPosting
og:image: /og-image.svg
og:image:width: 1200
og:image:height: 630
---

Summer is here, and so is our busiest season! We're looking for **passionate volunteers** to help keep Bellwick Repair Collective running smoothly.

## Who We're Looking For

We need volunteers with all kinds of skills and experience levels:

- **Repair experts** — share your skills in electronics, furniture, appliances, or clothing
- **Workshop coordinators** — help organize tools, manage the schedule, and keep things running
- **Community ambassadors** — help new visitors feel welcome and guide them through repairs
- **Admin support** — help with scheduling, social media, and communications
- **Students** — learn valuable repair skills while helping others
- **Retired professionals** — your experience is invaluable to our mission

**No experience required!** We'll train you. Enthusiasm is the only requirement.

## What You'll Do

- Help visitors troubleshoot and repair their items
- Teach others how to fix things
- Maintain and organize the workshop
- Contribute your expertise to growing our services
- Be part of a community making a real environmental impact

## Time Commitment

Flexible! We have:
- **One-time shifts** (3 hours) — test it out
- **Weekly commitments** (2-4 hours per week) — become a regular
- **Project-based work** — join us for specific initiatives like the new Electronics Bay

Summer shifts are especially needed:
- **Tuesday–Thursday evenings** (5:00 PM – 8:00 PM)
- **Saturday mornings** (10:00 AM – 1:00 PM)

## Benefits of Volunteering

- Learn new skills and share your expertise
- Make a real environmental impact—every repair is waste diverted from landfills
- Join a community of creative, resourceful people
- Free access to all workshop tools and equipment
- Volunteer hours documented for college or employment applications
- Pizza at our monthly volunteer appreciation potlucks!

## Ready to Join?

**Email us:** volunteers@bellwick.local  
**Call us:** (215) 555-FIXIT  
**Visit us:** 742 Maple Street, Suite 3 (drop in anytime we're open!)

Let's keep Bellwick thriving this summer!

---

*Elena Rodriguez is the volunteer coordinator for Bellwick Repair Collective.*
