---
title: First Repair Milestone - 500 Items Fixed
date: 2026-06-01T12:00:00Z
author: James Mitchell
description: We've reached an amazing milestone with our community—500 items repaired in just 18 months!
schema: BlogPosting
og:image: /og-image.svg
og:image:width: 1200
og:image:height: 630
---

Today marks a special moment for Bellwick Repair Collective: **we've officially repaired our 500th item!**

## What This Means

It's hard to overstate what this milestone represents:

- **500 items** kept out of landfills
- **500 household essentials** given a new lease on life
- **Hundreds of people** who learned that repair is possible
- **A thriving community** committed to sustainability over consumption

Over 18 months, our small team of volunteers has built something remarkable—a workshop where people bring broken things and leave with solutions, skills, and connection.

## The Numbers

- **Average repair rate:** 27 items per month
- **Most common repairs:** Electronics (28%), Furniture (23%), Appliances (22%), Clothing (19%), Other (8%)
- **Success rate:** 94% of items are successfully repaired
- **Volunteer hours:** Over 2,000 hours donated by our amazing team
- **Items value:** If purchased new, all 500 items would have cost over $150,000

## A Few Favorites from Our 500

- A 1970s turntable that now spins again in someone's living room
- A wedding dress altered for a bride who found it secondhand
- A grandmother's sewing machine restored and handed down to her granddaughter
- Countless phones, laptops, toasters, and treasured items given a second life
- One very stubborn espresso machine that took three weeks but finally worked

## What's Next?

With this momentum, we're planning to:

- Expand our electronics repair capabilities (watch for announcements!)
- Launch specialized workshops in leather repair, bicycle maintenance, and more
- Reach more neighborhoods with mobile repair clinics
- Train the next generation of repair enthusiasts

None of this would be possible without our incredible volunteers, generous donors, and—most importantly—our community members who believe that repair is worth the effort.

## Thank You

To everyone who's brought something to us, volunteered your time, donated tools or materials, or simply told a friend about what we do: **thank you.** You're part of this movement.

Here's to the next 500!

---

*James Mitchell is the co-founder and director of Bellwick Repair Collective.*
