---
title: Community Clothes Mending Circle
date: 2026-08-10T14:00:00Z
author: Marcus Johnson
description: Join us for our monthly mending circle where we teach clothing repair basics.
schema: BlogPosting
og:image: /og-image.svg
og:image:width: 1200
og:image:height: 630
---

Have a favorite shirt with a small tear? Jeans with a broken zipper? Join our **Monthly Mending Circle** and learn how to give your clothes a second life!

## What is the Mending Circle?

Every second Saturday, we gather to repair our own clothes while teaching each other new skills. It's part workshop, part social hour, and entirely about keeping good clothes out of the landfill.

## When and Where

- **Date:** Second Saturday of every month
- **Time:** 2:00 PM – 5:00 PM
- **Location:** Bellwick Repair Collective, 742 Maple Street, Suite 3
- **Cost:** Free! (donations welcome)

## What to Bring

- Items you want to repair (clothes, bags, shoes—anything textile)
- Any thread, buttons, or patches you have
- Scissors or sewing supplies you prefer (we have extras to share)
- A friend! (this is more fun with company)

## Learn These Skills

- **Hand sewing basics** — stitches that will hold
- **Machine sewing** — we have sewing machines available
- **Zipper repair and replacement**
- **Button replacement** — it's easier than you think
- **Patching techniques** — invisible and visible repairs
- **Darning** — fixing holes in socks and sweaters

## Why Come?

- **Save money** — fixing costs a fraction of replacing
- **Learn a lifelong skill** — hand sewing never goes out of style
- **Sustainable fashion** — extend the life of what you love
- **Community** — meet people who care about the same things
- **No experience necessary** — we'll teach you everything

Our volunteers love sharing what they know, and there's no judgment—we've all got clothes that need fixing!

Next circle: **Saturday, August 24th at 2 PM**. See you there!

---

*Marcus Johnson is a professional seamstress and volunteer instructor at the Bellwick Repair Collective.*
