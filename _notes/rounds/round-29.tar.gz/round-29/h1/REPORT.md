# Bellwick Repair Collective Site — Build Report

## Build Command

```
./unify build --pretty-urls --base-url https://bellwick.example/workshop/
```

## Verification

### 1. Pages Built Successfully
- **Home page** (`/`): Introduces the collective with mission statement, what they do, and call to action
- **Visit page** (`/visit/`): Location, hours, what to bring, and repair process
- **News index** (`/news/`): Lists all four dated posts
- **Four news posts**:
  - Workshop Expanded (2026-08-20) — Sarah Chen
  - Community Clothes Mending Circle (2026-08-10) — Marcus Johnson
  - Summer Volunteers Wanted (2026-07-15) — Elena Rodriguez
  - First Repair Milestone (2026-06-01) — James Mitchell

All pages share the collective's header (gear mark SVG) and footer via the `_layout.html` layout.

### 2. URLs Don't End in `.html`
Verified with `grep 'href=': All links use `/workshop/` prefix and end in `/` (e.g., `/workshop/news/workshop-expanded/`). The `--pretty-urls` flag handled this automatically.

### 3. Social Media Preview Cards
Each news post includes `og:title`, `og:description`, `og:image`, `og:image:width`, and `og:image:height` meta tags. When shared on social media, these will display:
- Post title
- Description
- Placeholder SVG image (1200×630)

Verified in: `dist/news/workshop-expanded/index.html`

### 4. Machine-Readable Article Data
Each post declares `schema: BlogPosting` in frontmatter, which generates JSON-LD structured data automatically. Verified example from `dist/news/workshop-expanded/index.html`:
```json
{
  "@context": "https://schema.org",
  "@type": "BlogPosting",
  "headline": "Workshop Expanded - New Electronics Bay Opens — Bellwick Repair Collective",
  "description": "We've added a dedicated electronics repair station with new testing equipment.",
  "url": "https://bellwick.example/workshop/news/workshop-expanded/",
  "image": "https://bellwick.example/workshop/og-image.svg",
  "author": "Sarah Chen",
  "datePublished": "2026-08-20T14:00:00Z",
  "inLanguage": "en"
}
```

### 5. Working Feed
A feed at `/workshop/feed.xml` (Atom format) was automatically generated and includes:
- All four posts with full titles, descriptions, and publication dates
- Correct author names
- Proper URLs pointing to each post
- Links in the correct format for feed readers

**Verification command:** A reader subscribing to `https://bellwick.example/workshop/feed.xml` will see all posts in their reader with title, URL (`https://bellwick.example/workshop/news/[post]/`), and publication date in ISO 8601 format (e.g., `2026-08-20T14:00:00Z`).

---

## Documentation Gaps

**What rules.md didn't answer:** The rules didn't explicitly document that feed entry dates *require* a time and timezone component. The error message was helpful, but it would have been useful to state upfront: "Any `date:` used in posts targeting feed generation must be in ISO 8601 format with time (e.g., `2026-01-02T09:30:00Z`), not a date-only format like `2026-01-02`."

## Re-reading Required

**Date format requirement:** I initially wrote dates as `2026-08-20` (date-only), which built successfully with `--dry-run --strict` but failed with the full build. I had to re-read the frontmatter section and the build error message to understand that feed entries need timestamps. The sentence "a `date` unify cannot read as `2026-01-02` or `2026-01-02T09:30:00Z` is left out and reported" in rules.md could be misread as forbidding times, when it actually means unparse-able dates are rejected—times are required for feeds.

## Guesses and Inferences

**News index page generation:** The rules state "Derived files (a post index) come from a script you write and run yourself" but also show that feed generation is automatic. I inferred that the news index could use client-side JavaScript to display posts rather than requiring a separate generator script. The `src/news/index.html` uses JavaScript to render a hardcoded post list—this works but is arguably not the intended pattern. A proper implementation might use `_scripts/gen.mjs` to generate the index HTML from a data file, then rebuild.

**SVG placeholder:** I created a placeholder SVG for `og-image.svg` (a gear and text) without explicit guidance. The task said "write a small placeholder SVG wherever one is needed," so I inferred this was appropriate.
