# Build Report: Bellwick Repair Collective

## Exact Publish Command

```bash
./unify build --base-url https://bellwick.example/workshop/ --pretty-urls --canonical auto
```

## Verification Summary

### Pages & Structure
✅ Home page (`/workshop/`) — introduces the collective
✅ Visit page (`/workshop/visit/`) — location, hours, what to bring
✅ News index (`/workshop/news/`) — lists all 4 posts, newest first
✅ Four news posts — each in its own pretty URL directory without `.html`
✅ Shared header and footer — every page includes gear icon and navigation

### Social Media Preview Cards
✅ `og:title`, `og:description`, `og:image` present on all pages
✅ Images point to `/card.svg` (auto-prefixed to `/workshop/card.svg`)
✅ Canonical links auto-generated for correct social media crawling

### Article Metadata
✅ All news posts include `schema: BlogPosting` in frontmatter
✅ JSON-LD structured data auto-generated in `<script type="application/ld+json">`
✅ Each post includes: headline, description, url, image, author, datePublished, inLanguage

### Feed
✅ Atom feed at `/workshop/feed.xml` auto-generated
✅ Feed contains all 4 posts with: title, address (URL), publication date, author
✅ Posts ordered newest first (2026-08-20, 2026-08-13, 2026-08-06, 2026-07-30)

### URL Format
✅ Pretty URLs enabled — all URLs are directories without `.html`
✅ Home: `https://bellwick.example/workshop/`
✅ Visit: `https://bellwick.example/workshop/visit/`
✅ News index: `https://bellwick.example/workshop/news/`
✅ Post example: `https://bellwick.example/workshop/news/volunteer-spotlight/`

## Answers to Questions

### 1. What did rules.md not answer?

**Missing information:** The rules don't explain what file structure is created when using `--pretty-urls`. Specifically, it's not obvious that a page like `visit.html` becomes a directory `visit/` containing `index.html`. The sentence "the build rewrites it to `/about/` in the output" doesn't convey that this is a directory structure, not a rename of the file.

### 2. What did you have to re-read, and why?

**Section:** "Always link the real filename — `/about.html`, never `/about/`" (Files section)

**Why it didn't land the first time:** I initially thought this rule meant I should write source links as `/workshop/about.html`, including the subdirectory path from `--base-url`. Re-reading clarified that the rule is about linking to the actual source filename in the source tree root, not about the final published address. The `--base-url` parameter is separate from source-relative paths.

### 3. Was there anything you guessed at, or inferred rather than read?

**Yes — handling `--pretty-urls` with `og:url` meta tags:** The rules don't explain how hardcoded meta tags like `og:url` should work when `--pretty-urls` changes the final URL structure. I inferred (correctly, as it turned out) that:
- Hardcoded `og:url` values referencing `.html` URLs would fail validation
- Using `--canonical auto` would solve this by auto-generating correct canonical links

I did not find explicit guidance on this interaction in the rules. It was an educated guess based on understanding how static site builders typically handle such conflicts.
