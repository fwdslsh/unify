---
title: "Community Impact Report: 2026 Mid-Year"
description: "In the first half of 2026, we've repaired over 500 items, saved an estimated 8 tons from the landfill, and grown our volunteer base by 40%."
author: "Bellwick Repair Collective"
date: 2026-07-30T10:00:00Z
schema: BlogPosting
og:image: /card.svg
---

As we reach the midpoint of 2026, we wanted to share what has been accomplished through your participation and support at Bellwick Repair Collective. The numbers are inspiring.

## By the Numbers

**Items Repaired:** 517
- Small appliances: 124
- Electronics: 156
- Clothing & textiles: 118
- Furniture: 89
- Tools & equipment: 30

**Environmental Impact:**
- Estimated waste diverted: 8.2 tons
- Equivalent to the weight of 60 cars
- CO₂ saved (vs. manufacturing new items): ~45 metric tons

**Community Growth:**
- Active volunteers: 67 (up from 48 in 2025)
- New members joining: 143
- Volunteer hours contributed: 412

## What This Means

Every item repaired instead of replaced keeps something precious out of the waste stream. But the numbers don't capture the full story.

A mother brought in a toy box of sentimental items from her childhood. Our volunteers helped restore 14 pieces — a music box, a doll, a board game — that she'll now pass on to her daughter.

A young person learned electronics repair and has started a small business fixing computers for neighbors on weekends.

A retired electrician found purpose and community volunteering at the workshop, teaching others to troubleshoot and repair.

## What Happens Next

With your continued support, we're planning:
- **Electronics workshop series** (launching September)
- **Monthly specialty classes** in upholstery, small appliances, and more
- **A tool library** where members can borrow and share equipment
- **Expanded hours** to serve more of our community

## How You Can Help

- **Visit and participate** in our open repair sessions
- **Volunteer your skills** — we need people of all experience levels
- **Spread the word** about repair, reuse, and community
- **Donate tools or materials** if you have extras
- **Support us financially** — donations help us buy supplies and keep the space open

## Thank You

This mid-year milestone belongs to every person who has walked through our doors. Whether you brought something to fix, volunteered your time, or simply believed in the mission of repair, you made this possible.

Here's to the second half of 2026 — and to many more things fixed, restored, and given new life.

---

*Want to stay connected? Subscribe to our newsletter or follow us on social media for updates on classes, special events, and volunteer opportunities.*
