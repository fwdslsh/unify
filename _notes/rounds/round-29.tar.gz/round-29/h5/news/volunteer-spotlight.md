---
title: "Volunteer Spotlight: Maria's Sewing Skills"
description: "Meet Maria, one of our longtime volunteers who has been teaching members how to repair and restore clothing."
author: "Bellwick Repair Collective"
date: 2026-08-20T10:00:00Z
schema: BlogPosting
og:image: /card.svg
---

Maria has been a cornerstone of Bellwick Repair Collective since its early days, and her passion for textile repair is infectious. Whether you've stopped by the workshop on a Wednesday evening or Saturday afternoon, there's a good chance you've seen her hunched over a sewing machine, carefully mending a loved garment.

## From Hobby to Calling

Maria learned to sew from her grandmother decades ago. What started as a practical skill for keeping her own wardrobe intact has evolved into a mission: showing others that clothes worth keeping are worth fixing.

"So much of what ends up in the landfill could live another decade or two," Maria says, threading a needle with practiced precision. "All it needs is someone who believes it's worth saving."

## Teaching the Next Generation

At Bellwick, Maria leads informal workshops on basic mending, zipper replacement, and hemming. She's patient with beginners and generous with her fabric scraps. Members say her teaching style is warm and encouraging — she never makes you feel silly for not knowing how to sew a simple stitch.

This month alone, Maria has helped restore three vintage coats, five pairs of jeans, and countless sweaters with small holes or loose seams.

## What's Next

When asked what she'd like to focus on next, Maria lights up: "Upholstery. I'd love to teach people how to recover chairs and couches. The skills are similar to sewing, but the scale is bigger. It's so satisfying to breathe new life into a piece of furniture."

If you're interested in learning textile repair, stop by the workshop and look for Maria. She's always happy to help.
