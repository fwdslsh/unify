---
title: "New Electronics Repair Workshop Starting"
description: "We're launching a dedicated electronics repair workshop! If you've ever wanted to learn how to fix laptops, phones, or small appliances, this six-week series is for you."
author: "Bellwick Repair Collective"
date: 2026-08-06T10:00:00Z
schema: BlogPosting
og:image: /card.svg
---

We're excited to announce the launch of our **Electronics Repair Workshop Series**, starting September 1st. This hands-on six-week course is perfect for anyone curious about what's inside their devices and how to fix common problems.

## What You'll Learn

Week 1: **Basics & Safety**
- How electronics work: circuits, components, and power
- Safety protocols and tools
- Understanding schematics

Week 2: **Diagnosing Problems**
- How to identify hardware vs. software issues
- Testing tools and techniques
- Common failure patterns

Week 3: **Phone Repair Fundamentals**
- Screen replacement
- Battery replacement
- Button and speaker repair

Week 4: **Laptop Repair**
- Accessing internal components
- RAM and storage upgrades
- Thermal management and cooling

Week 5: **Appliances & Power Tools**
- Small appliance troubleshooting
- Motor repairs
- Cord and plug safety

Week 6: **Your Own Device**
- Bring something you actually want to fix
- Work with mentor guidance
- Troubleshoot real-world problems

## Details

- **When:** Wednesdays, 6:00 PM – 8:30 PM, starting September 1st
- **Where:** Bellwick Repair Collective, 245 Main Street
- **Cost:** Free for volunteers; $50 suggested donation for materials
- **Capacity:** 20 participants (register to hold your spot)
- **What to bring:** Your curiosity and a device you'd like to learn to fix

## Why Take This Workshop?

- Save money by repairing instead of replacing
- Build valuable skills you'll use for life
- Join a community of repair enthusiasts
- Help the environment by keeping electronics out of landfills
- Have fun while you learn

Registration is open now. Contact us through our website or stop by the workshop to sign up. Spaces are limited!

---

*Questions? Reach out to us at the workshop during open hours or email our volunteer coordinator.*
