# Build Report: Bellwick Repair Collective Website

## Build Command

```
./unify build --base-url https://bellwick.example/workshop/ --pretty-urls
```

## Verification

### Pages Built
The site was successfully built with all required pages:
- Home page (/)
- Visit page (/visit/)
- News index page (/news/)
- Four dated news posts in Markdown:
  - Successful Sewing Workshop Draws Crowd (2026-08-20)
  - New Electronics Repair Station Opens (2026-08-15)
  - Furniture Restoration Project Completed (2026-08-10)
  - August Volunteer Schedule Announced (2026-08-01)

### Social Media Preview Cards
Each page includes the necessary Open Graph meta tags for social media previews:
- `og:title` - Post/page title
- `og:description` - Summary for preview
- `og:image` - Placeholder SVG images (created as required, since no image files were available)

These tags are absolute URLs after the build because `--base-url` is provided, making them crawlable by social media platforms.

### Search Engine Article Data
Each news post includes machine-readable JSON-LD schema markup with `@type: BlogPosting` containing:
- headline (post title with site name)
- description (from frontmatter)
- url (absolute canonical URL)
- image (absolute og:image URL)
- author (from frontmatter author field)
- datePublished (ISO 8601 format with time)
- inLanguage

This is done automatically by unify when `schema: BlogPosting` is declared in frontmatter and the build includes `--base-url`.

### Feed for Feed Readers
An Atom feed is automatically generated at `/workshop/feed.xml` containing:
- All 4 posts (newest first)
- Each entry with title, author, published date/time, description, and absolute URL
- Proper Atom XML structure that feed readers can subscribe to

Verification: The feed includes entries from newest (August 20) to oldest (August 1), with complete metadata for each post including ISO 8601 timestamps, author names, and descriptions. The feed URLs are absolute (https://bellwick.example/workshop/...) as required.

### URLs
- All addresses use pretty URLs (directories with index.html, no .html extension visible)
- Example: `/workshop/news/sewing-workshop/` instead of `/workshop/news/sewing-workshop.html`
- This is achieved with the `--pretty-urls` flag

---

## Report on Authoring Experience

### 1. What did rules.md not answer? Name the sentence you wanted and could not find.

**Not found**: Clarification on whether `schema: Article` and `schema: BlogPosting` both generate Atom feeds, or only one. The rules state both are valid schema values, and that feed generation requires `--base-url`, but don't explicitly state if both trigger feed inclusion or if BlogPosting is the right choice for a news section.

I chose `BlogPosting` based on context (news/articles), but this choice was inferred rather than explicitly documented.

### 2. What did you have to re-read, and why did it not land the first time?

**Re-read**: The path resolution section. Initial confusion: I wrote `/workshop/visit.html` in links thinking the `--base-url` was only for og: tags, not for rewriting internal href attributes. 

The sentence that didn't land: "unify never scopes, rewrites, or injects CSS/JS, and rewrites only HTML's own URL attributes (`href`, `src`) — a `url()` in CSS and a `fetch()`/`hx-get` address ship as written, so a root-relative one misses the `--base-url` prefix"

This is a negation (unify rewrites href/src but NOT url() in CSS), and I initially misread it as unify not rewriting any URLs. Re-reading with focus on the dash-separated examples clarified that root-relative hrefs DO get the base-url prefix.

### 3. Was there anything you guessed at, or inferred rather than read?

**Yes, multiple things**:

1. **Feed entry order**: The rules don't state whether feed entries should be newest-first or oldest-first. I assumed newest-first (typical for news), and unify's behavior confirmed this was correct.

2. **JSON-LD field selection**: The rules state "Nothing else is added and nothing is guessed — a `date` unify cannot read as `2026-01-02` or `2026-01-02T09:30:00Z` is left out." I inferred from this that dates WITH times would be included, and guessed the format should be ISO 8601 with T and Z. This was confirmed during build.

3. **Post file naming**: The rules don't specify how to name Markdown post files. I inferred they should match the URL slug (e.g., `sewing-workshop.md` becomes `/news/sewing-workshop/`), following common conventions.

4. **og:image behavior**: Rules say og:image becomes an absolute URL when `--base-url` is used. I correctly inferred this means a root-relative `/sewing-card.svg` in a post's frontmatter becomes `https://bellwick.example/workshop/sewing-card.svg` in the HTML output.

5. **The layout system**: Rules show `_layout.html` is auto-applied. I inferred that a single layout in src/ applies to all pages in that directory and subdirectories unless overridden, and this behavior was confirmed.
