---
title: August Volunteer Schedule Announced
date: 2026-08-01T09:00:00Z
author: Michael Thompson
description: Join us this month for special repair workshops every Saturday morning, focusing on household appliance repairs and basic electronics troubleshooting.
og:image: /schedule-card.svg
schema: BlogPosting
---

# August Volunteer Schedule Announced

Mark your calendars! This August, the Bellwick Repair Collective is hosting a series of specialized repair workshops. Whether you're looking to learn new skills or share your expertise, we have something for everyone.

## August Workshop Schedule

**Every Saturday in August, 10:00 AM – 1:00 PM**

### Week 1 (August 3rd)
**Household Appliance Fundamentals**

Learn how common kitchen and laundry appliances work and how to troubleshoot basic problems. We'll cover refrigerators, washers, dryers, and dishwashers.

**Instructor**: Patricia Nguyen, appliance repair specialist

### Week 2 (August 10th)
**Small Electronics and Chargers**

Discover what's inside your phone chargers, laptop power supplies, and small electronic gadgets. Learn basic circuit diagnosis and component replacement.

**Instructor**: Alex Kim, electronics engineer

### Week 3 (August 17th)
**Basic Woodworking and Furniture Repair**

Join our furniture team for hands-on practice with joint reinforcement, wood filler techniques, and finishing methods. Bring a small piece you'd like to repair!

**Instructor**: Walter Thompson, master woodworker

### Week 4 (August 24th)
**Introduction to Power Tools**

A comprehensive introduction to workshop power tools: sander, drill press, and miter saw. Safety certification included.

**Instructor**: James Robertson, woodworking instructor

### Bonus: Saturday, August 31st
**Open Workshop Day**

No formal instruction—just volunteers working on projects. Perfect for practicing new skills or getting help with ongoing repairs.

## Registration

No advance registration required! Just show up during workshop hours. We ask that participants arrive by 10:15 AM to give instructors time for safety briefings and introductions.

## What to Bring

- Yourself (and your curiosity!)
- Comfortable work clothes
- Any tools you'd like to practice with
- A project if you have one in mind

## Questions?

Contact us at the workshop during regular hours or reach out through our community board. We're excited to see you there!

---

*August is the perfect time to learn new repair skills. Don't miss out!*
